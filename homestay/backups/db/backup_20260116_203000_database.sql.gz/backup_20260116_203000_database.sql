--
-- PostgreSQL database dump
--

\restrict 4MqH7W8QZToWYtb4FItdOtZzQzDrLh7dALnjjrcsRDqTgCA4zfTb20TOy1m7mxx

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: application_actions; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.application_actions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    officer_id character varying NOT NULL,
    action character varying(50) NOT NULL,
    previous_status character varying(50),
    new_status character varying(50),
    feedback text,
    issues_found jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.application_actions OWNER TO hptourism_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    action character varying(100) NOT NULL,
    details jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO hptourism_user;

--
-- Name: certificates; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.certificates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    certificate_number character varying(50) NOT NULL,
    certificate_type character varying(50) DEFAULT 'homestay_registration'::character varying,
    issued_date timestamp without time zone NOT NULL,
    valid_from timestamp without time zone NOT NULL,
    valid_upto timestamp without time zone NOT NULL,
    property_name character varying(255) NOT NULL,
    category character varying(20) NOT NULL,
    address text NOT NULL,
    district character varying(100) NOT NULL,
    owner_name character varying(255) NOT NULL,
    owner_mobile character varying(15) NOT NULL,
    certificate_pdf_url text,
    qr_code_data text,
    digital_signature text,
    issued_by character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    revocation_reason text,
    revoked_by character varying,
    revoked_date timestamp without time zone,
    renewal_reminder_sent boolean DEFAULT false,
    renewal_application_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.certificates OWNER TO hptourism_user;

--
-- Name: clarifications; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.clarifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    objection_id character varying NOT NULL,
    application_id character varying NOT NULL,
    submitted_by character varying NOT NULL,
    submitted_date timestamp without time zone NOT NULL,
    clarification_text text NOT NULL,
    supporting_documents jsonb,
    reviewed_by character varying,
    reviewed_date timestamp without time zone,
    review_status character varying(50),
    review_notes text,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.clarifications OWNER TO hptourism_user;

--
-- Name: ddo_codes; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.ddo_codes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    district character varying(100) NOT NULL,
    ddo_code character varying(20) NOT NULL,
    ddo_description text NOT NULL,
    treasury_code character varying(10) NOT NULL,
    head1 character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ddo_codes OWNER TO hptourism_user;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.documents (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    document_type character varying(100) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path text NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(100) NOT NULL,
    upload_date timestamp without time zone DEFAULT now(),
    ai_verification_status character varying(50),
    ai_confidence_score numeric(5,2),
    ai_notes text,
    is_verified boolean DEFAULT false,
    verification_status character varying(50) DEFAULT 'pending'::character varying,
    verified_by character varying,
    verification_date timestamp without time zone,
    verification_notes text
);


ALTER TABLE public.documents OWNER TO hptourism_user;

--
-- Name: grievance_audit_log; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.grievance_audit_log (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    grievance_id character varying NOT NULL,
    action character varying(50) NOT NULL,
    old_value text,
    new_value text,
    performed_by character varying NOT NULL,
    performed_at timestamp without time zone DEFAULT now(),
    ip_address character varying(50),
    user_agent text
);


ALTER TABLE public.grievance_audit_log OWNER TO hptourism_user;

--
-- Name: grievance_comments; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.grievance_comments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    grievance_id character varying NOT NULL,
    user_id character varying NOT NULL,
    comment text NOT NULL,
    is_internal boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.grievance_comments OWNER TO hptourism_user;

--
-- Name: grievances; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.grievances (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_number character varying(50) NOT NULL,
    ticket_type character varying(20) DEFAULT 'owner_grievance'::character varying,
    user_id character varying,
    application_id character varying,
    category character varying(50) NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying,
    status character varying(20) DEFAULT 'open'::character varying,
    subject character varying(255) NOT NULL,
    description text NOT NULL,
    assigned_to character varying,
    resolution_notes text,
    attachments jsonb,
    last_comment_at timestamp without time zone,
    last_read_by_owner timestamp without time zone,
    last_read_by_officer timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone
);


ALTER TABLE public.grievances OWNER TO hptourism_user;

--
-- Name: himkosh_transactions; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.himkosh_transactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    dept_ref_no character varying(45) NOT NULL,
    app_ref_no character varying(20) NOT NULL,
    total_amount integer NOT NULL,
    tender_by character varying(70) NOT NULL,
    merchant_code character varying(15),
    dept_id character varying(10),
    service_code character varying(5),
    ddo character varying(12),
    head1 character varying(14),
    amount1 integer,
    head2 character varying(14),
    amount2 integer,
    head3 character varying(14),
    amount3 integer,
    head4 character varying(14),
    amount4 integer,
    head10 character varying(50),
    amount10 integer,
    period_from character varying(10),
    period_to character varying(10),
    encrypted_request text,
    request_checksum character varying(32),
    ech_txn_id character varying(10),
    bank_cin character varying(20),
    bank_name character varying(10),
    payment_date character varying(14),
    status character varying(70),
    status_cd character varying(1),
    response_checksum character varying(32),
    is_double_verified boolean DEFAULT false,
    double_verification_date timestamp without time zone,
    double_verification_data jsonb,
    challan_print_url text,
    portal_base_url text,
    transaction_status character varying(50) DEFAULT 'initiated'::character varying,
    initiated_at timestamp without time zone DEFAULT now(),
    responded_at timestamp without time zone,
    verified_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    is_archived boolean DEFAULT false
);


ALTER TABLE public.himkosh_transactions OWNER TO hptourism_user;

--
-- Name: homestay_applications; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.homestay_applications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    application_number character varying(50) NOT NULL,
    application_kind character varying(30) DEFAULT 'new_registration'::character varying NOT NULL,
    parent_application_id character varying,
    parent_application_number character varying(50),
    parent_certificate_number character varying(50),
    inherited_certificate_valid_upto timestamp without time zone,
    service_context jsonb,
    service_notes text,
    service_requested_at timestamp without time zone,
    application_type character varying(50) DEFAULT 'homestay'::character varying,
    water_sports_data jsonb,
    adventure_sports_data jsonb,
    property_name character varying(255) NOT NULL,
    category character varying(20) NOT NULL,
    location_type character varying(10) NOT NULL,
    total_rooms integer NOT NULL,
    district character varying(100) NOT NULL,
    district_other character varying(100),
    tehsil character varying(100) NOT NULL,
    tehsil_other character varying(100),
    block character varying(100),
    block_other character varying(100),
    gram_panchayat character varying(100),
    gram_panchayat_other character varying(100),
    urban_body character varying(200),
    urban_body_other character varying(200),
    ward character varying(50),
    address text NOT NULL,
    pincode character varying(10) NOT NULL,
    telephone character varying(20),
    fax character varying(20),
    latitude numeric(10,8),
    longitude numeric(11,8),
    owner_name character varying(255) NOT NULL,
    owner_gender character varying(10) NOT NULL,
    owner_mobile character varying(15) NOT NULL,
    owner_email character varying(255),
    guardian_name character varying(255),
    owner_aadhaar character varying(12) NOT NULL,
    guardian_relation character varying(20) DEFAULT 'father'::character varying,
    property_ownership character varying(10) DEFAULT 'owned'::character varying NOT NULL,
    proposed_room_rate numeric(10,2),
    project_type character varying(20) NOT NULL,
    property_area numeric(10,2) NOT NULL,
    property_area_unit character varying(10) DEFAULT 'sqm'::character varying,
    single_bed_rooms integer DEFAULT 0,
    single_bed_beds integer DEFAULT 1,
    single_bed_room_size numeric(10,2),
    single_bed_room_rate numeric(10,2),
    double_bed_rooms integer DEFAULT 0,
    double_bed_beds integer DEFAULT 2,
    double_bed_room_size numeric(10,2),
    double_bed_room_rate numeric(10,2),
    family_suites integer DEFAULT 0,
    family_suite_beds integer DEFAULT 4,
    family_suite_size numeric(10,2),
    family_suite_rate numeric(10,2),
    attached_washrooms integer NOT NULL,
    gstin character varying(15),
    selected_category character varying(20),
    average_room_rate numeric(10,2),
    highest_room_rate numeric(10,2),
    lowest_room_rate numeric(10,2),
    certificate_validity_years integer DEFAULT 1,
    is_pangi_sub_division boolean DEFAULT false,
    distance_airport numeric(10,2),
    distance_railway numeric(10,2),
    distance_city_center numeric(10,2),
    distance_shopping numeric(10,2),
    distance_bus_stand numeric(10,2),
    key_location_highlight1 text,
    key_location_highlight2 text,
    lobby_area numeric(10,2),
    dining_area numeric(10,2),
    parking_area text,
    eco_friendly_facilities text,
    differently_abled_facilities text,
    fire_equipment_details text,
    nearest_hospital character varying(255),
    amenities jsonb,
    nearby_attractions jsonb,
    mandatory_checklist jsonb,
    desirable_checklist jsonb,
    rooms jsonb,
    base_fee numeric(10,2),
    total_before_discounts numeric(10,2),
    validity_discount numeric(10,2) DEFAULT '0'::numeric,
    female_owner_discount numeric(10,2) DEFAULT '0'::numeric,
    pangi_discount numeric(10,2) DEFAULT '0'::numeric,
    total_discount numeric(10,2) DEFAULT '0'::numeric,
    total_fee numeric(10,2),
    per_room_fee numeric(10,2),
    gst_amount numeric(10,2),
    status character varying(50) DEFAULT 'draft'::character varying,
    current_stage character varying(50),
    current_page integer DEFAULT 1,
    district_officer_id character varying,
    district_review_date timestamp without time zone,
    district_notes text,
    da_id character varying,
    da_review_date timestamp without time zone,
    da_forwarded_date timestamp without time zone,
    da_remarks text,
    state_officer_id character varying,
    state_review_date timestamp without time zone,
    state_notes text,
    dtdo_id character varying,
    dtdo_review_date timestamp without time zone,
    correction_submission_count integer DEFAULT 0 NOT NULL,
    revert_count integer DEFAULT 0 NOT NULL,
    dtdo_remarks text,
    rejection_reason text,
    clarification_requested text,
    site_inspection_scheduled_date timestamp without time zone,
    site_inspection_completed_date timestamp without time zone,
    site_inspection_officer_id character varying,
    site_inspection_notes text,
    site_inspection_outcome character varying(50),
    site_inspection_findings jsonb,
    ownership_proof_url text,
    aadhaar_card_url text,
    pan_card_url text,
    gst_certificate_url text,
    fire_safety_noc_url text,
    pollution_clearance_url text,
    building_plan_url text,
    property_photos_urls jsonb,
    documents jsonb,
    certificate_number character varying(50),
    certificate_issued_date timestamp without time zone,
    certificate_expiry_date timestamp without time zone,
    payment_status character varying(20) DEFAULT 'pending'::character varying,
    payment_id character varying(100),
    payment_amount numeric(10,2),
    payment_date timestamp without time zone,
    refund_date timestamp without time zone,
    refund_reason text,
    submitted_at timestamp without time zone,
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    form_completion_time_seconds integer
);


ALTER TABLE public.homestay_applications OWNER TO hptourism_user;

--
-- Name: inspection_orders; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.inspection_orders (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    scheduled_by character varying NOT NULL,
    scheduled_date timestamp without time zone NOT NULL,
    assigned_to character varying NOT NULL,
    assigned_date timestamp without time zone NOT NULL,
    inspection_date timestamp without time zone NOT NULL,
    inspection_address text NOT NULL,
    special_instructions text,
    status character varying(50) DEFAULT 'scheduled'::character varying,
    dtdo_notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.inspection_orders OWNER TO hptourism_user;

--
-- Name: inspection_reports; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.inspection_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    inspection_order_id character varying NOT NULL,
    application_id character varying NOT NULL,
    submitted_by character varying NOT NULL,
    submitted_date timestamp without time zone NOT NULL,
    actual_inspection_date timestamp without time zone NOT NULL,
    room_count_verified boolean NOT NULL,
    actual_room_count integer,
    category_meets_standards boolean NOT NULL,
    recommended_category character varying(20),
    mandatory_checklist jsonb,
    mandatory_remarks text,
    desirable_checklist jsonb,
    desirable_remarks text,
    amenities_verified jsonb,
    amenities_issues text,
    fire_safety_compliant boolean,
    fire_safety_issues text,
    structural_safety boolean,
    structural_issues text,
    overall_satisfactory boolean NOT NULL,
    recommendation character varying(50) NOT NULL,
    detailed_findings text NOT NULL,
    inspection_photos jsonb,
    report_document_url text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.inspection_reports OWNER TO hptourism_user;

--
-- Name: lgd_blocks; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_blocks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    block_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    tehsil_id character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_blocks OWNER TO hptourism_user;

--
-- Name: lgd_districts; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_districts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    district_name character varying(100) NOT NULL,
    division_name character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_districts OWNER TO hptourism_user;

--
-- Name: lgd_gram_panchayats; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_gram_panchayats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    gram_panchayat_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    block_id character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_gram_panchayats OWNER TO hptourism_user;

--
-- Name: lgd_tehsils; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_tehsils (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    tehsil_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    tehsil_type character varying(50) DEFAULT 'tehsil'::character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_tehsils OWNER TO hptourism_user;

--
-- Name: lgd_urban_bodies; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_urban_bodies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    urban_body_name character varying(200) NOT NULL,
    district_id character varying NOT NULL,
    body_type character varying(50) NOT NULL,
    number_of_wards integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_urban_bodies OWNER TO hptourism_user;

--
-- Name: login_otp_challenges; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.login_otp_challenges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    otp_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.login_otp_challenges OWNER TO hptourism_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.notifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    application_id character varying,
    type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    channels jsonb,
    is_read boolean DEFAULT false,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO hptourism_user;

--
-- Name: objections; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.objections (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    inspection_report_id character varying,
    raised_by character varying NOT NULL,
    raised_date timestamp without time zone NOT NULL,
    objection_type character varying(50) NOT NULL,
    objection_title character varying(255) NOT NULL,
    objection_description text NOT NULL,
    severity character varying(20) NOT NULL,
    response_deadline timestamp without time zone,
    status character varying(50) DEFAULT 'pending'::character varying,
    resolution_notes text,
    resolved_by character varying,
    resolved_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.objections OWNER TO hptourism_user;

--
-- Name: password_reset_challenges; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.password_reset_challenges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    channel character varying(32) NOT NULL,
    recipient character varying(255),
    otp_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.password_reset_challenges OWNER TO hptourism_user;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.payments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    payment_type character varying(50) NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_gateway character varying(50),
    gateway_transaction_id character varying(255),
    payment_method character varying(50),
    payment_status character varying(50) DEFAULT 'pending'::character varying,
    payment_link text,
    qr_code_url text,
    payment_link_expiry_date timestamp without time zone,
    initiated_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    receipt_number character varying(100),
    receipt_url text
);


ALTER TABLE public.payments OWNER TO hptourism_user;

--
-- Name: production_stats; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.production_stats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    total_applications integer NOT NULL,
    approved_applications integer NOT NULL,
    rejected_applications integer NOT NULL,
    pending_applications integer NOT NULL,
    scraped_at timestamp without time zone DEFAULT now(),
    source_url text
);


ALTER TABLE public.production_stats OWNER TO hptourism_user;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.reviews (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    user_id character varying NOT NULL,
    rating integer NOT NULL,
    review_text text,
    is_verified_stay boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.reviews OWNER TO hptourism_user;

--
-- Name: session; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO hptourism_user;

--
-- Name: storage_objects; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.storage_objects (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    object_key text NOT NULL,
    storage_provider character varying(20) DEFAULT 'local'::character varying NOT NULL,
    file_type character varying(100) NOT NULL,
    category character varying(100) DEFAULT 'general'::character varying,
    mime_type character varying(100) DEFAULT 'application/octet-stream'::character varying,
    size_bytes integer DEFAULT 0 NOT NULL,
    checksum_sha256 character varying(128),
    uploaded_by character varying,
    application_id character varying,
    document_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    last_accessed_at timestamp without time zone
);


ALTER TABLE public.storage_objects OWNER TO hptourism_user;

--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.support_tickets (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_number character varying(50) NOT NULL,
    applicant_id character varying NOT NULL,
    application_id character varying,
    service_type character varying(50) DEFAULT 'homestay'::character varying,
    category character varying(50) NOT NULL,
    subject character varying(255) NOT NULL,
    description text NOT NULL,
    status character varying(30) DEFAULT 'open'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    assigned_to character varying,
    assigned_at timestamp without time zone,
    escalated_from character varying,
    escalated_at timestamp without time zone,
    escalation_level integer DEFAULT 0,
    sla_deadline timestamp without time zone,
    sla_breach boolean DEFAULT false,
    resolved_at timestamp without time zone,
    resolved_by character varying,
    resolution_notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.support_tickets OWNER TO hptourism_user;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.system_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value jsonb NOT NULL,
    description text,
    category character varying(50) DEFAULT 'general'::character varying,
    updated_by character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.system_settings OWNER TO hptourism_user;

--
-- Name: ticket_actions; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.ticket_actions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_id character varying NOT NULL,
    actor_id character varying,
    actor_role character varying(30),
    action character varying(50) NOT NULL,
    previous_status character varying(30),
    new_status character varying(30),
    previous_priority character varying(20),
    new_priority character varying(20),
    previous_assignee character varying,
    new_assignee character varying,
    notes text,
    metadata jsonb,
    ip_address character varying(45),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ticket_actions OWNER TO hptourism_user;

--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.ticket_messages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_id character varying NOT NULL,
    sender_id character varying NOT NULL,
    sender_role character varying(30) NOT NULL,
    message text NOT NULL,
    attachments jsonb,
    is_internal boolean DEFAULT false,
    is_read boolean DEFAULT false,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ticket_messages OWNER TO hptourism_user;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.user_profiles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    full_name character varying(255) NOT NULL,
    gender character varying(10) NOT NULL,
    aadhaar_number character varying(12),
    mobile character varying(15) NOT NULL,
    email character varying(255),
    district character varying(100),
    tehsil character varying(100),
    block character varying(100),
    gram_panchayat character varying(100),
    urban_body character varying(200),
    ward character varying(50),
    address text,
    pincode character varying(10),
    telephone character varying(20),
    fax character varying(20),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_profiles OWNER TO hptourism_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    mobile character varying(15) NOT NULL,
    full_name text NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    username character varying(50),
    email character varying(255),
    alternate_phone character varying(15),
    designation character varying(100),
    department character varying(100),
    employee_id character varying(50),
    office_address text,
    office_phone character varying(15),
    role character varying(50) DEFAULT 'property_owner'::character varying NOT NULL,
    aadhaar_number character varying(12),
    sso_id character varying(50),
    district character varying(100),
    password text,
    enabled_services jsonb DEFAULT '["homestay"]'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    signature_url text
);


ALTER TABLE public.users OWNER TO hptourism_user;

--
-- Data for Name: application_actions; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.application_actions (id, application_id, officer_id, action, previous_status, new_status, feedback, issues_found, created_at) FROM stdin;
ad39d316-32ad-4662-978e-2310d102a595	7e2c9070-be02-44d1-9172-d58edc1fe8eb	7d21d934-5f84-4f86-a74f-082a8dac21e1	owner_submitted	draft	submitted	Existing application finalized and submitted.	\N	2026-01-15 09:45:25.765005
07a4971e-3cc6-4f66-9353-f55e56143f28	cf464eb0-cf46-4a7f-92c4-66dcca32e4c0	4c411a33-6024-4f42-990b-08cbb9ec9a7c	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A26A247041). Application submitted.	\N	2026-01-15 10:27:13.751799
71f1565c-01c9-41e1-8367-0df5945a153a	f9e654ae-c40e-4101-a807-be2ca0d6b248	4bedfed3-5ed5-4f1f-9d26-cd9f6712c840	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A26A248960). Application submitted.	\N	2026-01-15 12:24:31.48471
40ec5052-9bba-4493-93f6-c61b2ba3bf22	6994f862-11e6-4224-af91-16d62212a082	7b737110-8680-4dbb-985c-98e71dc2c305	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 12:55:23.167708
bcdf84d3-922a-44df-99ca-5faa0b245b46	33ad1b9a-6ec5-4dd2-adcf-7a223567f41d	5f094d1f-2296-4502-9af4-d5aa25fff8be	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 12:57:07.832761
a0fa7a21-889c-4c6e-904b-dda31acac58c	33ad1b9a-6ec5-4dd2-adcf-7a223567f41d	1a8bab46-2d4c-4694-9009-12d50f644ec8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 12:57:07.949603
9a30b238-e107-4ed6-a873-6b834b24749c	f1ac720c-b358-4ce6-afdd-941e60691539	dc1c4494-a656-4f6a-be89-9c97b3b0f1d2	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 12:57:08.086775
75f96cf7-9530-4d9b-b193-a89719d6f024	f1ac720c-b358-4ce6-afdd-941e60691539	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 12:57:08.188141
af29b656-2822-496b-9bb2-a7b112e5ec57	22f9aa2f-93a0-4781-a16f-ff669534503e	c8e2e777-b34d-4b39-aca8-bd5050838408	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 12:57:08.311238
18dd73fc-de6d-4004-8b19-86f2c6fd7386	22f9aa2f-93a0-4781-a16f-ff669534503e	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 12:57:08.412851
e3d0ae9f-efd7-41af-8d63-410cbcc498b2	b1670254-995e-427c-b9db-179891609a62	c55eb023-85e0-4630-a965-2a8817e116f4	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:06:32.480916
7a8d95ce-f164-430f-91c8-c7540152bc58	b1670254-995e-427c-b9db-179891609a62	1a8bab46-2d4c-4694-9009-12d50f644ec8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:06:32.597756
11ddebbb-5114-4001-8cf5-6e79dacb0526	091839f8-e069-43c0-858b-b58c9274a447	c955fc27-7311-47e9-85da-c2e942c90035	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:06:32.737986
36a0974c-429b-4f09-8651-75614505b584	091839f8-e069-43c0-858b-b58c9274a447	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:06:32.854531
94e25582-0e50-48f9-81b5-9eb104011012	ba61eaff-8da6-4471-8361-670e72a184d8	a136d932-ae92-4bd9-8768-9e5914d08aa2	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:06:32.983085
2b5e52d6-3018-4e70-8dfa-2bd3f1c2c4fe	ba61eaff-8da6-4471-8361-670e72a184d8	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:06:33.085293
a88ab169-f2db-4b79-90d5-8f6ce82af4b8	bf49b055-a8dc-4e73-8119-576904d0e78b	8dd8642b-a59e-4beb-8866-cda32cbae6d3	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:11:32.542953
646961f9-f1f8-42b5-8ac9-9914dc6dd7df	bf49b055-a8dc-4e73-8119-576904d0e78b	1a8bab46-2d4c-4694-9009-12d50f644ec8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:11:32.661287
46436f76-a272-4d71-8370-974e2f80cad0	bf49b055-a8dc-4e73-8119-576904d0e78b	1a8bab46-2d4c-4694-9009-12d50f644ec8	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:11:32.725575
f0a659d1-a350-41ab-ae90-cdd41d308036	fb333b9e-39c1-44f6-bfca-04bb4cea0f31	4b1bf0bc-2d4c-4940-929e-3b5085a3838f	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:11:32.849341
c2e10327-2fc8-4706-94fb-5b215afd5ecd	fb333b9e-39c1-44f6-bfca-04bb4cea0f31	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:11:32.961282
a8554a43-82b1-4bbd-88d8-519850dbc05d	fb333b9e-39c1-44f6-bfca-04bb4cea0f31	5da8ac27-6650-4982-b51a-a7e7c5257075	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:11:33.011509
90ddee3b-784d-4a49-86a7-dd18d303fc56	223be33d-e90b-41d9-9e95-8061986be739	34b3e809-9941-4aa4-8176-da9aab2d0b81	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:11:33.139661
58705305-6d65-4c1b-be12-6279c4744848	223be33d-e90b-41d9-9e95-8061986be739	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:11:33.253079
e89dbfdf-3e6e-4110-a999-db322c8dfeea	223be33d-e90b-41d9-9e95-8061986be739	6affed07-7898-4fc9-b86d-af1d610ad3ea	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:11:33.310957
88d3519c-1466-479e-8de4-ca1295d45189	d85406fa-5e1b-4623-bc29-bd6b80024dd3	23e4fa53-d9bd-4b6c-a958-3e92e74bdf90	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:16:13.528186
82d9bed0-fa5b-4823-ae76-9a0e46859281	d85406fa-5e1b-4623-bc29-bd6b80024dd3	1a8bab46-2d4c-4694-9009-12d50f644ec8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:16:13.654821
0f835e14-8866-46c4-b39d-8a88d979d080	d85406fa-5e1b-4623-bc29-bd6b80024dd3	1a8bab46-2d4c-4694-9009-12d50f644ec8	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:16:13.71044
d1414697-1cb2-4af8-b645-415c7560aa77	4a1b03ae-01cc-44cd-b513-fa1e45766342	8bee7c4a-9bd2-4231-b035-f00616fc3af5	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:16:13.875774
bd51dc26-000b-4724-920c-35716ae54d8d	4a1b03ae-01cc-44cd-b513-fa1e45766342	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:16:14.015006
21113236-4ec5-4185-80d0-a7a68b280186	4a1b03ae-01cc-44cd-b513-fa1e45766342	5da8ac27-6650-4982-b51a-a7e7c5257075	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:16:14.069784
4857c630-fb52-47c6-bdd7-3d2935e52fc6	b2860363-180a-40e7-a835-7b7d55e53bf7	aa54f8a2-a077-4615-8679-1fa61d85f04a	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:16:14.207815
ca2f17fb-abba-44f6-b7a0-d230bf56082a	b2860363-180a-40e7-a835-7b7d55e53bf7	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:16:14.324455
65b032a9-e2b2-4d18-8905-6ce05e6723e5	b2860363-180a-40e7-a835-7b7d55e53bf7	6affed07-7898-4fc9-b86d-af1d610ad3ea	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:16:14.379601
9c58c8b8-12f9-4bb5-8f65-858828ba1236	e2b3164d-c007-43a9-a34f-626ff9b23ac3	76cfb0b9-31ce-42c9-bef3-f7078c4b61c0	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:16:14.501417
ebe2b403-9675-4db9-b097-ad25cd0847b8	6b3e202c-2e16-4702-936d-c73d7f0e6b0d	05f9dca8-9c18-45e9-9ce0-ee719e04dfea	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:17:39.70839
d85b3a53-c2ec-4032-ad65-8843d3fd72a8	6b3e202c-2e16-4702-936d-c73d7f0e6b0d	1a8bab46-2d4c-4694-9009-12d50f644ec8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:17:39.841459
c9e3ca5d-3093-4dab-a927-72003922dc3d	6b3e202c-2e16-4702-936d-c73d7f0e6b0d	1a8bab46-2d4c-4694-9009-12d50f644ec8	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:17:39.90832
cdf24964-3558-4b68-b3be-c07ef0811700	4ec594a0-8db8-48f7-98e9-067d70a2512a	528925ca-1b15-4382-9655-bfd346b76382	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:17:40.058519
b497e0b2-7986-408a-ade6-18b17fb78c1b	4ec594a0-8db8-48f7-98e9-067d70a2512a	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:17:40.187886
dcb86af1-48ec-4e93-a102-d69b84c2687f	4ec594a0-8db8-48f7-98e9-067d70a2512a	5da8ac27-6650-4982-b51a-a7e7c5257075	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:17:40.253922
c5f79a45-41aa-4f9b-bf71-ab255a7062e0	44c93e5e-8fcf-4012-92a7-7c12778a7dd5	6f5b6051-150d-42b7-b535-ca36bd42d34d	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:17:40.396603
4afc99fc-948c-4d3a-9154-f4e6008ca976	44c93e5e-8fcf-4012-92a7-7c12778a7dd5	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:17:40.515179
364d9eaa-8b11-4875-8d09-922e360985d1	44c93e5e-8fcf-4012-92a7-7c12778a7dd5	6affed07-7898-4fc9-b86d-af1d610ad3ea	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:17:40.582762
9a7ee425-51fe-4452-8af4-0839086006db	6852443d-8432-46ff-b332-eef72e339f42	3bb35af3-b2a5-4c2c-93f8-898c9df99693	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:17:40.721359
a34495fc-d090-4bfc-bcb8-2eb36ac6687f	6852443d-8432-46ff-b332-eef72e339f42	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:17:40.840581
d306a7dd-b46f-4637-af57-4e9d52d94959	6852443d-8432-46ff-b332-eef72e339f42	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:17:40.894208
58504b45-d9d6-489d-a257-57100be60d77	1f78fd55-b3ed-4387-b6bd-29b67e9915e1	7a0223d0-1224-4ea4-90ea-436cec619d8c	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:36:30.999508
7f5b6fbb-9aee-47a6-9acd-16a31e70bd80	1f78fd55-b3ed-4387-b6bd-29b67e9915e1	1a8bab46-2d4c-4694-9009-12d50f644ec8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:36:31.111996
c3b8cc8f-acfd-41f8-8fb5-96c08e37bc7f	1f78fd55-b3ed-4387-b6bd-29b67e9915e1	1a8bab46-2d4c-4694-9009-12d50f644ec8	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:36:31.159175
12a37040-bd04-416b-97aa-a708be4d044d	978ab8eb-e9cf-4d0c-82eb-e4ddeb3b65fc	0806dfb8-3002-485c-9a0e-a44d4be4d39b	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:36:31.276462
67c50349-e908-4e7d-90ea-0bb0211d567c	978ab8eb-e9cf-4d0c-82eb-e4ddeb3b65fc	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:36:31.381074
6062c8f1-08fe-43c3-b84d-a56368f43dbe	978ab8eb-e9cf-4d0c-82eb-e4ddeb3b65fc	5da8ac27-6650-4982-b51a-a7e7c5257075	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:36:31.422315
f4dfa1de-a0b1-476d-af44-5b3a657dad13	528e0eb5-e4c8-44dd-9fb6-cc3cc22f95a3	ed4db028-54eb-40ff-a3df-0e2507ef4ffd	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:36:31.536942
b38dcd07-64ce-4b90-b2e4-764bd56e4818	528e0eb5-e4c8-44dd-9fb6-cc3cc22f95a3	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:36:31.641437
4ad7d9e5-7d1a-4488-b931-632ac4318244	528e0eb5-e4c8-44dd-9fb6-cc3cc22f95a3	6affed07-7898-4fc9-b86d-af1d610ad3ea	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:36:31.678523
a0f6fcda-427a-49ce-9af3-f9a3c5b6d1dc	2f116765-df0d-4af2-ba3c-3955435110e5	dd94c7c5-ed80-428a-bc72-2e7c201e93c9	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:36:31.789306
b719fb6e-693d-4a47-b92a-4c4c90671d88	2f116765-df0d-4af2-ba3c-3955435110e5	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:36:31.891561
8c6b054e-42a8-4095-8044-ebfe15272d24	2f116765-df0d-4af2-ba3c-3955435110e5	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:36:31.933858
2ff70ca8-5b4f-45dd-8fef-ae6d2f00c565	8cc1f486-cd19-4135-82dd-00ddfa745838	ac827d2f-dd4a-460d-be2f-23ebad1fa102	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:36:32.051273
aa08d4f4-2784-44db-9769-04de38e092c6	8cc1f486-cd19-4135-82dd-00ddfa745838	efde4df9-1dcf-4d85-a9d3-151d17c8011d	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:36:32.153911
9c2afcd0-6407-42c3-8199-6a45b70288be	8cc1f486-cd19-4135-82dd-00ddfa745838	efde4df9-1dcf-4d85-a9d3-151d17c8011d	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:36:32.193215
68218f32-1084-4722-960a-9a50b4605756	94ade75a-5c5d-4e85-921f-fc60c0d500f8	c1521403-a2e5-4ef6-bdd0-1acb3cbc11c8	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:36:32.311784
19126b34-b5bd-4e3a-b31b-0df39e5e478f	94ade75a-5c5d-4e85-921f-fc60c0d500f8	b7987533-e127-4cad-8233-de0fdde7bbc7	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:36:32.418685
a0ba2ae4-ceae-461d-8139-641a4390d32b	94ade75a-5c5d-4e85-921f-fc60c0d500f8	b7987533-e127-4cad-8233-de0fdde7bbc7	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:36:32.468143
2973f68b-4a97-4332-942f-e75c8c5a202f	ce4b01d0-eed3-4f8b-8395-64a0ad54af68	89aad505-2170-453d-a0f6-94ac7c0e6d50	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:36:32.584299
fdd7b782-4082-4a92-988f-5442c798f7d2	ce4b01d0-eed3-4f8b-8395-64a0ad54af68	6d27a721-acb4-4dab-95d9-0b2c91645234	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:36:32.681054
66e4f7da-85fc-46cc-9126-4e6755499042	ce4b01d0-eed3-4f8b-8395-64a0ad54af68	6d27a721-acb4-4dab-95d9-0b2c91645234	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:36:32.719704
0c0cc46f-f91f-4754-9f30-4a098576d077	1d3bb4e4-41d6-42a9-b2ec-7a9f6520b2e4	be7d6c59-eea4-43cf-852c-f29c6e7e79ce	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:36:32.832753
0e65b675-abe5-47ad-897c-95ed777901a8	1d3bb4e4-41d6-42a9-b2ec-7a9f6520b2e4	d244a912-8065-4604-9b58-ba9b69d93e11	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:36:32.929312
fb38c2b8-07b6-496d-9003-62bdb720dd51	1d3bb4e4-41d6-42a9-b2ec-7a9f6520b2e4	d244a912-8065-4604-9b58-ba9b69d93e11	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:36:32.971283
5ccd4098-8fa9-4b30-a632-082f02de9ae5	e96e5136-191e-447b-8a26-c80576f427f9	aa627e94-1265-4128-944e-7739565896f5	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:36:33.079011
7d0a2735-0596-46ad-b26c-4d16871e41cd	e96e5136-191e-447b-8a26-c80576f427f9	249b7155-1f20-404f-b377-b0202b66a8a8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:36:33.172013
ab850ef6-661b-4a02-8ae2-08058938f624	e96e5136-191e-447b-8a26-c80576f427f9	249b7155-1f20-404f-b377-b0202b66a8a8	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:36:33.206904
7cadcb63-901b-4405-b57f-dd6e389696df	13e2ea6b-8f7d-4b05-8eb6-3510b5ee1505	3236f840-b1f9-4bee-87ce-26b85288c1ba	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:36:33.323203
6b26121c-931e-4642-9394-1b38ab617d9c	13e2ea6b-8f7d-4b05-8eb6-3510b5ee1505	a9a95a58-c2be-4175-83ed-7352a709c3c8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:36:33.433906
67a8ddbb-0b44-4927-b10a-fb3bb4f2816d	13e2ea6b-8f7d-4b05-8eb6-3510b5ee1505	a9a95a58-c2be-4175-83ed-7352a709c3c8	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:36:33.470067
ac4fe219-1e23-4e78-b105-e56b6033bd70	9d91fed9-d0cb-4b51-8e0c-95c072cda015	c5ec7add-599c-406d-b813-ced3b9ea84a9	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:36:33.576186
db9e586e-0553-4998-94c0-83ddfe97dfb5	9d91fed9-d0cb-4b51-8e0c-95c072cda015	5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:36:33.673321
899e1b1c-e7ae-41e0-981a-4a8c4aee7120	9d91fed9-d0cb-4b51-8e0c-95c072cda015	5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:36:33.71111
046c299b-bc4f-426d-afc6-2c31a063c186	1973b255-2892-4668-920b-1808d3e74fab	d6e5a82f-6df3-4ced-965a-4c7f328f76e7	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 13:36:33.817917
8ef88201-3c9e-4bb8-a618-2f4641cfa4c3	1973b255-2892-4668-920b-1808d3e74fab	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 13:36:33.912826
1bed3909-4a46-4eaf-ae1f-680010b731ac	1973b255-2892-4668-920b-1808d3e74fab	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-15 13:36:33.953364
bf01ab2a-8a1d-446b-b1ff-bba10c2b9edb	fd8745f9-9ae8-4753-a6c6-c03fce59d63e	b101b85e-abcb-49fe-b3f0-2f447c9a9f55	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:46.670292
05303d15-f603-4115-b4d7-f22d4de8d031	78c90848-7e3a-4a38-a403-bc4052c0aa62	f200d4d5-d569-462c-88d9-1ea25fa7b766	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:46.671947
5ee3e8d1-065e-4ae7-8520-addf35a2508c	a3b9fb40-9e19-4eca-b335-d7d1319088b8	a96bef40-5b38-4b9c-befb-86092cdc5f7c	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:46.686353
df3ef4a5-b45b-4700-911e-24dba243479a	6f5093be-7c13-4c55-b6cb-c04d8c9196f2	e989b0ee-dd0c-4ce9-8af8-781e8ba02f8e	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:46.714089
891f6e8e-d6ff-49b3-9fa9-8863af0495a9	78c90848-7e3a-4a38-a403-bc4052c0aa62	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:46.81371
5f98589f-85f7-48f5-8976-55f9fb41634c	fd8745f9-9ae8-4753-a6c6-c03fce59d63e	d244a912-8065-4604-9b58-ba9b69d93e11	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:46.821221
f0ba9248-532d-4e97-a16a-d0ac63b13991	a3b9fb40-9e19-4eca-b335-d7d1319088b8	6d27a721-acb4-4dab-95d9-0b2c91645234	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:46.846144
03f9cf3c-9a29-489e-bbe0-37e562ad18a6	6f5093be-7c13-4c55-b6cb-c04d8c9196f2	b7987533-e127-4cad-8233-de0fdde7bbc7	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:46.87743
f07a1430-3875-4536-8f75-44803011efe6	ff6a8c27-5c03-44ed-8df4-a379f64741c8	f7b801fa-0ef5-43e9-95e0-409790271f9e	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:47.083968
07b29d7e-dfe4-40e3-b567-dd1f5bfc8df7	a9d8804e-6fcf-4908-a042-338ddfd39ead	4831861c-2c25-419b-a820-3a1ddf62a080	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:47.101215
ee9ef526-5329-4dd1-837d-785479a1a320	a77c0633-e08e-414d-a020-18c1bd3fad4b	9596014c-87b6-4e87-a28c-3c06c10ffba6	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:47.113991
cb814369-52a0-445f-a8d5-b4102959b4b7	8754593e-05c9-45bb-8c16-436221cca004	a594f4f7-fd9f-40d6-a7d7-aeb205f64b0f	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:47.120402
9baf600a-8680-4062-a730-6db3fe9e3054	19e407b8-9d6c-4399-953a-37cfe3c3dec6	e24a09ce-1013-4dbf-8cfa-b13d0fb5aaf9	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:47.176013
7b3d46e7-db6c-4325-a935-f928423f1a17	ff6a8c27-5c03-44ed-8df4-a379f64741c8	d244a912-8065-4604-9b58-ba9b69d93e11	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:47.230978
e97a359e-3f9d-4829-808e-3ede14123459	a9d8804e-6fcf-4908-a042-338ddfd39ead	5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:47.262031
5c3a89ae-a0df-4f28-8843-b397cdd1d005	a77c0633-e08e-414d-a020-18c1bd3fad4b	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:47.293905
e6400392-f918-40c5-92fb-744ba99d5071	8754593e-05c9-45bb-8c16-436221cca004	1a8bab46-2d4c-4694-9009-12d50f644ec8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:47.301145
479b1241-e465-4cee-bf60-ce565b07ffd7	19e407b8-9d6c-4399-953a-37cfe3c3dec6	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:47.342581
b401d844-fe0a-4c31-8252-c03a3baa59ed	4146533f-6433-493e-9f53-2c4bb5607a12	cbef38fc-8cce-4eb9-ab5b-39cbb2d28038	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:47.626161
914b32a1-73d7-46ae-83c3-e5adaa43601f	fd23b7ab-c41a-45c3-af4f-ff12570887b3	a7562a1d-5b77-4b23-944b-6c44b3b416d3	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:47.630963
84b55e80-ba51-438d-96fc-0d0f4990ae57	8e014860-05eb-4ed6-a369-69051ff56b36	b5b9fbf8-9ae8-4548-8299-83e455af8bfc	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:47.638234
18433adc-b013-4c73-a1f1-b48f8f1e1b13	e86e8da7-8104-4ab1-a6be-361005d53180	e9813c7e-af8e-4fd1-8115-8849cd2ac909	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:47.646272
b63edb7c-8f89-4a78-9939-5f30eaf962f7	fcaf36d1-972e-4822-8320-772cc152e09f	fdf23724-9ca5-47be-93cb-3cf5340f7166	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:47.654852
34c314e4-1147-4030-a94f-e7799c6e64e1	4146533f-6433-493e-9f53-2c4bb5607a12	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:47.769716
128ebdd8-f2b7-4119-8ce9-fdd97ec28114	fd23b7ab-c41a-45c3-af4f-ff12570887b3	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:47.792702
f10b10b5-f2a7-480c-ad22-b6d766537a1b	8e014860-05eb-4ed6-a369-69051ff56b36	1a8bab46-2d4c-4694-9009-12d50f644ec8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:47.793531
95546340-5add-4000-a69e-72981ce908e7	e86e8da7-8104-4ab1-a6be-361005d53180	6d27a721-acb4-4dab-95d9-0b2c91645234	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:47.816902
19d762d3-3cbc-4c19-bf24-969a1324dec9	fcaf36d1-972e-4822-8320-772cc152e09f	a9a95a58-c2be-4175-83ed-7352a709c3c8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:47.913814
494f5d01-a248-45ce-b1ac-54a3309cc1e8	9f46af13-a978-4176-be50-6bc3ac8f8fed	8f167a42-a2e0-4fcf-bbd1-0853e57d6046	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:48.10478
7050e666-ebe1-40dc-92c2-88479873993d	a3e21aab-0ba6-4cfa-b249-98988e76c168	fe41e63b-04bf-4051-9588-c673afb3fbe4	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:48.115734
f1a7d453-5e33-494e-9904-3fe8d747eeb8	43bd665e-3464-449a-9a9d-bd7af94538eb	0855fedb-bc57-44a6-80ea-6db0044f1f9c	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:48.127015
72f4f8f2-07a0-4cf8-bcbd-b323f9e56139	738c76d3-886b-40b5-8091-b01cf4ff7466	f0e9b06e-a4da-453b-807a-aed75923e521	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:48.13488
b5c650b8-b529-4bca-8a87-e1afd38573b6	78edd442-343a-4932-b425-b567e60970b4	323f9bcd-7a71-47ba-8546-219347c8c03a	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:48.212035
02491c67-abad-40ff-990e-6d7f35a83c11	a3e21aab-0ba6-4cfa-b249-98988e76c168	6d27a721-acb4-4dab-95d9-0b2c91645234	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:48.248769
b8f03143-162d-4562-911e-f7c24b0caf25	9f46af13-a978-4176-be50-6bc3ac8f8fed	efde4df9-1dcf-4d85-a9d3-151d17c8011d	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:48.266399
8b4d6def-6743-4e6b-990a-3c4e07100374	073fcd8a-f9c4-46f9-babe-511fd8f752e9	c379e771-2fb9-444d-af77-f7037f9f85db	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:48.991506
7b97fc77-f604-4eda-a2ac-4b5bd3204bed	dc63fd1f-85dc-4012-9bc4-48959bdd5170	7d7d96b1-2f68-433b-b9d3-72955888d279	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:49.434465
adccd177-6d37-4fc4-bcba-386d433bf4c4	5e63c91f-42b8-4f8e-811d-91baa4d7d67f	01a776c9-bf4d-44e1-9124-729c088ab3fe	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:49.876662
8949444d-660b-4077-83e6-da3439108be0	85fb2d9e-bbff-43ef-89cb-8195e84aea55	162158b1-c39a-48d0-a09c-1c1e12e83a9a	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:50.001089
36fe6c85-b393-4f6a-b6cf-2baf1b8e8c34	17c96178-51fc-4bd5-a0f2-08233a50be60	33d7ab6b-6701-4764-8185-63d89e2e6e34	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:50.316488
af3fa15e-55f6-465e-b1eb-fa48f5c5d8f7	de23380e-153e-4ff2-b270-a857f00d4a7d	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.503392
57e297f4-69fd-4b0a-8bf8-56a85a5c94d1	2250f86d-c678-45c0-a263-fca010810f27	a9a95a58-c2be-4175-83ed-7352a709c3c8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.879442
93d472c7-7c27-48a7-86bb-ecbdce38fc69	906e1a03-fdb6-4934-8706-b33b42d523bb	acf9c22d-3a81-4318-ba4a-79833503f9b5	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.142071
b6a06dff-a050-453c-b0f2-cc0d5b8dbd3a	868feb27-e66d-46b4-8a37-4c8916ee910f	d244a912-8065-4604-9b58-ba9b69d93e11	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:51.252838
a860dac3-42f9-47fb-b89d-c6fac95206e9	a2d13a0d-a5e5-4cc9-aed8-52b9e242f21c	efde4df9-1dcf-4d85-a9d3-151d17c8011d	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:51.314673
b76598c7-9cca-4d0e-b2d1-08e58991da2f	b2f51457-0fbf-423c-8e49-f799c759202f	5d7509e3-6170-4772-a091-c9d1bf9a1a3c	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.542986
a6a3fbe3-7d73-4051-8936-de0312391f63	738c76d3-886b-40b5-8091-b01cf4ff7466	efde4df9-1dcf-4d85-a9d3-151d17c8011d	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:48.309067
4a31296e-a74b-4789-952a-71790e98aea5	43bd665e-3464-449a-9a9d-bd7af94538eb	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:48.32761
699bb73c-2956-481a-b695-969233cadaa1	868a4752-fe41-4605-93ef-d4574e10f6f3	e4d444d9-e616-4f32-bf82-498726cf3969	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:48.56382
abc50da9-2d36-453f-af13-8a71a11ee913	12a716ff-1ea9-4e7b-9184-7d15100d77c0	efde4df9-1dcf-4d85-a9d3-151d17c8011d	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:48.724771
35cac793-e502-45b5-b6e1-0ef1fc60b22a	073fcd8a-f9c4-46f9-babe-511fd8f752e9	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:49.150424
8cc35649-25fb-45b4-bf6e-a7664e8436c2	dc63fd1f-85dc-4012-9bc4-48959bdd5170	a9a95a58-c2be-4175-83ed-7352a709c3c8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:49.587576
77b728c9-e46c-48f7-a107-6bab35b47492	6d6853e9-6154-47d3-a1e7-109676e3411d	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:49.641836
c046a293-02f2-475f-85ee-cbab589bb6cb	93167516-1a44-4ad4-9636-e9d908c63d97	d244a912-8065-4604-9b58-ba9b69d93e11	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.003419
930e89fd-0740-46da-919f-8627f4a5c495	fd4ab56b-3774-4213-81b4-8ae96852109c	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.085301
e7ddfd82-c018-4d94-9781-08144ee0e487	85fb2d9e-bbff-43ef-89cb-8195e84aea55	b7987533-e127-4cad-8233-de0fdde7bbc7	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.14129
68cc3520-3365-40bd-8ce2-3c395c1bb4e3	ddb38037-ea8d-4d1e-969a-38c7bf65ee18	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:51.769836
cc24fb62-7618-41ff-a424-29ced1b0970f	ef4aaed1-3e89-401c-b184-2cefd24958ec	ea7e35ec-cfcd-48c5-90e0-60c08b8dbd27	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.932041
a03fe46f-126d-4bb3-9811-51aa9f5a9f39	f876b83e-9983-4641-b332-15bb05c641aa	98a4acdd-e2f4-4a89-bd14-86ea24657d21	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.940213
4256c35f-b46f-444d-a832-98344a997ded	40c0c66e-e693-470e-a0fd-e77f71021748	0988d42a-c1dc-4132-a11e-a8525c317065	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.995457
8861ad34-525e-4623-9d8d-91780d9cdec3	ef4aaed1-3e89-401c-b184-2cefd24958ec	249b7155-1f20-404f-b377-b0202b66a8a8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.052683
084f5864-6eb9-4209-9d1f-d1ce4c8f7cdd	2dd5e603-37bb-4cb3-a92d-ea6c110a5700	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.565617
de7b2871-cf9d-49bc-ad3d-feae1128cd32	822f5c3d-d20c-44d9-b3bf-4eb5ac3531fd	8ca9bb48-9ed8-4319-9f78-c675ad31e10e	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:52.800037
2d44f1ac-55cd-4152-92d5-8f3b9160ca89	b01a0e08-306a-4f05-88e3-317ece2172a7	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.867133
f6f2ff88-c84e-4607-8520-99e3b2e71aaf	78edd442-343a-4932-b425-b567e60970b4	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:48.362382
c94f8540-e065-437d-aed2-16708f1b45d1	8386817a-6e4f-4742-9ec2-f0a42931a7d2	792561d8-b915-4eaf-8854-e1b46099495a	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:48.556697
1f8d2602-3972-4251-a26d-069bc1d96ddf	cf0ee44c-3899-4297-80b0-c6c45d1cbe61	e9a64da4-b83d-4fa6-bcf7-7ba7efc32036	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:48.568606
5f771549-596d-49d7-b46a-c3badc514ba8	cf0ee44c-3899-4297-80b0-c6c45d1cbe61	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:48.714691
ced40921-5961-4efc-bc79-3e339de42440	913053e3-3766-4556-8abf-d952e4158780	4f0d7650-cf3e-4ed4-8a80-64e002cc6056	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:48.967936
b89794ac-4eb3-4665-b086-fbce3b604b0d	420e6c2f-d9b3-4e69-956d-b4f3473d3259	11e60245-7268-4e93-9045-4d9ca1ea5b33	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:49.003874
e0dea02c-4a86-4e2b-8722-b3586b098f30	61f54434-eed3-4db6-9fc5-c08826ef91e3	8aefe55b-5e79-4a19-b105-eba4b6eba999	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:49.049948
9d7f1813-b2f7-4cf3-a09b-7a6a4dbb95cf	913053e3-3766-4556-8abf-d952e4158780	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:49.129145
62a0e9bc-28ae-4728-a172-f092d9036345	d8e6c412-3d42-43c6-824b-d2aa7aa76abd	249b7155-1f20-404f-b377-b0202b66a8a8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:49.197864
f9559591-3ff3-46a1-91d8-8e8158338a22	1817e02b-530f-4c0b-9eb8-70a7f0c79677	f48891fe-0336-457e-9407-bcb7486b3247	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:49.460836
c0ade10c-4f82-4849-90a6-602921874be4	1817e02b-530f-4c0b-9eb8-70a7f0c79677	b7987533-e127-4cad-8233-de0fdde7bbc7	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:49.639957
e3f082ac-8835-4e01-a16b-519a02d905f7	8057b346-f45a-465d-8ef3-99a2648073dd	e7f15b4a-2b41-4a07-bd16-f956fb01daa4	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:50.314517
c2ed5734-9bf5-438d-a730-a61ca824503f	2ea0bab9-6a75-4eed-8f17-4faf84c69734	f3941361-fb0b-4a28-b9a6-028fcd2e76f9	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:50.737101
de75a994-577e-4749-a2bb-49ec5325a217	2250f86d-c678-45c0-a263-fca010810f27	1fce905f-56b3-4cda-9c74-9d9f50d43e06	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:50.74652
fd94edf2-a873-4376-a296-7a966de91ab5	24f391de-3450-41c7-859b-6f8a5fa046df	d244a912-8065-4604-9b58-ba9b69d93e11	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.922631
aaa1e9f1-251f-4047-9d86-f642f6f2ff69	868feb27-e66d-46b4-8a37-4c8916ee910f	f625569e-44c7-4f5f-9e88-d1ebe5418f08	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.117386
e63d059c-40d7-43bd-af5b-d6997a81996f	b129be29-244b-4346-8773-9b368d9df5fd	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:51.364038
9dc978e9-1d05-4963-8a67-8b13d8fc85cf	9abf87b1-83bd-4d80-98fb-cecfc09311ef	fb07e036-4faa-4031-93a1-16f3cb827fa3	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.549903
aa74ea5d-c645-4836-a675-ca19fe565ccf	ddb38037-ea8d-4d1e-969a-38c7bf65ee18	696a388e-c768-415b-b189-ab933b68572e	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.620437
1947a393-ad5b-40f3-98fb-1b6cfcab91de	9abf87b1-83bd-4d80-98fb-cecfc09311ef	5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:51.702259
72a51ef1-6925-4589-baf0-896af8b1e796	b2f51457-0fbf-423c-8e49-f799c759202f	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:51.737515
575a9412-1a6a-461c-8c2c-6a2bd25bcf46	f876b83e-9983-4641-b332-15bb05c641aa	5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.073051
6ae325ce-f2a3-4c7e-8811-cbcaf331475e	902d09ea-7181-4451-9384-4ca426eb6ebd	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.109319
f6f5ecfe-7186-43cb-b25c-2961271607a2	0396737e-066a-4c33-a276-0fdb8ef74731	a2bec987-4d03-418b-804e-69b9720b5f27	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:52.73071
a7452dd3-34fd-4c29-ab9f-ff3a8ea773cb	0396737e-066a-4c33-a276-0fdb8ef74731	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.892942
5ec6bae1-7d64-4a33-a339-3095a83ac5e5	0fb0a6b7-646a-4786-b03e-c081fd6c5485	efde4df9-1dcf-4d85-a9d3-151d17c8011d	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:53.26915
c438a7e6-8469-4b08-aa82-5f383f4ee7df	30cc8c65-da6a-4ab7-8626-c0de9cb8bb6b	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:53.685837
6a30b939-b92b-4481-ba08-2d409919d88a	dd96428f-41e7-447e-850f-af86df448e0d	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:53.736725
46e451dd-6a70-4451-a767-6cc316e44d06	b65e1c81-9be9-4203-ba1f-57589ea3b14c	7f9fb533-90ca-4e92-bc5c-0c5282eca554	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:54.840027
66d5ff47-b7aa-4a73-bdc5-2f3a5e845b3e	b65e1c81-9be9-4203-ba1f-57589ea3b14c	6d27a721-acb4-4dab-95d9-0b2c91645234	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:54.9884
10f47cb8-f59e-418f-be47-7074c9bc8edb	74fca047-68f8-4c01-b2dc-c6559967c05e	efde4df9-1dcf-4d85-a9d3-151d17c8011d	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:55.064511
45ee5c7d-adb5-4689-ba60-4082a65f1811	12a716ff-1ea9-4e7b-9184-7d15100d77c0	43815dc3-4cb4-41ae-983b-4a1e7d5315fa	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:48.558262
f46bba65-1588-4a5f-99c1-934fb048e821	868a4752-fe41-4605-93ef-d4574e10f6f3	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:48.75988
347be1ae-490b-4382-8aa1-e916350c262d	61f54434-eed3-4db6-9fc5-c08826ef91e3	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:49.22415
c68c790f-197b-409c-889a-e0a197131102	0d622163-7e73-416b-b3c0-df5e97333038	e38a12af-59f4-4657-a6b7-f9444d0a131e	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:49.429405
72b50a1c-b2ff-4980-85a0-b8ae9a3cbcfc	6d6853e9-6154-47d3-a1e7-109676e3411d	406c81de-5940-4e75-b942-aa769dca8b40	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:49.451922
2b001db7-e655-4878-a1c3-d1258ff58846	e7cd27b0-045c-481f-9d50-d0f408f80a42	a1771b13-6785-41fe-987c-0a6cf789e278	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:49.502415
f54cefe2-2a42-4f23-9948-d10fd83a201d	0d622163-7e73-416b-b3c0-df5e97333038	249b7155-1f20-404f-b377-b0202b66a8a8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:49.569938
2e4cfdc6-a048-453a-8038-e5883734c072	93167516-1a44-4ad4-9636-e9d908c63d97	945e7edc-69fc-45ea-a032-1432eb37f579	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:49.863345
72ae5189-64e8-40f1-9e99-d5b57da40a12	fd4ab56b-3774-4213-81b4-8ae96852109c	a55511fc-f7db-4788-8015-4fc0b501856a	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:49.875409
780c2e08-6e0c-494c-9aad-df84eb3c068d	d6025bfb-4961-4da6-a0f0-8d8a5b889cf0	efde4df9-1dcf-4d85-a9d3-151d17c8011d	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.042918
742a586b-ffc1-49f8-89df-557114950119	5e63c91f-42b8-4f8e-811d-91baa4d7d67f	d244a912-8065-4604-9b58-ba9b69d93e11	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.063996
b48fbf6a-afc9-4bd9-936c-6d0ce643d8d9	6c67e88c-83e0-4252-a3d0-8ebf8ec57597	036933d3-d229-49b1-9bbe-25e92800ce81	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:48.633644
6e172cf7-4a64-4f4b-9cad-c6e68263dd64	8386817a-6e4f-4742-9ec2-f0a42931a7d2	a9a95a58-c2be-4175-83ed-7352a709c3c8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:48.688297
638a33c4-e1fc-4887-878d-627a3ddd0c52	6c67e88c-83e0-4252-a3d0-8ebf8ec57597	d244a912-8065-4604-9b58-ba9b69d93e11	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:48.785575
f8359d10-a6d0-4730-abdf-9815cc1766ff	d8e6c412-3d42-43c6-824b-d2aa7aa76abd	411c21e8-35c2-44a6-a02b-f356d5d0622c	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:48.996531
e6739438-43c6-4a6b-a9ee-359e415b5d73	420e6c2f-d9b3-4e69-956d-b4f3473d3259	1a8bab46-2d4c-4694-9009-12d50f644ec8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:49.160571
683674e4-bbd0-4b57-b4d9-856bdc265e93	e7cd27b0-045c-481f-9d50-d0f408f80a42	249b7155-1f20-404f-b377-b0202b66a8a8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:49.676213
8eb40c7b-c1ec-4889-a647-0bec1b9612d8	17c96178-51fc-4bd5-a0f2-08233a50be60	b7987533-e127-4cad-8233-de0fdde7bbc7	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.463569
664aaabd-d396-4450-9e50-838a1690742e	f8678397-122c-4899-b691-c01c3ec1d9db	249b7155-1f20-404f-b377-b0202b66a8a8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.546673
57aba526-2368-48c3-83ff-907b0c02872f	154c6651-7315-4711-8f79-0549a4b6c44f	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.893366
8543ab92-5a1b-4048-8694-15d06c64538b	f1f46c71-cd29-4e57-8806-95b6f6181204	6d27a721-acb4-4dab-95d9-0b2c91645234	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.962261
264efffb-6a03-4010-8bad-7408bd720d26	906e1a03-fdb6-4934-8706-b33b42d523bb	b7987533-e127-4cad-8233-de0fdde7bbc7	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:51.326034
bd81c8fe-af0f-4bad-bf32-acffc9fe7359	902d09ea-7181-4451-9384-4ca426eb6ebd	dd25cdb7-53f5-46c2-a8c4-d80ea9550e28	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.945539
ebb0193a-ea9e-4603-bf4b-a8c30f21bb5c	40c0c66e-e693-470e-a0fd-e77f71021748	efde4df9-1dcf-4d85-a9d3-151d17c8011d	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.127539
0b57ae40-8f07-4b7f-bb84-12c855eced11	1b85a8ec-ff6a-483a-b80a-484f6c349a74	ca4eeec9-baa2-4bec-a33e-7d3993a6b89e	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:52.315638
6c8d3720-507e-45c8-a13b-c4834dd48c32	05a9f9df-2c59-43c9-bc06-24d69571e90b	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.476408
14f04a63-dd71-4e80-945d-2af4a2a6fdd0	a934be0e-3011-4392-a09f-f3c064591647	6d94db75-af33-4cda-8497-ae8f76392493	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:52.728635
9f032589-1a16-49a5-b3db-f40f61245091	b06ed3c3-31bb-46f2-9f95-926c39343315	d6269133-c1b6-4ccb-96a7-071892d618ea	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.131166
92df58f3-0bca-47b1-bf82-ae41b07adfe0	aa7c3fa6-0ec5-45bf-88b2-5cade216be14	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:53.258863
344fca8f-98fa-4b5a-b474-f911303323ce	0b38f2cb-09da-41e1-ba7e-998cf76a190c	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:53.343599
0d168285-7319-4d54-82e8-d32153b00a5d	30cc8c65-da6a-4ab7-8626-c0de9cb8bb6b	05b04ffb-fc9c-4e98-86c3-9e458bb985e7	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.520067
0d9c151f-d523-44e8-ab92-198ce9e684ba	68f85f6d-d5f2-4d5f-b2ed-84f6ad1b6a30	b7987533-e127-4cad-8233-de0fdde7bbc7	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:54.073356
57dfd85d-add4-4daa-af57-bef8d7bae441	bebeb5de-4a9b-4bf0-9427-a44e9eb6eb63	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:54.108385
b0ea60f7-526c-4488-b5e0-f75f58e9c537	d7c474bb-1e52-468c-a9e0-a484e6afa984	249b7155-1f20-404f-b377-b0202b66a8a8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:54.49602
9652c14c-88ea-41a7-84b8-f8e73e64e1d0	31a40a95-e4f4-4e71-80ba-6e87224303d0	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:54.534163
6ef5e9f6-2654-43d2-bb4f-08dfbd3f7a88	5c5a1b8c-01ef-474b-afc5-d82b1ac8ed3c	690520d7-e491-43bd-a6f1-7fcf2369fa20	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:54.771876
935d1d36-5b0f-4f22-8e14-4ef47aa3ceb6	74fca047-68f8-4c01-b2dc-c6559967c05e	cd61ce90-cb6c-4b6a-91b6-8a150b368f3d	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:54.831223
bea8f4f6-a233-42c5-bd1e-625c259a980d	bedf8398-fb71-4285-bc17-f0ac181e9224	960466d6-6220-4429-bfa4-8c2659dcaae8	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:54.857737
6ce2112e-3287-4674-835a-74c3739d3e46	b9c9c4f6-51b3-40bc-983d-facff9fffa16	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:55.126977
bcb65f41-0db6-49ca-9954-86173e3e4cd0	d6025bfb-4961-4da6-a0f0-8d8a5b889cf0	046e9240-3b2f-4463-a9c9-d22a00815ec7	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:49.864533
42be1506-3c91-47be-90b1-1dc00b41c25e	de23380e-153e-4ff2-b270-a857f00d4a7d	e0e71fd9-a2cf-454e-a357-371aab801a02	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:50.312966
690cdc2d-2138-42ca-9f87-3fa73cd1b361	f8678397-122c-4899-b691-c01c3ec1d9db	6e8e1f43-15eb-42f6-a680-9e4c44192952	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:50.387386
7269824e-8254-4e6c-ad95-8165dadb633e	8057b346-f45a-465d-8ef3-99a2648073dd	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.499968
72f8dab2-d15d-4804-9399-32c92dd176a1	154c6651-7315-4711-8f79-0549a4b6c44f	8b7896de-7997-448c-bb8d-27e3c9731e85	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:50.73875
e704527e-d321-4ebc-8315-fe33ecc217dc	24f391de-3450-41c7-859b-6f8a5fa046df	673fe948-c92f-4b68-85c2-9a2d7dfea971	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:50.752106
978afc89-b522-41a2-b6a7-3aad42d2e43d	f1f46c71-cd29-4e57-8806-95b6f6181204	380b5741-582b-4f6f-b858-9ae53ea54a87	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:50.795784
0ae71310-6abb-4afa-a4d5-2dd19073c0a7	2ea0bab9-6a75-4eed-8f17-4faf84c69734	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:50.878767
a7db1de6-29c6-4ef1-8f03-d55c74e84ad6	a2d13a0d-a5e5-4cc9-aed8-52b9e242f21c	e10b5523-68cf-4bb5-b92a-e3aa1690e2df	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.125541
62ad356b-751b-4b7f-8ecc-84d403d2ce1c	98d6f7c4-6468-4a62-bd0f-c7a4885c460c	b125661e-cd86-46d8-a22d-8e5f2cc750fe	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.140892
f022a23a-2b45-4cdb-8f1b-2f1d77a1d687	b129be29-244b-4346-8773-9b368d9df5fd	edb09e03-c176-459e-a2b4-5cffa2089a6e	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.210545
fe0b2deb-e502-444a-977f-14976c51000c	98d6f7c4-6468-4a62-bd0f-c7a4885c460c	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:51.327187
da16820e-6ee4-439d-b79a-5eb50ea5733e	59151e7a-d851-4fca-b29d-5ab2cb876e00	e5bb23b9-51e4-450b-85c2-550162dc77d8	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.539894
41a4e32e-6dab-4532-a787-1b533a3edd17	29daf7b4-9b97-4d7e-a43a-ebf26d74688f	a2575f11-7e3f-48da-a03e-2b1f49b00e1d	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:51.555526
865cee19-fbf0-48fb-a363-7a4540e58608	59151e7a-d851-4fca-b29d-5ab2cb876e00	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:51.677885
a72a4f69-8317-42be-8e10-ffcb920e7671	29daf7b4-9b97-4d7e-a43a-ebf26d74688f	b7987533-e127-4cad-8233-de0fdde7bbc7	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:51.703573
1e25c53e-446a-4fc8-b576-b8bac5a62982	04d6b8c1-ddd0-411d-9ed2-4b862ea6d7cc	b68f1178-5ef8-4655-8f2c-bea5ab0497a0	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:52.3112
6f34f070-80e8-431d-af5a-a3e4dfa6f805	7138043d-72c0-47e2-828b-b182eb1feee9	efde4df9-1dcf-4d85-a9d3-151d17c8011d	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.539687
a8f61402-bbaa-4d88-ac5e-c050335e4cd5	b01a0e08-306a-4f05-88e3-317ece2172a7	3a57bd93-ec0a-498d-8002-791de5545758	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:52.736324
2938a7c9-8cc3-4f2e-a5ee-6f7caec4646e	a934be0e-3011-4392-a09f-f3c064591647	249b7155-1f20-404f-b377-b0202b66a8a8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.866076
e155675b-5ffd-4ba7-85a8-6901163641e4	2771b4ad-0e39-49e9-9e13-5df01e725eb1	c2803612-a34b-4ed7-a3fe-3295c2a91980	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.127628
ac950d21-8c3e-4c18-b922-d9b8642f642d	0fb0a6b7-646a-4786-b03e-c081fd6c5485	14070c77-4ce8-44ac-af61-e325b9938a53	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.133229
a6f67938-fc05-4d6c-bb22-f62035939fcf	2771b4ad-0e39-49e9-9e13-5df01e725eb1	1a8bab46-2d4c-4694-9009-12d50f644ec8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:53.285975
1014eda1-b284-4a9e-947e-e9b4c2072d27	d629068e-63a2-4a3b-884d-ba4755c68b64	d244a912-8065-4604-9b58-ba9b69d93e11	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:53.675501
787b6e82-54e3-415a-99f7-7736f5e3a0c2	bebeb5de-4a9b-4bf0-9427-a44e9eb6eb63	06dee0ec-a7be-4f88-a8be-261fee6102ff	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.958577
eae33b98-33e1-4a06-ae3d-426b06a822b2	f90e0391-c214-4e73-b1f0-ade4bca39867	621c5f05-bc0c-433e-b9c0-c18c8ccfe5b4	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:54.014424
f454f191-21f9-4ed1-b5f8-a3ee0e387e3f	f90e0391-c214-4e73-b1f0-ade4bca39867	efde4df9-1dcf-4d85-a9d3-151d17c8011d	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:54.157589
f092d5e8-4965-406a-8599-2eef7acefdcf	b9c9c4f6-51b3-40bc-983d-facff9fffa16	ed6bb431-4be2-4abe-968e-6f7f801c6244	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:54.963014
657b7e07-f1d8-454b-af48-5e4225a5c18d	5c5a1b8c-01ef-474b-afc5-d82b1ac8ed3c	d244a912-8065-4604-9b58-ba9b69d93e11	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:55.060241
3298ba33-79fa-4963-afc7-79d60040a55e	05a9f9df-2c59-43c9-bc06-24d69571e90b	46aaeedd-b2f4-4161-99b9-6f4c182877af	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:52.313598
b378f22c-3341-4e36-9b15-8636109ddb7c	7138043d-72c0-47e2-828b-b182eb1feee9	54eb4664-f445-4e24-ab4c-6978bef45607	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:52.321371
6b92d930-9dd5-4d0e-8ed5-7008aa74f60d	2dd5e603-37bb-4cb3-a92d-ea6c110a5700	95635d39-c9be-4c3d-8046-8462e3820449	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:52.378176
97d6d077-9c2b-45ba-950b-5f79a2ae5e30	1b85a8ec-ff6a-483a-b80a-484f6c349a74	249b7155-1f20-404f-b377-b0202b66a8a8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.477153
607c40bc-f022-4da9-9674-02ea04d5cef8	04d6b8c1-ddd0-411d-9ed2-4b862ea6d7cc	d244a912-8065-4604-9b58-ba9b69d93e11	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.515701
079838cb-bd3d-4d9a-841c-670816b5126e	69fe1a8a-0c0c-4f4e-91ae-58a0a2a99965	d7ef0c54-60e5-4dec-b649-8d9f1d351888	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:52.769999
aada8573-eecc-458f-bd58-e8b5b5b605b9	69fe1a8a-0c0c-4f4e-91ae-58a0a2a99965	6d27a721-acb4-4dab-95d9-0b2c91645234	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.93488
242c8349-56a4-405a-9453-b3f866316764	822f5c3d-d20c-44d9-b3bf-4eb5ac3531fd	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:52.953628
fd14d257-0537-478c-9e3c-e09195309539	aa7c3fa6-0ec5-45bf-88b2-5cade216be14	f46e48c4-b313-4733-bec4-89be2f78f354	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.129041
abccce5d-39c7-411c-8ab6-31c439ce3a0a	0b38f2cb-09da-41e1-ba7e-998cf76a190c	9a50c9f1-e9e6-4f51-9c12-56f66794b518	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.191947
c9e88b6d-c06e-40b2-ac70-1358b4fccaf7	b06ed3c3-31bb-46f2-9f95-926c39343315	5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:53.29386
3c89c732-82f7-4964-aa43-912ed218169c	cadeae01-c10d-475c-9b06-ad456d8b4fb7	c76fa3ef-24b5-4e46-af49-360b7d0f994e	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.522149
2cf8c438-1b86-40e2-aeac-b798cc86a576	d629068e-63a2-4a3b-884d-ba4755c68b64	3f250339-fb43-43c5-b1c1-24e8e213c14f	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.5286
7de1b9be-1228-4327-8053-6778b1aeeecb	34f8242b-d9da-4514-9539-921b0db96806	1f736bea-42e4-48e9-884c-3510847a36cd	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.534189
9092c486-856b-4c76-a37b-177b192be008	dd96428f-41e7-447e-850f-af86df448e0d	cdbf6366-ab5f-4456-b5d3-2e2dcd43f636	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.589435
f30ca053-5b2d-4b82-8861-b2de5b5ddac1	cadeae01-c10d-475c-9b06-ad456d8b4fb7	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:53.658336
ccbf51e1-82c2-4df0-abe1-7721fea5336b	34f8242b-d9da-4514-9539-921b0db96806	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:53.683852
d9dd0a52-ea83-4b6d-aae8-7c4887f16613	68f85f6d-d5f2-4d5f-b2ed-84f6ad1b6a30	9e29b6ad-8a1b-47c8-a281-8396f616fafd	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.926307
3d17c578-3632-4a0f-841c-e10087c5e930	c170386d-626d-4e41-b81c-84169466c306	ead1848c-e771-4e43-9a19-dd316eeb552b	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.937355
78a13655-812c-4d9d-a478-7775540e29b9	c4cd4f33-2cda-4e66-bc2f-c89fe58cd65a	b50d541a-07ba-4850-9bad-918f237557e4	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:53.9447
2157e781-e0dd-4a34-bb7c-0de2d4911fa1	c4cd4f33-2cda-4e66-bc2f-c89fe58cd65a	a9a95a58-c2be-4175-83ed-7352a709c3c8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:54.072305
4bff0c57-bc77-4ecf-be58-2539db31ba06	c170386d-626d-4e41-b81c-84169466c306	5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:54.104937
1c04de58-8b02-4b76-9fc0-65a4068d23f6	d8eff996-514c-42d2-a056-b24781a9c017	e2599a1f-f9c6-4131-955d-006e836ee65c	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:54.336802
627b834e-715a-4c02-9d2f-fa6ee6c3e3c0	198c49bb-a739-4a9c-bc16-ab331ba5376b	24ede4da-51f7-48bc-916e-41fb15f9e280	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:54.345606
27882331-249a-42d3-bc30-6be4eb1c57b4	d7c474bb-1e52-468c-a9e0-a484e6afa984	d264c61b-c283-4506-945d-64d6c9e272b1	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:54.350033
e1be3ab1-596b-4c0e-8656-2340dd497ef2	31a40a95-e4f4-4e71-80ba-6e87224303d0	01237f8a-902b-4b14-b04a-38508d41c894	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:54.360438
898ad419-8b2d-430a-9e96-880343dd842a	45d5a8a0-4c21-4642-9ae6-023ab6ae4b7a	e3d15330-af7c-47c4-848c-92a18df6bc0c	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-15 14:00:54.411095
b11d539b-d6d2-4a8b-b87b-26c103ca2053	198c49bb-a739-4a9c-bc16-ab331ba5376b	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:54.497444
82542523-6922-41d3-9ae2-3470e1ed1f61	d8eff996-514c-42d2-a056-b24781a9c017	a9a95a58-c2be-4175-83ed-7352a709c3c8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:54.509708
0b81ff6b-e3d1-497c-b312-679871ad7adb	45d5a8a0-4c21-4642-9ae6-023ab6ae4b7a	efde4df9-1dcf-4d85-a9d3-151d17c8011d	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:54.596173
43ab6253-e0f7-42ef-9afd-cdaa045b64e9	bedf8398-fb71-4285-bc17-f0ac181e9224	249b7155-1f20-404f-b377-b0202b66a8a8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-15 14:00:55.097908
0029d11f-973d-4289-82a4-d37e35b050f0	53f5b3ef-23c8-4888-829c-e6751056d0a5	2c95df7d-a843-44b0-b5ee-e9a3458650ce	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-16 05:31:50.091038
cbe35399-5df8-4f79-a1ee-156a841b34e8	53f5b3ef-23c8-4888-829c-e6751056d0a5	1a8bab46-2d4c-4694-9009-12d50f644ec8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-16 05:31:50.217104
8f665d0f-ed20-430b-adc1-bc21fb9553db	53f5b3ef-23c8-4888-829c-e6751056d0a5	1a8bab46-2d4c-4694-9009-12d50f644ec8	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-16 05:31:50.290716
9589642f-a680-4187-a6ef-a5458f91de51	51a39e33-6ae9-4a9d-af9e-f9648da543dd	14ec132d-0a83-437d-84cc-c2ba4b1e79fc	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-16 05:31:50.454139
f4ff5c6e-e52b-48d1-8b6d-cd00add3d03a	51a39e33-6ae9-4a9d-af9e-f9648da543dd	5da8ac27-6650-4982-b51a-a7e7c5257075	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-16 05:31:50.573066
907f6dea-5bab-4f35-9cad-fe081fbfed00	51a39e33-6ae9-4a9d-af9e-f9648da543dd	5da8ac27-6650-4982-b51a-a7e7c5257075	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-16 05:31:50.635176
5a4c5e1f-047d-4193-8eca-245345a822e4	d2b4f6e3-2fe4-4a63-ba65-beb888dbaf3b	b6fa6422-dc6e-4d1b-ad0b-d8d6155ac133	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-16 05:31:50.765195
1043df5b-767c-453f-8236-4a315512cfac	d2b4f6e3-2fe4-4a63-ba65-beb888dbaf3b	6affed07-7898-4fc9-b86d-af1d610ad3ea	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-16 05:31:50.877251
1df98792-ce74-408e-bf1e-0e3103ad93d6	d2b4f6e3-2fe4-4a63-ba65-beb888dbaf3b	6affed07-7898-4fc9-b86d-af1d610ad3ea	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-16 05:31:50.932227
d5984cf6-19cc-4cbf-9244-674a8822e50a	bde01d20-d8d8-4401-9e4a-21ffb25d49f0	46a9bd6e-0895-46f1-9837-238ba478bc99	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-16 05:31:51.067036
b257d00f-151d-4d0e-adf4-be8db9196b9f	97d05564-2c7d-4c7c-86da-e055a99fdd07	efde4df9-1dcf-4d85-a9d3-151d17c8011d	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-16 05:31:51.454267
093eb023-0f77-4273-9762-8e26457a8880	97d05564-2c7d-4c7c-86da-e055a99fdd07	efde4df9-1dcf-4d85-a9d3-151d17c8011d	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-16 05:31:51.503728
e096211e-d925-4445-ac9d-ea6a9720fdd7	583d5ba7-b780-431b-bdf1-fd531a8f31db	51c83d0e-9f80-4d79-8eb3-6301950b29d3	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-16 05:31:51.631658
7f8714cc-ade0-4049-8722-92d61265d2d1	bf6cbcb7-606c-478e-bd40-78c9ee86effa	6d27a721-acb4-4dab-95d9-0b2c91645234	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-16 05:31:52.026528
c2b3a48f-14b1-4750-ae19-6e44487f5ac1	bf6cbcb7-606c-478e-bd40-78c9ee86effa	6d27a721-acb4-4dab-95d9-0b2c91645234	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-16 05:31:52.110245
1250aa34-a8c8-43fa-a8c5-320deb9f786d	ec6771dd-acfe-4a6f-8cd3-cf282b2c86aa	87b4b2dd-d35f-461d-853f-957c31ee3364	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-16 05:31:52.231219
5cf3e521-12b6-47f5-bf9c-3828d633fd7c	4471c66f-67a8-4161-a719-97421f4774b3	249b7155-1f20-404f-b377-b0202b66a8a8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-16 05:31:52.606522
e8ff8292-ebc5-4e27-bceb-6b7bb9e0bcaf	4471c66f-67a8-4161-a719-97421f4774b3	249b7155-1f20-404f-b377-b0202b66a8a8	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-16 05:31:52.661493
008e2612-7fe8-4ed6-848b-6a237c62e449	ed386a7e-ab27-4bea-be70-ec307cd36355	6af3e921-4c29-4eea-81c6-3ce45f97c261	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-16 05:31:52.807525
6b07084d-8af3-4535-893c-9aef617927d0	01fe3e3a-d6ba-466f-a815-12c4c9b161a6	5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-16 05:31:53.210866
5d0eb361-d48e-4757-86ec-47d48d12f2ab	01fe3e3a-d6ba-466f-a815-12c4c9b161a6	5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-16 05:31:53.2654
89042b10-8b53-44f7-9833-880666d50753	e458c717-ab36-45be-a8c3-2a121167d50e	f80dd5ab-6ca5-40f6-bf02-1e980b335e07	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-16 05:31:53.387819
74bc6e91-f81e-4e68-b6c7-1d65897c9179	bde01d20-d8d8-4401-9e4a-21ffb25d49f0	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-16 05:31:51.174123
d1dd572f-70ba-4f04-9650-41e820373e76	bde01d20-d8d8-4401-9e4a-21ffb25d49f0	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-16 05:31:51.223548
e3a3358b-9fac-40de-a835-59918ec56cd4	97d05564-2c7d-4c7c-86da-e055a99fdd07	1961069b-5b79-4334-ae5e-758545382c27	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-16 05:31:51.345016
63c203f4-924f-450d-acb1-4c4d216f1d79	583d5ba7-b780-431b-bdf1-fd531a8f31db	b7987533-e127-4cad-8233-de0fdde7bbc7	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-16 05:31:51.751951
03d27f58-aeb1-43f6-89b5-d0948bebc013	583d5ba7-b780-431b-bdf1-fd531a8f31db	b7987533-e127-4cad-8233-de0fdde7bbc7	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-16 05:31:51.799923
31888762-810d-4c43-a8e7-5ccd840998b4	bf6cbcb7-606c-478e-bd40-78c9ee86effa	d2c08f95-a3dd-42c0-9f49-b6363ea101aa	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-16 05:31:51.922073
d3e738b6-a059-4e5c-a914-5c4653f31a9f	ec6771dd-acfe-4a6f-8cd3-cf282b2c86aa	d244a912-8065-4604-9b58-ba9b69d93e11	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-16 05:31:52.333309
d4edcdd2-dfe3-4146-8d0d-f59d09cb0111	ec6771dd-acfe-4a6f-8cd3-cf282b2c86aa	d244a912-8065-4604-9b58-ba9b69d93e11	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-16 05:31:52.381752
7533526c-b867-4dd1-bc7f-0efdd8b782ab	4471c66f-67a8-4161-a719-97421f4774b3	a90d9e56-3d2d-45e0-8ca5-a8da134ffc5c	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-16 05:31:52.499889
b6d36eea-dcce-41fd-b828-e82533444ff1	ed386a7e-ab27-4bea-be70-ec307cd36355	a9a95a58-c2be-4175-83ed-7352a709c3c8	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-16 05:31:52.916795
c53d83f7-1332-48f8-bf7d-b1ffd8f7972a	ed386a7e-ab27-4bea-be70-ec307cd36355	a9a95a58-c2be-4175-83ed-7352a709c3c8	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-16 05:31:52.975274
3bc1862f-4249-4eb6-850b-9fa800c95f94	01fe3e3a-d6ba-466f-a815-12c4c9b161a6	9462b151-1337-4344-bc94-5bc90b59ab03	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-16 05:31:53.104537
27625013-7063-413f-afe1-c19547684f48	e458c717-ab36-45be-a8c3-2a121167d50e	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-16 05:31:53.491193
22028ea3-d791-4cad-9c7a-8deb9d559217	e458c717-ab36-45be-a8c3-2a121167d50e	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Automated Forward	\N	2026-01-16 05:31:53.536978
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.audit_logs (id, user_id, action, details, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.certificates (id, application_id, certificate_number, certificate_type, issued_date, valid_from, valid_upto, property_name, category, address, district, owner_name, owner_mobile, certificate_pdf_url, qr_code_data, digital_signature, issued_by, status, revocation_reason, revoked_by, revoked_date, renewal_reminder_sent, renewal_application_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: clarifications; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.clarifications (id, objection_id, application_id, submitted_by, submitted_date, clarification_text, supporting_documents, reviewed_by, reviewed_date, review_status, review_notes, updated_at) FROM stdin;
\.


--
-- Data for Name: ddo_codes; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.ddo_codes (id, district, ddo_code, ddo_description, treasury_code, head1, is_active, created_at, updated_at) FROM stdin;
3e17fad9-a314-45c4-9011-62715b800447	Chamba	CHM00-532	D.T.D.O. CHAMBA	CHM00	\N	t	2026-01-08 00:45:19.964858	2026-01-08 00:45:19.964858
105c6a4c-2835-4bec-93ae-42f397d4ff65	Bharmour	CHM01-001	S.D.O.(CIVIL) BHARMOUR	CHM01	\N	t	2026-01-08 00:45:19.969389	2026-01-08 00:45:19.969389
20d73826-0cbe-4c2a-8ab7-65ad871f53eb	Shimla (Central)	CTO00-068	A.C. (TOURISM) SHIMLA	CTO00	\N	t	2026-01-08 00:45:19.973877	2026-01-08 00:45:19.973877
e649d099-d4ad-43b0-adc8-6c56a5948ba5	Hamirpur	HMR00-053	DISTRICT TOURISM DEVELOPMENT OFFICE HAMIRPUR (UNA)	HMR00	\N	t	2026-01-08 00:45:19.978198	2026-01-08 00:45:19.978198
341b6fdb-90b6-4aef-8be1-e7aef76e1007	Una	HMR00-053	DISTRICT TOURISM DEVELOPMENT OFFICE HAMIRPUR (UNA)	HMR00	\N	t	2026-01-08 00:45:19.981531	2026-01-08 00:45:19.981531
b6b13efb-7a04-4491-96ee-27780a158570	Kullu (Dhalpur)	KLU00-532	DEPUTY DIRECTOR TOURISM AND CIVIL AVIATION KULLU DHALPUR	KLU00	\N	t	2026-01-08 00:45:19.984693	2026-01-08 00:45:19.984693
b68125ad-74dd-4823-98aa-f356fd207c0a	Kangra	KNG00-532	DIV.TOURISM DEV.OFFICER(DTDO) DHARAMSALA	KNG00	\N	t	2026-01-08 00:45:19.988087	2026-01-08 00:45:19.988087
c22224d4-fd67-47a1-a052-b1f24714045d	Kinnaur	KNR00-031	DISTRICT TOURISM DEVELOPMENT OFFICER KINNAUR AT RECKONG PEO	KNR00	\N	t	2026-01-08 00:45:19.991257	2026-01-08 00:45:19.991257
653ac4fe-f953-403a-a24f-e3ebb706db53	Lahaul-Spiti (Kaza)	KZA00-011	PO ITDP KAZA	KZA00	\N	t	2026-01-08 00:45:19.994623	2026-01-08 00:45:19.994623
755d95b8-015b-4cff-8776-4a4a8d0dd739	Lahaul	LHL00-017	DISTRICT TOURISM DEVELOPMENT OFFICER	LHL00	\N	t	2026-01-08 00:45:19.997599	2026-01-08 00:45:19.997599
1cb81eb0-4d5d-49b4-a229-19e30b4e4503	Mandi	MDI00-532	DIV. TOURISM DEV. OFFICER MANDI	MDI00	\N	t	2026-01-08 00:45:20.009625	2026-01-08 00:45:20.009625
e02ef70f-a43f-4bcb-8e6f-bf3abe6e7dc0	Pangi	PNG00-003	PROJECT OFFICER ITDP PANGI	PNG00	\N	t	2026-01-08 00:45:20.012551	2026-01-08 00:45:20.012551
d029a110-a870-4763-b290-b924e32663a2	Shimla	SML00-532	DIVISIONAL TOURISM OFFICER SHIMLA	SML00	\N	t	2026-01-08 00:45:20.015202	2026-01-08 00:45:20.015202
419c683c-b1a8-4be2-baa5-f0c20066b313	Sirmour	SMR00-055	DISTRICT TOURISM DEVELOPMENT OFFICE NAHAN	SMR00	\N	t	2026-01-08 00:45:20.017584	2026-01-08 00:45:20.017584
4224a80f-800c-4ab0-a98f-61d0988b3120	Solan	SOL00-046	DTDO SOLAN	SOL00	\N	t	2026-01-08 00:45:20.019928	2026-01-08 00:45:20.019928
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.documents (id, application_id, document_type, file_name, file_path, file_size, mime_type, upload_date, ai_verification_status, ai_confidence_score, ai_notes, is_verified, verification_status, verified_by, verification_date, verification_notes) FROM stdin;
784e60b4-c54d-4790-a7c2-e79491be9c95	7e2c9070-be02-44d1-9172-d58edc1fe8eb	revenue_papers	Hindi_Test01.pdf	/api/local-object/download/5883e85f-ebec-4bc8-991c-189cf688f8ac?type=revenue-papers	232135	application/pdf	2026-01-15 09:45:25.729413	\N	\N	\N	f	pending	\N	\N	\N
76e22b64-a431-4ff1-9768-553572a65e7c	7e2c9070-be02-44d1-9172-d58edc1fe8eb	affidavit_section_29	Hindi_Test01.pdf	/api/local-object/download/6cfbb4e2-4dd0-4f0c-89b9-99c04e4d6b57?type=affidavit-section29	232135	application/pdf	2026-01-15 09:45:25.734699	\N	\N	\N	f	pending	\N	\N	\N
97395777-e7e0-498e-8f71-2fd38f87eafa	7e2c9070-be02-44d1-9172-d58edc1fe8eb	undertaking_form_c	Hindi_Test01.pdf	/api/local-object/download/754f886e-bb4a-4f1c-a6fe-ab08df95cacd?type=undertaking-form-c	232135	application/pdf	2026-01-15 09:45:25.739195	\N	\N	\N	f	pending	\N	\N	\N
6435ee69-4e95-437d-b3d0-fdaf95dc1a32	7e2c9070-be02-44d1-9172-d58edc1fe8eb	property_photo	519109575.jpg	/api/local-object/download/4834929c-e760-4136-8a6f-dbe927b54ad1?type=property-photo	96524	image/jpeg	2026-01-15 09:45:25.743853	\N	\N	\N	f	pending	\N	\N	\N
72dbd554-771b-485a-a4de-e64f179e78b8	7e2c9070-be02-44d1-9172-d58edc1fe8eb	property_photo	529253340.jpg	/api/local-object/download/9e337e46-d0df-4a89-ba5d-dae8eff202c5?type=property-photo	13584	image/jpeg	2026-01-15 09:45:25.747907	\N	\N	\N	f	pending	\N	\N	\N
1c88555c-c3ec-4a09-a9f1-e7264c101872	cf464eb0-cf46-4a7f-92c4-66dcca32e4c0	revenue_papers	Test_Doc01-Hindi.pdf	/api/local-object/download/7d116319-0301-4454-a872-4b2ea5ade9f2?type=revenue-papers	61398	application/pdf	2026-01-15 10:27:13.758398	\N	\N	\N	f	pending	\N	\N	\N
14890179-e94a-47b3-8340-70c0cf399786	cf464eb0-cf46-4a7f-92c4-66dcca32e4c0	affidavit_section_29	Test_Doc01-Hindi.pdf	/api/local-object/download/8bf83f4c-73e5-47ed-ae7f-1fcf90764bbd?type=affidavit-section29	61398	application/pdf	2026-01-15 10:27:13.758398	\N	\N	\N	f	pending	\N	\N	\N
dafdb11f-90f5-44c6-8f79-661d29d06fd8	cf464eb0-cf46-4a7f-92c4-66dcca32e4c0	undertaking_form_c	Test_Doc01-Hindi.pdf	/api/local-object/download/9a812042-d6da-4772-a5f8-3de9b61aa313?type=undertaking-form-c	61398	application/pdf	2026-01-15 10:27:13.758398	\N	\N	\N	f	pending	\N	\N	\N
47470264-e183-4748-a329-d73b60522d80	cf464eb0-cf46-4a7f-92c4-66dcca32e4c0	commercial_electricity_bill	Test_Doc01-Hindi.pdf	/api/local-object/download/390c9dee-b741-49f2-b6dc-480eceb788fd?type=commercial-electricity-bill	61398	application/pdf	2026-01-15 10:27:13.758398	\N	\N	\N	f	pending	\N	\N	\N
937a78ff-0902-4ad8-892b-a9cc97717495	cf464eb0-cf46-4a7f-92c4-66dcca32e4c0	commercial_water_bill	Test_Doc01-Hindi.pdf	/api/local-object/download/2591f566-fe24-4153-b551-2ea2c2383156?type=commercial-water-bill	61398	application/pdf	2026-01-15 10:27:13.758398	\N	\N	\N	f	pending	\N	\N	\N
4dc32600-0e7c-41d2-927a-bd9f141fee90	cf464eb0-cf46-4a7f-92c4-66dcca32e4c0	property_photo	519109575.jpg	/api/local-object/download/3809b989-caa2-49ad-90ed-c92176a5c3a9?type=property-photo	96524	image/jpeg	2026-01-15 10:27:13.758398	\N	\N	\N	f	pending	\N	\N	\N
5e79954f-9a51-4530-8bc7-dd2d45ffc303	cf464eb0-cf46-4a7f-92c4-66dcca32e4c0	property_photo	529253340.jpg	/api/local-object/download/ae3f1566-d238-4226-89e8-5efa3c31e19f?type=property-photo	13584	image/jpeg	2026-01-15 10:27:13.758398	\N	\N	\N	f	pending	\N	\N	\N
f921c448-3596-4a80-b189-545589da153c	f9e654ae-c40e-4101-a807-be2ca0d6b248	revenue_papers	Test_Doc01-Hindi.pdf	/api/local-object/download/e3ce31c6-cde6-40d8-8c64-14efa7856697?type=revenue-papers	61398	application/pdf	2026-01-15 12:24:31.491714	\N	\N	\N	f	pending	\N	\N	\N
d67696c7-452b-402f-b39c-b14a9d0aee96	f9e654ae-c40e-4101-a807-be2ca0d6b248	affidavit_section_29	Test_Doc01-Hindi.pdf	/api/local-object/download/b930b932-fa87-4503-a565-633afce6b00c?type=affidavit-section29	61398	application/pdf	2026-01-15 12:24:31.491714	\N	\N	\N	f	pending	\N	\N	\N
c701e870-3908-4cc3-8591-62759bd665f8	f9e654ae-c40e-4101-a807-be2ca0d6b248	undertaking_form_c	Test_Doc01-Hindi.pdf	/api/local-object/download/6c8171b1-851a-43c1-817d-82bf96b0401d?type=undertaking-form-c	61398	application/pdf	2026-01-15 12:24:31.491714	\N	\N	\N	f	pending	\N	\N	\N
71c5cb6a-4adf-41c0-a849-959d89aed733	f9e654ae-c40e-4101-a807-be2ca0d6b248	property_photo	529253398.jpg	/api/local-object/download/9867c423-b0cd-4cf0-986f-40637d669b2a?type=property-photo	117294	image/jpeg	2026-01-15 12:24:31.491714	\N	\N	\N	f	pending	\N	\N	\N
a63a3da7-ddec-4070-8b7e-299a88ca766c	f9e654ae-c40e-4101-a807-be2ca0d6b248	property_photo	529253417.jpg	/api/local-object/download/e5c0a200-54ed-4f21-9b91-5b0852c7367e?type=property-photo	123434	image/jpeg	2026-01-15 12:24:31.491714	\N	\N	\N	f	pending	\N	\N	\N
af193fb8-e8da-459b-8f2d-f9d4e9d889c8	bf49b055-a8dc-4e73-8119-576904d0e78b	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:11:32.518748	\N	\N	\N	t	verified	1a8bab46-2d4c-4694-9009-12d50f644ec8	2026-01-15 13:11:32.701	Automated Smoke Test Verification
ef27d953-7cf7-4077-b117-c83df7d487be	fb333b9e-39c1-44f6-bfca-04bb4cea0f31	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:11:32.841833	\N	\N	\N	t	verified	5da8ac27-6650-4982-b51a-a7e7c5257075	2026-01-15 13:11:32.989	Automated Smoke Test Verification
db7e59e9-bb34-40cb-9f08-3fea22a7b25e	223be33d-e90b-41d9-9e95-8061986be739	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:11:33.131947	\N	\N	\N	t	verified	6affed07-7898-4fc9-b86d-af1d610ad3ea	2026-01-15 13:11:33.287	Automated Smoke Test Verification
7fb4cb55-efb9-422e-8d00-e8fa6cb64303	d85406fa-5e1b-4623-bc29-bd6b80024dd3	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:16:13.505715	\N	\N	\N	t	verified	1a8bab46-2d4c-4694-9009-12d50f644ec8	2026-01-15 13:16:13.69	Automated Smoke Test Verification
f1cc7d1e-ed29-4309-b28f-992e8377afc4	4a1b03ae-01cc-44cd-b513-fa1e45766342	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:16:13.865229	\N	\N	\N	t	verified	5da8ac27-6650-4982-b51a-a7e7c5257075	2026-01-15 13:16:14.049	Automated Smoke Test Verification
3ddb606d-ea47-43f3-90fe-7d970437a4ee	b2860363-180a-40e7-a835-7b7d55e53bf7	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:16:14.199333	\N	\N	\N	t	verified	6affed07-7898-4fc9-b86d-af1d610ad3ea	2026-01-15 13:16:14.359	Automated Smoke Test Verification
91d4ebb7-1d08-4371-ac67-5c8e953af2fe	e2b3164d-c007-43a9-a34f-626ff9b23ac3	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:16:14.494762	\N	\N	\N	f	pending	\N	\N	\N
73f5aca6-25b7-4e7b-83e0-469f8b036b72	6b3e202c-2e16-4702-936d-c73d7f0e6b0d	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:17:39.679897	\N	\N	\N	t	verified	1a8bab46-2d4c-4694-9009-12d50f644ec8	2026-01-15 13:17:39.88	Automated Smoke Test Verification
98378689-e450-47b2-96a1-de0996867b26	4ec594a0-8db8-48f7-98e9-067d70a2512a	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:17:40.043602	\N	\N	\N	t	verified	5da8ac27-6650-4982-b51a-a7e7c5257075	2026-01-15 13:17:40.227	Automated Smoke Test Verification
f4e52de7-8a0f-472f-aeab-d07964eb56d8	44c93e5e-8fcf-4012-92a7-7c12778a7dd5	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:17:40.38632	\N	\N	\N	t	verified	6affed07-7898-4fc9-b86d-af1d610ad3ea	2026-01-15 13:17:40.554	Automated Smoke Test Verification
0e5df68f-4739-4bb2-aa0d-5b0512b1818f	6852443d-8432-46ff-b332-eef72e339f42	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:17:40.712583	\N	\N	\N	t	verified	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	2026-01-15 13:17:40.873	Automated Smoke Test Verification
2d15dbb5-f334-4ea9-92d9-245930b3cf50	1f78fd55-b3ed-4387-b6bd-29b67e9915e1	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:36:30.982097	\N	\N	\N	t	verified	1a8bab46-2d4c-4694-9009-12d50f644ec8	2026-01-15 13:36:31.138	Automated Smoke Test Verification
3eba3ad9-ea36-4c8b-8f73-c752d9bcd0f0	978ab8eb-e9cf-4d0c-82eb-e4ddeb3b65fc	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:36:31.271844	\N	\N	\N	t	verified	5da8ac27-6650-4982-b51a-a7e7c5257075	2026-01-15 13:36:31.405	Automated Smoke Test Verification
6c3ee6d2-8d63-4276-aaef-eff345bf97ed	528e0eb5-e4c8-44dd-9fb6-cc3cc22f95a3	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:36:31.532003	\N	\N	\N	t	verified	6affed07-7898-4fc9-b86d-af1d610ad3ea	2026-01-15 13:36:31.664	Automated Smoke Test Verification
ce391bed-fc25-4e43-a854-8c974aa56edb	2f116765-df0d-4af2-ba3c-3955435110e5	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:36:31.78278	\N	\N	\N	t	verified	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	2026-01-15 13:36:31.917	Automated Smoke Test Verification
4ba55dfb-fc47-4a4e-8b4b-ac758b95b52e	8cc1f486-cd19-4135-82dd-00ddfa745838	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:36:32.045076	\N	\N	\N	t	verified	efde4df9-1dcf-4d85-a9d3-151d17c8011d	2026-01-15 13:36:32.177	Automated Smoke Test Verification
e6fbd6e0-01c6-4914-8e79-2d66eaeb768a	94ade75a-5c5d-4e85-921f-fc60c0d500f8	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:36:32.304672	\N	\N	\N	t	verified	b7987533-e127-4cad-8233-de0fdde7bbc7	2026-01-15 13:36:32.445	Automated Smoke Test Verification
a0852e09-dae8-4ed6-b60c-9f6374160186	ce4b01d0-eed3-4f8b-8395-64a0ad54af68	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:36:32.579217	\N	\N	\N	t	verified	6d27a721-acb4-4dab-95d9-0b2c91645234	2026-01-15 13:36:32.704	Automated Smoke Test Verification
91bc5c2d-7a5a-44bc-bd34-72516563d7f5	1d3bb4e4-41d6-42a9-b2ec-7a9f6520b2e4	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:36:32.827176	\N	\N	\N	t	verified	d244a912-8065-4604-9b58-ba9b69d93e11	2026-01-15 13:36:32.951	Automated Smoke Test Verification
545fd02e-3645-4d0b-98d0-583e8bbefa7f	e96e5136-191e-447b-8a26-c80576f427f9	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:36:33.074706	\N	\N	\N	t	verified	249b7155-1f20-404f-b377-b0202b66a8a8	2026-01-15 13:36:33.191	Automated Smoke Test Verification
653648ae-ea52-4efd-a0a8-cfeb66ef785b	13e2ea6b-8f7d-4b05-8eb6-3510b5ee1505	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:36:33.314947	\N	\N	\N	t	verified	a9a95a58-c2be-4175-83ed-7352a709c3c8	2026-01-15 13:36:33.454	Automated Smoke Test Verification
cd39e5d1-c819-4987-89b0-512268a55dd0	9d91fed9-d0cb-4b51-8e0c-95c072cda015	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:36:33.572165	\N	\N	\N	t	verified	5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	2026-01-15 13:36:33.695	Automated Smoke Test Verification
0e0eb709-c9ad-4454-8de0-c1152ba77170	1973b255-2892-4668-920b-1808d3e74fab	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-15 13:36:33.813873	\N	\N	\N	t	verified	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	2026-01-15 13:36:33.935	Automated Smoke Test Verification
3688daaa-cfcc-4045-85a3-f00374b0a35d	a3b9fb40-9e19-4eca-b335-d7d1319088b8	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:46.644747	\N	\N	\N	f	pending	\N	\N	\N
e191e61d-ad71-4188-ac7c-4805d10f4492	fd8745f9-9ae8-4753-a6c6-c03fce59d63e	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:46.655516	\N	\N	\N	f	pending	\N	\N	\N
bf032b46-afbe-4863-83ae-8c4df19ee432	78c90848-7e3a-4a38-a403-bc4052c0aa62	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:46.662535	\N	\N	\N	f	pending	\N	\N	\N
d32dad59-5875-4dcd-adbe-299c5b2b9297	6f5093be-7c13-4c55-b6cb-c04d8c9196f2	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:46.706075	\N	\N	\N	f	pending	\N	\N	\N
8d7ecf4f-efeb-445a-bcfb-3e18be3142b1	ff6a8c27-5c03-44ed-8df4-a379f64741c8	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:47.069055	\N	\N	\N	f	pending	\N	\N	\N
92df24d3-20f6-49de-a3a1-7ac9f8e90dcd	a9d8804e-6fcf-4908-a042-338ddfd39ead	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:47.087565	\N	\N	\N	f	pending	\N	\N	\N
8425f393-f625-425c-a331-dc63fa4f62ff	a77c0633-e08e-414d-a020-18c1bd3fad4b	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:47.103105	\N	\N	\N	f	pending	\N	\N	\N
06020601-941c-4743-b373-f91dddb5fa22	8754593e-05c9-45bb-8c16-436221cca004	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:47.103894	\N	\N	\N	f	pending	\N	\N	\N
46f42782-2eb3-4422-8c8c-bcbf5735bb92	19e407b8-9d6c-4399-953a-37cfe3c3dec6	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:47.170838	\N	\N	\N	f	pending	\N	\N	\N
c8655978-225f-479d-a136-612afd81b406	fd23b7ab-c41a-45c3-af4f-ff12570887b3	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:47.573378	\N	\N	\N	f	pending	\N	\N	\N
ee3c8ef5-3658-4807-a02a-4f8477a947c4	4146533f-6433-493e-9f53-2c4bb5607a12	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:47.574572	\N	\N	\N	f	pending	\N	\N	\N
1c1d9752-7439-41a3-9fdd-b4a99865df58	8e014860-05eb-4ed6-a369-69051ff56b36	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:47.616867	\N	\N	\N	f	pending	\N	\N	\N
50bae2e1-dca4-46a8-8677-7cd1f20dc61d	e86e8da7-8104-4ab1-a6be-361005d53180	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:47.632295	\N	\N	\N	f	pending	\N	\N	\N
5a8db10f-b13e-4ab3-ad2a-4164bc96d06e	fcaf36d1-972e-4822-8320-772cc152e09f	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:47.642554	\N	\N	\N	f	pending	\N	\N	\N
f26e5935-d7a8-476a-9d8f-3394ef27fb0c	9f46af13-a978-4176-be50-6bc3ac8f8fed	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.08729	\N	\N	\N	f	pending	\N	\N	\N
0caa5321-debb-4266-98e8-4f117efa2f5d	a3e21aab-0ba6-4cfa-b249-98988e76c168	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.098517	\N	\N	\N	f	pending	\N	\N	\N
23445855-74f3-403e-9a64-9773cdff4a06	43bd665e-3464-449a-9a9d-bd7af94538eb	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.109155	\N	\N	\N	f	pending	\N	\N	\N
0cdec8d3-4b5f-4cc7-a3d4-db28a8d54e28	738c76d3-886b-40b5-8091-b01cf4ff7466	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.112715	\N	\N	\N	f	pending	\N	\N	\N
436f1055-e049-447b-b401-7576919b0c14	78edd442-343a-4932-b425-b567e60970b4	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.196661	\N	\N	\N	f	pending	\N	\N	\N
6fbe14f5-ae44-41bc-ba32-9c33f3636b57	12a716ff-1ea9-4e7b-9184-7d15100d77c0	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.543349	\N	\N	\N	f	pending	\N	\N	\N
94bb46fd-9a77-42ed-8232-b2129c4b14c6	8386817a-6e4f-4742-9ec2-f0a42931a7d2	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.547506	\N	\N	\N	f	pending	\N	\N	\N
b3d7a11e-0c48-409b-9731-41c6a18a1a9a	868a4752-fe41-4605-93ef-d4574e10f6f3	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.550602	\N	\N	\N	f	pending	\N	\N	\N
9e850447-55a5-4242-801a-f0e0ab31cbf5	d8e6c412-3d42-43c6-824b-d2aa7aa76abd	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.985878	\N	\N	\N	f	pending	\N	\N	\N
7dd0b845-358c-4084-8e2d-167c8cae61c5	2ea0bab9-6a75-4eed-8f17-4faf84c69734	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:50.72757	\N	\N	\N	f	pending	\N	\N	\N
5f46f92c-ec5b-463b-9383-896c472b4e82	868feb27-e66d-46b4-8a37-4c8916ee910f	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.109524	\N	\N	\N	f	pending	\N	\N	\N
0665d730-d962-4fdf-b53a-773d61edb519	ddb38037-ea8d-4d1e-969a-38c7bf65ee18	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.615104	\N	\N	\N	f	pending	\N	\N	\N
28f573ad-1d7b-4663-a661-76cdf20f40ef	ef4aaed1-3e89-401c-b184-2cefd24958ec	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.921535	\N	\N	\N	f	pending	\N	\N	\N
154541df-702c-4ba4-9fa4-f6b93fec03d7	2dd5e603-37bb-4cb3-a92d-ea6c110a5700	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:52.371091	\N	\N	\N	f	pending	\N	\N	\N
16f80ce6-639d-4d97-a8ce-761132f98bb0	0396737e-066a-4c33-a276-0fdb8ef74731	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:52.724195	\N	\N	\N	f	pending	\N	\N	\N
763d5274-b57c-4e05-b46e-a6647446d74e	0b38f2cb-09da-41e1-ba7e-998cf76a190c	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.186982	\N	\N	\N	f	pending	\N	\N	\N
a89f75fa-f8ad-4abc-be5d-f2301a7f8e48	cadeae01-c10d-475c-9b06-ad456d8b4fb7	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.50757	\N	\N	\N	f	pending	\N	\N	\N
a144198b-c826-4c91-bb0b-6ffaa75c4bd7	c4cd4f33-2cda-4e66-bc2f-c89fe58cd65a	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.933243	\N	\N	\N	f	pending	\N	\N	\N
eab94e00-7230-40d6-a169-dc6afa998be6	d7c474bb-1e52-468c-a9e0-a484e6afa984	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:54.338921	\N	\N	\N	f	pending	\N	\N	\N
3a3ddf19-3658-432f-9760-2734676641ca	bedf8398-fb71-4285-bc17-f0ac181e9224	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:54.840466	\N	\N	\N	f	pending	\N	\N	\N
3e693464-f2df-4635-a334-de850b7c3358	cf0ee44c-3899-4297-80b0-c6c45d1cbe61	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.554225	\N	\N	\N	f	pending	\N	\N	\N
78f75095-a921-4b13-93b2-adc1137e14c6	073fcd8a-f9c4-46f9-babe-511fd8f752e9	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.984245	\N	\N	\N	f	pending	\N	\N	\N
225f735d-8d4c-4539-9090-44cc0b5b46a4	1817e02b-530f-4c0b-9eb8-70a7f0c79677	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:49.447331	\N	\N	\N	f	pending	\N	\N	\N
285bad6e-0bbc-4577-8e1f-a6b4ac126a4c	5e63c91f-42b8-4f8e-811d-91baa4d7d67f	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:49.865909	\N	\N	\N	f	pending	\N	\N	\N
2ea86578-c19c-4921-89f5-ab7f9edb88f9	17c96178-51fc-4bd5-a0f2-08233a50be60	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:50.307841	\N	\N	\N	f	pending	\N	\N	\N
eedfd9de-9703-4375-a8fc-358539ddb997	f8678397-122c-4899-b691-c01c3ec1d9db	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:50.374334	\N	\N	\N	f	pending	\N	\N	\N
f31714fc-7676-4530-9db2-ba82abc27ff5	154c6651-7315-4711-8f79-0549a4b6c44f	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:50.727932	\N	\N	\N	f	pending	\N	\N	\N
7e4bb2d8-23bf-4a73-8b83-ce84969e5aed	906e1a03-fdb6-4934-8706-b33b42d523bb	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.133346	\N	\N	\N	f	pending	\N	\N	\N
1234cacb-b319-4580-9ca2-1f80bea8e370	9abf87b1-83bd-4d80-98fb-cecfc09311ef	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.539204	\N	\N	\N	f	pending	\N	\N	\N
8598e757-4ec3-418c-a669-7b8c863a9134	f876b83e-9983-4641-b332-15bb05c641aa	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.93253	\N	\N	\N	f	pending	\N	\N	\N
784be010-6d7e-4e15-9cf2-8f2c0ab17a16	40c0c66e-e693-470e-a0fd-e77f71021748	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.990607	\N	\N	\N	f	pending	\N	\N	\N
b26c3006-150c-46de-a211-9398914a3d83	05a9f9df-2c59-43c9-bc06-24d69571e90b	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:52.30283	\N	\N	\N	f	pending	\N	\N	\N
2f8a13ee-e23d-41d6-8e1f-3fcc5a9e8440	aa7c3fa6-0ec5-45bf-88b2-5cade216be14	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.122107	\N	\N	\N	f	pending	\N	\N	\N
5b501e4f-ce1d-4ba1-9626-c9ff400f78fc	bebeb5de-4a9b-4bf0-9427-a44e9eb6eb63	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.945158	\N	\N	\N	f	pending	\N	\N	\N
b36dcaec-8ee0-4c94-9e45-3c38be62319d	f90e0391-c214-4e73-b1f0-ade4bca39867	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:54.008093	\N	\N	\N	f	pending	\N	\N	\N
8c80b65b-5ff5-4a7c-a518-e3cac4b49463	31a40a95-e4f4-4e71-80ba-6e87224303d0	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:54.350573	\N	\N	\N	f	pending	\N	\N	\N
4c41c808-07a7-4c92-868c-75638c0d5b5d	b9c9c4f6-51b3-40bc-983d-facff9fffa16	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:54.958097	\N	\N	\N	f	pending	\N	\N	\N
f0ad9778-61f0-4d3c-8bf5-e2fde01c44f0	6c67e88c-83e0-4252-a3d0-8ebf8ec57597	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.628276	\N	\N	\N	f	pending	\N	\N	\N
d7ea5721-827e-4038-83c2-239f1715a209	913053e3-3766-4556-8abf-d952e4158780	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.947829	\N	\N	\N	f	pending	\N	\N	\N
c5958fb9-02a4-4c21-ab28-b5712e351f88	dc63fd1f-85dc-4012-9bc4-48959bdd5170	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:49.418955	\N	\N	\N	f	pending	\N	\N	\N
e4add142-7d14-4f49-93dd-437032a80b4c	e7cd27b0-045c-481f-9d50-d0f408f80a42	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:49.493409	\N	\N	\N	f	pending	\N	\N	\N
777a17ec-7c6a-4cde-b3cd-c201ad168ca3	fd4ab56b-3774-4213-81b4-8ae96852109c	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:49.861912	\N	\N	\N	f	pending	\N	\N	\N
56e3bd02-d5ff-46f7-8da2-3e9f9ca0b988	8057b346-f45a-465d-8ef3-99a2648073dd	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:50.305526	\N	\N	\N	f	pending	\N	\N	\N
cf4279d6-8082-4846-af4a-49cf9d6f1550	2250f86d-c678-45c0-a263-fca010810f27	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:50.737782	\N	\N	\N	f	pending	\N	\N	\N
b51bd5f6-b3ac-4b1b-b05f-f5f17a5f754c	98d6f7c4-6468-4a62-bd0f-c7a4885c460c	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.130203	\N	\N	\N	f	pending	\N	\N	\N
47fd1ce0-46b0-46db-972e-db8dc2126fc4	29daf7b4-9b97-4d7e-a43a-ebf26d74688f	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.545611	\N	\N	\N	f	pending	\N	\N	\N
f10062a5-fe0e-44bc-ab6d-bdcf5186447a	7138043d-72c0-47e2-828b-b182eb1feee9	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:52.312506	\N	\N	\N	f	pending	\N	\N	\N
9de88749-ce2a-4758-b4e1-498857dee710	b01a0e08-306a-4f05-88e3-317ece2172a7	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:52.727038	\N	\N	\N	f	pending	\N	\N	\N
543e7acc-67fc-4aca-8acd-9a1afa8c9950	2771b4ad-0e39-49e9-9e13-5df01e725eb1	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.120314	\N	\N	\N	f	pending	\N	\N	\N
66cb05d6-469b-46fc-9fb1-cdce64909d4e	420e6c2f-d9b3-4e69-956d-b4f3473d3259	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:48.989635	\N	\N	\N	f	pending	\N	\N	\N
e38b373d-310d-4991-b6d0-4442577f8f2b	61f54434-eed3-4db6-9fc5-c08826ef91e3	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:49.040567	\N	\N	\N	f	pending	\N	\N	\N
93418cdc-4c47-40ab-982f-17f8a844866f	85fb2d9e-bbff-43ef-89cb-8195e84aea55	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:49.977516	\N	\N	\N	f	pending	\N	\N	\N
13519eb3-48d3-49cd-953f-84b3b21127cf	0d622163-7e73-416b-b3c0-df5e97333038	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:49.410633	\N	\N	\N	f	pending	\N	\N	\N
59e3e5c5-fdba-4946-816f-6473677a0114	93167516-1a44-4ad4-9636-e9d908c63d97	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:49.843991	\N	\N	\N	f	pending	\N	\N	\N
ea849317-6d5e-4280-a07c-398a8883a148	de23380e-153e-4ff2-b270-a857f00d4a7d	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:50.30454	\N	\N	\N	f	pending	\N	\N	\N
6202a899-fa14-4c90-befc-18f714c3d5c8	24f391de-3450-41c7-859b-6f8a5fa046df	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:50.743063	\N	\N	\N	f	pending	\N	\N	\N
d6732aa9-817f-4c1a-a623-0ada7745b881	a2d13a0d-a5e5-4cc9-aed8-52b9e242f21c	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.111181	\N	\N	\N	f	pending	\N	\N	\N
45428fd9-3ac1-4c1e-9f0b-c1d9192ade7a	b129be29-244b-4346-8773-9b368d9df5fd	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.198298	\N	\N	\N	f	pending	\N	\N	\N
87ee285a-d545-41ba-8342-ac492fd0b9f8	59151e7a-d851-4fca-b29d-5ab2cb876e00	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.530629	\N	\N	\N	f	pending	\N	\N	\N
35c79ad3-9716-4475-a16c-e4a0a7a7888e	6d6853e9-6154-47d3-a1e7-109676e3411d	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:49.436424	\N	\N	\N	f	pending	\N	\N	\N
c08a6dc1-2bd5-4216-acfc-2d304875743c	d6025bfb-4961-4da6-a0f0-8d8a5b889cf0	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:49.853117	\N	\N	\N	f	pending	\N	\N	\N
407af13a-aba4-4d57-bbe7-2933ff2b8797	f1f46c71-cd29-4e57-8806-95b6f6181204	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:50.789983	\N	\N	\N	f	pending	\N	\N	\N
be1523b7-9ed0-4569-9c8f-3da3a3af84eb	b2f51457-0fbf-423c-8e49-f799c759202f	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.534043	\N	\N	\N	f	pending	\N	\N	\N
2d0447ee-680d-4eb0-bec7-7ef0d0537951	902d09ea-7181-4451-9384-4ca426eb6ebd	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:51.936399	\N	\N	\N	f	pending	\N	\N	\N
efd6b07c-955e-4672-aa39-90fa963ae054	1b85a8ec-ff6a-483a-b80a-484f6c349a74	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:52.306963	\N	\N	\N	f	pending	\N	\N	\N
0b188d69-ca7f-4ea4-b6f3-61fcbfc47ea4	a934be0e-3011-4392-a09f-f3c064591647	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:52.722582	\N	\N	\N	f	pending	\N	\N	\N
b9d54c94-2a8c-4ced-8f6d-8df4e87cd126	822f5c3d-d20c-44d9-b3bf-4eb5ac3531fd	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:52.790511	\N	\N	\N	f	pending	\N	\N	\N
b085bd40-1012-4a67-a1ed-745178b41b8a	0fb0a6b7-646a-4786-b03e-c081fd6c5485	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.125718	\N	\N	\N	f	pending	\N	\N	\N
6ce01806-c28e-4398-8f5d-db6df8dcde08	d629068e-63a2-4a3b-884d-ba4755c68b64	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.518137	\N	\N	\N	f	pending	\N	\N	\N
30d423c5-a39d-4275-b030-4a3ea3a3877a	c170386d-626d-4e41-b81c-84169466c306	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.92587	\N	\N	\N	f	pending	\N	\N	\N
33f10781-a000-4f18-8f53-f8f8643a6a19	d8eff996-514c-42d2-a056-b24781a9c017	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:54.325906	\N	\N	\N	f	pending	\N	\N	\N
1acf3ffb-1cf7-40e7-8cde-2ce54a99ab5b	5c5a1b8c-01ef-474b-afc5-d82b1ac8ed3c	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:54.754247	\N	\N	\N	f	pending	\N	\N	\N
613c0f2b-7bf5-4f80-a357-9e2d03e31716	74fca047-68f8-4c01-b2dc-c6559967c05e	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:54.819327	\N	\N	\N	f	pending	\N	\N	\N
51da68d7-69e6-49b5-9810-6b6374b81b7a	04d6b8c1-ddd0-411d-9ed2-4b862ea6d7cc	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:52.294758	\N	\N	\N	f	pending	\N	\N	\N
810dced9-af5f-4334-ac97-53126d55bf12	69fe1a8a-0c0c-4f4e-91ae-58a0a2a99965	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:52.725303	\N	\N	\N	f	pending	\N	\N	\N
a7c38b56-a312-454f-a28d-c56a25bd6702	b06ed3c3-31bb-46f2-9f95-926c39343315	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.121873	\N	\N	\N	f	pending	\N	\N	\N
74cfd480-e32a-4651-9e9d-116ab6baecce	30cc8c65-da6a-4ab7-8626-c0de9cb8bb6b	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.507221	\N	\N	\N	f	pending	\N	\N	\N
411e2de9-f9c9-408c-adaf-d195556e8594	34f8242b-d9da-4514-9539-921b0db96806	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.522844	\N	\N	\N	f	pending	\N	\N	\N
f46d3b7f-4bb9-40a5-afc5-736c943bdafa	dd96428f-41e7-447e-850f-af86df448e0d	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.584153	\N	\N	\N	f	pending	\N	\N	\N
58160de9-c519-4dbd-be4a-19ba60e44729	68f85f6d-d5f2-4d5f-b2ed-84f6ad1b6a30	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:53.915532	\N	\N	\N	f	pending	\N	\N	\N
8f5ed8fc-1561-4daf-b35a-baed2fb99a01	198c49bb-a739-4a9c-bc16-ab331ba5376b	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:54.338114	\N	\N	\N	f	pending	\N	\N	\N
fa733782-4579-41df-91b1-74d32622320a	45d5a8a0-4c21-4642-9ae6-023ab6ae4b7a	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:54.404001	\N	\N	\N	f	pending	\N	\N	\N
839ce102-7561-4a0f-b687-ca5f7bced07e	b65e1c81-9be9-4203-ba1f-57589ea3b14c	proof_of_ownership	load_test_doc.pdf	/uploads/dummy.pdf	1024	application/pdf	2026-01-15 14:00:54.823967	\N	\N	\N	f	pending	\N	\N	\N
616936ab-b00e-4bf3-a043-46a80e4db88e	53f5b3ef-23c8-4888-829c-e6751056d0a5	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-16 05:31:50.068459	\N	\N	\N	t	verified	1a8bab46-2d4c-4694-9009-12d50f644ec8	2026-01-16 05:31:50.264	Automated Smoke Test Verification
b21e7ade-c8f4-4385-bb82-d3f6cf2ab6fd	51a39e33-6ae9-4a9d-af9e-f9648da543dd	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-16 05:31:50.443225	\N	\N	\N	t	verified	5da8ac27-6650-4982-b51a-a7e7c5257075	2026-01-16 05:31:50.607	Automated Smoke Test Verification
3fb80a73-5a1e-4138-9253-f269211f3e84	d2b4f6e3-2fe4-4a63-ba65-beb888dbaf3b	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-16 05:31:50.759251	\N	\N	\N	t	verified	6affed07-7898-4fc9-b86d-af1d610ad3ea	2026-01-16 05:31:50.91	Automated Smoke Test Verification
3f41edec-67a4-410a-a6a1-e25383709fa1	bde01d20-d8d8-4401-9e4a-21ffb25d49f0	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-16 05:31:51.058889	\N	\N	\N	t	verified	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	2026-01-16 05:31:51.204	Automated Smoke Test Verification
d7f395ad-dc7b-42b4-8cb9-276cdcdbf96d	97d05564-2c7d-4c7c-86da-e055a99fdd07	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-16 05:31:51.338147	\N	\N	\N	t	verified	efde4df9-1dcf-4d85-a9d3-151d17c8011d	2026-01-16 05:31:51.483	Automated Smoke Test Verification
3dcce316-c360-424f-8f81-afe756b9b839	583d5ba7-b780-431b-bdf1-fd531a8f31db	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-16 05:31:51.624004	\N	\N	\N	t	verified	b7987533-e127-4cad-8233-de0fdde7bbc7	2026-01-16 05:31:51.782	Automated Smoke Test Verification
ff3fd08a-3085-4b94-a316-34f27748a62e	bf6cbcb7-606c-478e-bd40-78c9ee86effa	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-16 05:31:51.914305	\N	\N	\N	t	verified	6d27a721-acb4-4dab-95d9-0b2c91645234	2026-01-16 05:31:52.078	Automated Smoke Test Verification
70baf197-aeca-4ebb-8f44-a2229c033f7a	ec6771dd-acfe-4a6f-8cd3-cf282b2c86aa	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-16 05:31:52.226321	\N	\N	\N	t	verified	d244a912-8065-4604-9b58-ba9b69d93e11	2026-01-16 05:31:52.361	Automated Smoke Test Verification
ef0de114-f554-486e-aa79-b1734baf63de	4471c66f-67a8-4161-a719-97421f4774b3	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-16 05:31:52.493263	\N	\N	\N	t	verified	249b7155-1f20-404f-b377-b0202b66a8a8	2026-01-16 05:31:52.637	Automated Smoke Test Verification
d9f6c783-850f-42d2-ac51-1aeb44369b23	ed386a7e-ab27-4bea-be70-ec307cd36355	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-16 05:31:52.798356	\N	\N	\N	t	verified	a9a95a58-c2be-4175-83ed-7352a709c3c8	2026-01-16 05:31:52.955	Automated Smoke Test Verification
167aa88a-e34e-42ba-9407-d978d349cd68	01fe3e3a-d6ba-466f-a815-12c4c9b161a6	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-16 05:31:53.097301	\N	\N	\N	t	verified	5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	2026-01-16 05:31:53.239	Automated Smoke Test Verification
16c64c60-909c-48f2-89b5-acb3961b2d01	e458c717-ab36-45be-a8c3-2a121167d50e	proof_of_ownership	dummy_deed.pdf	/uploads/dummy_deed.pdf	1024	application/pdf	2026-01-16 05:31:53.382098	\N	\N	\N	t	verified	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	2026-01-16 05:31:53.518	Automated Smoke Test Verification
\.


--
-- Data for Name: grievance_audit_log; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.grievance_audit_log (id, grievance_id, action, old_value, new_value, performed_by, performed_at, ip_address, user_agent) FROM stdin;
\.


--
-- Data for Name: grievance_comments; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.grievance_comments (id, grievance_id, user_id, comment, is_internal, created_at) FROM stdin;
\.


--
-- Data for Name: grievances; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.grievances (id, ticket_number, ticket_type, user_id, application_id, category, priority, status, subject, description, assigned_to, resolution_notes, attachments, last_comment_at, last_read_by_owner, last_read_by_officer, created_at, updated_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: himkosh_transactions; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.himkosh_transactions (id, application_id, dept_ref_no, app_ref_no, total_amount, tender_by, merchant_code, dept_id, service_code, ddo, head1, amount1, head2, amount2, head3, amount3, head4, amount4, head10, amount10, period_from, period_to, encrypted_request, request_checksum, ech_txn_id, bank_cin, bank_name, payment_date, status, status_cd, response_checksum, is_double_verified, double_verification_date, double_verification_data, challan_print_url, portal_base_url, transaction_status, initiated_at, responded_at, verified_at, created_at, updated_at, is_archived) FROM stdin;
b81d65b2-15a1-4070-90de-bb1a194d4cb9	cf464eb0-cf46-4a7f-92c4-66dcca32e4c0	HP-HS-2026-PNG-000003	HPT1768472720878LiVR	1	Test AAA	HIMKOSH230	230	TSM	PNG00-003	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	15-01-2026	14-01-2029	FdkGGiidekvpm0UUibJM5NLCoeGdXqcQsBV/MqcevsknpIP4bSVVGjRWIEzMtc7lJf/a9ebpx7X+nt+/0H3O+91otvlF1fhEGl+vLekTn2/TvNw/De90hBQQliaQFSrrxim/y+g0b19RNablSxnwkHaz17Cjy0OiHXwz+yia/icpkBbdlFDFXN/xh4XV73JkjTAc4GavJNouBeq/ZUBoWAY+f9mknIr/KnOy7P5wzQqIQ2LoXIYqIUARdc0BPytfV2qR7a0cuSj84cRQF7u8ynnRzF4wq7zRqb5NU1qeE+gaK3NB4teG512C5sU8aVg5Khursc0AvnVRHdZ/MUQx2OmbmAXABlAOAoawuvhMvD2wM6CCLO2TyKpoxFlMkcsAL42q65JjNkQqMiGcpjyhVYOtceoVY8TRPZkmESP7awg=	d773edcdd182acc0dd68904ad9bef420	A26A247041	CPAGEFBFO7	SBI	15012026155712	Completed successfully.	1	9f522424717ce4c70116815699a4f717	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A26A247041	https://dev1.osipl.dev	success	2026-01-15 10:25:20.88682	2026-01-15 10:27:13.74	\N	2026-01-15 10:25:20.88682	2026-01-15 10:25:20.88682	f
837a03d6-91a0-422c-b0bf-bac8e3b9c2a7	f9e654ae-c40e-4101-a807-be2ca0d6b248	HP-HS-2026-LAH-000004	HPT1768479368301tjhv	1	Test BBB	HIMKOSH230	230	TSM	KZA00-011	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	15-01-2026	14-01-2029	FdkGGiidekvpm0UUibJM5NLCoeGdXqcQsBV/Mqcevsk/FM/JAo/qWIr/kmsKF9PaMwoqcbw2hfg6/nNUk6eSMsZbzZiJFfl65FOo661r3eYZHgUir3Ae2BUQbCkabonP73ZiiQraUAz3xaAlKxSURPBK03wnjFlK1bANX1mFFOORfQYar4U98UCUY6E+bg0m6OdZcPaFwKpCKa8W9+r51bRe7vpAbrfi23NjDe91R5Xh6gSpdBoWAbC9KrF4PDz4ZoaJoktJU8GFX9aImJi6soatDbhKAs8m+Z+UEBTHLypxH6xMZ0c4Kl0ypr9mUCgzedbGykiacaj1/nunJcq1nHBeIfjkqSLIeopdvgDw+yh6CQ0Q/w1leYduoEYXiqRFJHt4Re7NDCIK8ZP6rIh1pbg1oqsbr3IFXW4SDUui5lI=	69b454eba89a2b02f7bbc57243c46bea	\N	\N	\N	\N	Cancelled by applicant	0	\N	f	\N	\N	\N	https://dev1.osipl.dev	failed	2026-01-15 12:16:08.309122	2026-01-15 12:22:42.201	\N	2026-01-15 12:16:08.309122	2026-01-15 12:22:42.201	f
8a18e8b8-93af-4683-aa8d-355df914369a	f9e654ae-c40e-4101-a807-be2ca0d6b248	HP-HS-2026-LAH-000004	HPT1768479765129TvU6	1	Test BBB	HIMKOSH230	230	TSM	KZA00-011	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	15-01-2026	14-01-2029	FdkGGiidekvpm0UUibJM5NLCoeGdXqcQsBV/Mqcevsk/FM/JAo/qWIr/kmsKF9PaMwoqcbw2hfg6/nNUk6eSMsZbzZiJFfl65FOo661r3ebM+ZJ4ejbYpEo7nbxGGqi0dVzTCPFRRUQ1/tF3fz+vx+iHanC3cl5AlVyON66PITknjtaZ7hgvY1Fx+2G02av0ZM3+xgP60b8kxiM7y+ZcqIBE25/xQ7CHiqEpHX4rOWaQlqsVVYOF6us4gOZwXU53i0qsLibJ427LG0Sno9qFf/T/Rn4pPVALP4Il6H4rcFiiCLMrufY5IKISbtpVt7qU+raSVAps0uw11mAg++05nX70O/8wL3TI3iinGCzD/fnltT7WGhmg3s6e4A6WW0kakrAS/vOWjoUK22EcQfNMiEujggFRwx+kW4av/t6n2oA=	4627d2a734d3db8e5bb12b2dec4bdc69	A26A248960	CPAGEFKSJ4	SBI	15012026175430	Completed successfully.	1	d078e120dd2354f75df8a2f01656853e	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A26A248960	https://dev1.osipl.dev	success	2026-01-15 12:22:45.132512	2026-01-15 12:24:31.472	\N	2026-01-15 12:22:45.132512	2026-01-15 12:22:45.132512	f
\.


--
-- Data for Name: homestay_applications; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.homestay_applications (id, user_id, application_number, application_kind, parent_application_id, parent_application_number, parent_certificate_number, inherited_certificate_valid_upto, service_context, service_notes, service_requested_at, application_type, water_sports_data, adventure_sports_data, property_name, category, location_type, total_rooms, district, district_other, tehsil, tehsil_other, block, block_other, gram_panchayat, gram_panchayat_other, urban_body, urban_body_other, ward, address, pincode, telephone, fax, latitude, longitude, owner_name, owner_gender, owner_mobile, owner_email, guardian_name, owner_aadhaar, guardian_relation, property_ownership, proposed_room_rate, project_type, property_area, property_area_unit, single_bed_rooms, single_bed_beds, single_bed_room_size, single_bed_room_rate, double_bed_rooms, double_bed_beds, double_bed_room_size, double_bed_room_rate, family_suites, family_suite_beds, family_suite_size, family_suite_rate, attached_washrooms, gstin, selected_category, average_room_rate, highest_room_rate, lowest_room_rate, certificate_validity_years, is_pangi_sub_division, distance_airport, distance_railway, distance_city_center, distance_shopping, distance_bus_stand, key_location_highlight1, key_location_highlight2, lobby_area, dining_area, parking_area, eco_friendly_facilities, differently_abled_facilities, fire_equipment_details, nearest_hospital, amenities, nearby_attractions, mandatory_checklist, desirable_checklist, rooms, base_fee, total_before_discounts, validity_discount, female_owner_discount, pangi_discount, total_discount, total_fee, per_room_fee, gst_amount, status, current_stage, current_page, district_officer_id, district_review_date, district_notes, da_id, da_review_date, da_forwarded_date, da_remarks, state_officer_id, state_review_date, state_notes, dtdo_id, dtdo_review_date, correction_submission_count, revert_count, dtdo_remarks, rejection_reason, clarification_requested, site_inspection_scheduled_date, site_inspection_completed_date, site_inspection_officer_id, site_inspection_notes, site_inspection_outcome, site_inspection_findings, ownership_proof_url, aadhaar_card_url, pan_card_url, gst_certificate_url, fire_safety_noc_url, pollution_clearance_url, building_plan_url, property_photos_urls, documents, certificate_number, certificate_issued_date, certificate_expiry_date, payment_status, payment_id, payment_amount, payment_date, refund_date, refund_reason, submitted_at, approved_at, created_at, updated_at, form_completion_time_seconds) FROM stdin;
ba61eaff-8da6-4471-8361-670e72a184d8	a136d932-ae92-4bd9-8768-9e5914d08aa2	HP-HS-2026-HMP-000011	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Hamirpur (Merged) Flow Property	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9977734596	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:06:32.974	\N	2026-01-15 13:06:32.97824	2026-01-15 13:06:33.08	\N
67814812-4d4e-4a1b-8cd5-0af146bf41e2	13b5ef36-7b4a-40c8-ae5d-3aa376467a34	HP-HS-2026-SML-000001	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Homestay 1	silver	gp	1	Shimla	\N	Chaupal	\N	\N	\N	Village AAA	\N		\N		Sondh Niwas, Lower Lakkar Bazar ,\nApple Tree	171710		\N	\N	\N	Test Test	female	6666666611	test@test.com	Test Test	666666666611	d_o	owned	0.00	new_project	1000.00	sqm	1	1	800.00	2498.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N				Fire Safety Equipment Details (Annexure-I #6g) *		{"cctv": true, "fireSafety": true}	{}	{"1": true, "2": true, "3": true, "4": true, "5": true, "6": true, "7": true, "8": true, "9": true, "10": true, "11": true, "12": true, "13": true, "14": true, "15": true, "16": true, "17": true, "18": true}	\N	\N	3000.00	3000.00	0.00	150.00	0.00	150.00	2850.00	0.00	0.00	draft	\N	5	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	2026-01-12 11:13:19.821657	2026-01-12 17:55:06.404	\N
b2860363-180a-40e7-a835-7b7d55e53bf7	aa54f8a2-a077-4615-8679-1fa61d85f04a	HP-HS-2026-HMP-000017	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Hamirpur (Merged) Flow Property	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9507344278	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	6affed07-7898-4fc9-b86d-af1d610ad3ea	2026-01-15 13:16:14.375	2026-01-15 13:16:14.375	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "1ef6a155-8b3a-4f57-88c9-c5edef6d7a89", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:16:14.186	\N	2026-01-15 13:16:14.193205	2026-01-15 13:16:14.375	\N
d85406fa-5e1b-4623-bc29-bd6b80024dd3	23e4fa53-d9bd-4b6c-a958-3e92e74bdf90	HP-HS-2026-PNG-000015	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Pangi Fee Waiver Test Property	silver	gp	2	Pangi	\N	Pangi	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9387237659	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	1a8bab46-2d4c-4694-9009-12d50f644ec8	2026-01-15 13:16:13.705	2026-01-15 13:16:13.705	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "bb101236-63b2-41aa-9dc8-b374d1c7b129", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:16:13.49	\N	2026-01-15 13:16:13.498144	2026-01-15 13:16:13.705	\N
4a1b03ae-01cc-44cd-b513-fa1e45766342	8bee7c4a-9bd2-4231-b035-f00616fc3af5	HP-HS-2026-LAH-000016	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Kaza (Spiti) Flow Property	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9993513534	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	5da8ac27-6650-4982-b51a-a7e7c5257075	2026-01-15 13:16:14.064	2026-01-15 13:16:14.064	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "5056f5b2-b9b1-4cda-af02-213fb12836b5", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:16:13.828	\N	2026-01-15 13:16:13.851859	2026-01-15 13:16:14.064	\N
6b3e202c-2e16-4702-936d-c73d7f0e6b0d	05f9dca8-9c18-45e9-9ce0-ee719e04dfea	HP-HS-2026-PNG-000019	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Pangi Fee Waiver Test Property	silver	gp	2	Pangi	\N	Pangi	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9260539454	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	1a8bab46-2d4c-4694-9009-12d50f644ec8	2026-01-15 13:17:39.901	2026-01-15 13:17:39.901	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "4c14f8dc-0eef-4b07-9235-ea52e51f501d", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:17:39.66	\N	2026-01-15 13:17:39.672227	2026-01-15 13:17:39.901	\N
4ec594a0-8db8-48f7-98e9-067d70a2512a	528925ca-1b15-4382-9655-bfd346b76382	HP-HS-2026-LAH-000020	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Kaza (Spiti) Flow Property	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9373400121	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	5da8ac27-6650-4982-b51a-a7e7c5257075	2026-01-15 13:17:40.246	2026-01-15 13:17:40.246	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "3253ab04-1478-4a9a-993d-fa1e0336ed3c", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:17:40.027	\N	2026-01-15 13:17:40.035193	2026-01-15 13:17:40.246	\N
ff6a8c27-5c03-44ed-8df4-a379f64741c8	f7b801fa-0ef5-43e9-95e0-409790271f9e	HP-HS-2026-KUL-000038	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kullu 9175774061	gold	tcp	4	Kullu	\N	Manali	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9175774061	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "6b018409-61c6-4c7c-86f2-57c163bec7f5", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:47.041	\N	2026-01-15 14:00:47.049773	2026-01-15 14:00:47.223	\N
7e2c9070-be02-44d1-9172-d58edc1fe8eb	7d21d934-5f84-4f86-a74f-082a8dac21e1	HP-HS-2026-UNA-000002	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Test Property 1	silver	gp	1	Una	\N	Amb	\N	\N	\N	Village 1	\N	\N	\N	\N	House #13\nApple Tree	171001	\N	\N	\N	\N	Test Test	female	7777777711	test@test.com	Test Owner 5	777777777711	w_o	owned	0.00	new_project	1000.00	sqm	1	1	900.00	2500.00	0	2	\N	0.00	0	4	\N	0.00	1	\N	silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Fire Safety Equipment Details (Annexure-I #6g) *	\N	{"cctv": true, "fireSafety": true}	{}	{"1": true, "2": true, "3": true, "4": true, "5": true, "6": true, "7": true, "8": true, "9": true, "10": true, "11": true, "12": true, "13": true, "14": true, "15": true, "16": true, "17": true, "18": true}	\N	\N	3000.00	3000.00	0.00	150.00	0.00	150.00	2850.00	0.00	0.00	submitted	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "f6a15c87-e2cc-4bf7-82e8-212130ed5303", "url": "/api/local-object/download/5883e85f-ebec-4bc8-991c-189cf688f8ac?type=revenue-papers", "name": "Hindi_Test01.pdf", "type": "revenue_papers", "fileName": "Hindi_Test01.pdf", "filePath": "/api/local-object/download/5883e85f-ebec-4bc8-991c-189cf688f8ac?type=revenue-papers", "fileSize": 232135, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "8a1e9940-1254-4cbb-ad8f-47d3b7a5653d", "url": "/api/local-object/download/6cfbb4e2-4dd0-4f0c-89b9-99c04e4d6b57?type=affidavit-section29", "name": "Hindi_Test01.pdf", "type": "affidavit_section_29", "fileName": "Hindi_Test01.pdf", "filePath": "/api/local-object/download/6cfbb4e2-4dd0-4f0c-89b9-99c04e4d6b57?type=affidavit-section29", "fileSize": 232135, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "463962ed-ea6d-4b19-805e-12b0406633e1", "url": "/api/local-object/download/754f886e-bb4a-4f1c-a6fe-ab08df95cacd?type=undertaking-form-c", "name": "Hindi_Test01.pdf", "type": "undertaking_form_c", "fileName": "Hindi_Test01.pdf", "filePath": "/api/local-object/download/754f886e-bb4a-4f1c-a6fe-ab08df95cacd?type=undertaking-form-c", "fileSize": 232135, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "d4feca38-fbe9-46b1-8591-45807deb9931", "url": "/api/local-object/download/4834929c-e760-4136-8a6f-dbe927b54ad1?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/4834929c-e760-4136-8a6f-dbe927b54ad1?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "3dd8b75a-d74f-4553-b2df-21d9b06d61e1", "url": "/api/local-object/download/9e337e46-d0df-4a89-ba5d-dae8eff202c5?type=property-photo", "name": "529253340.jpg", "type": "property_photo", "fileName": "529253340.jpg", "filePath": "/api/local-object/download/9e337e46-d0df-4a89-ba5d-dae8eff202c5?type=property-photo", "fileSize": 13584, "mimeType": "image/jpeg", "documentType": "property_photo"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 09:45:25.721	\N	2026-01-15 09:42:34.310791	2026-01-15 09:45:25.721	205
e2b3164d-c007-43a9-a34f-626ff9b23ac3	76cfb0b9-31ce-42c9-bef3-f7078c4b61c0	HP-HS-2026-BIL-000018	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Mandi (Merged) Flow Property	gold	mc	4	Bilaspur	\N	Sadar	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9521953530	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	submitted	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "efeda55f-745a-46b7-a0e4-45420c8bae2f", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:16:14.485	\N	2026-01-15 13:16:14.488993	2026-01-15 13:16:14.488993	\N
bf49b055-a8dc-4e73-8119-576904d0e78b	8dd8642b-a59e-4beb-8866-cda32cbae6d3	HP-HS-2026-PNG-000012	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Pangi Fee Waiver Test Property	silver	gp	2	Pangi	\N	Pangi	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9802239637	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	1a8bab46-2d4c-4694-9009-12d50f644ec8	2026-01-15 13:11:32.72	2026-01-15 13:11:32.72	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "f0e529de-8bf4-4cae-ab23-3ac611818fc9", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:11:32.503	\N	2026-01-15 13:11:32.51009	2026-01-15 13:11:32.72	\N
223be33d-e90b-41d9-9e95-8061986be739	34b3e809-9941-4aa4-8176-da9aab2d0b81	HP-HS-2026-HMP-000014	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Hamirpur (Merged) Flow Property	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9705592112	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	6affed07-7898-4fc9-b86d-af1d610ad3ea	2026-01-15 13:11:33.306	2026-01-15 13:11:33.306	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "7adb1589-7889-4206-bb84-8f2503c3a008", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:11:33.119	\N	2026-01-15 13:11:33.126764	2026-01-15 13:11:33.306	\N
fb333b9e-39c1-44f6-bfca-04bb4cea0f31	4b1bf0bc-2d4c-4940-929e-3b5085a3838f	HP-HS-2026-LAH-000013	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Kaza (Spiti) Flow Property	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9949607511	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	5da8ac27-6650-4982-b51a-a7e7c5257075	2026-01-15 13:11:33.006	2026-01-15 13:11:33.006	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "b072f831-f0a2-420a-8944-468bc83e15c5", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:11:32.832	\N	2026-01-15 13:11:32.836796	2026-01-15 13:11:33.006	\N
44c93e5e-8fcf-4012-92a7-7c12778a7dd5	6f5b6051-150d-42b7-b535-ca36bd42d34d	HP-HS-2026-HMP-000021	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Hamirpur (Merged) Flow Property	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9920376644	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	6affed07-7898-4fc9-b86d-af1d610ad3ea	2026-01-15 13:17:40.577	2026-01-15 13:17:40.577	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "8866c4f9-bb67-4fc9-a732-04dbaa0457b6", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:17:40.375	\N	2026-01-15 13:17:40.3802	2026-01-15 13:17:40.577	\N
6852443d-8432-46ff-b332-eef72e339f42	3bb35af3-b2a5-4c2c-93f8-898c9df99693	HP-HS-2026-BIL-000022	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Mandi (Merged) Flow Property	gold	mc	4	Bilaspur	\N	Sadar	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9674194112	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	2026-01-15 13:17:40.887	2026-01-15 13:17:40.887	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "40601855-13e6-4862-b14d-85689da244b6", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:17:40.702	\N	2026-01-15 13:17:40.706421	2026-01-15 13:17:40.887	\N
f9e654ae-c40e-4101-a807-be2ca0d6b248	4bedfed3-5ed5-4f1f-9d26-cd9f6712c840	HP-HS-2026-LAH-000004	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Test Property 04	silver	gp	1	Lahaul-Spiti (Kaza)	\N	Spiti	\N	\N	\N	Test AAA	\N		\N		House #13\nApple Tree	171001		\N	\N	\N	Test BBB	female	7777777713	test@test.com	Test Owner 3	777777777713	d_o	owned	0.00	new_project	2.00	kanal	1	1	1500.00	2500.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	3	f	\N	\N	\N	\N	\N	\N	\N	\N	\N				Fire Safety Equipment Details (Annexure-I #6g) *		{"cctv": true, "fireSafety": true}	{}	{"1": true, "2": true, "3": true, "4": true, "5": true, "6": true, "7": true, "8": true, "9": true, "10": true, "11": true, "12": true, "13": true, "14": true, "15": true, "16": true, "17": true, "18": true}	\N	\N	3000.00	9000.00	900.00	405.00	0.00	1305.00	7695.00	0.00	0.00	submitted	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "dafb8d29-1e3b-4b89-a7ec-60fb98221e2a", "url": "/api/local-object/download/e3ce31c6-cde6-40d8-8c64-14efa7856697?type=revenue-papers", "name": "Test_Doc01-Hindi.pdf", "type": "revenue_papers", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/e3ce31c6-cde6-40d8-8c64-14efa7856697?type=revenue-papers", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "72548dca-dff1-4d8c-9623-9f7e64a752ff", "url": "/api/local-object/download/b930b932-fa87-4503-a565-633afce6b00c?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/b930b932-fa87-4503-a565-633afce6b00c?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "c99f71b4-b333-40bb-a646-b28e7225e427", "url": "/api/local-object/download/6c8171b1-851a-43c1-817d-82bf96b0401d?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/6c8171b1-851a-43c1-817d-82bf96b0401d?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "228c1620-ad48-477b-97f4-70af7aa26888", "url": "/api/local-object/download/9867c423-b0cd-4cf0-986f-40637d669b2a?type=property-photo", "name": "529253398.jpg", "type": "property_photo", "fileName": "529253398.jpg", "filePath": "/api/local-object/download/9867c423-b0cd-4cf0-986f-40637d669b2a?type=property-photo", "fileSize": 117294, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "223ea57a-1955-4d75-8c3d-5469911f0cfa", "url": "/api/local-object/download/e5c0a200-54ed-4f21-9b91-5b0852c7367e?type=property-photo", "name": "529253417.jpg", "type": "property_photo", "fileName": "529253417.jpg", "filePath": "/api/local-object/download/e5c0a200-54ed-4f21-9b91-5b0852c7367e?type=property-photo", "fileSize": 123434, "mimeType": "image/jpeg", "documentType": "property_photo"}]	\N	\N	\N	paid	A26A248960	1.00	2026-01-15 00:00:00	\N	\N	2026-01-15 12:24:31.481	\N	2026-01-15 12:15:46.099952	2026-01-15 12:24:31.481	\N
cf464eb0-cf46-4a7f-92c4-66dcca32e4c0	4c411a33-6024-4f42-990b-08cbb9ec9a7c	HP-HS-2026-PNG-000003	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Draft Homestay 3	gold	mc	1	Chamba	\N	Pangi	\N	\N	\N		\N	Pangi	\N		House #13\nApple Tree	171001		\N	\N	\N	Test AAA	female	7777777712	test@test.com	Test Owner 5	777777777712	w_o	owned	0.00	new_project	15.00	kanal	1	1	2000.00	3500.00	0	2	\N	0.00	0	4	\N	0.00	1	111111111111133	gold	\N	\N	\N	3	t	\N	\N	\N	\N	\N	\N	\N	\N	\N				Fire Safety Equipment Details (Annexure-I #6g) *		{"cctv": true, "fireSafety": true}	{}	{"1": true, "2": true, "3": true, "4": true, "5": true, "6": true, "7": true, "8": true, "9": true, "10": true, "11": true, "12": true, "13": true, "14": true, "15": true, "16": true, "17": true, "18": true}	\N	\N	12000.00	36000.00	3600.00	1620.00	15390.00	20610.00	15390.00	0.00	0.00	submitted	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "fbbe0403-2eab-4587-9659-eb2641f434ef", "url": "/api/local-object/download/7d116319-0301-4454-a872-4b2ea5ade9f2?type=revenue-papers", "name": "Test_Doc01-Hindi.pdf", "type": "revenue_papers", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/7d116319-0301-4454-a872-4b2ea5ade9f2?type=revenue-papers", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "50ecd480-50d9-479a-a652-1e44107a5983", "url": "/api/local-object/download/8bf83f4c-73e5-47ed-ae7f-1fcf90764bbd?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/8bf83f4c-73e5-47ed-ae7f-1fcf90764bbd?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "9191aaf7-1176-4aed-b129-8b89a87625d6", "url": "/api/local-object/download/9a812042-d6da-4772-a5f8-3de9b61aa313?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/9a812042-d6da-4772-a5f8-3de9b61aa313?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "7b990fce-760c-4d36-b4c7-b7d78e3e684b", "url": "/api/local-object/download/390c9dee-b741-49f2-b6dc-480eceb788fd?type=commercial-electricity-bill", "name": "Test_Doc01-Hindi.pdf", "type": "commercial_electricity_bill", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/390c9dee-b741-49f2-b6dc-480eceb788fd?type=commercial-electricity-bill", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "commercial_electricity_bill"}, {"id": "8e388d5f-9a25-4541-836e-28ce0ac36ec0", "url": "/api/local-object/download/2591f566-fe24-4153-b551-2ea2c2383156?type=commercial-water-bill", "name": "Test_Doc01-Hindi.pdf", "type": "commercial_water_bill", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/2591f566-fe24-4153-b551-2ea2c2383156?type=commercial-water-bill", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "commercial_water_bill"}, {"id": "8a5a60c8-fad9-4057-9dec-a39f9eb5af84", "url": "/api/local-object/download/3809b989-caa2-49ad-90ed-c92176a5c3a9?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/3809b989-caa2-49ad-90ed-c92176a5c3a9?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "16820394-3363-4c2f-9e32-97bcb09b5ea6", "url": "/api/local-object/download/ae3f1566-d238-4226-89e8-5efa3c31e19f?type=property-photo", "name": "529253340.jpg", "type": "property_photo", "fileName": "529253340.jpg", "filePath": "/api/local-object/download/ae3f1566-d238-4226-89e8-5efa3c31e19f?type=property-photo", "fileSize": 13584, "mimeType": "image/jpeg", "documentType": "property_photo"}]	\N	\N	\N	paid	A26A247041	1.00	2026-01-15 00:00:00	\N	\N	2026-01-15 10:27:13.748	\N	2026-01-15 09:48:26.576983	2026-01-15 10:27:13.748	\N
6994f862-11e6-4224-af91-16d62212a082	7b737110-8680-4dbb-985c-98e71dc2c305	HP-HS-2026-PNG-000005	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Pangi Fee Waiver Test Property	silver	gp	2	Pangi	\N	Pangi	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9965322743	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	submitted	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 12:55:23.133	\N	2026-01-15 12:55:23.14526	2026-01-15 12:55:23.14526	\N
33ad1b9a-6ec5-4dd2-adcf-7a223567f41d	5f094d1f-2296-4502-9af4-d5aa25fff8be	HP-HS-2026-PNG-000006	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Pangi Fee Waiver Test Property	silver	gp	2	Pangi	\N	Pangi	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9319660269	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 12:57:07.806	\N	2026-01-15 12:57:07.814767	2026-01-15 12:57:07.941	\N
f1ac720c-b358-4ce6-afdd-941e60691539	dc1c4494-a656-4f6a-be89-9c97b3b0f1d2	HP-HS-2026-LAH-000007	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Kaza (Spiti) Flow Property	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9190624118	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 12:57:08.073	\N	2026-01-15 12:57:08.079375	2026-01-15 12:57:08.183	\N
22f9aa2f-93a0-4781-a16f-ff669534503e	c8e2e777-b34d-4b39-aca8-bd5050838408	HP-HS-2026-HMP-000008	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Hamirpur (Merged) Flow Property	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9197980798	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 12:57:08.301	\N	2026-01-15 12:57:08.306042	2026-01-15 12:57:08.408	\N
b1670254-995e-427c-b9db-179891609a62	c55eb023-85e0-4630-a965-2a8817e116f4	HP-HS-2026-PNG-000009	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Pangi Fee Waiver Test Property	silver	gp	2	Pangi	\N	Pangi	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9214342827	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:06:32.452	\N	2026-01-15 13:06:32.461283	2026-01-15 13:06:32.592	\N
091839f8-e069-43c0-858b-b58c9274a447	c955fc27-7311-47e9-85da-c2e942c90035	HP-HS-2026-LAH-000010	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Kaza (Spiti) Flow Property	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9773386604	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:06:32.723	\N	2026-01-15 13:06:32.729028	2026-01-15 13:06:32.846	\N
1f78fd55-b3ed-4387-b6bd-29b67e9915e1	7a0223d0-1224-4ea4-90ea-436cec619d8c	HP-HS-2026-PNG-000023	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Pangi Fee Waiver Test Property	silver	gp	2	Pangi	\N	Pangi	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9714421076	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	1a8bab46-2d4c-4694-9009-12d50f644ec8	2026-01-15 13:36:31.154	2026-01-15 13:36:31.154	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "561389f0-202a-4aa0-8d7d-9177421ca17a", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:36:30.97	\N	2026-01-15 13:36:30.976649	2026-01-15 13:36:31.154	\N
978ab8eb-e9cf-4d0c-82eb-e4ddeb3b65fc	0806dfb8-3002-485c-9a0e-a44d4be4d39b	HP-HS-2026-LAH-000024	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Kaza (Spiti) Flow Property	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9431294583	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	5da8ac27-6650-4982-b51a-a7e7c5257075	2026-01-15 13:36:31.418	2026-01-15 13:36:31.418	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "b49c7312-3740-4bfb-a9a4-9e3f2cad4186", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:36:31.263	\N	2026-01-15 13:36:31.267874	2026-01-15 13:36:31.418	\N
528e0eb5-e4c8-44dd-9fb6-cc3cc22f95a3	ed4db028-54eb-40ff-a3df-0e2507ef4ffd	HP-HS-2026-HMP-000025	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Hamirpur (Merged) Flow Property	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9712985328	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	6affed07-7898-4fc9-b86d-af1d610ad3ea	2026-01-15 13:36:31.675	2026-01-15 13:36:31.675	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "c5c4e5fd-184f-4841-bd0f-d230ed6848c9", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:36:31.523	\N	2026-01-15 13:36:31.527002	2026-01-15 13:36:31.675	\N
2f116765-df0d-4af2-ba3c-3955435110e5	dd94c7c5-ed80-428a-bc72-2e7c201e93c9	HP-HS-2026-BIL-000026	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Mandi (Merged) Flow Property	gold	mc	4	Bilaspur	\N	Sadar	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9163292395	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	2026-01-15 13:36:31.929	2026-01-15 13:36:31.929	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "d31e47f6-c26e-4c42-88b5-28c32b5f9176", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:36:31.775	\N	2026-01-15 13:36:31.778763	2026-01-15 13:36:31.929	\N
8cc1f486-cd19-4135-82dd-00ddfa745838	ac827d2f-dd4a-460d-be2f-23ebad1fa102	HP-HS-2026-CHM-000027	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Chamba (Main) Flow Property	silver	gp	2	Chamba	\N	Chamba	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9863559181	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	efde4df9-1dcf-4d85-a9d3-151d17c8011d	2026-01-15 13:36:32.189	2026-01-15 13:36:32.189	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "3fbd6540-fa1a-4f3c-9262-c2db60135f8e", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:36:32.037	\N	2026-01-15 13:36:32.040665	2026-01-15 13:36:32.189	\N
94ade75a-5c5d-4e85-921f-fc60c0d500f8	c1521403-a2e5-4ef6-bdd0-1acb3cbc11c8	HP-HS-2026-KNG-000028	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Kangra Flow Property	diamond	mc	5	Kangra	\N	Dharamsala	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9395783884	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	b7987533-e127-4cad-8233-de0fdde7bbc7	2026-01-15 13:36:32.462	2026-01-15 13:36:32.462	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "0fc0f2f6-a7d2-46f5-ab54-0793584fab80", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:36:32.295	\N	2026-01-15 13:36:32.299863	2026-01-15 13:36:32.462	\N
1d3bb4e4-41d6-42a9-b2ec-7a9f6520b2e4	be7d6c59-eea4-43cf-852c-f29c6e7e79ce	HP-HS-2026-KUL-000030	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Kullu Flow Property	gold	tcp	4	Kullu	\N	Manali	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9587465284	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	d244a912-8065-4604-9b58-ba9b69d93e11	2026-01-15 13:36:32.965	2026-01-15 13:36:32.965	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "9e79ba04-ce68-4962-a512-f37c6bb5d006", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:36:32.818	\N	2026-01-15 13:36:32.823089	2026-01-15 13:36:32.965	\N
ce4b01d0-eed3-4f8b-8395-64a0ad54af68	89aad505-2170-453d-a0f6-94ac7c0e6d50	HP-HS-2026-KNR-000029	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Kinnaur Flow Property	silver	gp	2	Kinnaur	\N	Kalpa	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9199971784	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	6d27a721-acb4-4dab-95d9-0b2c91645234	2026-01-15 13:36:32.715	2026-01-15 13:36:32.715	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "f0b61153-02bd-42dd-af53-815308bebf72", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:36:32.571	\N	2026-01-15 13:36:32.575499	2026-01-15 13:36:32.715	\N
e96e5136-191e-447b-8a26-c80576f427f9	aa627e94-1265-4128-944e-7739565896f5	HP-HS-2026-LHL-000031	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Lahaul (Main) Flow Property	silver	gp	2	Lahaul	\N	Lahaul	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9474788497	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	249b7155-1f20-404f-b377-b0202b66a8a8	2026-01-15 13:36:33.203	2026-01-15 13:36:33.203	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "92abab9c-962f-4a96-9996-3b6bdc6226a7", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:36:33.067	\N	2026-01-15 13:36:33.070709	2026-01-15 13:36:33.203	\N
13e2ea6b-8f7d-4b05-8eb6-3510b5ee1505	3236f840-b1f9-4bee-87ce-26b85288c1ba	HP-HS-2026-SML-000032	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Shimla Flow Property	diamond	mc	5	Shimla	\N	Shimla (Urban)	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9971948395	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	a9a95a58-c2be-4175-83ed-7352a709c3c8	2026-01-15 13:36:33.466	2026-01-15 13:36:33.466	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "f0eaaaf3-7c94-42d0-b637-6b3a5380d299", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:36:33.303	\N	2026-01-15 13:36:33.306933	2026-01-15 13:36:33.466	\N
1973b255-2892-4668-920b-1808d3e74fab	d6e5a82f-6df3-4ced-965a-4c7f328f76e7	HP-HS-2026-SOL-000034	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Solan Flow Property	gold	mc	3	Solan	\N	Solan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9948233079	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	2026-01-15 13:36:33.949	2026-01-15 13:36:33.949	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "d383105a-b71a-4d7f-8232-189618a76c88", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:36:33.807	\N	2026-01-15 13:36:33.810497	2026-01-15 13:36:33.949	\N
9d91fed9-d0cb-4b51-8e0c-95c072cda015	c5ec7add-599c-406d-b813-ced3b9ea84a9	HP-HS-2026-SMR-000033	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Sirmaur Flow Property	gold	mc	3	Sirmaur	\N	Nahan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9418779337	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	2026-01-15 13:36:33.707	2026-01-15 13:36:33.707	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "4a44a304-d39a-4332-8dae-49f3e969f9ac", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 13:36:33.565	\N	2026-01-15 13:36:33.569081	2026-01-15 13:36:33.707	\N
78c90848-7e3a-4a38-a403-bc4052c0aa62	f200d4d5-d569-462c-88d9-1ea25fa7b766	HP-HS-2026-SOL-000036	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Solan 9989906755	gold	mc	3	Solan	\N	Solan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9989906755	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "0d1159b6-4415-4d77-ab9c-06de7175b1a3", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:46.636	\N	2026-01-15 14:00:46.647547	2026-01-15 14:00:46.806	\N
fd8745f9-9ae8-4753-a6c6-c03fce59d63e	b101b85e-abcb-49fe-b3f0-2f447c9a9f55	HP-HS-2026-KUL-000035	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kullu 9223772067	gold	tcp	4	Kullu	\N	Manali	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9223772067	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "57e3ccda-10ce-449c-80df-14c1012f6563", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:46.634	\N	2026-01-15 14:00:46.641396	2026-01-15 14:00:46.815	\N
a3b9fb40-9e19-4eca-b335-d7d1319088b8	a96bef40-5b38-4b9c-befb-86092cdc5f7c	HP-HS-2026-KNR-000035	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kinnaur 9563745587	silver	gp	2	Kinnaur	\N	Kalpa	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9563745587	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "0f0187da-79ba-4556-9d62-604322116f28", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:46.625	\N	2026-01-15 14:00:46.634026	2026-01-15 14:00:46.837	\N
6f5093be-7c13-4c55-b6cb-c04d8c9196f2	e989b0ee-dd0c-4ce9-8af8-781e8ba02f8e	HP-HS-2026-KNG-000037	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kangra 9503653791	diamond	mc	5	Kangra	\N	Dharamsala	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9503653791	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "a1cfc574-f6a1-433e-9926-447b70d766f6", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:46.689	\N	2026-01-15 14:00:46.695268	2026-01-15 14:00:46.871	\N
a9d8804e-6fcf-4908-a042-338ddfd39ead	4831861c-2c25-419b-a820-3a1ddf62a080	HP-HS-2026-SMR-000039	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Sirmaur 9946349954	gold	mc	3	Sirmaur	\N	Nahan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9946349954	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "ff1ad3e7-5a6f-47f0-a995-8c41cc93bbc4", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:47.07	\N	2026-01-15 14:00:47.077127	2026-01-15 14:00:47.255	\N
a77c0633-e08e-414d-a020-18c1bd3fad4b	9596014c-87b6-4e87-a28c-3c06c10ffba6	HP-HS-2026-LAH-000040	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Spiti 9252017646	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9252017646	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "52851f4b-e828-4cfd-9558-56a08baae7ca", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:47.086	\N	2026-01-15 14:00:47.091736	2026-01-15 14:00:47.284	\N
19e407b8-9d6c-4399-953a-37cfe3c3dec6	e24a09ce-1013-4dbf-8cfa-b13d0fb5aaf9	HP-HS-2026-LAH-000041	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Spiti 9162561900	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9162561900	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "8ffa68da-9143-486d-8e54-7ed01c910adb", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:47.152	\N	2026-01-15 14:00:47.160976	2026-01-15 14:00:47.336	\N
8754593e-05c9-45bb-8c16-436221cca004	a594f4f7-fd9f-40d6-a7d7-aeb205f64b0f	HP-HS-2026-PNG-000040	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Pangi 9829775880	silver	gp	2	Pangi	\N	Pangi	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9829775880	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "a4ec6140-d605-4ec3-a48d-9e75baea7e6a", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:47.089	\N	2026-01-15 14:00:47.096142	2026-01-15 14:00:47.289	\N
8e014860-05eb-4ed6-a369-69051ff56b36	b5b9fbf8-9ae8-4548-8299-83e455af8bfc	HP-HS-2026-PNG-000043	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Pangi 9514763560	silver	gp	2	Pangi	\N	Pangi	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9514763560	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "4e108fe7-b825-4349-bcdd-09c905172444", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:47.598	\N	2026-01-15 14:00:47.608963	2026-01-15 14:00:47.785	\N
420e6c2f-d9b3-4e69-956d-b4f3473d3259	11e60245-7268-4e93-9045-4d9ca1ea5b33	HP-HS-2026-PNG-000052	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Pangi 9661365225	silver	gp	2	Pangi	\N	Pangi	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9661365225	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "621ee7b4-6d44-4e96-b178-d886a7e11c4b", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.97	\N	2026-01-15 14:00:48.97946	2026-01-15 14:00:49.153	\N
61f54434-eed3-4db6-9fc5-c08826ef91e3	8aefe55b-5e79-4a19-b105-eba4b6eba999	HP-HS-2026-HMP-000053	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Hamirpur 9839782758	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9839782758	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "a29412d4-17a9-49b4-a954-305aaad769e6", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:49.026	\N	2026-01-15 14:00:49.030824	2026-01-15 14:00:49.219	\N
85fb2d9e-bbff-43ef-89cb-8195e84aea55	162158b1-c39a-48d0-a09c-1c1e12e83a9a	HP-HS-2026-KNG-000061	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kangra 9745707674	diamond	mc	5	Kangra	\N	Dharamsala	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9745707674	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "1008c432-b34e-4be4-87a3-6fbd027da66a", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:49.919	\N	2026-01-15 14:00:49.929008	2026-01-15 14:00:50.135	\N
e86e8da7-8104-4ab1-a6be-361005d53180	e9813c7e-af8e-4fd1-8115-8849cd2ac909	HP-HS-2026-KNR-000044	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kinnaur 9508773363	silver	gp	2	Kinnaur	\N	Kalpa	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9508773363	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "5ce7953e-100d-4665-81d4-e8798089eb33", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:47.611	\N	2026-01-15 14:00:47.621839	2026-01-15 14:00:47.808	\N
9f46af13-a978-4176-be50-6bc3ac8f8fed	8f167a42-a2e0-4fcf-bbd1-0853e57d6046	HP-HS-2026-CHM-000045	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Chamba Main 9779467155	silver	gp	2	Chamba	\N	Chamba	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9779467155	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "5e089f28-c736-498c-8a5e-e55622a99d2b", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.066	\N	2026-01-15 14:00:48.081878	2026-01-15 14:00:48.26	\N
8386817a-6e4f-4742-9ec2-f0a42931a7d2	792561d8-b915-4eaf-8854-e1b46099495a	HP-HS-2026-SML-000048	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Shimla 9106394336	diamond	mc	5	Shimla	\N	Shimla (Urban)	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9106394336	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "66af2c52-7f45-4806-b22d-08ef71adc537", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.524	\N	2026-01-15 14:00:48.532902	2026-01-15 14:00:48.683	\N
0d622163-7e73-416b-b3c0-df5e97333038	e38a12af-59f4-4657-a6b7-f9444d0a131e	HP-HS-2026-LHL-000054	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Lahaul Main 9446121812	silver	gp	2	Lahaul	\N	Lahaul	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9446121812	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "645a8e9c-9667-4e4f-8548-3c82c0aaeb19", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:49.386	\N	2026-01-15 14:00:49.397728	2026-01-15 14:00:49.563	\N
93167516-1a44-4ad4-9636-e9d908c63d97	945e7edc-69fc-45ea-a032-1432eb37f579	HP-HS-2026-KUL-000059	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kullu 9498188042	gold	tcp	4	Kullu	\N	Manali	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9498188042	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "699951f9-7144-4221-9a43-886068d6b2e6", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:49.829	\N	2026-01-15 14:00:49.835421	2026-01-15 14:00:49.997	\N
de23380e-153e-4ff2-b270-a857f00d4a7d	e0e71fd9-a2cf-454e-a357-371aab801a02	HP-HS-2026-SOL-000062	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Solan 9798480857	gold	mc	3	Solan	\N	Solan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9798480857	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "3ef543d7-c9e4-4461-b0d9-d7f589d68dcd", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:50.284	\N	2026-01-15 14:00:50.290717	2026-01-15 14:00:50.497	\N
24f391de-3450-41c7-859b-6f8a5fa046df	673fe948-c92f-4b68-85c2-9a2d7dfea971	HP-HS-2026-KUL-000065	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kullu 9428928601	gold	tcp	4	Kullu	\N	Manali	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9428928601	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "48d5787a-cf08-4cb7-b990-56a5e1e92fe4", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:50.728	\N	2026-01-15 14:00:50.734879	2026-01-15 14:00:50.916	\N
b129be29-244b-4346-8773-9b368d9df5fd	edb09e03-c176-459e-a2b4-5cffa2089a6e	HP-HS-2026-HMP-000069	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Hamirpur 9346256527	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9346256527	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "9dbc1a63-55cf-46e4-bee3-1853c7b0df4c", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.182	\N	2026-01-15 14:00:51.193173	2026-01-15 14:00:51.356	\N
fcaf36d1-972e-4822-8320-772cc152e09f	fdf23724-9ca5-47be-93cb-3cf5340f7166	HP-HS-2026-SML-000044	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Shimla 9517412851	diamond	mc	5	Shimla	\N	Shimla (Urban)	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9517412851	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "16dc7773-2cbb-4b99-99ba-25deeec84d98", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:47.622	\N	2026-01-15 14:00:47.630715	2026-01-15 14:00:47.909	\N
738c76d3-886b-40b5-8091-b01cf4ff7466	f0e9b06e-a4da-453b-807a-aed75923e521	HP-HS-2026-CHM-000046	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Chamba Main 9337271202	silver	gp	2	Chamba	\N	Chamba	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9337271202	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "c821ecee-945f-44d7-8028-4e4e5a605e62", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.092	\N	2026-01-15 14:00:48.103197	2026-01-15 14:00:48.303	\N
cf0ee44c-3899-4297-80b0-c6c45d1cbe61	e9a64da4-b83d-4fa6-bcf7-7ba7efc32036	HP-HS-2026-HMP-000049	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Hamirpur 9574843713	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9574843713	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "a2792a9f-9b33-4bd0-a40a-d195ac041de4", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.539	\N	2026-01-15 14:00:48.546395	2026-01-15 14:00:48.707	\N
073fcd8a-f9c4-46f9-babe-511fd8f752e9	c379e771-2fb9-444d-af77-f7037f9f85db	HP-HS-2026-SOL-000052	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Solan 9957457277	gold	mc	3	Solan	\N	Solan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9957457277	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "c642f6b5-ed4c-4982-8ed8-5cacd0c935c3", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.951	\N	2026-01-15 14:00:48.966361	2026-01-15 14:00:49.141	\N
1817e02b-530f-4c0b-9eb8-70a7f0c79677	f48891fe-0336-457e-9407-bcb7486b3247	HP-HS-2026-KNG-000057	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kangra 9813576160	diamond	mc	5	Kangra	\N	Dharamsala	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9813576160	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "6a287b8a-269f-4f96-8fc4-6f2e64e49311", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:49.432	\N	2026-01-15 14:00:49.440155	2026-01-15 14:00:49.627	\N
5e63c91f-42b8-4f8e-811d-91baa4d7d67f	01a776c9-bf4d-44e1-9124-729c088ab3fe	HP-HS-2026-KUL-000060	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kullu 9511806935	gold	tcp	4	Kullu	\N	Manali	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9511806935	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "aac734b4-6ed3-414a-96cf-d4605b0989a3", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:49.844	\N	2026-01-15 14:00:49.858305	2026-01-15 14:00:50.058	\N
17c96178-51fc-4bd5-a0f2-08233a50be60	33d7ab6b-6701-4764-8185-63d89e2e6e34	HP-HS-2026-KNG-000062	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kangra 9157284347	diamond	mc	5	Kangra	\N	Dharamsala	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9157284347	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "0ba402b7-98cf-40c5-adcc-99af80f27e55", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:50.292	\N	2026-01-15 14:00:50.30086	2026-01-15 14:00:50.45	\N
f8678397-122c-4899-b691-c01c3ec1d9db	6e8e1f43-15eb-42f6-a680-9e4c44192952	HP-HS-2026-LHL-000063	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Lahaul Main 9183254736	silver	gp	2	Lahaul	\N	Lahaul	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9183254736	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "e9f8526f-13eb-4887-9222-136e80e70f26", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:50.362	\N	2026-01-15 14:00:50.36978	2026-01-15 14:00:50.539	\N
4146533f-6433-493e-9f53-2c4bb5607a12	cbef38fc-8cce-4eb9-ab5b-39cbb2d28038	HP-HS-2026-BIL-000042	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Bilaspur 9962889767	gold	mc	4	Bilaspur	\N	Sadar	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9962889767	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "7c13b3b0-22d3-4330-bee4-1563a08037e1", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:47.554	\N	2026-01-15 14:00:47.567667	2026-01-15 14:00:47.763	\N
fd23b7ab-c41a-45c3-af4f-ff12570887b3	a7562a1d-5b77-4b23-944b-6c44b3b416d3	HP-HS-2026-LAH-000042	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Spiti 9241632254	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9241632254	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "410e75fe-d7d7-4345-b1b8-c2950ac38362", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:47.55	\N	2026-01-15 14:00:47.559806	2026-01-15 14:00:47.783	\N
a3e21aab-0ba6-4cfa-b249-98988e76c168	fe41e63b-04bf-4051-9588-c673afb3fbe4	HP-HS-2026-KNR-000045	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kinnaur 9343338009	silver	gp	2	Kinnaur	\N	Kalpa	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9343338009	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "969e65dd-f093-4ad0-a7a3-944963b19c4a", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.082	\N	2026-01-15 14:00:48.090038	2026-01-15 14:00:48.242	\N
43bd665e-3464-449a-9a9d-bd7af94538eb	0855fedb-bc57-44a6-80ea-6db0044f1f9c	HP-HS-2026-SOL-000046	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Solan 9683754371	gold	mc	3	Solan	\N	Solan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9683754371	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "a664ac45-05ab-4d15-a08e-fe3ec23ab283", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.086	\N	2026-01-15 14:00:48.096203	2026-01-15 14:00:48.322	\N
78edd442-343a-4932-b425-b567e60970b4	323f9bcd-7a71-47ba-8546-219347c8c03a	HP-HS-2026-SOL-000047	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Solan 9357072687	gold	mc	3	Solan	\N	Solan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9357072687	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "47570b7c-7012-439d-96a9-d5afccd8a06c", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.177	\N	2026-01-15 14:00:48.186621	2026-01-15 14:00:48.357	\N
12a716ff-1ea9-4e7b-9184-7d15100d77c0	43815dc3-4cb4-41ae-983b-4a1e7d5315fa	HP-HS-2026-CHM-000048	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Chamba Main 9579733663	silver	gp	2	Chamba	\N	Chamba	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9579733663	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "e185f30c-f46a-4aa9-96eb-e211387622b0", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.523	\N	2026-01-15 14:00:48.52879	2026-01-15 14:00:48.719	\N
868a4752-fe41-4605-93ef-d4574e10f6f3	e4d444d9-e616-4f32-bf82-498726cf3969	HP-HS-2026-LAH-000048	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Spiti 9676103308	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9676103308	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "31fcaecc-1f28-415e-8799-021272d27e85", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.529	\N	2026-01-15 14:00:48.539506	2026-01-15 14:00:48.754	\N
6c67e88c-83e0-4252-a3d0-8ebf8ec57597	036933d3-d229-49b1-9bbe-25e92800ce81	HP-HS-2026-KUL-000050	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kullu 9743514252	gold	tcp	4	Kullu	\N	Manali	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9743514252	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "104c6a39-247b-44a8-b1ff-c4e3661b7d3d", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.61	\N	2026-01-15 14:00:48.620192	2026-01-15 14:00:48.779	\N
d8e6c412-3d42-43c6-824b-d2aa7aa76abd	411c21e8-35c2-44a6-a02b-f356d5d0622c	HP-HS-2026-LHL-000052	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Lahaul Main 9203852905	silver	gp	2	Lahaul	\N	Lahaul	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9203852905	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "db88c3b0-0c4c-48dd-aa4e-6c6ca59362ad", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.969	\N	2026-01-15 14:00:48.975795	2026-01-15 14:00:49.192	\N
2ea0bab9-6a75-4eed-8f17-4faf84c69734	f3941361-fb0b-4a28-b9a6-028fcd2e76f9	HP-HS-2026-BIL-000064	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Bilaspur 9883451148	gold	mc	4	Bilaspur	\N	Sadar	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9883451148	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "d89f3b30-9991-431d-8164-48b73d9ad55b", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:50.705	\N	2026-01-15 14:00:50.713861	2026-01-15 14:00:50.874	\N
868feb27-e66d-46b4-8a37-4c8916ee910f	f625569e-44c7-4f5f-9e88-d1ebe5418f08	HP-HS-2026-KUL-000067	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kullu 9896556910	gold	tcp	4	Kullu	\N	Manali	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9896556910	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "06727ab1-ff2b-410f-9345-7b886a27b214", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.097	\N	2026-01-15 14:00:51.101002	2026-01-15 14:00:51.246	\N
ddb38037-ea8d-4d1e-969a-38c7bf65ee18	696a388e-c768-415b-b189-ab933b68572e	HP-HS-2026-HMP-000072	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Hamirpur 9615790852	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9615790852	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "3f7b5f9e-344f-444e-9252-057d099d22c7", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.598	\N	2026-01-15 14:00:51.604758	2026-01-15 14:00:51.766	\N
ef4aaed1-3e89-401c-b184-2cefd24958ec	ea7e35ec-cfcd-48c5-90e0-60c08b8dbd27	HP-HS-2026-LHL-000073	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Lahaul Main 9646606801	silver	gp	2	Lahaul	\N	Lahaul	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9646606801	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "39905713-656c-4cb1-a86d-834b5e5e7519", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.902	\N	2026-01-15 14:00:51.909459	2026-01-15 14:00:52.048	\N
2dd5e603-37bb-4cb3-a92d-ea6c110a5700	95635d39-c9be-4c3d-8046-8462e3820449	HP-HS-2026-HMP-000078	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Hamirpur 9653908971	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9653908971	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "5caef8ad-8ade-4b92-a7dc-90d77af96c95", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:52.357	\N	2026-01-15 14:00:52.364807	2026-01-15 14:00:52.56	\N
a934be0e-3011-4392-a09f-f3c064591647	6d94db75-af33-4cda-8497-ae8f76392493	HP-HS-2026-LHL-000079	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Lahaul Main 9431406151	silver	gp	2	Lahaul	\N	Lahaul	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9431406151	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "a2419b40-7ce9-4c1a-a2ed-c79fcf452189", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:52.702	\N	2026-01-15 14:00:52.711966	2026-01-15 14:00:52.858	\N
0396737e-066a-4c33-a276-0fdb8ef74731	a2bec987-4d03-418b-804e-69b9720b5f27	HP-HS-2026-HMP-000079	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Hamirpur 9405879103	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9405879103	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "0f550019-8c00-41f5-8b52-4e26f37aa01b", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:52.707	\N	2026-01-15 14:00:52.71553	2026-01-15 14:00:52.886	\N
913053e3-3766-4556-8abf-d952e4158780	4f0d7650-cf3e-4ed4-8a80-64e002cc6056	HP-HS-2026-HMP-000051	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Hamirpur 9705781325	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9705781325	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "7bab70c8-8892-4a80-8a62-c256755dd19c", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:48.932	\N	2026-01-15 14:00:48.939648	2026-01-15 14:00:49.121	\N
6d6853e9-6154-47d3-a1e7-109676e3411d	406c81de-5940-4e75-b942-aa769dca8b40	HP-HS-2026-BIL-000056	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Bilaspur 9784282893	gold	mc	4	Bilaspur	\N	Sadar	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9784282893	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "3fa69557-8957-4e61-819e-8c81f724c4af", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:49.417	\N	2026-01-15 14:00:49.425106	2026-01-15 14:00:49.636	\N
d6025bfb-4961-4da6-a0f0-8d8a5b889cf0	046e9240-3b2f-4463-a9c9-d22a00815ec7	HP-HS-2026-CHM-000059	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Chamba Main 9103841154	silver	gp	2	Chamba	\N	Chamba	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9103841154	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "ee71e71d-2d29-4095-a75d-e05cdc852708", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:49.831	\N	2026-01-15 14:00:49.839952	2026-01-15 14:00:50.038	\N
f1f46c71-cd29-4e57-8806-95b6f6181204	380b5741-582b-4f6f-b858-9ae53ea54a87	HP-HS-2026-KNR-000066	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kinnaur 9951344325	silver	gp	2	Kinnaur	\N	Kalpa	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9951344325	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "642845b0-91c2-4a1b-9bed-720e04099034", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:50.776	\N	2026-01-15 14:00:50.780179	2026-01-15 14:00:50.956	\N
b2f51457-0fbf-423c-8e49-f799c759202f	5d7509e3-6170-4772-a091-c9d1bf9a1a3c	HP-HS-2026-LAH-000070	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Spiti 9250839957	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9250839957	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "f84b72e7-a01b-42a7-b30a-565e405080eb", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.514	\N	2026-01-15 14:00:51.524659	2026-01-15 14:00:51.728	\N
902d09ea-7181-4451-9384-4ca426eb6ebd	dd25cdb7-53f5-46c2-a8c4-d80ea9550e28	HP-HS-2026-BIL-000074	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Bilaspur 9249046780	gold	mc	4	Bilaspur	\N	Sadar	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9249046780	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "ea17be30-4254-478a-a706-56f46dfdf9f8", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.916	\N	2026-01-15 14:00:51.924701	2026-01-15 14:00:52.102	\N
1b85a8ec-ff6a-483a-b80a-484f6c349a74	ca4eeec9-baa2-4bec-a33e-7d3993a6b89e	HP-HS-2026-LHL-000077	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Lahaul Main 9495135166	silver	gp	2	Lahaul	\N	Lahaul	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9495135166	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "28e57cc7-9e2c-4f1a-8ad7-c9ac14b82400", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:52.292	\N	2026-01-15 14:00:52.296974	2026-01-15 14:00:52.469	\N
822f5c3d-d20c-44d9-b3bf-4eb5ac3531fd	8ca9bb48-9ed8-4319-9f78-c675ad31e10e	HP-HS-2026-HMP-000080	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Hamirpur 9285416612	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9285416612	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "42e47576-3972-4899-857b-92771eac4e07", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:52.78	\N	2026-01-15 14:00:52.785289	2026-01-15 14:00:52.947	\N
dc63fd1f-85dc-4012-9bc4-48959bdd5170	7d7d96b1-2f68-433b-b9d3-72955888d279	HP-HS-2026-SML-000055	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Shimla 9434955366	diamond	mc	5	Shimla	\N	Shimla (Urban)	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9434955366	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "3545c429-3ef6-4af1-8d12-4a138aaf7128", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:49.4	\N	2026-01-15 14:00:49.408324	2026-01-15 14:00:49.58	\N
e7cd27b0-045c-481f-9d50-d0f408f80a42	a1771b13-6785-41fe-987c-0a6cf789e278	HP-HS-2026-LHL-000058	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Lahaul Main 9600728499	silver	gp	2	Lahaul	\N	Lahaul	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9600728499	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "11b49106-9d36-4e17-92de-51514b5dfae8", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:49.479	\N	2026-01-15 14:00:49.486049	2026-01-15 14:00:49.67	\N
fd4ab56b-3774-4213-81b4-8ae96852109c	a55511fc-f7db-4788-8015-4fc0b501856a	HP-HS-2026-LAH-000060	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Spiti 9399864397	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9399864397	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "8eaf8a42-6f1a-4db1-89a2-acc236e869ce", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:49.842	\N	2026-01-15 14:00:49.848659	2026-01-15 14:00:50.079	\N
8057b346-f45a-465d-8ef3-99a2648073dd	e7f15b4a-2b41-4a07-bd16-f956fb01daa4	HP-HS-2026-BIL-000062	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Bilaspur 9945480524	gold	mc	4	Bilaspur	\N	Sadar	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9945480524	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "0099165f-a896-4ae7-99ca-a0bfdbb5654a", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:50.292	\N	2026-01-15 14:00:50.295358	2026-01-15 14:00:50.493	\N
2250f86d-c678-45c0-a263-fca010810f27	1fce905f-56b3-4cda-9c74-9d9f50d43e06	HP-HS-2026-SML-000065	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Shimla 9474528189	diamond	mc	5	Shimla	\N	Shimla (Urban)	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9474528189	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "6e108286-be86-4541-b32b-55efb8355ecd", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:50.726	\N	2026-01-15 14:00:50.730783	2026-01-15 14:00:50.872	\N
98d6f7c4-6468-4a62-bd0f-c7a4885c460c	b125661e-cd86-46d8-a22d-8e5f2cc750fe	HP-HS-2026-LAH-000068	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Spiti 9412209388	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9412209388	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "b2f863e9-8ac4-4fe6-a3f0-be067484e694", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.108	\N	2026-01-15 14:00:51.119207	2026-01-15 14:00:51.321	\N
29daf7b4-9b97-4d7e-a43a-ebf26d74688f	a2575f11-7e3f-48da-a03e-2b1f49b00e1d	HP-HS-2026-KNG-000071	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kangra 9529684539	diamond	mc	5	Kangra	\N	Dharamsala	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9529684539	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "da3a5450-23e0-4451-941d-2a7ac1e63f45", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.529	\N	2026-01-15 14:00:51.537031	2026-01-15 14:00:51.696	\N
7138043d-72c0-47e2-828b-b182eb1feee9	54eb4664-f445-4e24-ab4c-6978bef45607	HP-HS-2026-CHM-000077	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Chamba Main 9484826171	silver	gp	2	Chamba	\N	Chamba	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9484826171	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "68634093-391d-4463-9219-fa340ffc85fd", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:52.291	\N	2026-01-15 14:00:52.304951	2026-01-15 14:00:52.535	\N
154c6651-7315-4711-8f79-0549a4b6c44f	8b7896de-7997-448c-bb8d-27e3c9731e85	HP-HS-2026-SOL-000064	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Solan 9314605269	gold	mc	3	Solan	\N	Solan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9314605269	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "7c8d7ec6-33ef-4416-87bb-114b4f248ca2", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:50.713	\N	2026-01-15 14:00:50.72257	2026-01-15 14:00:50.885	\N
906e1a03-fdb6-4934-8706-b33b42d523bb	acf9c22d-3a81-4318-ba4a-79833503f9b5	HP-HS-2026-KNG-000068	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kangra 9226123980	diamond	mc	5	Kangra	\N	Dharamsala	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9226123980	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "1b788a7e-7f60-45e3-822c-1dfe8961d68c", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.115	\N	2026-01-15 14:00:51.123747	2026-01-15 14:00:51.32	\N
9abf87b1-83bd-4d80-98fb-cecfc09311ef	fb07e036-4faa-4031-93a1-16f3cb827fa3	HP-HS-2026-SMR-000070	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Sirmaur 9647203911	gold	mc	3	Sirmaur	\N	Nahan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9647203911	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "c8732000-d875-4fad-8c29-9be25f02d836", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.52	\N	2026-01-15 14:00:51.529028	2026-01-15 14:00:51.692	\N
f876b83e-9983-4641-b332-15bb05c641aa	98a4acdd-e2f4-4a89-bd14-86ea24657d21	HP-HS-2026-SMR-000073	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Sirmaur 9279834117	gold	mc	3	Sirmaur	\N	Nahan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9279834117	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "7b8cdd99-729a-409e-96be-26a93b0b48b0", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.909	\N	2026-01-15 14:00:51.919182	2026-01-15 14:00:52.067	\N
40c0c66e-e693-470e-a0fd-e77f71021748	0988d42a-c1dc-4132-a11e-a8525c317065	HP-HS-2026-CHM-000075	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Chamba Main 9461205243	silver	gp	2	Chamba	\N	Chamba	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9461205243	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "dca2436f-40ba-494b-84b5-a44bed345a4d", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.982	\N	2026-01-15 14:00:51.986058	2026-01-15 14:00:52.123	\N
05a9f9df-2c59-43c9-bc06-24d69571e90b	46aaeedd-b2f4-4161-99b9-6f4c182877af	HP-HS-2026-HMP-000076	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Hamirpur 9453263898	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9453263898	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "bc5fbb6a-a213-4b36-8bc7-13140d28ccf1", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:52.278	\N	2026-01-15 14:00:52.290702	2026-01-15 14:00:52.457	\N
aa7c3fa6-0ec5-45bf-88b2-5cade216be14	f46e48c4-b313-4733-bec4-89be2f78f354	HP-HS-2026-BIL-000081	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Bilaspur 9575405341	gold	mc	4	Bilaspur	\N	Sadar	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9575405341	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "c3eb1fa5-7d34-45c6-bbaa-27717eb8890c", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.1	\N	2026-01-15 14:00:53.113532	2026-01-15 14:00:53.253	\N
0b38f2cb-09da-41e1-ba7e-998cf76a190c	9a50c9f1-e9e6-4f51-9c12-56f66794b518	HP-HS-2026-HMP-000082	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Hamirpur 9817574824	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9817574824	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "d13beb5f-475e-49b4-9d2c-9f23d77caf4e", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.176	\N	2026-01-15 14:00:53.180151	2026-01-15 14:00:53.339	\N
a2d13a0d-a5e5-4cc9-aed8-52b9e242f21c	e10b5523-68cf-4bb5-b92a-e3aa1690e2df	HP-HS-2026-CHM-000067	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Chamba Main 9166104791	silver	gp	2	Chamba	\N	Chamba	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9166104791	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "63d96f3f-c26a-4b0e-a262-4d1a7bb754c7", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.098	\N	2026-01-15 14:00:51.106072	2026-01-15 14:00:51.306	\N
59151e7a-d851-4fca-b29d-5ab2cb876e00	e5bb23b9-51e4-450b-85c2-550162dc77d8	HP-HS-2026-SOL-000070	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Solan 9491655937	gold	mc	3	Solan	\N	Solan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9491655937	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "a8c6d6f4-a30e-4d14-8910-d66ee19562c0", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:51.513	\N	2026-01-15 14:00:51.518689	2026-01-15 14:00:51.673	\N
04d6b8c1-ddd0-411d-9ed2-4b862ea6d7cc	b68f1178-5ef8-4655-8f2c-bea5ab0497a0	HP-HS-2026-KUL-000076	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kullu 9858047317	gold	tcp	4	Kullu	\N	Manali	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9858047317	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "941d139d-492e-4dd9-823e-a84182f1b8cc", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:52.278	\N	2026-01-15 14:00:52.284673	2026-01-15 14:00:52.506	\N
69fe1a8a-0c0c-4f4e-91ae-58a0a2a99965	d7ef0c54-60e5-4dec-b649-8d9f1d351888	HP-HS-2026-KNR-000079	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kinnaur 9194574345	silver	gp	2	Kinnaur	\N	Kalpa	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9194574345	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "59625794-c887-4fc7-a810-80e4a15adeb8", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:52.708	\N	2026-01-15 14:00:52.7181	2026-01-15 14:00:52.929	\N
cadeae01-c10d-475c-9b06-ad456d8b4fb7	c76fa3ef-24b5-4e46-af49-360b7d0f994e	HP-HS-2026-LAH-000083	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Spiti 9603304170	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9603304170	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "7420109a-92ac-4a3a-bf7e-96e8dc76555f", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.488	\N	2026-01-15 14:00:53.495233	2026-01-15 14:00:53.651	\N
30cc8c65-da6a-4ab7-8626-c0de9cb8bb6b	05b04ffb-fc9c-4e98-86c3-9e458bb985e7	HP-HS-2026-SOL-000083	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Solan 9501536910	gold	mc	3	Solan	\N	Solan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9501536910	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "8fb601c9-46f0-45fd-a067-1a6053d52e2c", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.491	\N	2026-01-15 14:00:53.498125	2026-01-15 14:00:53.679	\N
c4cd4f33-2cda-4e66-bc2f-c89fe58cd65a	b50d541a-07ba-4850-9bad-918f237557e4	HP-HS-2026-SML-000087	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Shimla 9828093904	diamond	mc	5	Shimla	\N	Shimla (Urban)	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9828093904	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "77fbe91a-ff4d-413a-b7d6-ba4331802b7e", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.918	\N	2026-01-15 14:00:53.925295	2026-01-15 14:00:54.064	\N
68f85f6d-d5f2-4d5f-b2ed-84f6ad1b6a30	9e29b6ad-8a1b-47c8-a281-8396f616fafd	HP-HS-2026-KNG-000086	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kangra 9256041176	diamond	mc	5	Kangra	\N	Dharamsala	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9256041176	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "c3ae941f-cbbe-4467-bd8d-4e562cf83285", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.898	\N	2026-01-15 14:00:53.905639	2026-01-15 14:00:54.066	\N
198c49bb-a739-4a9c-bc16-ab331ba5376b	24ede4da-51f7-48bc-916e-41fb15f9e280	HP-HS-2026-SOL-000091	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Solan 9140537016	gold	mc	3	Solan	\N	Solan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9140537016	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "cc4560b7-2268-4873-a8f8-7230c87e830e", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:54.324	\N	2026-01-15 14:00:54.329869	2026-01-15 14:00:54.489	\N
b65e1c81-9be9-4203-ba1f-57589ea3b14c	7f9fb533-90ca-4e92-bc5c-0c5282eca554	HP-HS-2026-KNR-000096	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kinnaur 9522112869	silver	gp	2	Kinnaur	\N	Kalpa	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9522112869	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "d4b373a6-937a-44e3-b855-3b2d4162b2d4", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:54.809	\N	2026-01-15 14:00:54.817279	2026-01-15 14:00:54.981	\N
bedf8398-fb71-4285-bc17-f0ac181e9224	960466d6-6220-4429-bfa4-8c2659dcaae8	HP-HS-2026-LHL-000097	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Lahaul Main 9252159510	silver	gp	2	Lahaul	\N	Lahaul	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9252159510	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "3da00ffd-952b-4bc4-8a80-4b0e8226982e", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:54.824	\N	2026-01-15 14:00:54.828747	2026-01-15 14:00:55.092	\N
b01a0e08-306a-4f05-88e3-317ece2172a7	3a57bd93-ec0a-498d-8002-791de5545758	HP-HS-2026-LAH-000079	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Spiti 9800516572	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9800516572	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "f873b669-b211-439c-aa4d-002e4dc2b877", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:52.712	\N	2026-01-15 14:00:52.721501	2026-01-15 14:00:52.86	\N
2771b4ad-0e39-49e9-9e13-5df01e725eb1	c2803612-a34b-4ed7-a3fe-3295c2a91980	HP-HS-2026-PNG-000081	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Pangi 9356091186	silver	gp	2	Pangi	\N	Pangi	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9356091186	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "6412584d-d605-403e-bb39-4b50489cf9df", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.105	\N	2026-01-15 14:00:53.112714	2026-01-15 14:00:53.282	\N
b06ed3c3-31bb-46f2-9f95-926c39343315	d6269133-c1b6-4ccb-96a7-071892d618ea	HP-HS-2026-SMR-000081	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Sirmaur 9479152559	gold	mc	3	Sirmaur	\N	Nahan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9479152559	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "0b1b40b2-49bb-4101-8863-161b609ab77b", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.104	\N	2026-01-15 14:00:53.110547	2026-01-15 14:00:53.287	\N
34f8242b-d9da-4514-9539-921b0db96806	1f736bea-42e4-48e9-884c-3510847a36cd	HP-HS-2026-LAH-000084	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Spiti 9800716814	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9800716814	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "7b1d88ad-9b1b-4f5d-b068-0b241823d830", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.504	\N	2026-01-15 14:00:53.514693	2026-01-15 14:00:53.677	\N
dd96428f-41e7-447e-850f-af86df448e0d	cdbf6366-ab5f-4456-b5d3-2e2dcd43f636	HP-HS-2026-LAH-000085	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Spiti 9959132601	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9959132601	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "f3f61a9b-9595-4962-b442-116a1ec8a05d", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.568	\N	2026-01-15 14:00:53.577022	2026-01-15 14:00:53.732	\N
45d5a8a0-4c21-4642-9ae6-023ab6ae4b7a	e3d15330-af7c-47c4-848c-92a18df6bc0c	HP-HS-2026-CHM-000093	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Chamba Main 9284239068	silver	gp	2	Chamba	\N	Chamba	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9284239068	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "07b4e33b-eb37-4759-b5c1-5c1f360bde70", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:54.39	\N	2026-01-15 14:00:54.394531	2026-01-15 14:00:54.592	\N
0fb0a6b7-646a-4786-b03e-c081fd6c5485	14070c77-4ce8-44ac-af61-e325b9938a53	HP-HS-2026-CHM-000081	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Chamba Main 9853781935	silver	gp	2	Chamba	\N	Chamba	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9853781935	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "1bca857d-4aef-4c8d-aeca-4ff04b8ef2b3", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.114	\N	2026-01-15 14:00:53.119771	2026-01-15 14:00:53.262	\N
d629068e-63a2-4a3b-884d-ba4755c68b64	3f250339-fb43-43c5-b1c1-24e8e213c14f	HP-HS-2026-KUL-000084	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kullu 9888619744	gold	tcp	4	Kullu	\N	Manali	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9888619744	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "c6f4cb9a-fb58-45e9-8a64-3757b939fc95", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.503	\N	2026-01-15 14:00:53.510972	2026-01-15 14:00:53.668	\N
c170386d-626d-4e41-b81c-84169466c306	ead1848c-e771-4e43-9a19-dd316eeb552b	HP-HS-2026-SMR-000087	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Sirmaur 9521769682	gold	mc	3	Sirmaur	\N	Nahan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9521769682	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "9f7b7bbd-5502-4f92-8884-a340ddf33359", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.907	\N	2026-01-15 14:00:53.917873	2026-01-15 14:00:54.094	\N
d8eff996-514c-42d2-a056-b24781a9c017	e2599a1f-f9c6-4131-955d-006e836ee65c	HP-HS-2026-SML-000090	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Shimla 9979316320	diamond	mc	5	Shimla	\N	Shimla (Urban)	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9979316320	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "7a585203-88aa-4038-9330-38fc036a4333", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:54.299	\N	2026-01-15 14:00:54.311229	2026-01-15 14:00:54.504	\N
5c5a1b8c-01ef-474b-afc5-d82b1ac8ed3c	690520d7-e491-43bd-a6f1-7fcf2369fa20	HP-HS-2026-KUL-000094	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Kullu 9985920238	gold	tcp	4	Kullu	\N	Manali	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9985920238	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "0d265e63-8447-4f31-899f-febc0185301b", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:54.738	\N	2026-01-15 14:00:54.746792	2026-01-15 14:00:55.042	\N
74fca047-68f8-4c01-b2dc-c6559967c05e	cd61ce90-cb6c-4b6a-91b6-8a150b368f3d	HP-HS-2026-CHM-000095	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Chamba Main 9802339396	silver	gp	2	Chamba	\N	Chamba	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9802339396	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "effd429f-60af-40d3-be1a-921d3d304fb5", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:54.793	\N	2026-01-15 14:00:54.804914	2026-01-15 14:00:55.056	\N
bebeb5de-4a9b-4bf0-9427-a44e9eb6eb63	06dee0ec-a7be-4f88-a8be-261fee6102ff	HP-HS-2026-LAH-000088	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Spiti 9151628645	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9151628645	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "b458de77-3d05-4407-8747-167f25aed110", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.925	\N	2026-01-15 14:00:53.930624	2026-01-15 14:00:54.098	\N
f90e0391-c214-4e73-b1f0-ade4bca39867	621c5f05-bc0c-433e-b9c0-c18c8ccfe5b4	HP-HS-2026-CHM-000089	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Chamba Main 9734383522	silver	gp	2	Chamba	\N	Chamba	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9734383522	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "5fc045cf-9a9b-4dc3-8e0e-d3de20da464e", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:53.992	\N	2026-01-15 14:00:54.00152	2026-01-15 14:00:54.153	\N
d7c474bb-1e52-468c-a9e0-a484e6afa984	d264c61b-c283-4506-945d-64d6c9e272b1	HP-HS-2026-LHL-000091	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Lahaul Main 9436537980	silver	gp	2	Lahaul	\N	Lahaul	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9436537980	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "75aa0320-7399-452d-967d-f3b269fa0074", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:54.326	\N	2026-01-15 14:00:54.3337	2026-01-15 14:00:54.487	\N
31a40a95-e4f4-4e71-80ba-6e87224303d0	01237f8a-902b-4b14-b04a-38508d41c894	HP-HS-2026-SOL-000092	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Solan 9649537544	gold	mc	3	Solan	\N	Solan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9649537544	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "4bb39776-b0e9-41d4-b482-aa67b1b73c34", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:54.338	\N	2026-01-15 14:00:54.342617	2026-01-15 14:00:54.526	\N
b9c9c4f6-51b3-40bc-983d-facff9fffa16	ed6bb431-4be2-4abe-968e-6f7f801c6244	HP-HS-2026-BIL-000098	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Load Test Bilaspur 9193764919	gold	mc	4	Bilaspur	\N	Sadar	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Load User	male	9193764919	load@test.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	under_scrutiny	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "64177dcd-02cb-4cda-b8a0-3f4626638e80", "url": "/uploads/dummy.pdf", "name": "load_test_doc.pdf", "type": "proof_of_ownership", "fileName": "load_test_doc.pdf", "filePath": "/uploads/dummy.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-15 14:00:54.939	\N	2026-01-15 14:00:54.951501	2026-01-15 14:00:55.122	\N
53f5b3ef-23c8-4888-829c-e6751056d0a5	2c95df7d-a843-44b0-b5ee-e9a3458650ce	HP-HS-2026-PNG-000099	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Pangi Fee Waiver Test Property	silver	gp	2	Pangi	\N	Pangi	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9559345036	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	1a8bab46-2d4c-4694-9009-12d50f644ec8	2026-01-16 05:31:50.284	2026-01-16 05:31:50.284	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "94f43b99-e38b-4011-9c9f-06eff48729df", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-16 05:31:50.048	\N	2026-01-16 05:31:50.057868	2026-01-16 05:31:50.284	\N
d2b4f6e3-2fe4-4a63-ba65-beb888dbaf3b	b6fa6422-dc6e-4d1b-ad0b-d8d6155ac133	HP-HS-2026-HMP-000101	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Hamirpur (Merged) Flow Property	gold	mc	4	Hamirpur	\N	Amb	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9847079548	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	6affed07-7898-4fc9-b86d-af1d610ad3ea	2026-01-16 05:31:50.926	2026-01-16 05:31:50.926	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "7b78c1a1-9e7c-4c7b-8e97-5fb438c2560e", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-16 05:31:50.747	\N	2026-01-16 05:31:50.753821	2026-01-16 05:31:50.926	\N
51a39e33-6ae9-4a9d-af9e-f9648da543dd	14ec132d-0a83-437d-84cc-c2ba4b1e79fc	HP-HS-2026-LAH-000100	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Kaza (Spiti) Flow Property	silver	gp	3	Lahaul-Spiti (Kaza)	\N	Spiti	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9335290214	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	5da8ac27-6650-4982-b51a-a7e7c5257075	2026-01-16 05:31:50.626	2026-01-16 05:31:50.626	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "ca9a0fda-5d81-416b-89f0-cd703d926356", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-16 05:31:50.427	\N	2026-01-16 05:31:50.435541	2026-01-16 05:31:50.626	\N
bde01d20-d8d8-4401-9e4a-21ffb25d49f0	46a9bd6e-0895-46f1-9837-238ba478bc99	HP-HS-2026-BIL-000102	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Mandi (Merged) Flow Property	gold	mc	4	Bilaspur	\N	Sadar	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9606808974	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	34db6a0f-a3a8-4860-8bc5-fc03291de0d3	2026-01-16 05:31:51.218	2026-01-16 05:31:51.218	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "6d715848-1010-47c9-86b1-bf5af68c17a1", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-16 05:31:51.045	\N	2026-01-16 05:31:51.052645	2026-01-16 05:31:51.218	\N
97d05564-2c7d-4c7c-86da-e055a99fdd07	1961069b-5b79-4334-ae5e-758545382c27	HP-HS-2026-CHM-000103	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Chamba (Main) Flow Property	silver	gp	2	Chamba	\N	Chamba	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9206716444	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	efde4df9-1dcf-4d85-a9d3-151d17c8011d	2026-01-16 05:31:51.498	2026-01-16 05:31:51.498	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "10385916-83f7-4be7-8274-b9b05b58bea2", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-16 05:31:51.327	\N	2026-01-16 05:31:51.333152	2026-01-16 05:31:51.498	\N
583d5ba7-b780-431b-bdf1-fd531a8f31db	51c83d0e-9f80-4d79-8eb3-6301950b29d3	HP-HS-2026-KNG-000104	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Kangra Flow Property	diamond	mc	5	Kangra	\N	Dharamsala	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9301330440	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	b7987533-e127-4cad-8233-de0fdde7bbc7	2026-01-16 05:31:51.795	2026-01-16 05:31:51.795	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "dabc9fa4-d9b7-4ec9-b179-1b0680a951f5", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-16 05:31:51.61	\N	2026-01-16 05:31:51.617041	2026-01-16 05:31:51.795	\N
bf6cbcb7-606c-478e-bd40-78c9ee86effa	d2c08f95-a3dd-42c0-9f49-b6363ea101aa	HP-HS-2026-KNR-000105	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Kinnaur Flow Property	silver	gp	2	Kinnaur	\N	Kalpa	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9695618367	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	6d27a721-acb4-4dab-95d9-0b2c91645234	2026-01-16 05:31:52.098	2026-01-16 05:31:52.098	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "1a574d4f-71fb-4536-bc9a-f6cef80e9c1d", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-16 05:31:51.904	\N	2026-01-16 05:31:51.909539	2026-01-16 05:31:52.098	\N
ec6771dd-acfe-4a6f-8cd3-cf282b2c86aa	87b4b2dd-d35f-461d-853f-957c31ee3364	HP-HS-2026-KUL-000106	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Kullu Flow Property	gold	tcp	4	Kullu	\N	Manali	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9275216873	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	4	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	4	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	d244a912-8065-4604-9b58-ba9b69d93e11	2026-01-16 05:31:52.377	2026-01-16 05:31:52.377	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "9b8f6149-c54f-45d1-b49e-b3f23c42b062", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-16 05:31:52.216	\N	2026-01-16 05:31:52.222232	2026-01-16 05:31:52.377	\N
4471c66f-67a8-4161-a719-97421f4774b3	a90d9e56-3d2d-45e0-8ca5-a8da134ffc5c	HP-HS-2026-LHL-000107	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Lahaul (Main) Flow Property	silver	gp	2	Lahaul	\N	Lahaul	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9499435951	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	2	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	249b7155-1f20-404f-b377-b0202b66a8a8	2026-01-16 05:31:52.652	2026-01-16 05:31:52.652	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "770e3f06-2bf5-4877-8d67-755afe05fc15", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-16 05:31:52.484	\N	2026-01-16 05:31:52.488745	2026-01-16 05:31:52.652	\N
01fe3e3a-d6ba-466f-a815-12c4c9b161a6	9462b151-1337-4344-bc94-5bc90b59ab03	HP-HS-2026-SMR-000109	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Sirmaur Flow Property	gold	mc	3	Sirmaur	\N	Nahan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9666748514	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	2026-01-16 05:31:53.258	2026-01-16 05:31:53.258	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "663895cf-2caf-4ff4-b794-c86dc2d0967c", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-16 05:31:53.087	\N	2026-01-16 05:31:53.091787	2026-01-16 05:31:53.258	\N
ed386a7e-ab27-4bea-be70-ec307cd36355	6af3e921-4c29-4eea-81c6-3ce45f97c261	HP-HS-2026-SML-000108	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Shimla Flow Property	diamond	mc	5	Shimla	\N	Shimla (Urban)	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9854390338	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	5	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	5	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	a9a95a58-c2be-4175-83ed-7352a709c3c8	2026-01-16 05:31:52.97	2026-01-16 05:31:52.97	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "b4a8a49f-10ee-4ed2-8cb5-81e3278976c7", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-16 05:31:52.788	\N	2026-01-16 05:31:52.792423	2026-01-16 05:31:52.97	\N
e458c717-ab36-45be-a8c3-2a121167d50e	f80dd5ab-6ca5-40f6-bf02-1e980b335e07	HP-HS-2026-SOL-000110	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Solan Flow Property	gold	mc	3	Solan	\N	Solan	\N	Test Block	\N	Test GP	\N	Test MC	\N	1	Smoke Test Lane	171001	01770000000	\N	\N	\N	Smoke Owner	male	9715419216	owner@example.com	\N	123456789012	\N	owned	2000.00	new_project	1200.00	sqm	3	1	120.00	2000.00	0	2	0.00	0.00	0	4	0.00	0.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	100.00	100.00	Yes	None	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	\N	\N	\N	\N	5000.00	\N	\N	forwarded_to_dtdo	\N	1	\N	\N	\N	cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	2026-01-16 05:31:53.532	2026-01-16 05:31:53.532	Automated Forward	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "48258039-2aab-4e59-8445-b715e0c12726", "url": "/uploads/dummy_deed.pdf", "name": "dummy_deed.pdf", "type": "proof_of_ownership", "fileName": "dummy_deed.pdf", "filePath": "/uploads/dummy_deed.pdf", "fileSize": 1024, "mimeType": "application/pdf", "documentType": "proof_of_ownership"}]	\N	\N	\N	pending	\N	\N	\N	\N	\N	2026-01-16 05:31:53.373	\N	2026-01-16 05:31:53.377762	2026-01-16 05:31:53.532	\N
\.


--
-- Data for Name: inspection_orders; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.inspection_orders (id, application_id, scheduled_by, scheduled_date, assigned_to, assigned_date, inspection_date, inspection_address, special_instructions, status, dtdo_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inspection_reports; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.inspection_reports (id, inspection_order_id, application_id, submitted_by, submitted_date, actual_inspection_date, room_count_verified, actual_room_count, category_meets_standards, recommended_category, mandatory_checklist, mandatory_remarks, desirable_checklist, desirable_remarks, amenities_verified, amenities_issues, fire_safety_compliant, fire_safety_issues, structural_safety, structural_issues, overall_satisfactory, recommendation, detailed_findings, inspection_photos, report_document_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_blocks; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_blocks (id, lgd_code, block_name, district_id, tehsil_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_districts; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_districts (id, lgd_code, district_name, division_name, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_gram_panchayats; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_gram_panchayats (id, lgd_code, gram_panchayat_name, district_id, block_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_tehsils; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_tehsils (id, lgd_code, tehsil_name, district_id, tehsil_type, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_urban_bodies; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_urban_bodies (id, lgd_code, urban_body_name, district_id, body_type, number_of_wards, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: login_otp_challenges; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.login_otp_challenges (id, user_id, otp_hash, expires_at, consumed_at, created_at) FROM stdin;
1635e056-7463-4d0d-9954-2232543f0613	abc973c9-0b50-44f5-9df2-2aca18d9ccfa	$2b$10$ryE30wybtCb0A8JupWGgoOFh3aDTl9JC.1wT8okIbR/07wFiS5HD.	2026-01-16 12:40:21.812	2026-01-16 12:30:38.273	2026-01-16 12:30:21.816959
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.notifications (id, user_id, application_id, type, title, message, channels, is_read, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: objections; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.objections (id, application_id, inspection_report_id, raised_by, raised_date, objection_type, objection_title, objection_description, severity, response_deadline, status, resolution_notes, resolved_by, resolved_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_reset_challenges; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.password_reset_challenges (id, user_id, channel, recipient, otp_hash, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.payments (id, application_id, payment_type, amount, payment_gateway, gateway_transaction_id, payment_method, payment_status, payment_link, qr_code_url, payment_link_expiry_date, initiated_at, completed_at, receipt_number, receipt_url) FROM stdin;
\.


--
-- Data for Name: production_stats; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.production_stats (id, total_applications, approved_applications, rejected_applications, pending_applications, scraped_at, source_url) FROM stdin;
c136ea40-b254-4614-a276-da40e98950c0	4	4	4	4	2026-01-08 00:46:39.924033	https://eservices.himachaltourism.gov.in/
48fdc8d0-692e-4a37-993a-e54688142566	4	4	4	4	2026-01-08 00:46:39.942396	https://eservices.himachaltourism.gov.in/
802136d7-fc57-4009-a736-eedb97a56554	4	4	4	4	2026-01-08 00:48:31.414282	https://eservices.himachaltourism.gov.in/
1acd27ac-af25-46cf-bc73-80471dd96616	4	4	4	4	2026-01-08 00:48:31.514408	https://eservices.himachaltourism.gov.in/
76463abc-4c37-4429-8ce4-9b10ec387da7	4	4	4	4	2026-01-08 01:05:36.499225	https://eservices.himachaltourism.gov.in/
9c6b11f1-f571-480b-960d-2a4968029dc7	4	4	4	4	2026-01-08 01:06:52.657354	https://eservices.himachaltourism.gov.in/
dd300da0-236e-4ce9-9d41-8771def9a5ab	4	4	4	4	2026-01-08 01:17:47.686854	https://eservices.himachaltourism.gov.in/
b47ebbb2-136d-4c0c-b62a-f9cc8c935e95	4	4	4	4	2026-01-08 01:39:30.119468	https://eservices.himachaltourism.gov.in/
8b18c48a-a4e5-498d-8eeb-79aa97c48d09	4	4	4	4	2026-01-08 01:40:36.11727	https://eservices.himachaltourism.gov.in/
58695279-7d14-4e30-8ac6-06607529780a	4	4	4	4	2026-01-08 01:48:31.397839	https://eservices.himachaltourism.gov.in/
ef38131c-6a0f-4bd2-8ce8-a61dfd138778	4	4	4	4	2026-01-08 01:48:31.49186	https://eservices.himachaltourism.gov.in/
3a91ea49-2635-4724-8310-82ac067c769d	4	4	4	4	2026-01-08 02:40:35.749051	https://eservices.himachaltourism.gov.in/
d3dc6040-b0aa-445c-a090-12eec34f953e	4	4	4	4	2026-01-08 02:48:31.378308	https://eservices.himachaltourism.gov.in/
f377dc4c-3c5e-4f42-a19e-93d2436e7478	4	4	4	4	2026-01-08 02:48:31.495727	https://eservices.himachaltourism.gov.in/
a86f12a0-5a76-46a0-9bfd-03228379303b	4	4	4	4	2026-01-08 03:40:35.75908	https://eservices.himachaltourism.gov.in/
01ce343e-13fa-4f55-879e-6fdd46b7e370	4	4	4	4	2026-01-08 03:48:31.393771	https://eservices.himachaltourism.gov.in/
bbc6a72c-1956-4ce6-ac8e-1f5ce6833763	4	4	4	4	2026-01-08 03:48:31.508194	https://eservices.himachaltourism.gov.in/
36d2c9ce-f454-4671-b4d6-3ecc2da85d78	4	4	4	4	2026-01-08 04:40:35.737525	https://eservices.himachaltourism.gov.in/
e268d4ee-db7d-4185-b52e-3c128a157f2c	4	4	4	4	2026-01-08 04:48:31.412989	https://eservices.himachaltourism.gov.in/
a04c8e3b-eff7-416f-8786-20ff83c17dca	4	4	4	4	2026-01-08 04:48:31.482347	https://eservices.himachaltourism.gov.in/
c7c30e56-e690-4f79-b7c0-046074eabd01	4	4	4	4	2026-01-08 05:40:35.773548	https://eservices.himachaltourism.gov.in/
625f50ee-bac5-4579-8449-5b841e33a3ba	4	4	4	4	2026-01-08 05:48:31.414763	https://eservices.himachaltourism.gov.in/
d132813f-6306-426a-8cfd-cf2ea510ac22	4	4	4	4	2026-01-08 05:48:31.497109	https://eservices.himachaltourism.gov.in/
d714c17e-8846-44a6-a1d8-fb6c97c2219c	4	4	4	4	2026-01-08 06:40:35.79278	https://eservices.himachaltourism.gov.in/
3fd8d835-8738-4aee-ac9a-81c2c9821907	4	4	4	4	2026-01-08 06:48:31.406364	https://eservices.himachaltourism.gov.in/
d7989282-a463-4584-a0c6-ec66eb13c5bc	4	4	4	4	2026-01-08 06:48:31.521966	https://eservices.himachaltourism.gov.in/
21b9f1ec-2781-4875-96c0-7c9d6b5fc34c	4	4	4	4	2026-01-08 07:40:35.796874	https://eservices.himachaltourism.gov.in/
3ca6d223-8e7d-47b6-a95e-45150a3d5da7	4	4	4	4	2026-01-08 07:48:31.407771	https://eservices.himachaltourism.gov.in/
be2976e8-f4a5-40de-b828-18005a94324b	4	4	4	4	2026-01-08 07:48:31.514086	https://eservices.himachaltourism.gov.in/
2d72a890-7c0f-4aa0-9216-29129f9812d2	4	4	4	4	2026-01-08 08:40:35.79803	https://eservices.himachaltourism.gov.in/
804298f3-e631-49d7-8211-bd11de1f2b09	4	4	4	4	2026-01-08 08:48:31.40491	https://eservices.himachaltourism.gov.in/
01a9aee3-f922-49dc-a706-acbb72e0bd6d	4	4	4	4	2026-01-08 08:48:31.503526	https://eservices.himachaltourism.gov.in/
45467045-23e8-47e5-acb8-48aa398bd3df	4	4	4	4	2026-01-08 09:40:35.815218	https://eservices.himachaltourism.gov.in/
f874ff17-5586-4ed7-b0f8-3d13068fa41a	4	4	4	4	2026-01-08 09:48:31.409262	https://eservices.himachaltourism.gov.in/
dbdcf2d4-1669-4473-bb33-b2a1e5c83618	4	4	4	4	2026-01-08 09:48:31.498021	https://eservices.himachaltourism.gov.in/
fc7e1bb1-8fd3-4f80-8525-6f0c5936ff55	4	4	4	4	2026-01-10 08:34:31.090238	https://eservices.himachaltourism.gov.in/
1138c7cd-bc27-4396-a72f-cac27296de7a	4	4	4	4	2026-01-10 08:46:15.956129	https://eservices.himachaltourism.gov.in/
04bd6fbe-e8aa-48e9-bf75-3e796b7d30d5	4	4	4	4	2026-01-10 08:49:30.002659	https://eservices.himachaltourism.gov.in/
2c498be3-39db-4ab4-bda2-9c9908530eba	4	4	4	4	2026-01-10 08:54:40.007042	https://eservices.himachaltourism.gov.in/
2961722f-c641-4435-aa24-00518ff8d759	4	4	4	4	2026-01-10 09:02:34.894845	https://eservices.himachaltourism.gov.in/
0441e383-f951-4d6e-a0a9-730ab55062a6	4	4	4	4	2026-01-10 09:06:48.620387	https://eservices.himachaltourism.gov.in/
b638656a-a1f9-45f3-a1c6-1ebb74b85bff	4	4	4	4	2026-01-10 10:06:49.699648	https://eservices.himachaltourism.gov.in/
88a2e931-8939-4cc1-898f-781e1029331d	4	4	4	4	2026-01-10 11:06:48.66553	https://eservices.himachaltourism.gov.in/
b941ab94-d037-42e5-bc30-a07d65c0888f	4	4	4	4	2026-01-10 12:06:48.721491	https://eservices.himachaltourism.gov.in/
83f4f499-807e-4c82-9a23-6a891da352f6	4	4	4	4	2026-01-10 13:06:48.72717	https://eservices.himachaltourism.gov.in/
f16657a8-5ec5-4ac7-bfa1-c923a1d50e31	4	4	4	4	2026-01-10 14:06:48.715277	https://eservices.himachaltourism.gov.in/
2bf72372-d7a4-45d6-8f38-f59a78a271f9	4	4	4	4	2026-01-10 15:06:48.702035	https://eservices.himachaltourism.gov.in/
89cd05d4-874b-4799-bd47-9aeb3d00d160	4	4	4	4	2026-01-10 16:06:48.734989	https://eservices.himachaltourism.gov.in/
b2aeb2f1-ab59-4c8a-a01d-c2949ab730d3	4	4	4	4	2026-01-10 17:06:48.733301	https://eservices.himachaltourism.gov.in/
4b54412d-f4f1-4ddf-bb25-a0fa70948903	4	4	4	4	2026-01-10 18:06:48.766655	https://eservices.himachaltourism.gov.in/
ba7ae7d1-126d-4db4-8b63-b99a1dd99c79	4	4	4	4	2026-01-10 19:06:48.782261	https://eservices.himachaltourism.gov.in/
49e0d5f7-76e9-477f-a8bc-723165f387dc	4	4	4	4	2026-01-10 20:06:48.771268	https://eservices.himachaltourism.gov.in/
79405365-55a3-469f-bf1b-15fa9a8cee0c	4	4	4	4	2026-01-10 21:06:48.824673	https://eservices.himachaltourism.gov.in/
b2374ced-a9cb-4165-aa27-f2ed311005f9	4	4	4	4	2026-01-10 22:06:48.901048	https://eservices.himachaltourism.gov.in/
53c4e5e2-7879-4e17-85db-86c16843d5ab	4	4	4	4	2026-01-10 23:06:48.833165	https://eservices.himachaltourism.gov.in/
ad7e00f2-b127-447c-9ffb-38dc304c13ee	4	4	4	4	2026-01-11 00:06:48.87723	https://eservices.himachaltourism.gov.in/
d8fb6566-32f0-439e-930b-9da7f05e2cb2	4	4	4	4	2026-01-11 01:06:48.890802	https://eservices.himachaltourism.gov.in/
7dc6aece-12a4-4354-9ffc-d8c09673515c	4	4	4	4	2026-01-11 02:06:48.921295	https://eservices.himachaltourism.gov.in/
a22d6e20-3d36-4f40-ad45-e062e9f00b6f	4	4	4	4	2026-01-11 03:06:48.926607	https://eservices.himachaltourism.gov.in/
0606f5b0-f939-43e3-85d2-7e5eae73a567	4	4	4	4	2026-01-11 04:06:48.934022	https://eservices.himachaltourism.gov.in/
f7b69f19-e0a2-4e21-b94b-5ecf84ba5e6e	4	4	4	4	2026-01-11 05:06:48.985722	https://eservices.himachaltourism.gov.in/
01e4df65-6f42-4f7f-9df3-e0ff8d421637	4	4	4	4	2026-01-11 06:06:48.932377	https://eservices.himachaltourism.gov.in/
ef5abf76-a145-422f-96c7-128879a5e14c	4	4	4	4	2026-01-11 07:06:48.952972	https://eservices.himachaltourism.gov.in/
48ec7697-0048-4ca6-983f-e53d4bf6198e	4	4	4	4	2026-01-11 08:06:48.9596	https://eservices.himachaltourism.gov.in/
3629979b-4715-4109-8587-cb42be96ddd4	4	4	4	4	2026-01-11 09:06:48.970047	https://eservices.himachaltourism.gov.in/
02e6ca18-79db-40a2-9773-a8f8598f2f94	4	4	4	4	2026-01-11 10:06:49.009207	https://eservices.himachaltourism.gov.in/
a30a63d0-1d38-4107-989f-03d9c2b3a9aa	4	4	4	4	2026-01-11 11:06:49.018401	https://eservices.himachaltourism.gov.in/
7e95937d-9c7c-48ca-8e2b-208a68860930	4	4	4	4	2026-01-11 12:06:49.048236	https://eservices.himachaltourism.gov.in/
0c5745ff-abf3-4cfe-8a33-90edab754a5f	4	4	4	4	2026-01-12 07:47:55.812886	https://eservices.himachaltourism.gov.in/
85f823af-9c5a-43b7-b372-4f185c78ceda	4	4	4	4	2026-01-12 07:47:56.074414	https://eservices.himachaltourism.gov.in/
36ca24a8-99d3-47d9-8eca-391d6344760d	4	4	4	4	2026-01-12 08:47:55.792272	https://eservices.himachaltourism.gov.in/
5f72041f-4b45-4056-af13-2dbd3ed8a1a9	4	4	4	4	2026-01-12 08:47:55.794146	https://eservices.himachaltourism.gov.in/
49a07067-2d56-4312-9ba0-964de24d7436	4	4	4	4	2026-01-12 09:04:08.56653	https://eservices.himachaltourism.gov.in/
e25da85d-103a-4359-9e0b-b7db92b8dfa6	4	4	4	4	2026-01-12 09:04:08.786371	https://eservices.himachaltourism.gov.in/
1bda1b41-4176-4957-a4b3-70d052a3d310	4	4	4	4	2026-01-12 09:09:53.748893	https://eservices.himachaltourism.gov.in/
963de838-95fb-4501-a148-22f1f161bc8c	4	4	4	4	2026-01-12 09:09:53.862423	https://eservices.himachaltourism.gov.in/
3861da7f-edf6-4cc6-b102-32827b22d805	4	4	4	4	2026-01-12 09:14:20.706822	https://eservices.himachaltourism.gov.in/
f6d8c895-ffa7-4741-8c0e-91fdaa8bc28c	4	4	4	4	2026-01-12 09:14:20.876452	https://eservices.himachaltourism.gov.in/
2b473e7a-9895-4b0e-82b1-62a54ac2b022	4	4	4	4	2026-01-12 09:18:56.194821	https://eservices.himachaltourism.gov.in/
e8c09698-c94b-4666-b6ff-2dcfe5c6a413	4	4	4	4	2026-01-12 09:18:56.376183	https://eservices.himachaltourism.gov.in/
2e18a09f-7141-434d-a54c-17c2bef32027	4	4	4	4	2026-01-12 09:23:12.24457	https://eservices.himachaltourism.gov.in/
d0360ca6-bc11-4e3a-9a40-c33abba22e9f	4	4	4	4	2026-01-12 09:23:12.508276	https://eservices.himachaltourism.gov.in/
977bb75f-616f-4c69-bd91-4660e550319c	4	4	4	4	2026-01-12 09:27:48.831671	https://eservices.himachaltourism.gov.in/
db7e3425-c738-4637-a13f-51fb0b373aa9	4	4	4	4	2026-01-12 09:27:49.19247	https://eservices.himachaltourism.gov.in/
350bd9b0-dee1-412f-b256-946c6d4eac35	4	4	4	4	2026-01-12 09:31:33.473609	https://eservices.himachaltourism.gov.in/
6665d6ad-9eaa-4940-a91d-5d3485e64676	4	4	4	4	2026-01-12 09:31:33.660097	https://eservices.himachaltourism.gov.in/
2a1f186d-56e2-4ea8-9275-30655b373352	4	4	4	4	2026-01-12 09:36:32.417717	https://eservices.himachaltourism.gov.in/
c848f405-a2f7-4bef-87bc-179f3797f0f4	4	4	4	4	2026-01-12 09:36:32.685821	https://eservices.himachaltourism.gov.in/
62233edc-c047-4a41-8c2f-090148d4bdac	4	4	4	4	2026-01-12 09:40:59.342522	https://eservices.himachaltourism.gov.in/
f100d868-d378-4f7c-9548-319ba88d182f	4	4	4	4	2026-01-12 09:40:59.56545	https://eservices.himachaltourism.gov.in/
76cb2899-44cc-499c-96f4-94f96be5e9b1	4	4	4	4	2026-01-12 09:44:57.115008	https://eservices.himachaltourism.gov.in/
467093f8-0e50-4b47-b164-32bceef79362	4	4	4	4	2026-01-12 09:44:57.339264	https://eservices.himachaltourism.gov.in/
cdd5d957-bd78-4f9f-9a84-6fe46d988c74	4	4	4	4	2026-01-12 09:47:40.692468	https://eservices.himachaltourism.gov.in/
5b70d3d5-1f64-471b-bc8c-9419bda61fea	4	4	4	4	2026-01-12 09:47:40.957531	https://eservices.himachaltourism.gov.in/
6ed7d7c9-cbff-4486-80b8-43bcd82935c5	4	4	4	4	2026-01-12 09:52:56.18153	https://eservices.himachaltourism.gov.in/
bd99bebe-77e5-465f-8750-52d0fc684e5d	4	4	4	4	2026-01-12 09:52:56.390072	https://eservices.himachaltourism.gov.in/
a6f62c88-8785-49dd-9502-6d56c464f634	4	4	4	4	2026-01-12 09:55:08.862526	https://eservices.himachaltourism.gov.in/
29222c65-6b30-48cd-a7a8-7e41315b8aa6	4	4	4	4	2026-01-12 09:55:08.964439	https://eservices.himachaltourism.gov.in/
849d1d0f-1b32-4de6-bdd3-109c6bb57b9c	4	4	4	4	2026-01-12 10:00:15.067817	https://eservices.himachaltourism.gov.in/
6680b3dc-313f-40cf-8ef7-729f38387353	4	4	4	4	2026-01-12 10:00:15.172538	https://eservices.himachaltourism.gov.in/
5528e273-7588-490b-a758-56f643b08232	4	4	4	4	2026-01-12 10:04:15.36109	https://eservices.himachaltourism.gov.in/
93990a25-6745-435e-b493-552b603f2e54	4	4	4	4	2026-01-12 10:04:15.532528	https://eservices.himachaltourism.gov.in/
4309462d-932c-48d4-96c3-a3b9eb0fce6c	4	4	4	4	2026-01-12 10:09:22.583528	https://eservices.himachaltourism.gov.in/
2db58972-9562-4ee8-a2bd-868499f9b424	4	4	4	4	2026-01-12 10:09:22.75306	https://eservices.himachaltourism.gov.in/
83241200-932c-4b01-b96a-08467c5d50d7	4	4	4	4	2026-01-12 10:11:58.306899	https://eservices.himachaltourism.gov.in/
b1c8cabf-09e1-4e38-8a5c-69d94ae879f1	4	4	4	4	2026-01-12 10:11:58.595419	https://eservices.himachaltourism.gov.in/
f34e3714-38bf-4c9c-a803-0c98fa0cec1e	4	4	4	4	2026-01-12 10:16:50.351598	https://eservices.himachaltourism.gov.in/
4f44941e-d4b4-4521-98e6-1a94c55d3d1b	4	4	4	4	2026-01-12 10:16:50.548143	https://eservices.himachaltourism.gov.in/
9d8e8be7-e283-494c-9d02-66008a313f6a	4	4	4	4	2026-01-12 10:20:20.656174	https://eservices.himachaltourism.gov.in/
4037ebbd-1b9b-43e2-a858-c32aca26c793	4	4	4	4	2026-01-12 10:20:21.953533	https://eservices.himachaltourism.gov.in/
71034ef9-0f09-4b5a-8bdd-123be57a1c18	4	4	4	4	2026-01-12 10:22:57.056537	https://eservices.himachaltourism.gov.in/
5f6baddd-1c56-4ac3-b032-6595576d5451	4	4	4	4	2026-01-12 10:22:57.28478	https://eservices.himachaltourism.gov.in/
df2e2f99-4d7c-4a79-ad22-1cb1e0e0c3a9	4	4	4	4	2026-01-12 10:26:15.56827	https://eservices.himachaltourism.gov.in/
8dc2fbed-7539-4597-b4b3-97e41f7ca25d	4	4	4	4	2026-01-12 10:26:15.679855	https://eservices.himachaltourism.gov.in/
87aac52e-c6c6-4846-aa5a-65cbcb3d4d56	4	4	4	4	2026-01-12 10:29:49.17847	https://eservices.himachaltourism.gov.in/
570bfb6e-0dc1-4c58-b3b1-2617f8409ac8	4	4	4	4	2026-01-12 10:29:49.363525	https://eservices.himachaltourism.gov.in/
6d2e69d8-3127-4c38-998b-5b5ef86216e4	4	4	4	4	2026-01-12 10:33:38.413936	https://eservices.himachaltourism.gov.in/
59d392fd-fa8b-4ad1-8a34-000cbc546f10	4	4	4	4	2026-01-12 10:33:38.676524	https://eservices.himachaltourism.gov.in/
686703a1-2160-4307-ac2d-64df1adb3763	4	4	4	4	2026-01-12 10:40:09.398648	https://eservices.himachaltourism.gov.in/
3b3b4bf8-e313-4ce5-b8d0-4a29350f5aec	4	4	4	4	2026-01-12 10:40:09.557678	https://eservices.himachaltourism.gov.in/
aae90c0c-cb24-4a53-81da-8953a2e313f6	4	4	4	4	2026-01-12 10:47:30.304298	https://eservices.himachaltourism.gov.in/
492517d9-a71c-4be1-a737-6d2ccbb65da2	4	4	4	4	2026-01-12 10:47:30.410521	https://eservices.himachaltourism.gov.in/
d3acfa19-c551-4f18-a3de-2c9499162d42	4	4	4	4	2026-01-12 10:52:05.781415	https://eservices.himachaltourism.gov.in/
924b0591-a200-4545-ac9b-2db57ba5b3bf	4	4	4	4	2026-01-12 10:52:06.105525	https://eservices.himachaltourism.gov.in/
f7f1306b-fa10-4103-89c7-50919de495b6	4	4	4	4	2026-01-12 11:09:56.727055	https://eservices.himachaltourism.gov.in/
ce63dd17-0b68-4bfc-840f-f35e7f6337e1	4	4	4	4	2026-01-12 11:09:57.042319	https://eservices.himachaltourism.gov.in/
68e94361-1623-49b4-bfd6-d7aeeacd7f2a	4	4	4	4	2026-01-12 11:11:36.615518	https://eservices.himachaltourism.gov.in/
26878741-079e-410c-93d7-3c267d6dfcc5	4	4	4	4	2026-01-12 11:11:36.863397	https://eservices.himachaltourism.gov.in/
1333fe32-bfe0-4bf7-8497-648f8518a138	4	4	4	4	2026-01-12 11:19:53.180936	https://eservices.himachaltourism.gov.in/
f4e494f9-0024-4c62-ad2c-bc266bddb607	4	4	4	4	2026-01-12 11:19:53.310524	https://eservices.himachaltourism.gov.in/
091f0414-48a9-4188-bc79-26249475ab8e	4	4	4	4	2026-01-12 12:19:53.179353	https://eservices.himachaltourism.gov.in/
6045c998-71c4-4149-8e38-ce774ee93441	4	4	4	4	2026-01-12 12:19:53.264092	https://eservices.himachaltourism.gov.in/
b15f107a-380f-4870-be61-ef68a6c82f73	4	4	4	4	2026-01-12 13:19:53.199418	https://eservices.himachaltourism.gov.in/
36176f28-8bfc-42f0-97ca-93a1ec46890b	4	4	4	4	2026-01-12 13:19:53.24063	https://eservices.himachaltourism.gov.in/
212f8c7c-4d90-4c98-b569-c22126ce8103	4	4	4	4	2026-01-12 14:19:53.18719	https://eservices.himachaltourism.gov.in/
0b4d04e5-b116-4546-b3d1-e1f02e160979	4	4	4	4	2026-01-12 14:19:53.266184	https://eservices.himachaltourism.gov.in/
2c749c2e-a0a0-4143-8ce9-70745ba9fe4d	4	4	4	4	2026-01-12 15:19:53.17421	https://eservices.himachaltourism.gov.in/
5859b66f-b46d-4278-86c1-d38d5c9a3651	4	4	4	4	2026-01-12 15:19:53.255743	https://eservices.himachaltourism.gov.in/
fd13899e-7ed3-47d8-948f-3226e854371e	4	4	4	4	2026-01-12 16:19:53.231376	https://eservices.himachaltourism.gov.in/
ad6bcd41-500f-452b-994f-f8776e74c4e5	4	4	4	4	2026-01-12 16:19:53.258689	https://eservices.himachaltourism.gov.in/
b44872a8-5621-4ef6-b3f5-71d9dd5ee3e6	4	4	4	4	2026-01-12 16:23:39.689518	https://eservices.himachaltourism.gov.in/
5010f28f-1fd2-47b6-bfdf-2ab65a9d4c69	4	4	4	4	2026-01-12 16:23:39.711413	https://eservices.himachaltourism.gov.in/
d9f525ee-35bc-4a74-80da-5e6fb5e65940	4	4	4	4	2026-01-12 16:37:12.751031	https://eservices.himachaltourism.gov.in/
2ba00f78-725c-47d9-8cbe-213b87af1c88	4	4	4	4	2026-01-12 16:37:12.934196	https://eservices.himachaltourism.gov.in/
74cf0532-e289-4a9c-9171-3bbd2a26f940	4	4	4	4	2026-01-12 16:37:49.998256	https://eservices.himachaltourism.gov.in/
3e649ab8-e891-405a-a2d7-79ade92f0791	4	4	4	4	2026-01-12 16:37:50.133188	https://eservices.himachaltourism.gov.in/
a7fc87e0-2e2c-4ff7-aa3f-88bcd8ed177e	4	4	4	4	2026-01-12 17:37:50.025296	https://eservices.himachaltourism.gov.in/
d9e47b55-a48c-4841-a2aa-3e36df3ca71e	4	4	4	4	2026-01-12 17:37:50.090106	https://eservices.himachaltourism.gov.in/
7630a2cf-6214-45d2-a81d-0321e4dae86e	4	4	4	4	2026-01-12 17:53:59.987779	https://eservices.himachaltourism.gov.in/
4b12d1d8-fa8b-4120-ba42-a0ec52d1a229	4	4	4	4	2026-01-12 17:54:00.299766	https://eservices.himachaltourism.gov.in/
9bffce57-8e68-4b22-82d0-3dc29c31c987	4	4	4	4	2026-01-12 18:48:14.836253	https://eservices.himachaltourism.gov.in/
d9880a3a-7a4c-4cf4-bb66-678e718e1500	4	4	4	4	2026-01-12 18:48:14.956369	https://eservices.himachaltourism.gov.in/
0effccf2-c532-44e5-b0dd-ccf3455db039	4	4	4	4	2026-01-12 18:53:33.40719	https://eservices.himachaltourism.gov.in/
d6929139-264f-4680-b536-2718c73406a2	4	4	4	4	2026-01-12 18:53:58.949378	https://eservices.himachaltourism.gov.in/
e0c80e94-e60b-4969-8603-ef0a4ea4498b	4	4	4	4	2026-01-12 18:59:29.414425	https://eservices.himachaltourism.gov.in/
2c00c733-a7a7-418e-87c3-505e1479a991	4	4	4	4	2026-01-12 19:59:29.4264	https://eservices.himachaltourism.gov.in/
e4e5a813-a20e-4189-8eb8-939ddb65b244	4	4	4	4	2026-01-12 20:59:29.450214	https://eservices.himachaltourism.gov.in/
7d5c7f17-e972-46fc-afe2-6037f676e61c	4	4	4	4	2026-01-12 21:59:29.474445	https://eservices.himachaltourism.gov.in/
347d61aa-4806-45b1-8b93-d22b326d10dd	4	4	4	4	2026-01-12 22:59:29.477494	https://eservices.himachaltourism.gov.in/
577952bd-24fd-4001-af92-fe0b346501aa	4	4	4	4	2026-01-12 23:59:29.502989	https://eservices.himachaltourism.gov.in/
bad0ae84-e0e5-4c38-a8b4-9530751912f7	4	4	4	4	2026-01-13 00:59:29.51108	https://eservices.himachaltourism.gov.in/
96bdf6d2-b72f-4e2e-a86e-e7cbe764d6a1	4	4	4	4	2026-01-13 01:48:00.81707	https://eservices.himachaltourism.gov.in/
111ffe40-b0c5-4fa6-ab11-a2015f7875c1	4	4	4	4	2026-01-13 02:08:08.833549	https://eservices.himachaltourism.gov.in/
0450ca71-eb4f-49ba-a2d3-78238ad07642	4	4	4	4	2026-01-13 03:08:08.873143	https://eservices.himachaltourism.gov.in/
5b3cb9e8-d482-4670-b8b4-263096ed8c80	4	4	4	4	2026-01-13 04:08:08.896945	https://eservices.himachaltourism.gov.in/
9080e125-aa84-4d59-9200-27c109c444d6	4	4	4	4	2026-01-13 04:21:05.40365	https://eservices.himachaltourism.gov.in/
b1a5f409-5d00-4f2c-9510-6cabfe9e0d1f	4	4	4	4	2026-01-13 04:21:05.867399	https://eservices.himachaltourism.gov.in/
250eddc9-e333-4821-962e-d98f1e5428de	4	4	4	4	2026-01-13 05:21:05.849938	https://eservices.himachaltourism.gov.in/
03cfe51a-d8f5-45c7-ad72-78ebdaafe616	4	4	4	4	2026-01-13 05:21:06.499713	https://eservices.himachaltourism.gov.in/
2ee01c1f-7054-4313-9a0f-4ca2b2f1b7ce	4	4	4	4	2026-01-13 06:21:05.436147	https://eservices.himachaltourism.gov.in/
b4d738ad-96a8-4dea-a0c4-19f35dd5caea	4	4	4	4	2026-01-13 06:21:05.831556	https://eservices.himachaltourism.gov.in/
30dd3674-4fbb-42af-942e-211345c4819c	4	4	4	4	2026-01-13 07:21:05.455464	https://eservices.himachaltourism.gov.in/
71390735-24c6-4c7a-8cec-f5f97af68a7f	4	4	4	4	2026-01-13 07:21:06.071967	https://eservices.himachaltourism.gov.in/
9e1db3bb-852b-4813-adb2-e9647be83c79	4	4	4	4	2026-01-13 08:21:05.415091	https://eservices.himachaltourism.gov.in/
7f688a2f-38d5-4a03-805d-c70647caa4cc	4	4	4	4	2026-01-13 08:21:05.832194	https://eservices.himachaltourism.gov.in/
83670fbf-887d-4916-800b-c86d9b38084a	4	4	4	4	2026-01-13 09:21:05.427022	https://eservices.himachaltourism.gov.in/
d8ab7896-bf1f-41e9-b64a-c4effef0c7f8	4	4	4	4	2026-01-13 09:21:05.834342	https://eservices.himachaltourism.gov.in/
7fd63bb3-9614-44c6-a26a-f66126315ae6	4	4	4	4	2026-01-13 10:21:05.44423	https://eservices.himachaltourism.gov.in/
abeef943-fe8e-432e-a8e7-92c0b5232253	4	4	4	4	2026-01-13 10:21:05.841331	https://eservices.himachaltourism.gov.in/
db6f6433-86a0-402d-a312-b2211810c0e3	4	4	4	4	2026-01-13 11:21:05.428023	https://eservices.himachaltourism.gov.in/
8809fe27-b632-4bf9-905b-80e7942925de	4	4	4	4	2026-01-13 11:21:05.822311	https://eservices.himachaltourism.gov.in/
8d13cad3-6227-4b4e-916b-06c8b225629b	4	4	4	4	2026-01-13 12:21:05.416646	https://eservices.himachaltourism.gov.in/
9a93a6dc-3201-4737-b029-02c7d1ebdd17	4	4	4	4	2026-01-13 12:21:05.82558	https://eservices.himachaltourism.gov.in/
29323220-65e3-4cd6-b58b-16e48c9e86c7	4	4	4	4	2026-01-13 13:21:05.425168	https://eservices.himachaltourism.gov.in/
e48101ac-6743-4ab8-89fc-1b500a444a28	4	4	4	4	2026-01-13 13:21:05.835926	https://eservices.himachaltourism.gov.in/
800af94d-5728-4685-b629-33f5ff6ac2b0	4	4	4	4	2026-01-13 14:21:15.440091	https://eservices.himachaltourism.gov.in/
48f11630-8178-473b-93c7-86a16c16da89	4	4	4	4	2026-01-13 14:21:15.592982	https://eservices.himachaltourism.gov.in/
2d27a7c7-f2c4-4a6a-a480-9a01abc8bbd6	4	4	4	4	2026-01-13 15:21:05.416737	https://eservices.himachaltourism.gov.in/
e9799fd1-5eb8-45ed-a156-5c550bcd1971	4	4	4	4	2026-01-13 15:21:05.819084	https://eservices.himachaltourism.gov.in/
d026c531-24f4-46f5-9b96-a675a73c1165	4	4	4	4	2026-01-13 16:21:05.424046	https://eservices.himachaltourism.gov.in/
6a85ccb4-2069-4d4f-8d5a-530b23216296	4	4	4	4	2026-01-13 16:21:05.829177	https://eservices.himachaltourism.gov.in/
6465d96b-d7ab-4f0c-9887-b36bee691f49	4	4	4	4	2026-01-13 17:21:05.421919	https://eservices.himachaltourism.gov.in/
682b6846-db64-4d93-9e1c-4d750b109660	4	4	4	4	2026-01-13 17:21:05.818878	https://eservices.himachaltourism.gov.in/
d009611f-bdcf-4907-95a9-49172793fa8d	4	4	4	4	2026-01-13 18:21:05.425576	https://eservices.himachaltourism.gov.in/
1d656942-60d5-4e02-9e81-4e4d1e86465c	4	4	4	4	2026-01-13 18:21:05.836415	https://eservices.himachaltourism.gov.in/
4eb752b6-ef8b-4d79-9fcf-636463d24da9	4	4	4	4	2026-01-13 19:21:05.468971	https://eservices.himachaltourism.gov.in/
630910a9-e288-439b-9ded-a2a7995b1890	4	4	4	4	2026-01-13 19:21:05.850276	https://eservices.himachaltourism.gov.in/
6478ba2b-c7e6-441c-8257-ba7e383b63c9	4	4	4	4	2026-01-13 20:21:05.493654	https://eservices.himachaltourism.gov.in/
1e6cb5ee-cf97-4150-a41b-65d52b1e6244	4	4	4	4	2026-01-13 20:21:05.854896	https://eservices.himachaltourism.gov.in/
082c8ea2-f79f-4bbd-a329-743ccbc2e651	4	4	4	4	2026-01-13 21:21:05.462372	https://eservices.himachaltourism.gov.in/
72b0d1be-cd5d-4851-a9e2-a20d98207866	4	4	4	4	2026-01-13 21:21:05.84791	https://eservices.himachaltourism.gov.in/
d6456e39-96cb-4e6e-a401-2055ee37f6cf	4	4	4	4	2026-01-13 22:21:05.440693	https://eservices.himachaltourism.gov.in/
76e93cfc-a04f-4264-8f47-43518839d330	4	4	4	4	2026-01-13 22:21:05.829698	https://eservices.himachaltourism.gov.in/
2de633ac-9a81-4944-a33a-2349e3f81c6a	4	4	4	4	2026-01-13 23:21:05.458137	https://eservices.himachaltourism.gov.in/
66975060-bddc-4055-933a-46ae153c258e	4	4	4	4	2026-01-13 23:21:05.827022	https://eservices.himachaltourism.gov.in/
faeefb66-d1ef-4ef9-b3fa-1302b9eddd56	4	4	4	4	2026-01-14 00:21:05.460239	https://eservices.himachaltourism.gov.in/
bdaaea1e-6af9-4444-b673-87663f77e396	4	4	4	4	2026-01-14 00:21:05.831032	https://eservices.himachaltourism.gov.in/
27fbd3cd-ce19-465c-8a5f-f599302ead20	4	4	4	4	2026-01-14 01:21:05.448262	https://eservices.himachaltourism.gov.in/
843a6967-bd68-44d1-b078-0ea96e155c4b	4	4	4	4	2026-01-14 01:21:05.83283	https://eservices.himachaltourism.gov.in/
6cc918c2-71e3-4c39-989a-42eef5656e9d	4	4	4	4	2026-01-14 02:21:05.447788	https://eservices.himachaltourism.gov.in/
a07c5fa9-3339-4a5f-9e4b-35b5434a39e5	4	4	4	4	2026-01-14 02:21:05.825839	https://eservices.himachaltourism.gov.in/
e762f417-b85a-4b86-8229-aaccc9500c7e	4	4	4	4	2026-01-14 03:21:19.445292	https://eservices.himachaltourism.gov.in/
e441277c-267e-4cb0-92ec-6943a8be2913	4	4	4	4	2026-01-14 03:21:19.529888	https://eservices.himachaltourism.gov.in/
70f8863e-d3f7-426a-aab0-9b2c1614af1d	4	4	4	4	2026-01-14 04:21:05.502667	https://eservices.himachaltourism.gov.in/
69d0b6b3-15b4-4803-a5af-654c003cab93	4	4	4	4	2026-01-14 04:21:05.849731	https://eservices.himachaltourism.gov.in/
02c6693d-07e9-467d-a740-0ea5a73f3f5e	4	4	4	4	2026-01-14 04:51:18.102644	https://eservices.himachaltourism.gov.in/
feca7eaf-7cb0-4dc2-a0b8-b635783cee1f	4	4	4	4	2026-01-14 05:21:05.930912	https://eservices.himachaltourism.gov.in/
5af76032-409e-4906-a037-2dc599b00d2c	4	4	4	4	2026-01-14 05:32:07.409858	https://eservices.himachaltourism.gov.in/
baf2c976-1cab-4e56-aa6c-ad03db46533a	4	4	4	4	2026-01-14 06:21:05.944665	https://eservices.himachaltourism.gov.in/
dcfc590f-d763-46b7-b1e9-bbaaa3d1363c	4	4	4	4	2026-01-14 06:32:07.391455	https://eservices.himachaltourism.gov.in/
1095561f-d14a-4946-b267-3502b444f005	4	4	4	4	2026-01-14 07:21:05.933522	https://eservices.himachaltourism.gov.in/
e2941c4c-8b73-4ce8-8161-380b213c1391	4	4	4	4	2026-01-14 07:30:16.440628	https://eservices.himachaltourism.gov.in/
465347f2-82dc-454b-902b-15beb1b51b42	4	4	4	4	2026-01-14 07:32:07.363196	https://eservices.himachaltourism.gov.in/
ee25cd31-4fd0-424f-b075-0ad8ae836a3b	4	4	4	4	2026-01-14 08:21:05.935886	https://eservices.himachaltourism.gov.in/
be548eaa-58fa-40fe-9843-51ba067fe549	4	4	4	4	2026-01-14 08:27:46.608507	https://eservices.himachaltourism.gov.in/
7f000f15-9b23-4460-bfac-3d0d3d2ebfb5	4	4	4	4	2026-01-14 08:32:07.417809	https://eservices.himachaltourism.gov.in/
9222b908-7dab-4fc2-8ae3-95cf6facc295	4	4	4	4	2026-01-14 08:35:14.704594	https://eservices.himachaltourism.gov.in/
c8900f3f-e72c-4c34-9675-9357a5de4d6d	4	4	4	4	2026-01-14 08:59:02.207824	https://eservices.himachaltourism.gov.in/
dd2f84aa-74ef-40a6-849c-3a1a37a2a794	4	4	4	4	2026-01-14 09:21:05.850169	https://eservices.himachaltourism.gov.in/
e5c67470-7766-4611-abf4-42a347e59bf9	4	4	4	4	2026-01-14 09:32:07.381709	https://eservices.himachaltourism.gov.in/
baa970a7-1db9-42dc-bf59-3b63cd767546	4	4	4	4	2026-01-14 10:21:05.937755	https://eservices.himachaltourism.gov.in/
913b9f3c-bf1b-4952-b769-18f753eee8ce	4	4	4	4	2026-01-14 10:22:22.499372	https://eservices.himachaltourism.gov.in/
9cde6ce8-0844-43aa-b26b-b2ca26daa36d	4	4	4	4	2026-01-14 10:32:07.392769	https://eservices.himachaltourism.gov.in/
d6229fb5-dc36-4a58-8be2-36bf7ef4a21c	4	4	4	4	2026-01-14 11:21:05.94618	https://eservices.himachaltourism.gov.in/
6e97e24d-926a-4521-bfb5-7e04eb99ab68	4	4	4	4	2026-01-14 11:22:21.900243	https://eservices.himachaltourism.gov.in/
a66bbaa3-6a43-4626-9c91-dbeb175ec58f	4	4	4	4	2026-01-14 11:32:07.469456	https://eservices.himachaltourism.gov.in/
ce6c118d-a09b-4dfc-aac4-6eefd9b51633	4	4	4	4	2026-01-14 12:21:05.927307	https://eservices.himachaltourism.gov.in/
31f38d7f-0775-4144-9bd2-33fbb0121f4a	4	4	4	4	2026-01-14 12:22:21.886596	https://eservices.himachaltourism.gov.in/
c55b48da-ecd9-4c46-bafe-5800797a9f18	4	4	4	4	2026-01-14 12:32:07.371363	https://eservices.himachaltourism.gov.in/
4f0a5c90-85f7-40b6-88ea-f9929c5877ec	4	4	4	4	2026-01-14 13:21:05.918789	https://eservices.himachaltourism.gov.in/
0e4fcf0f-7a4d-4f50-aeda-572d5718e4d8	4	4	4	4	2026-01-14 13:22:21.92683	https://eservices.himachaltourism.gov.in/
a27cc3d4-34a0-4acd-ac3f-06ef0bf3de83	4	4	4	4	2026-01-14 13:32:07.377658	https://eservices.himachaltourism.gov.in/
ffc38e62-4da1-45ec-a778-c9fe3975a7b5	4	4	4	4	2026-01-14 14:21:05.940473	https://eservices.himachaltourism.gov.in/
311aae32-aeb8-4864-b1a4-774bff526ff1	4	4	4	4	2026-01-14 14:22:21.876746	https://eservices.himachaltourism.gov.in/
300d1503-b460-40b3-b7b7-d68c2bc3f494	4	4	4	4	2026-01-14 14:32:07.397519	https://eservices.himachaltourism.gov.in/
48380520-2bfa-48fa-bcf7-81ebb721bf81	4	4	4	4	2026-01-14 15:21:05.940365	https://eservices.himachaltourism.gov.in/
da7d5110-cf14-41a5-ba05-c20357283ca1	4	4	4	4	2026-01-14 15:22:21.902932	https://eservices.himachaltourism.gov.in/
fd13afdb-2071-4974-bf6d-1d954b25b452	4	4	4	4	2026-01-14 15:32:07.427224	https://eservices.himachaltourism.gov.in/
c80ce6ca-a7d8-4914-93a0-124078d4e9e5	4	4	4	4	2026-01-14 15:37:04.793033	https://eservices.himachaltourism.gov.in/
cdc96304-8a03-4580-bb3f-d56510dbcd9a	4	4	4	4	2026-01-14 15:37:04.804291	https://eservices.himachaltourism.gov.in/
898ea7fb-e305-4d0f-aa4d-9f916e7a03c5	4	4	4	4	2026-01-14 15:38:22.957458	https://eservices.himachaltourism.gov.in/
7703e94c-667f-47ec-a24e-411fca00e7e9	4	4	4	4	2026-01-14 15:54:04.217212	https://eservices.himachaltourism.gov.in/
09fcd60f-156c-4b8c-8564-13de8368dc00	4	4	4	4	2026-01-14 15:54:58.248164	https://eservices.himachaltourism.gov.in/
a1063146-5dbd-42df-bb8b-065662e050d9	4	4	4	4	2026-01-14 15:55:46.126826	https://eservices.himachaltourism.gov.in/
45261ffe-a65d-4f16-9461-75d543289670	4	4	4	4	2026-01-14 16:55:45.78684	https://eservices.himachaltourism.gov.in/
a9664b94-7c99-4875-bc42-6db033792b2f	4	4	4	4	2026-01-14 17:55:45.721954	https://eservices.himachaltourism.gov.in/
b3b200e1-e4e8-4764-82bc-6dd10e4ee4d6	4	4	4	4	2026-01-14 18:55:45.719269	https://eservices.himachaltourism.gov.in/
98204179-5a13-4b4b-93e8-3e1cb4fb9cfe	4	4	4	4	2026-01-14 19:55:45.723353	https://eservices.himachaltourism.gov.in/
17f4a8e2-a24c-48f0-8651-d6c62558969d	4	4	4	4	2026-01-14 20:55:45.857327	https://eservices.himachaltourism.gov.in/
3bea82a0-a35e-4e06-a5de-6def4252597f	4	4	4	4	2026-01-14 21:55:45.771994	https://eservices.himachaltourism.gov.in/
63668612-6e98-4489-8ce8-e71d02e30443	4	4	4	4	2026-01-14 22:55:45.762915	https://eservices.himachaltourism.gov.in/
8322b869-5463-41fd-9301-61549eef53e3	4	4	4	4	2026-01-14 23:55:45.804285	https://eservices.himachaltourism.gov.in/
61e9dedc-ae20-46b9-acdf-b51509dff497	4	4	4	4	2026-01-15 00:55:45.737174	https://eservices.himachaltourism.gov.in/
fca6476c-8e5e-4833-b6e0-c0f6cdc872d8	4	4	4	4	2026-01-15 02:39:39.318525	https://eservices.himachaltourism.gov.in/
e039a784-4aa7-4d2a-856c-4dff81b795a9	4	4	4	4	2026-01-15 02:41:44.408156	https://eservices.himachaltourism.gov.in/
7ee1ac96-b665-481b-8371-c089d1fd7fad	4	4	4	4	2026-01-15 03:24:57.972727	https://eservices.himachaltourism.gov.in/
8210ad54-e7cf-4c94-8e82-7c4d786f2717	4	4	4	4	2026-01-15 04:04:02.845074	https://eservices.himachaltourism.gov.in/
2dc62d83-501e-49f0-ba02-d3efbf251fe3	4	4	4	4	2026-01-15 04:10:49.940526	https://eservices.himachaltourism.gov.in/
661d164d-b48d-4f89-b415-583eecc2baed	4	4	4	4	2026-01-15 04:13:54.958717	https://eservices.himachaltourism.gov.in/
b33c1c4d-a143-469b-88e4-994c6fb54f77	4	4	4	4	2026-01-15 04:17:09.076323	https://eservices.himachaltourism.gov.in/
117dfdbe-ab5f-44da-b492-eb3968f4b62f	4	4	4	4	2026-01-15 04:21:19.232023	https://eservices.himachaltourism.gov.in/
7239ff62-dd9f-4cb5-92c3-6f666e435e83	4	4	4	4	2026-01-15 04:25:52.784184	https://eservices.himachaltourism.gov.in/
974d2739-81fc-4da3-ac06-38028e0dab02	4	4	4	4	2026-01-15 04:32:35.724294	https://eservices.himachaltourism.gov.in/
7935585a-61f4-4dcd-ab43-ccefbe771251	4	4	4	4	2026-01-15 04:45:20.558667	https://eservices.himachaltourism.gov.in/
e9ad1634-b876-4fdb-9aea-5d195389c6bb	4	4	4	4	2026-01-15 04:54:28.266567	https://eservices.himachaltourism.gov.in/
d2b90bf6-c23e-43cd-bb73-eb7e900eb071	4	4	4	4	2026-01-15 05:14:45.575352	https://eservices.himachaltourism.gov.in/
d5ffe390-95aa-4740-8732-080afeec866e	4	4	4	4	2026-01-15 05:18:10.515853	https://eservices.himachaltourism.gov.in/
ff6189e4-a4f4-4531-9b94-60e3006ed177	4	4	4	4	2026-01-15 05:23:12.988605	https://eservices.himachaltourism.gov.in/
6baf9869-985a-4f61-b237-c45316f8bde4	4	4	4	4	2026-01-15 05:27:45.975148	https://eservices.himachaltourism.gov.in/
7471630c-d7ba-48fa-9dcd-53d30ee7b92f	4	4	4	4	2026-01-15 05:31:57.680873	https://eservices.himachaltourism.gov.in/
f04549e4-9340-4b16-8200-ac983922d7be	4	4	4	4	2026-01-15 05:50:38.226791	https://eservices.himachaltourism.gov.in/
21f32687-ecab-4e95-b957-9e44cc2b1c48	4	4	4	4	2026-01-15 05:54:14.364905	https://eservices.himachaltourism.gov.in/
401719d8-3739-4c50-b10b-8168f2dfc76c	4	4	4	4	2026-01-15 06:08:02.099043	https://eservices.himachaltourism.gov.in/
2e1e6671-7a93-4a25-bc6e-d3b6331412b2	4	4	4	4	2026-01-15 06:16:22.525062	https://eservices.himachaltourism.gov.in/
e3562d6e-df74-4ebf-80f0-e19f9f98a39b	4	4	4	4	2026-01-15 06:25:51.459798	https://eservices.himachaltourism.gov.in/
136821d1-8994-4895-9f3e-574f0f68b902	4	4	4	4	2026-01-15 06:33:07.243364	https://eservices.himachaltourism.gov.in/
876b93dc-a99f-4452-b32e-cbd6182f7b49	4	4	4	4	2026-01-15 06:38:41.832749	https://eservices.himachaltourism.gov.in/
23fab5aa-1254-433a-bac0-6cf614e6deaa	4	4	4	4	2026-01-15 06:46:53.95878	https://eservices.himachaltourism.gov.in/
eb37de71-a194-4cbb-92ff-5e1ffb432b71	4	4	4	4	2026-01-15 07:01:24.672434	https://eservices.himachaltourism.gov.in/
de2057cc-1d18-4c89-b61f-0d97104bd7a6	4	4	4	4	2026-01-15 08:01:24.63123	https://eservices.himachaltourism.gov.in/
66e1e3f5-5d73-47fb-981e-4495f0839518	4	4	4	4	2026-01-15 09:01:24.611904	https://eservices.himachaltourism.gov.in/
35b882bc-c1b2-4720-b059-f204565318f7	4	4	4	4	2026-01-15 10:01:24.655867	https://eservices.himachaltourism.gov.in/
0dfcd4c3-834b-4e42-981e-c5af63919f8f	4	4	4	4	2026-01-15 11:01:24.61397	https://eservices.himachaltourism.gov.in/
3d7aed31-818f-42ea-a7fd-970ca22ef6b3	4	4	4	4	2026-01-15 12:01:08.18294	https://eservices.himachaltourism.gov.in/
d87a90ea-b21c-4791-8f3b-7f84cab4afca	4	4	4	4	2026-01-15 12:15:26.475721	https://eservices.himachaltourism.gov.in/
988309f7-9d24-43ca-b349-462bedffc310	4	4	4	4	2026-01-15 12:51:37.575472	https://eservices.himachaltourism.gov.in/
51c0c533-5169-4103-9f39-4fcec3b6b183	4	4	4	4	2026-01-15 12:53:35.367405	https://eservices.himachaltourism.gov.in/
df3913fb-7bc3-4d48-8abe-bfc0917c4645	4	4	4	4	2026-01-15 13:53:35.438521	https://eservices.himachaltourism.gov.in/
fc31bec5-c83a-41db-892c-a06991c75461	4	4	4	4	2026-01-15 14:53:35.38051	https://eservices.himachaltourism.gov.in/
84a6ab5d-e115-4adb-8ce6-c5d00747abe6	4	4	4	4	2026-01-15 15:20:06.056939	https://eservices.himachaltourism.gov.in/
b971f0ee-7b5b-4b83-8dc5-014ad969d9a2	4	4	4	4	2026-01-15 15:38:55.627034	https://eservices.himachaltourism.gov.in/
d2ff3063-70e8-44e7-a341-cc59ea75667d	4	4	4	4	2026-01-15 15:49:25.156454	https://eservices.himachaltourism.gov.in/
c7df69ca-7299-4123-8bbd-f9dbf8c14880	4	4	4	4	2026-01-15 16:24:04.649551	https://eservices.himachaltourism.gov.in/
5699dafb-046d-43e8-805d-b41ff02a9da6	4	4	4	4	2026-01-15 16:40:57.505327	https://eservices.himachaltourism.gov.in/
a892ae6c-64f3-4a51-a68c-0790221ce9c6	4	4	4	4	2026-01-15 16:49:10.297301	https://eservices.himachaltourism.gov.in/
258bdf74-652b-4cfe-804f-22e50ffae380	4	4	4	4	2026-01-15 16:57:13.798717	https://eservices.himachaltourism.gov.in/
000a2a18-0f40-46a8-b4c8-f2ae4f8d30e6	4	4	4	4	2026-01-15 17:22:10.64903	https://eservices.himachaltourism.gov.in/
3c28e7cf-03c3-4adc-b8ba-c85bb809e2fc	4	4	4	4	2026-01-15 18:22:10.654768	https://eservices.himachaltourism.gov.in/
86f12118-7dc2-4499-a6a2-c51ed65cfed0	4	4	4	4	2026-01-15 19:02:53.36513	https://eservices.himachaltourism.gov.in/
e24428df-35b6-4933-b9fe-51afe88febf6	4	4	4	4	2026-01-15 19:09:55.594408	https://eservices.himachaltourism.gov.in/
7bda7840-c489-4174-bdc1-220a27d7cef5	4	4	4	4	2026-01-15 19:28:45.259231	https://eservices.himachaltourism.gov.in/
cac4c787-d0de-409e-984d-e2146598417a	4	4	4	4	2026-01-15 19:35:14.903228	https://eservices.himachaltourism.gov.in/
3f865046-d3d4-4c54-a8de-180cd400b8c3	4	4	4	4	2026-01-15 19:39:14.005964	https://eservices.himachaltourism.gov.in/
bd6fe58b-7cce-4775-ac9b-56bdb4deb852	4	4	4	4	2026-01-15 19:42:45.237461	https://eservices.himachaltourism.gov.in/
62d853a0-7643-4d7e-8b44-f3b4920419d9	4	4	4	4	2026-01-15 19:46:40.797741	https://eservices.himachaltourism.gov.in/
ddcd6227-2985-403e-b7e8-da294c9afe65	4	4	4	4	2026-01-15 19:49:56.630632	https://eservices.himachaltourism.gov.in/
45934bc9-20b5-472d-a59c-b972f9100c69	4	4	4	4	2026-01-15 19:54:30.93252	https://eservices.himachaltourism.gov.in/
96c3f2b1-ec28-469a-ac84-579486574c14	4	4	4	4	2026-01-15 20:54:30.948717	https://eservices.himachaltourism.gov.in/
206d76eb-892c-482d-8e31-89a94fabab42	4	4	4	4	2026-01-15 21:39:31.70014	https://eservices.himachaltourism.gov.in/
8e50b5c1-0bd8-4b05-8b96-5bd75deb9284	4	4	4	4	2026-01-15 21:51:23.094966	https://eservices.himachaltourism.gov.in/
8a6409d0-e15b-40f8-87f9-af8c19ef3fee	4	4	4	4	2026-01-15 21:57:16.55177	https://eservices.himachaltourism.gov.in/
c71fee21-90f5-4355-9601-01a5cd9cc70e	4	4	4	4	2026-01-16 02:34:43.922544	https://eservices.himachaltourism.gov.in/
2a1949fc-4501-4993-b36d-5cf050eec950	4	4	4	4	2026-01-16 02:46:49.768125	https://eservices.himachaltourism.gov.in/
c7a35d5d-1831-4d0f-9e97-a1a73c19cd0a	4	4	4	4	2026-01-16 03:14:10.954733	https://eservices.himachaltourism.gov.in/
f0f5b7b0-0586-47ee-85b7-b997e6ca203d	4	4	4	4	2026-01-16 03:15:01.733545	https://eservices.himachaltourism.gov.in/
e115b6a1-6413-4b54-8435-7fdc9c90f5bd	4	4	4	4	2026-01-16 03:15:05.095304	https://eservices.himachaltourism.gov.in/
23f9443a-0739-4fb8-bd38-ef15fa5d6790	4	4	4	4	2026-01-16 03:15:09.619273	https://eservices.himachaltourism.gov.in/
88e1b529-78ce-4b94-bb16-2284985395a8	4	4	4	4	2026-01-16 03:15:12.089536	https://eservices.himachaltourism.gov.in/
fe0fa6b4-733b-47e3-b3c1-df6097cb87fb	4	4	4	4	2026-01-16 03:15:18.634247	https://eservices.himachaltourism.gov.in/
02a02df6-4ef5-4f85-b3b9-bbabcef99cf5	4	4	4	4	2026-01-16 03:15:22.114582	https://eservices.himachaltourism.gov.in/
b37c28e9-4bd7-4969-b71a-5a351228c5e8	4	4	4	4	2026-01-16 03:15:43.821936	https://eservices.himachaltourism.gov.in/
d8e73674-5bb0-4e60-a178-e47b9d6db389	4	4	4	4	2026-01-16 03:16:40.624804	https://eservices.himachaltourism.gov.in/
d41b4a55-7d5c-4017-aba9-aaf44bc2d8bc	4	4	4	4	2026-01-16 03:16:50.754283	https://eservices.himachaltourism.gov.in/
38f6a55c-df45-47d0-aec2-9b285ab362ce	4	4	4	4	2026-01-16 03:17:39.192423	https://eservices.himachaltourism.gov.in/
e8327388-e27f-40cd-ac0e-0678a221eff7	4	4	4	4	2026-01-16 03:17:46.915088	https://eservices.himachaltourism.gov.in/
7aa018fa-e1f3-41f0-8baf-b0dc3cf8948b	4	4	4	4	2026-01-16 03:17:49.381373	https://eservices.himachaltourism.gov.in/
2c6278dd-3cb7-4fa2-9411-50238be38ae6	4	4	4	4	2026-01-16 03:18:21.817682	https://eservices.himachaltourism.gov.in/
0fa57e71-9c11-4b09-ac5a-ee9b2a24dc7d	4	4	4	4	2026-01-16 03:19:32.704185	https://eservices.himachaltourism.gov.in/
b6587a8b-b5b3-4eb9-9e52-5cfd54f5c0e0	4	4	4	4	2026-01-16 03:21:12.700959	https://eservices.himachaltourism.gov.in/
8518dd38-854d-4e56-bc4c-aa767ce5530e	4	4	4	4	2026-01-16 03:36:52.398158	https://eservices.himachaltourism.gov.in/
1379dba2-f736-42ce-a142-b1d7b25cab95	4	4	4	4	2026-01-16 03:36:52.609691	https://eservices.himachaltourism.gov.in/
9c6cea51-678a-497e-9f62-c805bd387c9d	4	4	4	4	2026-01-16 04:05:32.113574	https://eservices.himachaltourism.gov.in/
19336d54-4328-4cd1-8f3e-8053b1aae6cc	4	4	4	4	2026-01-16 04:05:32.396526	https://eservices.himachaltourism.gov.in/
57072e31-80e6-4769-8ea8-f1e0a05bf2e3	4	4	4	4	2026-01-16 04:09:06.202789	https://eservices.himachaltourism.gov.in/
202b085c-3b02-4031-9141-c739b926cb36	4	4	4	4	2026-01-16 04:09:06.455363	https://eservices.himachaltourism.gov.in/
f100862c-85fc-4efd-b608-9acf2280add4	4	4	4	4	2026-01-16 04:20:30.491523	https://eservices.himachaltourism.gov.in/
32e5feb0-183c-46c1-895e-f1c6bcce0efa	4	4	4	4	2026-01-16 04:20:30.696756	https://eservices.himachaltourism.gov.in/
8452b658-1a86-4947-9d3e-ad2d4a1ce121	4	4	4	4	2026-01-16 04:30:15.777389	https://eservices.himachaltourism.gov.in/
f9b3d4fc-9d7a-472b-9cc6-571b9158376c	4	4	4	4	2026-01-16 04:30:15.80202	https://eservices.himachaltourism.gov.in/
7d6aa055-2629-45a4-8013-8c0099e23aa8	4	4	4	4	2026-01-16 04:35:01.770539	https://eservices.himachaltourism.gov.in/
7c1af9da-c567-4c37-ab7a-dcb2e2dcee99	4	4	4	4	2026-01-16 04:35:01.772518	https://eservices.himachaltourism.gov.in/
aeb27e6e-9a31-4125-a3b5-a2a3f77ff6d7	4	4	4	4	2026-01-16 04:49:53.073616	https://eservices.himachaltourism.gov.in/
f2c681bf-8ee1-4a2b-808c-628e2a1c6d34	4	4	4	4	2026-01-16 04:49:53.081232	https://eservices.himachaltourism.gov.in/
a100dceb-509b-42c7-b947-7196819ffd58	4	4	4	4	2026-01-16 05:22:41.401537	https://eservices.himachaltourism.gov.in/
e749f10e-d638-471f-b66e-7b85f8af18b2	4	4	4	4	2026-01-16 05:22:41.420778	https://eservices.himachaltourism.gov.in/
613724f5-6791-44aa-841b-76af18974cff	4	4	4	4	2026-01-16 06:22:41.331798	https://eservices.himachaltourism.gov.in/
0e88b88b-07e8-4a25-a340-2ebcaa4a633f	4	4	4	4	2026-01-16 06:22:41.596984	https://eservices.himachaltourism.gov.in/
a49b12dd-f277-42c2-88cb-bbcecbb11854	4	4	4	4	2026-01-16 07:22:41.347981	https://eservices.himachaltourism.gov.in/
d459817c-fb66-4ad3-a411-15044c60f265	4	4	4	4	2026-01-16 07:22:41.354718	https://eservices.himachaltourism.gov.in/
b3d67817-d9da-4f34-9798-f35d3a9fa20d	4	4	4	4	2026-01-16 08:22:41.331549	https://eservices.himachaltourism.gov.in/
37375426-464c-4b82-8e05-4be5699f85d6	4	4	4	4	2026-01-16 08:22:41.374256	https://eservices.himachaltourism.gov.in/
ad20e8a3-a960-4c2a-aa78-aadf40db9291	4	4	4	4	2026-01-16 09:22:41.36022	https://eservices.himachaltourism.gov.in/
71e843b8-f12b-41fa-8a1b-5cd7b3193f87	4	4	4	4	2026-01-16 09:22:41.360366	https://eservices.himachaltourism.gov.in/
4802d5af-b47d-4916-865e-5f9741dce2dc	4	4	4	4	2026-01-16 10:22:41.451369	https://eservices.himachaltourism.gov.in/
9a5dbc8c-7831-42ce-80ee-3613784f303f	4	4	4	4	2026-01-16 10:22:41.465803	https://eservices.himachaltourism.gov.in/
d501c0a6-2ab4-4bc4-8b19-b5ac72eca505	4	4	4	4	2026-01-16 11:23:08.91073	https://eservices.himachaltourism.gov.in/
0e2604b7-0207-4e55-814e-9f85be6fb5a3	4	4	4	4	2026-01-16 11:23:09.017824	https://eservices.himachaltourism.gov.in/
d032e04a-592b-419e-923c-770f35faacbd	4	4	4	4	2026-01-16 12:22:41.375167	https://eservices.himachaltourism.gov.in/
f8ff930e-2842-47ab-89ce-0c2fb38059d8	4	4	4	4	2026-01-16 12:22:41.408931	https://eservices.himachaltourism.gov.in/
067b7c4d-48cf-457e-a39e-1518970b6e6a	4	4	4	4	2026-01-16 13:22:41.351695	https://eservices.himachaltourism.gov.in/
e585e6a0-c676-4cb1-b77e-1fff62f8c86f	4	4	4	4	2026-01-16 13:22:41.358039	https://eservices.himachaltourism.gov.in/
fed822f7-12cf-42c6-bb30-1431d05ca000	4	4	4	4	2026-01-16 14:22:41.320198	https://eservices.himachaltourism.gov.in/
0e07b209-953c-46bb-ab37-152397c05d8b	4	4	4	4	2026-01-16 14:22:41.336328	https://eservices.himachaltourism.gov.in/
2ddb6676-eac4-4aba-9bb2-4606cde2b997	4	4	4	4	2026-01-16 15:22:41.352559	https://eservices.himachaltourism.gov.in/
95c18052-7d43-4f60-9aba-ba930e800615	4	4	4	4	2026-01-16 15:22:41.353511	https://eservices.himachaltourism.gov.in/
60772a93-bb93-4651-9ac0-42d3f1e48221	4	4	4	4	2026-01-16 16:22:41.348709	https://eservices.himachaltourism.gov.in/
5bfc4274-eff6-4988-bb3b-4b7330b37abb	4	4	4	4	2026-01-16 16:22:41.352854	https://eservices.himachaltourism.gov.in/
2c1e6193-ec70-4cec-80f0-08072b3aae54	4	4	4	4	2026-01-16 17:22:41.345464	https://eservices.himachaltourism.gov.in/
8428de84-0c95-4c51-89d0-b8d188633a69	4	4	4	4	2026-01-16 17:22:41.356741	https://eservices.himachaltourism.gov.in/
323c2a0f-555d-4fc5-a423-e5f4038c9e3e	4	4	4	4	2026-01-16 18:22:41.35797	https://eservices.himachaltourism.gov.in/
6e612567-678d-41a8-9034-916698fb8f40	4	4	4	4	2026-01-16 18:22:41.384877	https://eservices.himachaltourism.gov.in/
b55d5018-551f-427e-bf70-b9b1da034df9	4	4	4	4	2026-01-16 19:22:41.396197	https://eservices.himachaltourism.gov.in/
0265a8fa-81b7-424d-bf92-157486add573	4	4	4	4	2026-01-16 19:22:41.397798	https://eservices.himachaltourism.gov.in/
8d93a1fe-0b86-41e2-b312-810e2adcce13	4	4	4	4	2026-01-16 20:22:41.381727	https://eservices.himachaltourism.gov.in/
f6353d2b-ba1f-47ee-8708-ce31f91b9521	4	4	4	4	2026-01-16 20:22:41.389694	https://eservices.himachaltourism.gov.in/
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.reviews (id, application_id, user_id, rating, review_text, is_verified_stay, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.session (sid, sess, expire) FROM stdin;
D6WaTb-h1Ek2SqzmFP8PEPFXO3EfQQO_	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:46.591Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f200d4d5-d569-462c-88d9-1ea25fa7b766"}	2026-01-22 14:00:47
YADHETfreyCy3bt7CCRrfXGQ9FjyqbC2	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T12:51:59.190Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "29535615-298c-4d60-a7df-13d08040e147"}	2026-01-22 12:52:00
_1qqKhqm3v63ba74dfNxFPNofzPMvI6B	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-21T15:48:23.707Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-21 15:48:24
ioWf_XSpFrrJ4pfc1jSWlTQbuck3J3XO	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T12:43:31.501Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a4743f40-a89f-441d-996a-167529e8590f"}	2026-01-22 12:43:32
uOJ8M8eKt8Nv9g0WjglgFoU28tp9BBtB	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:49.812Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "046e9240-3b2f-4463-a9c9-d22a00815ec7"}	2026-01-22 14:00:50
RZxPgiSh0HD96rIIXRnQfj4Ncb0vtdVm	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-18T08:02:59.655Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-18 09:17:29
YniNMYYctsLo-6nbzyPQ9uqyKGwloL9y	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T12:54:48.456Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "3a1ee037-a804-4a4d-a30a-c2f6039e96c7"}	2026-01-22 12:54:49
bX_tX87Emcpbze8aXIqUP6uEhxkBV_Aw	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T12:42:26.381Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f553b9c0-ae24-42a2-97af-bb442cbf4d2d"}	2026-01-22 12:42:27
lrAEc2Cbx9cgn05mDVin9to72hL5ytEk	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T12:44:43.909Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "311ceb5c-b065-4e3a-abc9-0954af3154b6"}	2026-01-22 12:44:44
8UewWmhkcsmfvbqh7lRlYauA30aeewe7	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T12:57:08.291Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "c8e2e777-b34d-4b39-aca8-bd5050838408"}	2026-01-22 12:57:09
Q-kr3SDAmO5wVVRIxdiSEw52xYgAaRg-	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T12:47:11.271Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "83d4956e-3aa4-4990-8a7f-efaf4fb27d09"}	2026-01-22 12:47:12
a6kz9-jKDIdzzt7-5M6wTJawj5VR0x0E	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T12:57:08.062Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "dc1c4494-a656-4f6a-be89-9c97b3b0f1d2"}	2026-01-22 12:57:09
vw9CWtvvgsXPCQCyEtb-LbQYCl7b2aAl	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T12:55:23.106Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "7b737110-8680-4dbb-985c-98e71dc2c305"}	2026-01-22 12:55:24
dDcsMg-e5jh6oH00Ta2fZ0KnhurzdiWH	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-21T18:01:07.166Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-21 19:20:45
Bj6P51wbIm6f1A_RSnvbenGmolKrNA0n	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:49.981Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "2c95df7d-a843-44b0-b5ee-e9a3458650ce"}	2026-01-23 05:31:51
PAcARTIdzM1OIfll3wPnRM1-1_mnDVRn	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:49.897Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "162158b1-c39a-48d0-a09c-1c1e12e83a9a"}	2026-01-22 14:00:51
56uUtNQp9xuywAkr3OPfTBGyFeTKwAyK	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T12:57:07.783Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5f094d1f-2296-4502-9af4-d5aa25fff8be"}	2026-01-22 12:57:08
H2YxHiXWlswsUrq7zzrHcbJKRzwDhhto	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T09:25:51.596Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604799999}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-22 09:26:28
uZ4QSG25nwB5bMo63ij0sVVqxqKzaN2E	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:06:32.427Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "c55eb023-85e0-4630-a965-2a8817e116f4"}	2026-01-22 13:06:33
ijoxz8CJpYMI_Kei0f7vXN-qm10ezDs8	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:06:32.962Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a136d932-ae92-4bd9-8768-9e5914d08aa2"}	2026-01-22 13:06:33
lzLEm3iMfJ-SdM-GFhxktke36QG0Hik8	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:06:32.711Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "c955fc27-7311-47e9-85da-c2e942c90035"}	2026-01-22 13:06:33
Bu1yoMW3KzmZ8jKux3d05xtZNPNIxeCJ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:11:32.479Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "8dd8642b-a59e-4beb-8866-cda32cbae6d3"}	2026-01-22 13:11:33
99fOsTOw5fej_owTDn-UnmBAQ6ATSFeo	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:11:32.821Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "4b1bf0bc-2d4c-4940-929e-3b5085a3838f"}	2026-01-22 13:11:33
1tNNLbEWu3huy7o5DguvMQRKnTzroTtD	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:11:33.106Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "34b3e809-9941-4aa4-8176-da9aab2d0b81"}	2026-01-22 13:11:34
C4FF4ws8TrmZkylxjOEeuaFa4hhEcr4G	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-20T01:47:43.767Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-20 02:12:02
pylqrj9zkD_n-vyvfrEFvFcfeW1EvCeh	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:16:13.465Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "23e4fa53-d9bd-4b6c-a958-3e92e74bdf90"}	2026-01-22 13:16:14
ajhFiOUu1mb2OBFuVdjGDcBIICiJodwr	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-21T09:14:44.058Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-21 09:21:53
sZCP0poX_XuwRf5PVpsndic-r7r8XDax	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:16:13.806Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "8bee7c4a-9bd2-4231-b035-f00616fc3af5"}	2026-01-22 13:16:14
tBW2k0iecHiPHof_V7EtS6ZZJuOw05wL	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.944Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "11e60245-7268-4e93-9045-4d9ca1ea5b33"}	2026-01-22 14:00:50
8GRYCbF0QyChlS9mcgRPtVJgDytbYZgN	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:46.604Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a96bef40-5b38-4b9c-befb-86092cdc5f7c"}	2026-01-22 14:00:47
Ss_iaAv8av637puCWYPVPW0VF59u2joN	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:47.044Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "4831861c-2c25-419b-a820-3a1ddf62a080"}	2026-01-22 14:00:48
8lxvuzgVDi7BYvw1fN1IsgYiXkGZqfz_	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:50.194Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "1a8bab46-2d4c-4694-9009-12d50f644ec8", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-23 05:31:51
06QvxyF4uGRZDu6grK5JYMO-wsY-ws5C	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:47.128Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e24a09ce-1013-4dbf-8cfa-b13d0fb5aaf9"}	2026-01-22 14:00:48
583uOp2L-oQeD9ZQUS25JYLXiilwp82x	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:50.269Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a77b31b7-49fe-49a5-a01b-6197bd4d468e"}	2026-01-22 14:00:51
RBl5bBJF0UCA3uqTagKpSRZ3ouK4pmi4	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.090Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "b125661e-cd86-46d8-a22d-8e5f2cc750fe"}	2026-01-22 14:00:52
T9OzD0aBLi0XJADqaZNohTQEHAzwenQ7	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.898Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "dd25cdb7-53f5-46c2-a8c4-d80ea9550e28"}	2026-01-22 14:00:52
CGVVph_gFoiPUMI4L4597Mj8aqEP6BOV	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:50.393Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "14ec132d-0a83-437d-84cc-c2ba4b1e79fc"}	2026-01-23 05:31:51
G3CLHMYlAhJ_KZSMRhHaWaWhwQX971Hf	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:50.859Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "6affed07-7898-4fc9-b86d-af1d610ad3ea", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-23 05:31:51
3Vs0uQ3Q7R0yHWwcZDdpqDUByITmDrGo	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:49.378Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "406c81de-5940-4e75-b942-aa769dca8b40"}	2026-01-22 14:00:50
0OY4yo-GWrJ8OhAqPJxWnbRdyvF7TjlH	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:50.271Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "33d7ab6b-6701-4764-8185-63d89e2e6e34"}	2026-01-22 14:00:51
f4YY2luN1PkgvUXj9rV7nutzr5qQEpcD	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.919Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "c379e771-2fb9-444d-af77-f7037f9f85db"}	2026-01-22 14:00:49
fm3ggEyE3iRKiJI3bqqwyv_GJ91whmWb	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:50.686Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f3941361-fb0b-4a28-b9a6-028fcd2e76f9"}	2026-01-22 14:00:51
ReSz9-unAGoP3edFtXMPY-fnWzuhxB37	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.499Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a2575f11-7e3f-48da-a03e-2b1f49b00e1d"}	2026-01-22 14:00:52
SxpS_RjbSxTnClKAfxRZe7IgywJP8wSV	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.968Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "0988d42a-c1dc-4132-a11e-a8525c317065"}	2026-01-22 14:00:52
NUJak9qO9AmpsiZFvUe6EfRS6efPMdSC	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:52.692Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d7ef0c54-60e5-4dec-b649-8d9f1d351888"}	2026-01-22 14:00:53
QdaLzyPsFT33vxbC6rWAM9BBYm9X9WcR	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:52.261Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "b68f1178-5ef8-4655-8f2c-bea5ab0497a0"}	2026-01-22 14:00:53
QG-RzvFsMHdSn8XjTc4yEonTJjnj0hC0	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:52.771Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "8ca9bb48-9ed8-4319-9f78-c675ad31e10e"}	2026-01-22 14:00:53
JXQc31CF8y3sGMp5187mjxK2yKCZNm4H	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.087Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d6269133-c1b6-4ccb-96a7-071892d618ea"}	2026-01-22 14:00:54
iX6xs3gu2TNU9RBTL_KMSMO-d3JRdeC5	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:54.299Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d264c61b-c283-4506-945d-64d6c9e272b1"}	2026-01-22 14:00:55
-P91gWNIoxAI-5tveJHdXQ8jdjFnfPdJ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.484Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "1f736bea-42e4-48e9-884c-3510847a36cd"}	2026-01-22 14:00:54
Uib7mJxymtXNAusrmyBxZ4KewIIlRYGl	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.473Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "c76fa3ef-24b5-4e46-af49-360b7d0f994e"}	2026-01-22 14:00:54
P7LQtTyzu6WGx4QIVRyj91fE23Gh5DQ1	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.882Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "9e29b6ad-8a1b-47c8-a281-8396f616fafd"}	2026-01-22 14:00:54
2uiwNOsvlVH4w2he1D08ViPiHa0DOTYD	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:54.284Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e2599a1f-f9c6-4131-955d-006e836ee65c"}	2026-01-22 14:00:55
OUYGgNyI9MLf7C3DosqZFfK6j1spc9wN	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:16:14.172Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "aa54f8a2-a077-4615-8679-1fa61d85f04a"}	2026-01-22 13:16:15
twmIsCKLYnO_vvbtAcaD-bvpYpzjPwpp	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:16:14.474Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "76cfb0b9-31ce-42c9-bef3-f7078c4b61c0"}	2026-01-22 13:16:15
9MsUpUnF2ap240qPb3pPJh5HwdnRF5dv	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:17:40.363Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "6f5b6051-150d-42b7-b535-ca36bd42d34d"}	2026-01-22 13:17:41
IpIcVs60HyqNOLcGmb6w-lp3cRmB79Zg	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:17:39.625Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "05f9dca8-9c18-45e9-9ce0-ee719e04dfea"}	2026-01-22 13:17:40
bTa2Laz_7GFn9TXk257yvQq6MUJ_3M7E	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:52.319Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d244a912-8065-4604-9b58-ba9b69d93e11", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-23 05:31:53
VbJ_iHEGNSM0jRfbFNzH0rHBTBjLXC-i	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:51.316Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "1961069b-5b79-4334-ae5e-758545382c27"}	2026-01-23 05:31:52
3evtcjLlt_koadc-eawuuR8vIlxJBzpu	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:36:30.949Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "7a0223d0-1224-4ea4-90ea-436cec619d8c"}	2026-01-22 13:36:32
ZdvSMU2HiBC2xM0vBN1RtwatmsEWNAoU	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:50.552Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5da8ac27-6650-4982-b51a-a7e7c5257075", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-23 05:31:51
GQddxlzjmVxoWfhHVB7zYNz3SrfotJd0	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:17:40.011Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "528925ca-1b15-4382-9655-bfd346b76382"}	2026-01-22 13:17:41
YQss1nWeeaIiefKL5XJsIin5Ks9pv9LJ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:51.892Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d2c08f95-a3dd-42c0-9f49-b6363ea101aa"}	2026-01-23 05:31:52
X7f9J2mIExJpVKiDbve75ZOl4TOKGbk-	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:36:31.767Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "dd94c7c5-ed80-428a-bc72-2e7c201e93c9"}	2026-01-22 13:36:32
YJWKHcJ8ZpW_Sj2nEsj7Ll0BxXID3Zay	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:50.732Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "b6fa6422-dc6e-4d1b-ad0b-d8d6155ac133"}	2026-01-23 05:31:51
aZ8IF8u_5Wkr5RGqtsLUteTsVVTcxLWY	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:17:40.685Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "3bb35af3-b2a5-4c2c-93f8-898c9df99693"}	2026-01-22 13:17:41
MXBlsJSWzD9ui9YpQUfTW-sT231ySrDY	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:51.159Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "34db6a0f-a3a8-4860-8bc5-fc03291de0d3", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-23 05:31:52
OasRhW3uOTU5xbGjBbq7aCrzZOjmeSXJ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:36:31.514Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ed4db028-54eb-40ff-a3df-0e2507ef4ffd"}	2026-01-22 13:36:32
RrJ6j5YIez1dn3LG1jx2hj19kcTcY-NK	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:36:32.026Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ac827d2f-dd4a-460d-be2f-23ebad1fa102"}	2026-01-22 13:36:33
mplkKJz3rpVHxo2-jm5x-l4DwSVzhjFm	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:36:31.252Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "0806dfb8-3002-485c-9a0e-a44d4be4d39b"}	2026-01-22 13:36:32
hmSuQjbO4jW0ZqElSQBrTtDrukUVnfEF	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:51.732Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "b7987533-e127-4cad-8233-de0fdde7bbc7", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-23 05:31:52
EBEJSd19RkhGxLqjAXbUelatdH5wbkfq	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:36:32.284Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "c1521403-a2e5-4ef6-bdd0-1acb3cbc11c8"}	2026-01-22 13:36:33
-h_jrSzoUBFT7GsxB4aP5UkQdIVSO5lw	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:52.474Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a90d9e56-3d2d-45e0-8ca5-a8da134ffc5c"}	2026-01-23 05:31:53
1ctcfEj4qXRVvi334qBGJzatxt-p5y--	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:36:32.560Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "89aad505-2170-453d-a0f6-94ac7c0e6d50"}	2026-01-22 13:36:33
_HznJdvnjQwlmWJHtrHlQW5b--CScRt-	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:36:32.810Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "be7d6c59-eea4-43cf-852c-f29c6e7e79ce"}	2026-01-22 13:36:33
yvvZauU43LHI-InRmywtBiNxy9SDYX6J	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:52.900Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a9a95a58-c2be-4175-83ed-7352a709c3c8", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-23 05:31:53
fQqAJ6jWK9D3JrcSmb5Fa4koWc7EzIJV	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:53.073Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "9462b151-1337-4344-bc94-5bc90b59ab03"}	2026-01-23 05:31:54
ZHd3OpzTSw1i6d8SGNCeSyOO5dBFLS2F	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:36:33.058Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "aa627e94-1265-4128-944e-7739565896f5"}	2026-01-22 13:36:34
dP9i7lqKBMqPrEGBaYwCKpTekoX1cq9m	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:36:33.295Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "3236f840-b1f9-4bee-87ce-26b85288c1ba"}	2026-01-22 13:36:34
XAofEt_cPT9hxnnkrB4mzqXg7U3aHGhg	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.505Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e4d444d9-e616-4f32-bf82-498726cf3969"}	2026-01-22 14:00:49
Rdp9f_vRxZ5kFxoxzkfH819DbnJqrvNJ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:46.608Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d59bb89f-25a0-4fd3-8b47-2976ac3b3f9b"}	2026-01-22 14:00:47
l6F04jS1MvavrAz738TaoEXD88--zqCt	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:46.673Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e989b0ee-dd0c-4ce9-8af8-781e8ba02f8e"}	2026-01-22 14:00:47
WOkhRY-PqXjSuRcQxYuqbcv8QJdA9q5B	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:36:33.800Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d6e5a82f-6df3-4ced-965a-4c7f328f76e7"}	2026-01-22 13:36:34
53bdKTyRT1alRAmWRIUCN4JveanyzviO	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.914Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "4f0d7650-cf3e-4ed4-8a80-64e002cc6056"}	2026-01-22 14:00:49
OQFdlecduBzJDszsQwxYzUPCzOiT9oCd	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.949Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "411c21e8-35c2-44a6-a02b-f356d5d0622c"}	2026-01-22 14:00:50
hSz0-012oVJZERibEn2ua4wRhjHL9Xfb	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:47.508Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a7562a1d-5b77-4b23-944b-6c44b3b416d3"}	2026-01-22 14:00:48
HPPgdsSjoh5bRGW7wCkTA9pqBTbMJlPn	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:47.572Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "b5b9fbf8-9ae8-4548-8299-83e455af8bfc"}	2026-01-22 14:00:48
NZI0yNknaT8-Czl3jE83_lhCmOwFEzse	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:47.597Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "fdf23724-9ca5-47be-93cb-3cf5340f7166"}	2026-01-22 14:00:48
qSx-ekxXK4xg4V7jdDeEEyVNwyoar6vV	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:50.349Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "6e8e1f43-15eb-42f6-a680-9e4c44192952"}	2026-01-22 14:00:51
XiFWcMdhiRT7oEZl9JHnqKaZAa-3YdUi	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:50.687Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "8b7896de-7997-448c-bb8d-27e3c9731e85"}	2026-01-22 14:00:51
6Ulno7EbQRA_WgnzYMlKMT9frsZbzibF	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:50.688Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "673fe948-c92f-4b68-85c2-9a2d7dfea971"}	2026-01-22 14:00:51
ueZj6a-fnulK80g8OiyrdzfhczhNRPpw	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:50.764Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "380b5741-582b-4f6f-b858-9ae53ea54a87"}	2026-01-22 14:00:51
hK7LaWZjWyyaMjtNPR0tJGj5lUKNKM24	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.168Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "edb09e03-c176-459e-a2b4-5cffa2089a6e"}	2026-01-22 14:00:52
S35efBgVwcZ8aEfhuIbTlo9qTP5rKVr1	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.084Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f625569e-44c7-4f5f-9e88-d1ebe5418f08"}	2026-01-22 14:00:52
n0C2RRUm4EJnCpG7Bj5R3icbbkouHWdJ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.085Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e10b5523-68cf-4bb5-b92a-e3aa1690e2df"}	2026-01-22 14:00:52
fxkqWxa85j2rZ5FEG27fVlmfbvcTqJYl	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.581Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "696a388e-c768-415b-b189-ab933b68572e"}	2026-01-22 14:00:52
s5msmZJ5P60qCmrW2kpE68zT5V23vu0P	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.497Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e5bb23b9-51e4-450b-85c2-550162dc77d8"}	2026-01-22 14:00:52
K9Z34UJE_Cwt2NMQbS9vMAdKWjA5x_dK	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.492Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5d7509e3-6170-4772-a091-c9d1bf9a1a3c"}	2026-01-22 14:00:52
saN96TW3wr6pvPbK0hNDpSssec9-aj7u	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.890Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ea7e35ec-cfcd-48c5-90e0-60c08b8dbd27"}	2026-01-22 14:00:52
mmQgUY9xSOl9c9QCQgyc1VOmvj_ciW6N	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.888Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "c7424520-a888-4ddb-be2b-d1ad81902c4a"}	2026-01-22 14:00:52
74CkTkpz6Pnr-J0xuJbCq1qOllAIbs18	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:52.261Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "54eb4664-f445-4e24-ab4c-6978bef45607"}	2026-01-22 14:00:53
a4bWqpzP3z4Ok8VCXBeRQ7VPoLI-boo4	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:51.028Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "46a9bd6e-0895-46f1-9837-238ba478bc99"}	2026-01-23 05:31:52
jL8tijWASjQe4hW5FyXq8xsaR3Ic6nR2	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:51.438Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "efde4df9-1dcf-4d85-a9d3-151d17c8011d", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-23 05:31:52
7CYSf5DxKAtXPIqNBklyc--9k1ZlLD7k	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:51.597Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "51c83d0e-9f80-4d79-8eb3-6301950b29d3"}	2026-01-23 05:31:52
NFGarA--P7FLRnopBS0XimYDQCQ1FV4h	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:36:33.556Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "c5ec7add-599c-406d-b813-ced3b9ea84a9"}	2026-01-22 13:36:34
yMlUkjrgzHO3cR2yiiAaExboN8DSS3tR	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.189Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "909b1192-abb6-4efb-92a1-69a15764c77e"}	2026-01-22 13:56:59
01-UIrf99p4oCO7mfGUdAQk8Iv978Hsr	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.211Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "69dc6a1e-02f6-442c-8bdf-499c70998d86"}	2026-01-22 13:56:59
tKBk3_54t3OwTBObyVP0CVej8fCagiIe	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:52.009Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "6d27a721-acb4-4dab-95d9-0b2c91645234", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-23 05:31:53
8oqFRzyL3t9wNNOTaJHT7vaEXZoQFj7i	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:57.956Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "c02dcf24-ca3c-4743-92a0-6573a90f7d56"}	2026-01-22 13:56:58
ZOCilxsViC6xMEcTHn64e2sd0YSEe-hc	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:57.983Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "10b6e321-4701-4b87-9f86-d9de9198fe52"}	2026-01-22 13:56:59
u8azhc8aiAAcsslC7jebht-Z6zrmKwZM	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.239Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "4ee6f8f9-6afd-4954-8058-776ec799689b"}	2026-01-22 13:56:59
f4kqDJqLj3c8VlmKNspvHrSufv2PQlNF	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.015Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "87583a3b-b7fc-478e-9147-84c3a7139e2e"}	2026-01-22 13:56:59
_TGtcdTL9vRCQ6pPXYRu7t22D6k_EfDX	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.020Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "96ff9912-757e-444b-aca9-c9b1c909361f"}	2026-01-22 13:56:59
wylAQ68fad4UhqglGtjBq10NGipyTP23	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.242Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "381ca68f-d502-4f03-b9b8-e1f0a957899d"}	2026-01-22 13:56:59
TOI9KLjz-Y4_tUp3O4v8tocJxYnwuyuz	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.060Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f1d3bcd6-d91a-4969-8f3b-22945f38d610"}	2026-01-22 13:56:59
FFmpGMSmi-aFIsFd31f3NaUsRqeVWFuV	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.565Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "0f35b272-e917-4986-9d78-eaaa3b864584"}	2026-01-22 13:56:59
IltnvEeDZ459tZCOeFPKjMugSHFm07Zo	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.294Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "b786ff90-ee91-442d-ad40-105d169939ed"}	2026-01-22 13:56:59
DWJJXhq6JLndHxPt2zVYy7f5UjvnccAZ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.782Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "1c5dc184-b368-4c15-8489-48da2b8358b2"}	2026-01-22 13:56:59
A8DBEZ_1WMVtwvV2KF_jVWNdpiPXtkCj	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.434Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5c623ea5-eb1d-48bd-b74a-43944f3570d2"}	2026-01-22 13:56:59
G4NUmu_fKkDnEq_qU6u18ZJysUa03eOc	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.115Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f00fd95a-237e-4cb2-b70c-5eb3b0b06c8d"}	2026-01-22 13:57:00
hn_J1JWGjRe2HKYo9REffxDSepLCh2Ml	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.577Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "6d74b278-3899-4181-b8fc-7b6924c84ac0"}	2026-01-22 13:56:59
wQCvXqmTht_PPDMYafee3G5cp26Et_VN	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.578Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "1c8e1e8a-2dbb-4261-b950-dfb11f3df84b"}	2026-01-22 13:56:59
EjCPjaQrOugpVCxRc9_XHGA0KdUO9fED	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.580Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "2f4e750e-d051-410f-b689-4c3d0730f4a5"}	2026-01-22 13:56:59
MIkvhDDHmIBvqI8S65TREGkw5IkM50lC	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.886Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "89e2f0d0-07ba-40bd-a6bf-a919314ca3eb"}	2026-01-22 13:56:59
-ROBTcgGOigCbNOJPIp48xZGXHQwt-dx	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.926Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "3aff33cf-8803-4de9-9cb0-584178375d07"}	2026-01-22 13:56:59
XuUVcCbXJnV_-p2_6Q1P6KNtg8RUwYGv	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.920Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "cf29bed0-3c8e-4cf2-bde4-bce648e2049f"}	2026-01-22 13:56:59
HTtjz6PltQHRpko8KDvJCzy1MwAlW73c	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:58.933Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a021dcff-7eef-4958-8613-8cf125d1d205"}	2026-01-22 13:56:59
rwfyRQURuQHVnEFqAnBcai0S1VPexuOx	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.210Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a510a19b-55eb-43d7-a1c5-e2ed16f2851d"}	2026-01-22 13:57:00
uVeXwarjY_BwCsaRQ2MFuWcfBSb1yGxn	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.218Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "729de72b-6fe2-4f6a-a10e-8c4eafd95430"}	2026-01-22 13:57:00
onUXcj85jXdovyekOsf3w13sY1Q1iq0k	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.236Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "373a9529-93ee-41c6-be48-4f83819f492c"}	2026-01-22 13:57:00
cmzuT5engSsPGzkd_r4F9VcW7j1lEVEU	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.357Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "edd36979-eb2a-4da8-a99b-789b240f81f0"}	2026-01-22 13:57:00
7XZTzVrho1Yy6iaL3ibZi8XdtcSSfdaE	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.227Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "dd59cbae-d9b4-4e72-beda-1dcd7cb3ba71"}	2026-01-22 13:57:00
eu60NMc159AlY7FOz3Nr5L_Eq3PPBDEW	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:46.605Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "b101b85e-abcb-49fe-b3f0-2f447c9a9f55"}	2026-01-22 14:00:47
6iQc4x3h_Wfw83faFOwCXGVBx6XjJlIc	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.488Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "fdd9bf4a-9bc0-4de0-b620-e49491aa3203"}	2026-01-22 13:57:00
KFU4AjU6GzmVbRx2pbtFvADsT5QW9aEb	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.850Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "43904951-3cc3-4867-a45c-eb6bab1ced42"}	2026-01-22 13:57:00
EAYArOs4vJVKQGF_azJN7j0c0-fNf-0M	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.910Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "dd9186b4-2911-4ea6-abd2-461774f5781d"}	2026-01-22 13:57:00
p44aSEXjNl87-aReMxXwi_O4-YVN4l23	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.891Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "98a4acdd-e2f4-4a89-bd14-86ea24657d21"}	2026-01-22 14:00:52
I6TITJbqZo1855W8OJZ6q8ttOJC2kvvv	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.334Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "47dd9d82-8deb-4b46-a793-889062bfd1b5"}	2026-01-22 13:57:01
K2-EjJcRGlSS4k6Ob1jQOVK0q6z8AM9Z	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.813Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "6b15888a-902f-4e9f-9376-05c134cb8db0"}	2026-01-22 13:57:01
6Mmu9uXkTypuXFw0CGd6X4e7QFLfPzYl	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:52.590Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "249b7155-1f20-404f-b377-b0202b66a8a8", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-23 05:31:53
Rl2WLV4Fy8tKZsSIJN1mReJ-DEp3g9Fn	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.867Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "2b8caf08-b176-471b-88ae-4c2844de12e3"}	2026-01-22 13:57:01
cSgMwb6ue3WPBV6lALNAyHGUtNn6Ral_	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.899Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "0a2d8b1e-1459-4ecf-8d0c-f8fa6f1b14b4"}	2026-01-22 13:57:01
GYHoq-3pUDITYdH23V7HIlAXloejRB9v	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:52.340Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "95635d39-c9be-4c3d-8046-8462e3820449"}	2026-01-22 14:00:53
yAgnlIq1iAunVCVYg0CSORsFJFFqAE7N	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.493Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "849e5f2a-5a65-4397-b5c0-97e68d23b636"}	2026-01-22 13:57:02
e4H8bI30RjFvDu2jz7K4nK81raCB76pY	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:47.024Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f7b801fa-0ef5-43e9-95e0-409790271f9e"}	2026-01-22 14:00:48
XXk3AntURCBv-4898T9FKxr_gyA7gTdq	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:52.204Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "87b4b2dd-d35f-461d-853f-957c31ee3364"}	2026-01-23 05:31:53
SbNBV0bC9b_ZzeRqzB7yjvazYviXwns8	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.498Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "fb07e036-4faa-4031-93a1-16f3cb827fa3"}	2026-01-22 14:00:52
iTaYdYNoqFaTaaDjTp7_663urukqvVpu	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:52.690Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a2bec987-4d03-418b-804e-69b9720b5f27"}	2026-01-22 14:00:53
wBcbh9lLu1R2pcnDXKDjEbtNyF45Z-Xg	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.476Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "3f250339-fb43-43c5-b1c1-24e8e213c14f"}	2026-01-22 14:00:54
vC4gjnEBVEp1F_YAVGKHDweUyimQXnb5	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:52.776Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "6af3e921-4c29-4eea-81c6-3ce45f97c261"}	2026-01-23 05:31:53
pbD7qKWRVEcNKAN3dOk3OG5wsk8IsY95	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:52.693Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "3a57bd93-ec0a-498d-8002-791de5545758"}	2026-01-22 14:00:53
MU3T2lDe3TYHR8og_uD0LAQNV2ToZk1x	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:52.259Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "46aaeedd-b2f4-4161-99b9-6f4c182877af"}	2026-01-22 14:00:53
FixBHAovaHOMoqgamxvcV8xQ0ReISuJL	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.079Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f46e48c4-b313-4733-bec4-89be2f78f354"}	2026-01-22 14:00:54
vpRqxe8FKCTu_reKZS3QWEEwvfFg3AM7	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.162Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "9a50c9f1-e9e6-4f51-9c12-56f66794b518"}	2026-01-22 14:00:54
XdycWP8sGGaxu4P71wjlc5GqBsYAMd41	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.089Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "14070c77-4ce8-44ac-af61-e325b9938a53"}	2026-01-22 14:00:54
pDXDz4SuOl9RKoeEXl5CJM3t6JMz-UIl	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.470Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "05b04ffb-fc9c-4e98-86c3-9e458bb985e7"}	2026-01-22 14:00:54
1FWF86j8e-ArHPCPg-cdVOj9KkLTNIQ3	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.554Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "cdbf6366-ab5f-4456-b5d3-2e2dcd43f636"}	2026-01-22 14:00:54
uDD2nrRi8W81PZ1Mu7lyjLy2bjM0sIFa	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.445Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "8e041e3b-c6b3-46f1-9529-7b5ba76aa20b"}	2026-01-22 13:57:00
Q3oy0GcPXhojcsynFXE4vGH_0X8YbqNS	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.476Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "1fd1232f-b5d7-4bdf-bba9-8c0326b9f829"}	2026-01-22 13:57:00
j6iTnC8xkWf1Lpwqafepx7-81h0o0IDN	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.729Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "1245ccf4-c90f-492a-84f4-472d63ef685b"}	2026-01-22 13:57:03
2jvZqaBPE1N_g7mWcg46fxcl1YVzxQDS	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.865Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "c9c9113c-b765-4d47-bf71-3287d3a7f49c"}	2026-01-22 13:57:00
lrJyatS5tJkGEzksRdVPc-MK2njJG3q_	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.592Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "bf939f60-6235-4ae8-aa1e-d46d90374cd3"}	2026-01-22 13:57:02
SxyLwhG_FLfM8yld8T1pGecKLtl6it8A	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.918Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "87423dc5-ccf6-4db7-99e2-8abc183247a7"}	2026-01-22 13:57:00
ajy1KFLZOuV9mOssT-n3rODsKSvOIfOU	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.937Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "8cd2f222-d4f2-47be-b9b1-429ab74ab91e"}	2026-01-22 13:57:00
vtWmHkOCmtZSfuz1BOttzBxwV8KMfKbh	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.278Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "c6fa55cd-4924-4e1b-aaef-635d93bdca11"}	2026-01-22 13:57:01
J7Y5P3to0m_TADOboCpl6ueJ49aJ3meH	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.030Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d91fc001-b4bd-401c-9752-77e55ba52107"}	2026-01-22 13:57:03
_diWONyQY9Ym8xcQke1RoYkveMiV8V6z	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.686Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5e02532c-036a-41df-9969-aae2403345bc"}	2026-01-22 13:57:01
xQgygRfs89BRIdemfD2JUiN8YcfFsxzT	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.020Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f454c940-57ec-46f8-b926-fbf2bd3ef09e"}	2026-01-22 13:57:02
3T0oka3ykEae6PzxZ_RH_PxcZ7iuVTj0	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:47.521Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "cbef38fc-8cce-4eb9-ab5b-39cbb2d28038"}	2026-01-22 14:00:48
GIsjlQI_JlUGTr9g261urIcbusrhe_Pn	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.081Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d6a47232-8588-4854-a584-8dfccd2ef033"}	2026-01-22 13:57:02
aSe0iWGMBXkzMdO5HLBBeWl9pi18L4jc	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.053Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "436958d5-932e-4f78-86b2-9ee0d0b31a8e"}	2026-01-22 13:57:03
QnFJqX3-zmj25q8R3erfOl8hX4vO66At	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.097Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "418b92bb-30fd-4700-b155-99a6356e457f"}	2026-01-22 13:57:03
pqIfjB3_sh06lwbuYpBDZavzOoM_mM4f	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:53.197Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ff8dbe4-2fe2-44a2-82ab-0588baab4da6", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-23 05:31:54
lI2tpiuTxpc1gIvzjWg9rADY2tJ5QgYw	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.523Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e7bd1c4e-8570-45b9-a923-bc8e7401c0dc"}	2026-01-22 13:57:03
JrGB635uODyakUPfraffRfB2egYZoBsC	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:53.361Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f80dd5ab-6ca5-40f6-bf02-1e980b335e07"}	2026-01-23 05:31:54
s2iD1wZrHH41fDaXpG8OYEIUBtbe5brc	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:47.059Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "9596014c-87b6-4e87-a28c-3c06c10ffba6"}	2026-01-22 14:00:48
7w_T6D03T_r1Ef0kZFPhoyON-fjHxRg_	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.053Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "fe41e63b-04bf-4051-9588-c673afb3fbe4"}	2026-01-22 14:00:49
SjSzxaK9jlonYYi_v_Z6cV0xOsDpg3WG	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.512Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e9a64da4-b83d-4fa6-bcf7-7ba7efc32036"}	2026-01-22 14:00:49
SNhi8ooPF-Yxvvpx5Rl-VPNLgCrEn9kl	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:49.401Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f48891fe-0336-457e-9407-bcb7486b3247"}	2026-01-22 14:00:50
dr-LvNs9WcFzlYiRpbniRVX_kCSKfKHK	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:49.816Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "01a776c9-bf4d-44e1-9124-729c088ab3fe"}	2026-01-22 14:00:50
WApibpPmjHgzfFCqMS2y8LgFdcIxQEN7	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:50.690Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "1fce905f-56b3-4cda-9c74-9d9f50d43e06"}	2026-01-22 14:00:51
lVrjmxoM7DeZQDuyzyZAaD2uNjqWIBaU	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:50.268Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e0e71fd9-a2cf-454e-a357-371aab801a02"}	2026-01-22 14:00:51
uxPacfafpqDTjU2hkPvlGxU95j_fZ6bb	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:51.096Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "acf9c22d-3a81-4318-ba4a-79833503f9b5"}	2026-01-22 14:00:52
rNCSHYNVP8iOHFMiKDnJf604HCouP-Is	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.469Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "afcf6eca-e9ec-4edc-baa0-7262a3011a8a"}	2026-01-22 13:57:00
URMpuW66HlFlAZN6DVeSvuMnQuCPZtku	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.622Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "2c688215-185c-48ce-b5fe-8ce3e6b95553"}	2026-01-22 13:57:00
pjxHxW41rqtaxoHzpwTACUxxXBMFfRf9	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.730Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "13d8cb4c-bdce-4886-a1af-2891e3ab2ce1"}	2026-01-22 13:57:03
o4Ll-TkN5b2i_mgpY-P1MEaLfoaxIWg2	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.681Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "2cb960fa-b151-45cb-b272-ec3a308492b5"}	2026-01-22 13:57:00
avgytd4OVv69jE8juztK41ifNS6Q_353	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.881Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a6fc9813-13b6-4de5-9f14-8e8505329a2a"}	2026-01-22 13:57:02
Uwd0Wn_pISyWHMCQTrJaoG-s5JsGUJyw	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.058Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "8a6ed20b-e56d-4026-bc8d-e293e859bfb1"}	2026-01-22 13:57:01
OkY76a9QgDs2aOjN_pLGQihbzDe0E-xf	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.344Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "754337fd-58d9-4ef2-945a-c6dab90c9f00"}	2026-01-22 13:57:01
LnfdoDoYfc5bMoJurXybcQeMggG8la0W	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.409Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "bb9243e6-77f2-4aa9-8a37-7b6359f4f58a"}	2026-01-22 13:57:01
vNav-iZFVPvXNuRqnPJFWfi5EMPw8Sf0	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.216Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "32fa482a-3c77-44b6-bb62-1932046a01e2"}	2026-01-22 13:57:03
wymWI5l6_lT3KracVuwYBY7fyMLvCsoA	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.795Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "37c8755e-96a5-492d-9ac1-be552a322634"}	2026-01-22 13:57:01
sVsK1oi7tzxzzSDd9y_A9l6UlkzePleZ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.862Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "158595de-5d1d-4b34-88f2-d61de98a99e4"}	2026-01-22 13:57:01
tY84HWzv1H9Tlu8IiUf9N4rkvjwffL1y	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.596Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604799999}, "userId": "6124fbd3-c9cd-43cf-b348-5c0f233c9e57"}	2026-01-22 13:57:02
LIgFrhaXXs1DAVCHMn4MQ3QY_geAF6PA	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.277Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "8d1ec217-1909-41c7-86c7-09c65f89c941"}	2026-01-22 13:57:03
Ug_jrva23jdDSUdmZwskLLkJMIo_Ce5I	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.785Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "497f1c74-1828-4bac-9900-c193c25faecb"}	2026-01-22 13:57:03
Di7529gvhMI6eMV3UmaxgIAouFBDKcRL	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.311Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a8d831f4-9caa-4ae0-9719-67bafb7811a7"}	2026-01-22 13:57:03
KJH9mU135QK-zYK6G9R24y_Q5S8VGA--	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:49.367Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e38a12af-59f4-4657-a6b7-f9444d0a131e"}	2026-01-22 14:00:50
Rdejv43nEkAN2dl3IyhD7aRphoH7hb82	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.687Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "be935755-2dba-4b80-b321-007bb44d762e"}	2026-01-22 13:57:03
9dMSP8wM3icH73rngo9QxrQjhblq4X1n	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T05:31:53.479Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "cdb880ee-4ba6-4441-b5b1-0852c2cb4b55", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-23 05:31:54
qAsBMLEHjjOgf_by3vR4ArkUNXRJokb3	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:47.064Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a594f4f7-fd9f-40d6-a7d7-aeb205f64b0f"}	2026-01-22 14:00:48
lzJliM7BaEktTcrfpEHA1KOeX-jrKdhu	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.044Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "8f167a42-a2e0-4fcf-bbd1-0853e57d6046"}	2026-01-22 14:00:49
TfSnyk4HdpbST_TcN1bcYAuTSeV0_Knl	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:47.589Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e9813c7e-af8e-4fd1-8115-8849cd2ac909"}	2026-01-22 14:00:48
O7_EMK-EWvAJlf0cqz3MQIiDWlqUR4KR	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.503Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "792561d8-b915-4eaf-8854-e1b46099495a"}	2026-01-22 14:00:49
JVowHKB0mtOVHGjcSsRqf-ewUQUnDRFv	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.141Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "323f9bcd-7a71-47ba-8546-219347c8c03a"}	2026-01-22 14:00:49
kqNo2ZRvA4YhcScLxpowfdj9gJmv_pOY	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:49.810Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "945e7edc-69fc-45ea-a032-1432eb37f579"}	2026-01-22 14:00:50
tiZ4VI7-OjvzPeCDyGMkY7sBkt6fzRJo	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:50.269Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e7f15b4a-2b41-4a07-bd16-f956fb01daa4"}	2026-01-22 14:00:51
D8RQmUXSR4k_SayKrJEtkJOFhHU4j1RS	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.617Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "1fc59259-967e-4a0b-b351-38bf051355ae"}	2026-01-22 13:57:00
BgWOWUWciUp_DEjLQ7jICSIkH6jx-mUW	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.451Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "3de23620-9a5a-406c-8b06-0e3661950149"}	2026-01-22 13:57:03
GYHqnlVr67949Krum8Mv-DZ5g1jpKXBj	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.684Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "7738698c-1383-4f61-ba77-5bbde111734d"}	2026-01-22 13:57:00
N5Ya1s-ZRXgy3pYN9LldTLwDcmKf-jn9	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.068Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a2be5f8f-1d29-4527-8ed3-e65756e77118"}	2026-01-22 13:57:02
pfYJgPws85EdYsUiYVXgXMjj-axeyfqm	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:56:59.728Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "369255ba-d44b-40e4-b543-e46328f5505a"}	2026-01-22 13:57:00
o9cp2YCC29XmBnnSQVdOYbXyCDNfYOA6	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.055Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "950a2ad1-6913-4a69-98fe-abbf9f085e70"}	2026-01-22 13:57:01
_1UzcZ0JGnOcuvEtC4zor_XPcqBLR6rJ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.103Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "740e33ea-0a84-4421-b22d-768aad5a7b34"}	2026-01-22 13:57:01
Jd8BtxvIucyAnFaiPMQyGBA-BnnsrLuv	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.100Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "da6bfec4-3b41-4242-9cf6-6c0e886be883"}	2026-01-22 13:57:02
9DA4gUU2l-cs9s2A0_2k2RykfNo1tp7m	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.337Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "01d77aa4-3860-4b31-ae90-0dc219e62dbe"}	2026-01-22 13:57:01
koQGTDR4FtxESUO-0RtKjBCLedSjT3LJ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.571Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "92e981bb-7128-4960-a10a-17230554679a"}	2026-01-22 13:57:01
PTJwYO9FBfH0LkXaKoq8dgbxmBax1byq	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.663Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8fbdd30-523e-4c89-aca5-cc174bf13bac"}	2026-01-22 13:57:01
QnVeEfQduK66szmw36H67dcfiNjKX643	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.593Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ef4fb1ff-7832-4746-a9c5-bd441fe503f5"}	2026-01-22 13:57:02
vAqq5essjVOkgB6zI7AGK4lNc4YUjDzK	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.024Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "b7059504-fc6e-4716-a2b4-86dbac25fdf2"}	2026-01-22 13:57:02
IhalX8T0UkWoeCBnDAidkNHiU-UyA0Rv	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.054Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "0855fedb-bc57-44a6-80ea-6db0044f1f9c"}	2026-01-22 14:00:49
NlzEi2B57j6FtDOHqhUEw1KoOtPiHwAc	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.511Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "b64fb697-751e-4c62-93ef-c9f41dd32352"}	2026-01-22 13:57:03
Q51ItAp_m2ljmYTfR1FjNJffq-LYQCYI	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.993Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "7aad5caf-7a0a-4174-9a58-46383263e499"}	2026-01-22 13:57:03
FoGQ6mft0-M8WYGDie-9YBELVH4I-ngb	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.031Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "09af5782-66ed-4b15-b173-fe2b9c8b3d8f"}	2026-01-22 13:57:03
ean1rcDaaaQWqtwuJ-RUZAQMEVwKGxgA	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.718Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "bd44c2b3-d219-4b29-a18c-42a77b946178"}	2026-01-22 13:57:03
c_X4jE_0BHkwPiPNu7yc3-oiUO0eW1LD	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.937Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "170dc23c-ced4-4980-b8b4-b2e18b48e41b"}	2026-01-22 13:57:03
lF7kv9UTeinBwfcBzFNjIdrTywgDtSrh	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:49.814Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a55511fc-f7db-4788-8015-4fc0b501856a"}	2026-01-22 14:00:50
jaD4Hke7pEyxJS0FT-A2PqxwucPKYODR	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:52.267Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ca4eeec9-baa2-4bec-a33e-7d3993a6b89e"}	2026-01-22 14:00:53
ovumgO8Hs8d-90UAwG9ZREm4ZuExbAhX	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:52.688Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "6d94db75-af33-4cda-8497-ae8f76392493"}	2026-01-22 14:00:53
0LzAh6Vncx_qpME0UM20ZrClntynrfv9	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.080Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "c2803612-a34b-4ed7-a3fe-3295c2a91980"}	2026-01-22 14:00:54
SuTdm6XZ2DSW4IwjP4-OHcyyEyVbhZVA	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.120Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "256f2ffb-8e13-46bf-8f5c-87a38f4e32da"}	2026-01-22 13:57:01
aYQET9fxviKqkPAztceBbL9sSe8q9Vr2	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.159Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "b6e2eacf-f593-4d50-9c7a-fb20af0d2421"}	2026-01-22 13:57:01
ws-GfbqhWGGUi1ey9h3IZ2G6L3gBVlfu	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.931Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ba9cd756-1c48-4f09-8a37-d44db487a7fd"}	2026-01-22 13:57:03
dUtd3LzprZxlT4ltpMzuAuSJW09UzEDQ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.526Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d1a9b7ff-62c0-4bc1-becf-3151d26403b9"}	2026-01-22 13:57:01
SX_-rfUFJl8HCiawYPScWvFrXidkvPrJ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.226Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f568d988-11d7-4dd0-b50f-9b2fa3e901d3"}	2026-01-22 13:57:03
NwLCtMfObcVO3Ti791utP8wycORQmW6v	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:00.650Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d429d2db-1685-47d2-8ac7-3e7bba72e2df"}	2026-01-22 13:57:01
lFsHAyaY4KemJwVewMVrex83omcLvCYK	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.593Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e850b0bb-b7e6-4bc4-ba70-8b62e9c01a22"}	2026-01-22 13:57:02
-1Itx502OXrpzd38RdsfKVLoIfB5B0yV	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.746Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "cd1b6c9b-625d-468f-93a6-8d4ee8d269b4"}	2026-01-22 13:57:02
fmf2RgYmIsO_sPImSugbLSqUQkii_5-n	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.271Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "2485e477-5cf6-4a53-a7c6-0ec1b0b648a3"}	2026-01-22 13:57:03
joqtqUyqMXNrxN6_oxo05AskyaJED0Gi	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.789Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "9c469098-d812-4427-8b7c-ab635899e4e1"}	2026-01-22 13:57:02
1VQIJdATrEbSPwwGr0ZIizWeA2KvsjGb	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.831Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f07bf262-3abf-4db4-a767-9f89f2236723"}	2026-01-22 13:57:02
liFae0iBPdbTxqPne-jjfhYrMIUBjqOM	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:01.847Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "0b26dec4-aa95-44a7-9866-22d180f9a3ff"}	2026-01-22 13:57:02
mkIoz26SEhwBZgRzKXhQMnvd95zmxzz3	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.524Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d7f74aa5-6b78-4536-ad5b-c62df573e2ec"}	2026-01-22 13:57:03
rGiWloImRqogwXYq4IKbb8Twy3TD2Q-S	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.972Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "54453845-500b-4bbf-8004-da0df57b1c7f"}	2026-01-22 13:57:03
ErbEe2q98NZm5Jik7mwckUL72MiMo2hU	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.551Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "074d042a-de29-43e8-8d43-e4192743bc0c"}	2026-01-22 13:57:03
kZHdKkLvYQ0RhvwBJTtYXdRJ66H-6Mgs	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.893Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "2aa49b9e-a6a5-4537-b722-7e573bbedfb9"}	2026-01-22 13:57:03
AbYjNm1WIeK-DsN3Wnni_0M-tFuaVtxL	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.059Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f0e9b06e-a4da-453b-807a-aed75923e521"}	2026-01-22 14:00:49
NbzacS0SZaJkEDYd8SP1NbCmuXVwtiga	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T13:57:02.993Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "84545c01-95ce-4a71-a2c1-838e6e932ab3"}	2026-01-22 13:57:03
5pWH0U9DY5L-gbX2zIDLPeCHLnRYHP44	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.506Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "43815dc3-4cb4-41ae-983b-4a1e7d5315fa"}	2026-01-22 14:00:49
Eo-JC02RtOIqohffZOCpRD_Vzoa8i-DP	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:48.592Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "036933d3-d229-49b1-9bbe-25e92800ce81"}	2026-01-22 14:00:49
JvN9ZZG1u8drNMVFBl_vWRh3GR5t0aAs	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:49.376Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "7d7d96b1-2f68-433b-b9d3-72955888d279"}	2026-01-22 14:00:50
QKEuBDrlXdtTw7oEXRbUVKZPdsAzA3RZ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:49.002Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "8aefe55b-5e79-4a19-b105-eba4b6eba999"}	2026-01-22 14:00:50
M-XGFxXoUNWcrGwJ_MF5AIBs_mDvIM47	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:49.463Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "a1771b13-6785-41fe-987c-0a6cf789e278"}	2026-01-22 14:00:50
U5soJ_MyUwYgS-5tYOxqPjd-srBOl13n	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.885Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ead1848c-e771-4e43-9a19-dd316eeb552b"}	2026-01-22 14:00:54
JFgfSEB6NoNZblSV53xSExCbGsoCVLZD	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.905Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "06dee0ec-a7be-4f88-a8be-261fee6102ff"}	2026-01-22 14:00:54
KYme0FM94Fg_Wf_W2Mbp1ACVbzS6vGfj	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.977Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "621c5f05-bc0c-433e-b9c0-c18c8ccfe5b4"}	2026-01-22 14:00:55
AB3LWbPOiowkluTgwuqmquMQdZUR7JSt	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-23T12:30:38.284Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "abc973c9-0b50-44f5-9df2-2aca18d9ccfa", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-23 12:30:39
jlbfwvdVfV6FZohqDyXGNLbEIgPKb9LV	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:54.316Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "01237f8a-902b-4b14-b04a-38508d41c894"}	2026-01-22 14:00:55
7QktH_E8TYBS7s54BTLmjSV7pHzFpZ8A	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:54.921Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ed6bb431-4be2-4abe-968e-6f7f801c6244"}	2026-01-22 14:00:55
dPzGhkIlYCDiF4RfHPUzvkXS38a6d8M6	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:54.301Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "24ede4da-51f7-48bc-916e-41fb15f9e280"}	2026-01-22 14:00:55
51jE7H-BHTRxsYEkC8HrKiLgtyJmOrAh	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:54.723Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "690520d7-e491-43bd-a6f1-7fcf2369fa20"}	2026-01-22 14:00:55
XE-FpKrfFxZkjhdklBuoxiq-6n34uo_Z	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:53.901Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "b50d541a-07ba-4850-9bad-918f237557e4"}	2026-01-22 14:00:54
GPPFw4Adju2Ab09A0Uy0H5XZAgUI_IKW	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:54.773Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "cd61ce90-cb6c-4b6a-91b6-8a150b368f3d"}	2026-01-22 14:00:55
i0GH2JY34ZlMr2dIqut0PbWV_clrCVNN	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:54.798Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "960466d6-6220-4429-bfa4-8c2659dcaae8"}	2026-01-22 14:00:55
_8sAqEbjWEFOWxcTxhLUg3Kt_fKT7t-Y	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:54.376Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "e3d15330-af7c-47c4-848c-92a18df6bc0c"}	2026-01-22 14:00:55
TIBM_aO1LMpY1GKKqEvIr7ZPZtxkaivy	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-22T14:00:54.784Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "7f9fb533-90ca-4e92-bc5c-0c5282eca554"}	2026-01-22 14:00:55
\.


--
-- Data for Name: storage_objects; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.storage_objects (id, object_key, storage_provider, file_type, category, mime_type, size_bytes, checksum_sha256, uploaded_by, application_id, document_id, created_at, last_accessed_at) FROM stdin;
c8163649-f388-4d14-bfd0-1911e329b4f0	revenue-paperss/5883e85f-ebec-4bc8-991c-189cf688f8ac	local	revenue-papers	revenue_papers	application/pdf	232135	\N	\N	7e2c9070-be02-44d1-9172-d58edc1fe8eb	784e60b4-c54d-4790-a7c2-e79491be9c95	2026-01-15 09:43:30.068146	\N
ae674d55-ca99-44ed-bfc1-3f9281673a59	affidavit-section29s/6cfbb4e2-4dd0-4f0c-89b9-99c04e4d6b57	local	affidavit-section29	affidavit_section_29	application/pdf	232135	\N	\N	7e2c9070-be02-44d1-9172-d58edc1fe8eb	76e22b64-a431-4ff1-9768-553572a65e7c	2026-01-15 09:43:35.057811	\N
ecad2343-2b3c-49f8-ba3e-50a2aa8787c2	undertaking-form-cs/754f886e-bb4a-4f1c-a6fe-ab08df95cacd	local	undertaking-form-c	undertaking_form_c	application/pdf	232135	\N	\N	7e2c9070-be02-44d1-9172-d58edc1fe8eb	97395777-e7e0-498e-8f71-2fd38f87eafa	2026-01-15 09:43:39.762102	\N
07b71b6c-0eb3-4bd0-9458-1200d14b938d	property-photos/4834929c-e760-4136-8a6f-dbe927b54ad1	local	property-photo	property_photo	image/jpeg	96524	\N	\N	7e2c9070-be02-44d1-9172-d58edc1fe8eb	6435ee69-4e95-437d-b3d0-fdaf95dc1a32	2026-01-15 09:45:23.2457	\N
46832a4b-307d-47ae-a52d-4527e230faad	property-photos/9e337e46-d0df-4a89-ba5d-dae8eff202c5	local	property-photo	property_photo	image/jpeg	13584	\N	\N	7e2c9070-be02-44d1-9172-d58edc1fe8eb	72dbd554-771b-485a-a4de-e64f179e78b8	2026-01-15 09:45:23.391938	\N
6c7258e3-7ee8-4c1a-a97b-b7db07f82de6	revenue-paperss/7d116319-0301-4454-a872-4b2ea5ade9f2	local	revenue-papers	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	4c411a33-6024-4f42-990b-08cbb9ec9a7c	\N	\N	2026-01-15 09:49:35.257158	\N
ad57a07f-ffce-41ef-9a5a-b85f7c3f6b1c	affidavit-section29s/8bf83f4c-73e5-47ed-ae7f-1fcf90764bbd	local	affidavit-section29	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	4c411a33-6024-4f42-990b-08cbb9ec9a7c	\N	\N	2026-01-15 09:50:38.701279	\N
dd16e7df-949d-4e66-b697-879e2501df26	undertaking-form-cs/9a812042-d6da-4772-a5f8-3de9b61aa313	local	undertaking-form-c	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	4c411a33-6024-4f42-990b-08cbb9ec9a7c	\N	\N	2026-01-15 09:50:44.59097	\N
c7d68a48-b29a-413b-aa0f-3037fc17ef60	commercial-electricity-bills/390c9dee-b741-49f2-b6dc-480eceb788fd	local	commercial-electricity-bill	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	4c411a33-6024-4f42-990b-08cbb9ec9a7c	\N	\N	2026-01-15 09:50:50.378216	\N
988aaa78-2e86-4937-912b-d2ec9040df89	commercial-water-bills/2591f566-fe24-4153-b551-2ea2c2383156	local	commercial-water-bill	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	4c411a33-6024-4f42-990b-08cbb9ec9a7c	\N	\N	2026-01-15 09:50:56.620562	\N
abe51424-2781-48c3-aed9-b0d327de15ec	property-photos/3809b989-caa2-49ad-90ed-c92176a5c3a9	local	property-photo	photos	image/jpeg	96524	02f226a52cfa9b5054adcfe008a6b8885b9a5f56adc2d53ad3382d9502cbd6dd	4c411a33-6024-4f42-990b-08cbb9ec9a7c	\N	\N	2026-01-15 09:51:04.300664	\N
36e9ceea-c2bf-48d2-8125-2a55bcf83144	property-photos/ae3f1566-d238-4226-89e8-5efa3c31e19f	local	property-photo	photos	image/jpeg	13584	12434b6deb0704e02e9f467b990ca3498923894c9c205a1ab3acff0f3eb8a846	4c411a33-6024-4f42-990b-08cbb9ec9a7c	\N	\N	2026-01-15 09:51:04.380861	\N
a02a5a0f-b001-4c1f-810d-96f6eea6d36f	revenue-paperss/e3ce31c6-cde6-40d8-8c64-14efa7856697	local	revenue-papers	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	4bedfed3-5ed5-4f1f-9d26-cd9f6712c840	\N	\N	2026-01-15 12:07:41.558844	\N
19a963f2-2346-4a42-8793-2c2b83d19b71	affidavit-section29s/b930b932-fa87-4503-a565-633afce6b00c	local	affidavit-section29	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	4bedfed3-5ed5-4f1f-9d26-cd9f6712c840	\N	\N	2026-01-15 12:08:44.229318	\N
7faaf2b8-a310-4c73-8b71-0be0472e1f42	undertaking-form-cs/6c8171b1-851a-43c1-817d-82bf96b0401d	local	undertaking-form-c	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	4bedfed3-5ed5-4f1f-9d26-cd9f6712c840	\N	\N	2026-01-15 12:08:53.215506	\N
1a56261c-07ae-43f0-b14d-4ee44c2e9be6	property-photos/9867c423-b0cd-4cf0-986f-40637d669b2a	local	property-photo	photos	image/jpeg	117294	f59b32cc0c72de69f0c6264f07482c24b5b955c0a2da79a9bb36b6fdc357fdfe	4bedfed3-5ed5-4f1f-9d26-cd9f6712c840	\N	\N	2026-01-15 12:09:04.101769	\N
d9fba986-aed2-4b9e-852f-4692a4ae327b	property-photos/e5c0a200-54ed-4f21-9b91-5b0852c7367e	local	property-photo	photos	image/jpeg	123434	ad3fabdc279096be6f6b0bc398e6af4b54e24c2fb6417090f892d073729ed9a2	4bedfed3-5ed5-4f1f-9d26-cd9f6712c840	\N	\N	2026-01-15 12:09:04.17941	\N
24fe9a3b-d030-4d34-b64e-1576302b40bb	uploads/dummy_deed.pdf	local	dummy_deed.pdf	proof_of_ownership	application/pdf	1024	\N	\N	e458c717-ab36-45be-a8c3-2a121167d50e	16c64c60-909c-48f2-89b5-acb3961b2d01	2026-01-15 13:11:32.52426	\N
17914fb4-a71e-49fc-9876-d731692492af	uploads/dummy.pdf	local	dummy.pdf	proof_of_ownership	application/pdf	1024	\N	\N	b9c9c4f6-51b3-40bc-983d-facff9fffa16	4c41c808-07a7-4c92-868c-75638c0d5b5d	2026-01-15 14:00:46.648892	\N
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.support_tickets (id, ticket_number, applicant_id, application_id, service_type, category, subject, description, status, priority, assigned_to, assigned_at, escalated_from, escalated_at, escalation_level, sla_deadline, sla_breach, resolved_at, resolved_by, resolution_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.system_settings (id, setting_key, setting_value, description, category, updated_by, created_at, updated_at) FROM stdin;
498dbd8d-4322-416e-a72e-4002e6c06158	enforce_single_session	true	Enforce single concurrent session per user (kicks old sessions on new login)	general	\N	2026-01-08 03:01:48.867166	2026-01-08 03:01:48.867166
e77eae49-4987-4132-8eb2-3bd830f85929	payment_workflow	{"workflow": "upfront", "upfrontSubmitMode": "auto"}	Payment workflow: 'upfront' = pay before submission, 'on_approval' = pay after approval	payment	5e2c291b-e9f0-4ead-a6ed-3fe8098a7760	2026-01-15 09:46:27.312966	2026-01-15 09:46:27.312966
2d4bfeb6-2acb-478b-a5d3-ce16f183e5a9	backup_configuration	{"enabled": true, "schedule": "0 2 * * *", "includeEnv": true, "includeFiles": true, "lastBackupAt": "2026-01-15T20:30:00.044Z", "retentionDays": 30, "backupDirectory": "/home/subhash.thakur.india/Projects/hptourism-rc7/backups", "includeDatabase": true, "lastBackupStatus": "success"}	\N	general	\N	2026-01-10 20:30:00.481759	2026-01-15 20:30:00.396
3c29b1ac-6a6f-41c7-89f2-d26c34d6d43a	comm_email_gateway	{"custom": {"host": "mail.smtp2go.com", "port": 2525, "password": "osipl@2025", "username": "osipl.dev", "fromEmail": "Mail2Smtp"}, "provider": "custom"}	Email gateway configuration	communications	5e2c291b-e9f0-4ead-a6ed-3fe8098a7760	2026-01-14 06:39:24.099995	2026-01-14 06:48:24.932
1dd1247e-d747-4051-9521-81e47e51569f	comm_sms_gateway	{"nic": {"postUrl": "https://msdgweb.mgov.gov.in/esms/sendsmsrequestDLT", "password": "Tour@sml352", "senderId": "hpgovt", "username": "hpgovt-TACA", "templateId": "1007739248479536901", "departmentKey": "a63f7853-6297-44c7-820b-392541a47fc1"}, "provider": "nic"}	SMS gateway configuration	communications	5e2c291b-e9f0-4ead-a6ed-3fe8098a7760	2026-01-14 06:36:24.36111	2026-01-14 06:49:51.578
0c489058-71d4-4415-9e0a-b38096d0816b	payment_test_mode	{"enabled": true}	When enabled, payment requests send ₹1 to gateway instead of actual amount (for testing)	payment	5e2c291b-e9f0-4ead-a6ed-3fe8098a7760	2026-01-14 07:35:35.822385	2026-01-14 07:35:35.822385
581aad64-4af9-4801-9e3c-1529c44b4d99	woman_discount_mode	{"mode": "SEQUENTIAL"}	Configuration for woman owner discount calculation (Additive vs Sequential)	general	\N	2026-01-14 07:36:55.921742	2026-01-14 07:36:57.565
e6141603-69bb-449e-9fb4-d6832f992d95	admin_super_console_enabled	{"enabled": true}	Enable/disable super console	admin	5e2c291b-e9f0-4ead-a6ed-3fe8098a7760	2026-01-14 06:34:47.665642	2026-01-14 15:34:15.016
92818204-de11-4045-8ed0-1bdca9e1d651	maintenance_mode_config	{"enabled": false, "accessKey": "launch2026"}	Test Maintenance Mode	general	30d01ccb-a38d-44df-b1fe-f904926574b3	2026-01-14 07:25:23.431063	2026-01-14 15:38:33.827
\.


--
-- Data for Name: ticket_actions; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.ticket_actions (id, ticket_id, actor_id, actor_role, action, previous_status, new_status, previous_priority, new_priority, previous_assignee, new_assignee, notes, metadata, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: ticket_messages; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.ticket_messages (id, ticket_id, sender_id, sender_role, message, attachments, is_internal, is_read, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.user_profiles (id, user_id, full_name, gender, aadhaar_number, mobile, email, district, tehsil, block, gram_panchayat, urban_body, ward, address, pincode, telephone, fax, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.users (id, mobile, full_name, first_name, last_name, username, email, alternate_phone, designation, department, employee_id, office_address, office_phone, role, aadhaar_number, sso_id, district, password, enabled_services, is_active, created_at, updated_at, signature_url) FROM stdin;
30d01ccb-a38d-44df-b1fe-f904926574b3	9999999999	Admin Admin	Admin	Admin	admin	\N	\N	\N	\N	\N	\N	\N	admin	\N	\N	\N	$2b$10$J/OIXeqxtoZ06ZOWpsOlX.7IekDkhGOl6mplrEZ4wbFLrOyv62vpW	["homestay"]	t	2026-01-08 00:45:19.959719	2026-01-08 00:45:19.959719	\N
5e2c291b-e9f0-4ead-a6ed-3fe8098a7760	9999999998	Super Admin	Super	Admin	superadmin	superadmin@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	super_admin	\N	\N	\N	$2b$10$O3eLVm3tZzbzceNqeF6zh.z2sj0NEpzw5mNWRmDkuTDLjt9REl1/m	["homestay"]	t	2026-01-08 00:45:20.096523	2026-01-08 00:45:20.096523	\N
ae0f4a20-aaad-4c76-8b3d-b914dfa561db	7900001002	DTDO Bharmour	DTDO	Bharmour	dtdo_bharmour	dtdo.bharmour@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Bharmour Sub-Division	$2b$10$sHx6adRSlHq4Yy0eDglQR.bQvRNc3oBsWP8OPgJKfrU5UR1pasqPa	["homestay"]	t	2026-01-08 00:45:20.40481	2026-01-08 00:45:20.40481	\N
6affed07-7898-4fc9-b86d-af1d610ad3ea	7800001004	DA Hamirpur	DA	Hamirpur	da_hamirpur	da.hamirpur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Hamirpur	$2b$10$wQ9Q6yaTLBl8FDd55YGbbePzknRJZ6xpIIxOT1p/jzo.gZ1yyNPe2	["homestay"]	t	2026-01-08 00:45:20.638833	2026-01-08 00:45:20.638833	\N
94a33229-2eec-4bfe-a5ce-d01b06625974	7800001003	DA Shimla Hq	DA	Shimla Hq	da_shimla_hq	da.shimla-hq@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Shimla HQ (AC Tourism)	$2b$10$v9zOltOtsfYrLPM.n0TnaOVTxJ6q2ANjG/YkvTLmj3O7VSc8DXbLK	["homestay"]	t	2026-01-08 00:45:20.481319	2026-01-08 00:45:20.481319	\N
4a415c0e-67e4-4cb9-90ba-159a7877aaef	7900001003	DTDO Shimla Hq	DTDO	Shimla Hq	dtdo_shimla_hq	dtdo.shimla-hq@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Shimla HQ (AC Tourism)	$2b$10$0BfEb6/ak19z5U5AueaTIueRfcKCvPgHMsXzuQyLtEhQkaqFJikuW	["homestay"]	t	2026-01-08 00:45:20.56027	2026-01-08 00:45:20.56027	\N
adfed2b7-282f-4aa3-8ee3-8285c108d51c	7800001006	DA Kullu Dhalpur	DA	Kullu Dhalpur	da_kullu_dhalpur	da.kullu-dhalpur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Kullu Dhalpur	$2b$10$kOWCFRbHViZCy6HU4BKqTenX5QxgXWzbLhZAk90BeIS8H8LFtaHza	["homestay"]	t	2026-01-08 00:45:21.061375	2026-01-08 00:45:21.061375	\N
379057ec-a3f3-4e88-9950-fc96ecc97bdc	7900001006	DTDO Kullu Dhalpur	DTDO	Kullu Dhalpur	dtdo_kullu_dhalpur	dtdo.kullu-dhalpur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Kullu Dhalpur	$2b$10$RSlggXSjgUYZPxArMNPt8eso9GP7Yw1tFYSzeRNcEaP6u2v.mMCWW	["homestay"]	t	2026-01-08 00:45:21.24217	2026-01-08 00:45:21.24217	\N
aa54f8a2-a077-4615-8679-1fa61d85f04a	9507344278	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$V2zAP2rrPK1oiq/EHSYLNu4Dol3zUxDxlyAJJdu0ceL6ZhgXSVCeW	["homestay"]	t	2026-01-15 13:16:14.16185	2026-01-15 13:16:14.16185	\N
76cfb0b9-31ce-42c9-bef3-f7078c4b61c0	9521953530	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$QWMVaYaem9qOG2EhwEnQdOzxszF2AxzjqWtsAkqFlbRToBM3Dah/m	["homestay"]	t	2026-01-15 13:16:14.466523	2026-01-15 13:16:14.466523	\N
29e9c380-3b7d-49aa-882e-94d37ec3e59d	7900001001	DTDO Chamba	DTDO	Chamba	dtdo_chamba	dtdo.chamba@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Chamba	$2b$10$rG68dezaxlMn92IVOrfj3.XKHkFxekN2y/dQ5M9vc0HYbtoLaJqly	["homestay"]	t	2026-01-08 00:45:20.252529	2026-01-08 00:45:20.252529	\N
f284ccb8-33fc-42d0-a45a-eb231e6cac9a	7800001002	DA Bharmour	DA	Bharmour	da_bharmour	da.bharmour@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Bharmour Sub-Division	$2b$10$sMJhfYeImStwMpcj6sp.Aucyth7yE.Xx3sHKyZpaN1flFdVR.l4iC	["homestay"]	t	2026-01-08 00:45:20.328813	2026-01-08 00:45:20.328813	\N
6536d907-78d1-419a-b023-8a6f141fdcf5	7900001004	DTDO Hamirpur	DTDO	Hamirpur	dtdo_hamirpur	dtdo.hamirpur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Hamirpur	$2b$10$89TiI0YVRNHSRmrJnKEEn.gB1sRItgPYW8if/oMFJ/CzbVFtu7XI6	["homestay"]	t	2026-01-08 00:45:20.733503	2026-01-08 00:45:20.733503	\N
d244a912-8065-4604-9b58-ba9b69d93e11	7800001005	DA Kullu Manali	DA	Kullu Manali	da_kullu_manali	da.kullu-manali@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Kullu	$2b$10$MHZ7GFt1oo2ngK4Ivklx0.p/VPrPdCwrsJSlo8gcn8FZj5fX9hefK	["homestay"]	t	2026-01-08 00:45:20.821971	2026-01-08 00:45:20.821971	\N
4d890d65-0a0f-49f1-92cc-34d046586531	7900001005	DTDO Kullu Manali	DTDO	Kullu Manali	dtdo_kullu_manali	dtdo.kullu-manali@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Kullu	$2b$10$gF1BrGMyc4WYgGKNeGsqAe.bCdLyWOmuu3lpqU1.dCUCOtoN2skoa	["homestay"]	t	2026-01-08 00:45:20.975105	2026-01-08 00:45:20.975105	\N
b7987533-e127-4cad-8233-de0fdde7bbc7	7800001007	DA Dharamsala	DA	Dharamsala	da_dharamsala	da.dharamsala@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Kangra	$2b$10$LXLKHkYSa8qzvSHs/7xb9OaU2hPgN6yv8YalqNgJInWX5O04UeEIO	["homestay"]	t	2026-01-08 00:45:21.328771	2026-01-08 00:45:21.328771	\N
6181fa83-d0af-492e-9fca-840005f2600e	7900001007	DTDO Dharamsala	DTDO	Dharamsala	dtdo_dharamsala	dtdo.dharamsala@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Kangra	$2b$10$u.zamAdjGeeB5RjKF4qeGOtIrjCCCOFXeBJWNQY3bjaDaTs.TaABq	["homestay"]	t	2026-01-08 00:45:21.429953	2026-01-08 00:45:21.429953	\N
6d27a721-acb4-4dab-95d9-0b2c91645234	7800001008	DA Kinnaur	DA	Kinnaur	da_kinnaur	da.kinnaur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Kinnaur	$2b$10$tSJbrAdjbbiKsSFnDZn9DeHJX1pvaYHzP5Jg/LgeKj9pRPmdQTBWG	["homestay"]	t	2026-01-08 00:45:21.531155	2026-01-08 00:45:21.531155	\N
1562faf8-b959-43ec-b3ef-936d901e3131	7900001008	DTDO Kinnaur	DTDO	Kinnaur	dtdo_kinnaur	dtdo.kinnaur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Kinnaur	$2b$10$OOn9c0888hAIFIIRteMxl.5hr9KZ0MiytWwxD.foWYuCeQ79cIAqm	["homestay"]	t	2026-01-08 00:45:21.646263	2026-01-08 00:45:21.646263	\N
5da8ac27-6650-4982-b51a-a7e7c5257075	7800001009	DA Kaza	DA	Kaza	da_kaza	da.kaza@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Lahaul-Spiti (Kaza)	$2b$10$uNTEF00Gyeslt/J9KldzmOpwkaJh9V0JdJXBJoTQXGj6G9NloxOtK	["homestay"]	t	2026-01-08 00:45:21.743951	2026-01-08 00:45:21.743951	\N
422d1de0-8342-42b3-9767-d71d3297cd57	7900001009	DTDO Kaza	DTDO	Kaza	dtdo_kaza	dtdo.kaza@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Lahaul-Spiti (Kaza)	$2b$10$pebO29e2NSc9R5laVsSHyea3GINQziRCQBXbGqt1jQHlqKn5/K6Lu	["homestay"]	t	2026-01-08 00:45:21.82239	2026-01-08 00:45:21.82239	\N
249b7155-1f20-404f-b377-b0202b66a8a8	7800001010	DA Lahaul	DA	Lahaul	da_lahaul	da.lahaul@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Lahaul	$2b$10$CwFfmkmo7SmojEOO8aVYcOwmxo.JHp1.X3vaeKVjcyRC3Plb3iNuy	["homestay"]	t	2026-01-08 00:45:21.898119	2026-01-08 00:45:21.898119	\N
a7aea641-74c2-451f-8c5b-c3d01dd2d5fd	7900001010	DTDO Lahaul	DTDO	Lahaul	dtdo_lahaul	dtdo.lahaul@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Lahaul	$2b$10$xRA9wM4PCuJ/LUqetVJKEu/63hyKfcjKO0RV4mAw4o6QGd9amjGM2	["homestay"]	t	2026-01-08 00:45:21.974547	2026-01-08 00:45:21.974547	\N
38b25f9c-a43e-47c9-a74c-ee74519eadb8	7800001011	DA Mandi	DA	Mandi	da_mandi	da.mandi@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Mandi	$2b$10$9.TJqxViaXqxjyDlDeH5LOM3rWQCNj1xCTwhFB0egiqyQ2bPvpBPe	["homestay"]	t	2026-01-08 00:45:22.053293	2026-01-08 00:45:22.053293	\N
e058334e-e9c3-47e3-938b-5a9a273ff1a0	7900001011	DTDO Mandi	DTDO	Mandi	dtdo_mandi	dtdo.mandi@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Mandi	$2b$10$upZvMNll/06Sl7HGe2QpN.f0vGeox4nG5q4s8XomYp3lVg/VrVY8m	["homestay"]	t	2026-01-08 00:45:22.137953	2026-01-08 00:45:22.137953	\N
cf29bed0-3c8e-4cf2-bde4-bce648e2049f	9786356929	Load Test 9786356929	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$BOijlJXKR7nhxKttCyZxcO6wYAJeaZ/nk6sc3TEt8h/WXq2EKGI8y	["homestay"]	t	2026-01-15 13:56:58.879417	2026-01-15 13:56:58.879417	\N
4bedfed3-5ed5-4f1f-9d26-cd9f6712c840	7777777713	Test BBB	Test	BBB	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	777777777713	\N	\N	$2b$10$5dEqDZIcNPjNN1mEU1Dk5ugEEhoZWG.KFsWOowcjlKx9wkVSutL5m	["homestay"]	t	2026-01-15 12:04:41.459169	2026-01-15 12:04:41.459169	\N
f553b9c0-ae24-42a2-97af-bb442cbf4d2d	9752113206	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$WlD51jAHQMn3kES/R3w4EunqpTErSHSEvLQpQBaZV5kKkNZsKY2/u	["homestay"]	t	2026-01-15 12:42:26.374404	2026-01-15 12:42:26.374404	\N
8dd8642b-a59e-4beb-8866-cda32cbae6d3	9802239637	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$OG9GZo9Gg77dN4yrDzaiTOhauRFAGuD.nucSaXRPpw1aN5K22BlFe	["homestay"]	t	2026-01-15 13:11:32.471867	2026-01-15 13:11:32.471867	\N
a4743f40-a89f-441d-996a-167529e8590f	9268672662	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$F3WyW2nSlh.a1PNaaq4ba.uqH6lnXfnDi6GFJ.rPi67YRv7l9ln7y	["homestay"]	t	2026-01-15 12:43:31.492838	2026-01-15 12:43:31.492838	\N
13b5ef36-7b4a-40c8-ae5d-3aa376467a34	6666666611	Test Test	Test	Test	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	666666666611	\N	\N	$2b$10$uykQlcieHiSCqyAIb6rdFOsELygne14iN2ekc8waPkExvqkKn.jhG	["homestay"]	t	2026-01-08 01:13:30.082175	2026-01-08 01:13:30.082175	\N
311ceb5c-b065-4e3a-abc9-0954af3154b6	9197155033	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$yNmUaLGXUkD.GtaRexv3.O/Ixhw4cb2s92KLVWQpvPbSz6ZLuPd46	["homestay"]	t	2026-01-15 12:44:43.900449	2026-01-15 12:44:43.900449	\N
83d4956e-3aa4-4990-8a7f-efaf4fb27d09	9367696100	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$BoRe5Go7r3nydSVrPucy9u/XfRiDrEilZSxF/KrtNquzYeGiMRXRa	["homestay"]	t	2026-01-15 12:47:11.263503	2026-01-15 12:47:11.263503	\N
29535615-298c-4d60-a7df-13d08040e147	9557355685	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$6ilFJUD3UlNxzu/JrEOYhuwT8R2K40bx0BpQpUnBpUEZn8P2oKEsO	["homestay"]	t	2026-01-15 12:51:59.178538	2026-01-15 12:51:59.178538	\N
3a1ee037-a804-4a4d-a30a-c2f6039e96c7	9182929778	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$rIM7Z57ZAxfWO58v1Hal/u5fFvWUs7.F5zjE5t1TmV/qH3rhycYVC	["homestay"]	t	2026-01-15 12:54:48.440376	2026-01-15 12:54:48.440376	\N
7b737110-8680-4dbb-985c-98e71dc2c305	9965322743	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$LrZADaMHZNCeEPi0gKKLMuBCrCPK/oowRaiPfUCX.jGa5bDrv6XjS	["homestay"]	t	2026-01-15 12:55:23.096719	2026-01-15 12:55:23.096719	\N
abc973c9-0b50-44f5-9df2-2aca18d9ccfa	8091441005	Subhash Thakur	Subhash	Thakur	\N	subhash.thakur2010@gmail.com	\N	\N	\N	\N	\N	\N	property_owner	313881022691	\N	\N	$2b$10$huvvdSGBm8Bomth8WRULs.n.kZvWsGKvECwbaUasLuLdhHTn5CHoW	["homestay"]	t	2026-01-14 15:48:14.149796	2026-01-14 15:48:14.149796	\N
7d21d934-5f84-4f86-a74f-082a8dac21e1	7777777711	Test Test	Test	Test	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	777777777711	\N	\N	$2b$10$bdSQFLFTlddA7Qaf0rh/M.xneXBkhfcQJ6zDdu69WYLGw8iPs.91W	["homestay"]	t	2026-01-15 09:41:52.341984	2026-01-15 09:41:52.341984	\N
4c411a33-6024-4f42-990b-08cbb9ec9a7c	7777777712	Test AAA	Test	AAA	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	777777777712	\N	\N	$2b$10$k/93vs.6QsQWQhF3b9pDceU3FVBSRxE84hYyDTyBLvc6QdfEZl5LO	["homestay"]	t	2026-01-15 09:47:53.382983	2026-01-15 09:47:53.382983	\N
5f094d1f-2296-4502-9af4-d5aa25fff8be	9319660269	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$P8vc95xVxwe7xRAjhPCeW.Y3VyLVXyQiuDSeFPO7A9x68j4iYJ28y	["homestay"]	t	2026-01-15 12:57:07.776032	2026-01-15 12:57:07.776032	\N
dc1c4494-a656-4f6a-be89-9c97b3b0f1d2	9190624118	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$ckVAbeui5IRRae9Buvoh3u5Wk3nGq.uOGJkWIl.1Z9Sfc7Xn7qIp2	["homestay"]	t	2026-01-15 12:57:08.055708	2026-01-15 12:57:08.055708	\N
c8e2e777-b34d-4b39-aca8-bd5050838408	9197980798	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$4z8Eh60q7beqDLz3D0wXae5Y.i92z52a7jyTolH4IRvpCGSp8hJW2	["homestay"]	t	2026-01-15 12:57:08.285737	2026-01-15 12:57:08.285737	\N
c55eb023-85e0-4630-a965-2a8817e116f4	9214342827	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$30PcOpwoJ3MoVBR1BZrbMumocRdGiq4tmeHhXkGhleyLPV.Vlwe0y	["homestay"]	t	2026-01-15 13:06:32.417257	2026-01-15 13:06:32.417257	\N
c955fc27-7311-47e9-85da-c2e942c90035	9773386604	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$8yeA8e/y9uLDkhdenLThiuqZmPyq65NQo7rrylCO1KsFYNUhTCdZS	["homestay"]	t	2026-01-15 13:06:32.704048	2026-01-15 13:06:32.704048	\N
a136d932-ae92-4bd9-8768-9e5914d08aa2	9977734596	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$eiGu1IuyJpYvygP/Mf.cR.bi3dRjbAxtMCeO4Ytxz7aUkfIokRLyu	["homestay"]	t	2026-01-15 13:06:32.956529	2026-01-15 13:06:32.956529	\N
4b1bf0bc-2d4c-4940-929e-3b5085a3838f	9949607511	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$W50j/M7CU2IhnVkkZxKcce7FdNBDfuL8gDWdijwpi/sdgNTI7f/DW	["homestay"]	t	2026-01-15 13:11:32.814442	2026-01-15 13:11:32.814442	\N
34b3e809-9941-4aa4-8176-da9aab2d0b81	9705592112	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$/3OFwBgZTuroSml303Y5l.c/eBElBXk2mHvs6VqIVVYpX/P2DpVnW	["homestay"]	t	2026-01-15 13:11:33.098393	2026-01-15 13:11:33.098393	\N
23e4fa53-d9bd-4b6c-a958-3e92e74bdf90	9387237659	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$eFrCtAur6AJLB.moGQ2SEOSOiGDJ63yCKEVsqFpcBr15/iz0hBdse	["homestay"]	t	2026-01-15 13:16:13.454647	2026-01-15 13:16:13.454647	\N
8bee7c4a-9bd2-4231-b035-f00616fc3af5	9993513534	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$qwA8T4dKnSnioYy.WikU2u.4Gi2PBCy0SE.DYsG5Fhx8gCKCBF0n2	["homestay"]	t	2026-01-15 13:16:13.797777	2026-01-15 13:16:13.797777	\N
1a8bab46-2d4c-4694-9009-12d50f644ec8	7800001012	DA Pangi	DA	Pangi	da_pangi	da.pangi@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Pangi	$2b$10$Tc8Cvo5TIS.FzwyvoQ83CO1SWNl7njXXPNMCsINBLWF2HQ3SJNOQ.	["homestay"]	t	2026-01-08 00:45:22.237459	2026-01-08 00:45:22.237459	\N
01e17065-3ce4-46af-8a36-97cf24502482	7900001012	DTDO Pangi	DTDO	Pangi	dtdo_pangi	dtdo.pangi@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Pangi	$2b$10$rF6pX5Ce8B.b3muMtJiCkudj1zHN03gQ8ThECxKfc5BdwCDUhb5em	["homestay"]	t	2026-01-08 00:45:22.313669	2026-01-08 00:45:22.313669	\N
a9a95a58-c2be-4175-83ed-7352a709c3c8	7800001013	DA Shimla	DA	Shimla	da_shimla	da.shimla@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Shimla	$2b$10$/DblSM4weUyFFTZ25lmHwOQOHdSmFsBvvjMpAuWJ8N87/B7ZknfgW	["homestay"]	t	2026-01-08 00:45:22.390449	2026-01-08 00:45:22.390449	\N
2803bd35-34f0-4751-86ae-6cc3918c7165	7900001013	DTDO Shimla	DTDO	Shimla	dtdo_shimla	dtdo.shimla@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Shimla	$2b$10$cfWkjaIcTuE144WemxbDaeTGyaU3B7kzFpODatKhjXpIuLT8cVUmS	["homestay"]	t	2026-01-08 00:45:22.466632	2026-01-08 00:45:22.466632	\N
5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	7800001014	DA Sirmaur	DA	Sirmaur	da_sirmaur	da.sirmaur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Sirmaur	$2b$10$v1hJNJovpqrji7l1cGFKZ.tc41pFR.7B.i3jWfnVrDsT6qnni6QuK	["homestay"]	t	2026-01-08 00:45:22.544892	2026-01-08 00:45:22.544892	\N
32d7d290-8270-4aa9-977b-6b67743b953a	7900001014	DTDO Sirmaur	DTDO	Sirmaur	dtdo_sirmaur	dtdo.sirmaur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Sirmaur	$2b$10$rWcH.wzttAMNrG5JAdJjTO8boMxEhtfsNyxNyhHLiudgmOmcJkZGC	["homestay"]	t	2026-01-08 00:45:22.62149	2026-01-08 00:45:22.62149	\N
cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	7800001015	DA Solan	DA	Solan	da_solan	da.solan@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Solan	$2b$10$zVM9/k8FNXOVX1k5XcslUu2N82Rqw0l4RJ9eKetTcGrdp9JgzuL1e	["homestay"]	t	2026-01-08 00:45:22.698356	2026-01-08 00:45:22.698356	\N
683e4272-6948-451a-bffe-2aeac46f9137	7900001015	DTDO Solan	DTDO	Solan	dtdo_solan	dtdo.solan@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Solan	$2b$10$n19IXU7XSIlL.EcAh5o59O6OoE2I70aTMbbltJy4mxu6fx76/AB9u	["homestay"]	t	2026-01-08 00:45:22.776118	2026-01-08 00:45:22.776118	\N
b8f573d3-9eee-48f7-a2a4-ea670ce192d1	9800000001	State HQ Supervisor	\N	\N	supervisor_hq	supervisor.hq@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	state_officer	\N	\N	\N	$2b$10$Jy71P.J5iU7c71LNOsboCuAa2tm/017zU1abuqLaJT7vC0PETaWoK	["homestay"]	t	2026-01-12 18:20:44.944366	2026-01-12 18:20:44.944366	\N
efde4df9-1dcf-4d85-a9d3-151d17c8011d	7800001001	DA Chamba	DA	Chamba	da_chamba	da.chamba@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Chamba	$2b$10$x6zoLjUZ6vEloSnonobJnO0DAIDpBmdJai2aebgfoSgnYiPP0Wl1u	["homestay"]	t	2026-01-08 00:45:20.176033	2026-01-08 00:45:20.176033	\N
34db6a0f-a3a8-4860-8bc5-fc03291de0d3	7800001016	DA Bilaspur	DA	Bilaspur	da_bilaspur	da.bilaspur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	\N	Bilaspur	$2b$10$vfHCMZRRrHbBWE14DbLiZeDzY.e7KoYH2G6CKiAdCah4aQFbLcyUO	["homestay"]	t	2026-01-15 13:17:23.75	2026-01-15 13:17:23.75	\N
9ae7b91c-700e-4b6b-823d-fc51ca25ad8f	7900001016	DTDO Bilaspur	DTDO	Bilaspur	dtdo_bilaspur	dtdo.bilaspur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	\N	Bilaspur	$2b$10$QZn2td1Cx87Ce9O/QgKFLuBtI5ZJlKsTqc7LlccI12peS2YY7YR1q	["homestay"]	t	2026-01-15 13:17:23.831	2026-01-15 13:17:23.831	\N
05f9dca8-9c18-45e9-9ce0-ee719e04dfea	9260539454	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$K6TYVgqgMEu7UYvnSHI3yO6TLX74o2yY3vI6VJyJ391xyhqgtGPFq	["homestay"]	t	2026-01-15 13:17:39.612697	2026-01-15 13:17:39.612697	\N
528925ca-1b15-4382-9655-bfd346b76382	9373400121	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$8ZNI38a.9iF0kRSIbue1z.mHXctY1rSqLytYKsGbpTN8yyrVt.X.6	["homestay"]	t	2026-01-15 13:17:40.00063	2026-01-15 13:17:40.00063	\N
6f5b6051-150d-42b7-b535-ca36bd42d34d	9920376644	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$zkOkDVBwD0Br/HgA1FWjxOIOtO85/A1b8G5USwxoahAxR2.gbmkBq	["homestay"]	t	2026-01-15 13:17:40.356615	2026-01-15 13:17:40.356615	\N
3bb35af3-b2a5-4c2c-93f8-898c9df99693	9674194112	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$kPgzewE4dhEz5eMRQ2xrC.Vij14wlCX3dlwuYQ9rue0OaOwwvTgTG	["homestay"]	t	2026-01-15 13:17:40.677654	2026-01-15 13:17:40.677654	\N
7a0223d0-1224-4ea4-90ea-436cec619d8c	9714421076	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$nwB9Tef2cJGtIZPMQ9qaT.Frz8RJI3Z7MM.mdCIQy.XXLz.SCiDb2	["homestay"]	t	2026-01-15 13:36:30.940998	2026-01-15 13:36:30.940998	\N
0806dfb8-3002-485c-9a0e-a44d4be4d39b	9431294583	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$VIDVCsZYqiKPCwV03sqmkeIP6SHpcMUMwMpBAWou8gq.J7AOdVjy6	["homestay"]	t	2026-01-15 13:36:31.246229	2026-01-15 13:36:31.246229	\N
ed4db028-54eb-40ff-a3df-0e2507ef4ffd	9712985328	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$LTIexfvfMy2nhL.Zk1tKrejMS6loz/BSifgD7afMGjKn31xtJbt8G	["homestay"]	t	2026-01-15 13:36:31.508698	2026-01-15 13:36:31.508698	\N
dd94c7c5-ed80-428a-bc72-2e7c201e93c9	9163292395	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$8OfmokVhntxC8C3DODJf0uLTQBtzQs.5/3q8O5eNDydXEz4DtSwFO	["homestay"]	t	2026-01-15 13:36:31.761433	2026-01-15 13:36:31.761433	\N
ac827d2f-dd4a-460d-be2f-23ebad1fa102	9863559181	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$DkhHEcgvPyewWaWHEsEMGe4/SesvVxfwmGWc0bXap5Jxg0XfdY1l2	["homestay"]	t	2026-01-15 13:36:32.018761	2026-01-15 13:36:32.018761	\N
c1521403-a2e5-4ef6-bdd0-1acb3cbc11c8	9395783884	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$Qfb42.R/2dEyuY1voiwBAu7PkParczveHZgQxwARoYDCcNZNL44/.	["homestay"]	t	2026-01-15 13:36:32.278152	2026-01-15 13:36:32.278152	\N
89aad505-2170-453d-a0f6-94ac7c0e6d50	9199971784	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$kzqy0V2yanbzOeaYAqEEi.9X8yvfXVhwWx7F7Oet2sWsOvKOhBc6q	["homestay"]	t	2026-01-15 13:36:32.552576	2026-01-15 13:36:32.552576	\N
be7d6c59-eea4-43cf-852c-f29c6e7e79ce	9587465284	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$6rZp3YyQZYDxkKk716zM.O0mU9bDe/5ikx8pNgIov1MbVx/gIs3/i	["homestay"]	t	2026-01-15 13:36:32.805174	2026-01-15 13:36:32.805174	\N
aa627e94-1265-4128-944e-7739565896f5	9474788497	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$a6nzk1LA9o/EsiUCj30cmeyig3Mp8byGZ1kalAf0Fkt.dtJek4f92	["homestay"]	t	2026-01-15 13:36:33.053153	2026-01-15 13:36:33.053153	\N
3236f840-b1f9-4bee-87ce-26b85288c1ba	9971948395	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$OqDFu.NwMCYdYFAJZiCzrOJj0ujKpLlrAp6W0MFHYGN/c3aF5Eq8S	["homestay"]	t	2026-01-15 13:36:33.28932	2026-01-15 13:36:33.28932	\N
c5ec7add-599c-406d-b813-ced3b9ea84a9	9418779337	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$/Y6XZqSLHd74t7VChyRxZeJU4A1jXAgOHkThGqYgLTVlEFAwMtMR2	["homestay"]	t	2026-01-15 13:36:33.551951	2026-01-15 13:36:33.551951	\N
d6e5a82f-6df3-4ced-965a-4c7f328f76e7	9948233079	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$hyvqvT3qe3RIiVkJWDcD1OlTSe/dhuvSvzSpqmanY4PxDVIMVfRCO	["homestay"]	t	2026-01-15 13:36:33.794304	2026-01-15 13:36:33.794304	\N
c02dcf24-ca3c-4743-92a0-6573a90f7d56	9989649467	Load Test 9989649467	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$x85eFyiZTXQSiq8yhBLUXORihMGy.Z17m6rDm3WSEi/OUkpgWxTAO	["homestay"]	t	2026-01-15 13:56:57.944629	2026-01-15 13:56:57.944629	\N
10b6e321-4701-4b87-9f86-d9de9198fe52	9898318712	Load Test 9898318712	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$eyTZaw3CLt/abcopH2TUOOU6SbLbc1P3rPnFyf/Fnvs18ZyZJBGBu	["homestay"]	t	2026-01-15 13:56:57.973505	2026-01-15 13:56:57.973505	\N
87583a3b-b7fc-478e-9147-84c3a7139e2e	9635595443	Load Test 9635595443	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$TpBZtKH6pwq9MJZP6K7.tenJD2WPuZUsUCeMFVzNDKGBff4XEJAhu	["homestay"]	t	2026-01-15 13:56:57.996467	2026-01-15 13:56:57.996467	\N
96ff9912-757e-444b-aca9-c9b1c909361f	9621440886	Load Test 9621440886	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$1HDi/nT7/JJYUcPrz9T1rOieRJz8duZffgMu.fvAuMJXC4luTZrVi	["homestay"]	t	2026-01-15 13:56:58.009004	2026-01-15 13:56:58.009004	\N
f1d3bcd6-d91a-4969-8f3b-22945f38d610	9673325764	Load Test 9673325764	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$wnLnfdvQB1Cu7qpu7JvOrOwkQmm7zqWTyv6OFFCFOzOLsuPxjs/n6	["homestay"]	t	2026-01-15 13:56:58.052439	2026-01-15 13:56:58.052439	\N
909b1192-abb6-4efb-92a1-69a15764c77e	9267068349	Load Test 9267068349	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$8khkkJ7rv2Z0N5XXVSAryedUVnWRU.G7/fM13jWWf1tdBsE9fq0M.	["homestay"]	t	2026-01-15 13:56:58.171973	2026-01-15 13:56:58.171973	\N
69dc6a1e-02f6-442c-8bdf-499c70998d86	9663818529	Load Test 9663818529	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$lCh/VOxXTXYblcQjLc498ujSVOZz5eEBv3hKfOkoR8JIPK6KHEeSm	["homestay"]	t	2026-01-15 13:56:58.180623	2026-01-15 13:56:58.180623	\N
4ee6f8f9-6afd-4954-8058-776ec799689b	9687947217	Load Test 9687947217	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$8.qVtTDSZWZWhpFXQuSwM.BQI5qNNIzOjFZX4bcpmcRn.VtqSlh7W	["homestay"]	t	2026-01-15 13:56:58.230545	2026-01-15 13:56:58.230545	\N
381ca68f-d502-4f03-b9b8-e1f0a957899d	9798704282	Load Test 9798704282	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$IS28oQX9HbnMjzaVIxxkvuosnx7FWeYVsT74MGvKK1TS2Ars3zrjO	["homestay"]	t	2026-01-15 13:56:58.231196	2026-01-15 13:56:58.231196	\N
b786ff90-ee91-442d-ad40-105d169939ed	9737116724	Load Test 9737116724	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$mXgQQGiXYzlBbU32wVotROkwfNfVwNc/wOgeeKI2Xpf2BarLzje.e	["homestay"]	t	2026-01-15 13:56:58.288398	2026-01-15 13:56:58.288398	\N
5c623ea5-eb1d-48bd-b74a-43944f3570d2	9314201746	Load Test 9314201746	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$bcS0OQuT2Hvm7JxNYI7cXOFEAh3dV7PH6JVRy/djukSwIQVFKmUl6	["homestay"]	t	2026-01-15 13:56:58.411142	2026-01-15 13:56:58.411142	\N
0f35b272-e917-4986-9d78-eaaa3b864584	9714815446	Load Test 9714815446	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$..oL8mPIa.RgwUKjMEVqY.aIehp8jEmmo6a.GY3Am9um0imOU/DWS	["homestay"]	t	2026-01-15 13:56:58.519392	2026-01-15 13:56:58.519392	\N
2f4e750e-d051-410f-b689-4c3d0730f4a5	9802169679	Load Test 9802169679	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$sfYGItl67Z2PUtEmE5DexuJDf.ORfxp4ZSBg6kHh6Gq7w6T.Dpsb2	["homestay"]	t	2026-01-15 13:56:58.563211	2026-01-15 13:56:58.563211	\N
1c8e1e8a-2dbb-4261-b950-dfb11f3df84b	9718438547	Load Test 9718438547	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$97w32NvH.Htql6X3Z.ZhceAHpv5okwJ.tT.4y2IEjQ7olYuE3LJuC	["homestay"]	t	2026-01-15 13:56:58.564143	2026-01-15 13:56:58.564143	\N
6d74b278-3899-4181-b8fc-7b6924c84ac0	9727190451	Load Test 9727190451	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$oTR9Zsmwpl7zP.QQs5wR1ubE8fuxKaVnpkeBlsQAhl2I0Fu.z/sF6	["homestay"]	t	2026-01-15 13:56:58.56494	2026-01-15 13:56:58.56494	\N
1c5dc184-b368-4c15-8489-48da2b8358b2	9993795005	Load Test 9993795005	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$uPh5uidFCc5yYc7NNZn0xukezz3UysQ7tORn8fOIfC8CZt1qdr3dK	["homestay"]	t	2026-01-15 13:56:58.774966	2026-01-15 13:56:58.774966	\N
89e2f0d0-07ba-40bd-a6bf-a919314ca3eb	9435279277	Load Test 9435279277	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$kWB.G.s2e9E7Qlf.mMKrxup/HGg/4GQpnHKPV6nxGDUNKBjvPcdTC	["homestay"]	t	2026-01-15 13:56:58.871439	2026-01-15 13:56:58.871439	\N
3aff33cf-8803-4de9-9cb0-584178375d07	9116353798	Load Test 9116353798	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$Cfl1qqCkspwEWOuvEBR7GenybXr3OLUk5uIQRxmU86T9rlEHHKpqK	["homestay"]	t	2026-01-15 13:56:58.891726	2026-01-15 13:56:58.891726	\N
a510a19b-55eb-43d7-a1c5-e2ed16f2851d	9627419244	Load Test 9627419244	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$mEs3./FDOvuifzdcT/a1x.Cl7aeH2f9nDCylBrDlJEppG2FpKOOFK	["homestay"]	t	2026-01-15 13:56:59.203773	2026-01-15 13:56:59.203773	\N
8e041e3b-c6b3-46f1-9529-7b5ba76aa20b	9388034871	Load Test 9388034871	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$lc6Uap3Vd5954G1XRg6q5OlUwdkgApgA1rmfEWRT.L8sMtxCpq89u	["homestay"]	t	2026-01-15 13:56:59.435329	2026-01-15 13:56:59.435329	\N
1fd1232f-b5d7-4bdf-bba9-8c0326b9f829	9426974456	Load Test 9426974456	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$EYxVovxfXqMVt9Lf2FTm.u5IvR2HT8ll4Xli4s1it3wK.g7z5tdJq	["homestay"]	t	2026-01-15 13:56:59.466668	2026-01-15 13:56:59.466668	\N
c9c9113c-b765-4d47-bf71-3287d3a7f49c	9493020576	Load Test 9493020576	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$ujOyjV7CzFRoHJbmmX42wO5omgeGroiLSqNMNpInjKfg5IboFiDAC	["homestay"]	t	2026-01-15 13:56:59.845159	2026-01-15 13:56:59.845159	\N
87423dc5-ccf6-4db7-99e2-8abc183247a7	9449088048	Load Test 9449088048	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$upOAhNGtYn.pHmff8/wmFuVBRlxrj9gTfIb5wq9w7oikL/x22S/dK	["homestay"]	t	2026-01-15 13:56:59.90935	2026-01-15 13:56:59.90935	\N
8cd2f222-d4f2-47be-b9b1-429ab74ab91e	9957610672	Load Test 9957610672	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$I4.DZQbBmM7Kqh95WMfNQ.uAq6xjzHw6e8CqkBzQpclbbaHZL/0AO	["homestay"]	t	2026-01-15 13:56:59.930997	2026-01-15 13:56:59.930997	\N
c6fa55cd-4924-4e1b-aaef-635d93bdca11	9552652488	Load Test 9552652488	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$N5Ks.ftYrlS/QIZAsZRbuOpnX7PTIeWs3y7ZLw52as/p6mtPrU4WS	["homestay"]	t	2026-01-15 13:57:00.270182	2026-01-15 13:57:00.270182	\N
5e02532c-036a-41df-9969-aae2403345bc	9359670510	Load Test 9359670510	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$0yu3PYwSu6Oqekar2G/ad.5I8OgJJmo6RHKBYGF7lz2RbSCBaatj6	["homestay"]	t	2026-01-15 13:57:00.681131	2026-01-15 13:57:00.681131	\N
f454c940-57ec-46f8-b926-fbf2bd3ef09e	9677372724	Load Test 9677372724	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$J0uXl4.2psrdY8w5dLYVYOvy0aSFRY7WA4w0z2ouoOA8lLtjR6ZXm	["homestay"]	t	2026-01-15 13:57:01.005722	2026-01-15 13:57:01.005722	\N
d6a47232-8588-4854-a584-8dfccd2ef033	9414211943	Load Test 9414211943	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$X3irc/.1FZu9JxZculDyVebz1C24vpw.oZF/mEDOGX0oE9A0HdN3a	["homestay"]	t	2026-01-15 13:57:01.071448	2026-01-15 13:57:01.071448	\N
bf939f60-6235-4ae8-aa1e-d46d90374cd3	9905376844	Load Test 9905376844	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$OhJMMghRTCuL1EczxHDih.8BLmP.vQTN8RfsUPqKXlzWAord8cVW.	["homestay"]	t	2026-01-15 13:57:01.275126	2026-01-15 13:57:01.275126	\N
d91fc001-b4bd-401c-9752-77e55ba52107	9419784083	Load Test 9419784083	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$PAGdSpdVKoygFvo8lfgu.Oua9lNu5FDlXOEcFKKjYDNWMUYvG/uj.	["homestay"]	t	2026-01-15 13:57:02.021645	2026-01-15 13:57:02.021645	\N
436958d5-932e-4f78-86b2-9ee0d0b31a8e	9950033334	Load Test 9950033334	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$J/XoV.JVaG8lnsKx082hXe8EBNvuuqdhcrH/Q.sqBw.p9xyaWvwam	["homestay"]	t	2026-01-15 13:57:02.046104	2026-01-15 13:57:02.046104	\N
418b92bb-30fd-4700-b155-99a6356e457f	9371459961	Load Test 9371459961	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$2kbbBE.6gxkSkF8WbV7dAeJUHabOQeORDa.SiGtP0RKjOc7M6MwHq	["homestay"]	t	2026-01-15 13:57:02.091842	2026-01-15 13:57:02.091842	\N
e7bd1c4e-8570-45b9-a923-bc8e7401c0dc	9217088065	Load Test 9217088065	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$OYM07V5b17g35F4JkWhcgO1om6AabL84rPQLblVq2JdYS4epEOHqa	["homestay"]	t	2026-01-15 13:57:02.510014	2026-01-15 13:57:02.510014	\N
1245ccf4-c90f-492a-84f4-472d63ef685b	9825522266	Load Test 9825522266	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$kO.j4qKLFOSpLD1G3DTefOm9OXhWeil3dl4/jufH6gDRuHE2OAfQ.	["homestay"]	t	2026-01-15 13:57:02.717175	2026-01-15 13:57:02.717175	\N
a021dcff-7eef-4958-8613-8cf125d1d205	9924441627	Load Test 9924441627	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$uY/hTtxHvx3yCfUGVbtyN.4maZfzf8sZDBFPPo3Tf9oXES3QDSf7C	["homestay"]	t	2026-01-15 13:56:58.911261	2026-01-15 13:56:58.911261	\N
dd59cbae-d9b4-4e72-beda-1dcd7cb3ba71	9178766628	Load Test 9178766628	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$XEDTPAWgKdAX.Tp2tYz/sujR6vf/CqJ4zRjyRyCLVvEJNrQYRoyGa	["homestay"]	t	2026-01-15 13:56:59.219576	2026-01-15 13:56:59.219576	\N
fdd9bf4a-9bc0-4de0-b620-e49491aa3203	9521938346	Load Test 9521938346	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$YhqxTM8538Yfvs9h3BMVFeGvrHI3jd5ngKClK.NEdm5OB4l0nSr8.	["homestay"]	t	2026-01-15 13:56:59.469013	2026-01-15 13:56:59.469013	\N
43904951-3cc3-4867-a45c-eb6bab1ced42	9532169542	Load Test 9532169542	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$X6Df6qBFqPgElQ81jV6vc.U3JFdqJSbaIFb/xlwkb1jiFihrTAHYa	["homestay"]	t	2026-01-15 13:56:59.842521	2026-01-15 13:56:59.842521	\N
dd9186b4-2911-4ea6-abd2-461774f5781d	9111008051	Load Test 9111008051	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$4wyBtm3/BUB9DGw6dWlujeaGGCCmFc5ZK7yENDyeV6f2zOiguyhjC	["homestay"]	t	2026-01-15 13:56:59.903217	2026-01-15 13:56:59.903217	\N
47dd9d82-8deb-4b46-a793-889062bfd1b5	9332632407	Load Test 9332632407	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$0xbSCulu9OE3TzT/0s7ysuWTny/HVNKfbn6MdTZRs.RxcUsvqalWO	["homestay"]	t	2026-01-15 13:57:00.31452	2026-01-15 13:57:00.31452	\N
6b15888a-902f-4e9f-9376-05c134cb8db0	9105485480	Load Test 9105485480	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$7dyHaxxoh75M/Mw7htX16ORq/GsJutaBmAyzeu8Atd914tCcp5ISq	["homestay"]	t	2026-01-15 13:57:00.797109	2026-01-15 13:57:00.797109	\N
2b8caf08-b176-471b-88ae-4c2844de12e3	9575549504	Load Test 9575549504	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$N23qcg/i2IPHbfa7x2zqHuB1ZBwWWKWZK5b3GvL.7Ee5HH8DAooPa	["homestay"]	t	2026-01-15 13:57:00.855755	2026-01-15 13:57:00.855755	\N
0a2d8b1e-1459-4ecf-8d0c-f8fa6f1b14b4	9339101042	Load Test 9339101042	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$liNSnp3jM5ghUYEK5wjzc.s3eoyqEdFoZc9FVeAsIBWSYr7SHnNN.	["homestay"]	t	2026-01-15 13:57:00.893541	2026-01-15 13:57:00.893541	\N
849e5f2a-5a65-4397-b5c0-97e68d23b636	9866412269	Load Test 9866412269	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$d6qmC5yrPH/6ZjpcNIT7ZOaXZhj9WSHThVsPFc2yNdEjmzUEG8eri	["homestay"]	t	2026-01-15 13:57:01.224311	2026-01-15 13:57:01.224311	\N
f00fd95a-237e-4cb2-b70c-5eb3b0b06c8d	9302741564	Load Test 9302741564	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$6Ct68hMi/jrSddxXoEtf1OYUyfm3YKzeWTHZ3YexRa5GasgMHkY.i	["homestay"]	t	2026-01-15 13:56:59.105531	2026-01-15 13:56:59.105531	\N
729de72b-6fe2-4f6a-a10e-8c4eafd95430	9956115475	Load Test 9956115475	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$0DMr0dWzpymlzZ0u/4pSLuUmhsNbjS8LTFJdXoLqc.Iwbfy.FHKgq	["homestay"]	t	2026-01-15 13:56:59.204433	2026-01-15 13:56:59.204433	\N
256f2ffb-8e13-46bf-8f5c-87a38f4e32da	9549505125	Load Test 9549505125	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$F9x3J25.vOQk8XDSwGrXhunaGiWVxoo6xmevtL9x0AAefLgbEKj.a	["homestay"]	t	2026-01-15 13:57:00.11182	2026-01-15 13:57:00.11182	\N
b6e2eacf-f593-4d50-9c7a-fb20af0d2421	9419684878	Load Test 9419684878	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$AOoQR954GlFFhyY9fzSf7.zPC0MV/cxdADRZ5Qwyj0JexuNLzb3Ca	["homestay"]	t	2026-01-15 13:57:00.152116	2026-01-15 13:57:00.152116	\N
d1a9b7ff-62c0-4bc1-becf-3151d26403b9	9297965045	Load Test 9297965045	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$5lsf827k4uPROI6qbeOmjOC0pgXeDor2QFZAvx8y3F1/YQWgYZuc2	["homestay"]	t	2026-01-15 13:57:00.511881	2026-01-15 13:57:00.511881	\N
d429d2db-1685-47d2-8ac7-3e7bba72e2df	9231429952	Load Test 9231429952	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$0N5wgEr/scTM2F17QIHQO.VgldtYzA/GmlBkktspxF2lpZsqToApa	["homestay"]	t	2026-01-15 13:57:00.601383	2026-01-15 13:57:00.601383	\N
e850b0bb-b7e6-4bc4-ba70-8b62e9c01a22	9450870107	Load Test 9450870107	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$za0B32TcjvxJ.FZkRqb67uDWXR8G4LZc2wmma45KVjLCoPUS7BbYS	["homestay"]	t	2026-01-15 13:57:01.273398	2026-01-15 13:57:01.273398	\N
0b26dec4-aa95-44a7-9866-22d180f9a3ff	9169417707	Load Test 9169417707	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$plBnuKM3yVaOyPEBhZYeI.2W4AuFg5f5WPDES9BEPst9Yw.b7q4Ry	["homestay"]	t	2026-01-15 13:57:01.833625	2026-01-15 13:57:01.833625	\N
f568d988-11d7-4dd0-b50f-9b2fa3e901d3	9759032877	Load Test 9759032877	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$FVArIO9hA5R1SqDQlN2tmuf9Tcm4R6eco8C8q/eiEGj//xhLPhRtu	["homestay"]	t	2026-01-15 13:57:02.214364	2026-01-15 13:57:02.214364	\N
2485e477-5cf6-4a53-a7c6-0ec1b0b648a3	9937132758	Load Test 9937132758	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$c6R336CfJ0Wp5SSLds.mgus51vQ/klwRTGni/yPxd35DHap9jR84W	["homestay"]	t	2026-01-15 13:57:02.265074	2026-01-15 13:57:02.265074	\N
2aa49b9e-a6a5-4537-b722-7e573bbedfb9	9144779029	Load Test 9144779029	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$g0spkK7OA9yYl6UQ2VU5WuU0278nXBCSBtcT/ulfAm8wMQ6RzRSJ6	["homestay"]	t	2026-01-15 13:57:02.885346	2026-01-15 13:57:02.885346	\N
ba9cd756-1c48-4f09-8a37-d44db487a7fd	9420757420	Load Test 9420757420	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$IIDahlSqnEk7Mpd3lohZT.yRSbHwKxiwqvPK1ZyugWlqgB/1Xr./G	["homestay"]	t	2026-01-15 13:57:02.921919	2026-01-15 13:57:02.921919	\N
373a9529-93ee-41c6-be48-4f83819f492c	9114847386	Load Test 9114847386	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$st2XptU8ItXHuzKWFFGpEuti50Ygpp9NlaTVk.KTz5yw9v9buZKmS	["homestay"]	t	2026-01-15 13:56:59.220204	2026-01-15 13:56:59.220204	\N
1fc59259-967e-4a0b-b351-38bf051355ae	9537325758	Load Test 9537325758	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$0JXWYQkIZFfqECdhOIIAauCTtS2Ne7ZCg4RKw8sFvK6IqHrxJlCoy	["homestay"]	t	2026-01-15 13:56:59.610075	2026-01-15 13:56:59.610075	\N
7738698c-1383-4f61-ba77-5bbde111734d	9699513694	Load Test 9699513694	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$ABgr6BJA5cKaoJAlCc7yaOds8P1FuUVmFI.mfnkeqfOKZmunxJSYe	["homestay"]	t	2026-01-15 13:56:59.674112	2026-01-15 13:56:59.674112	\N
369255ba-d44b-40e4-b543-e46328f5505a	9720399052	Load Test 9720399052	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$LiDZxdd2WXwHrH3oQ2ChmOUcxBfi2GJItE57T8zClUmYpZ/WgIu9u	["homestay"]	t	2026-01-15 13:56:59.721743	2026-01-15 13:56:59.721743	\N
950a2ad1-6913-4a69-98fe-abbf9f085e70	9318408149	Load Test 9318408149	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$WYjjVA1hlUkNF7fqbyASoeo065qGMce0WJB8bR0TJRWAcBcBzmrqi	["homestay"]	t	2026-01-15 13:57:00.044686	2026-01-15 13:57:00.044686	\N
740e33ea-0a84-4421-b22d-768aad5a7b34	9525174926	Load Test 9525174926	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$W6aw51zGYq8E5MAhZBC/oez65tp3G96JCgNU1Ver9nvH7fBk0O72W	["homestay"]	t	2026-01-15 13:57:00.095986	2026-01-15 13:57:00.095986	\N
01d77aa4-3860-4b31-ae90-0dc219e62dbe	9621514245	Load Test 9621514245	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$XWSFB7QtBcq0.3ipD76dU.SpokVAnvxjQm79bBcy2Pz5ggA1jgRSi	["homestay"]	t	2026-01-15 13:57:00.314393	2026-01-15 13:57:00.314393	\N
92e981bb-7128-4960-a10a-17230554679a	9878605328	Load Test 9878605328	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$/lP.xCbKnkmrAAuyYTTN6Oic563s77NzxUN89WgDAWDEeQ14Tr.Eq	["homestay"]	t	2026-01-15 13:57:00.519202	2026-01-15 13:57:00.519202	\N
f8fbdd30-523e-4c89-aca5-cc174bf13bac	9207705821	Load Test 9207705821	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$0ZQgfD9i2XpP2uYhRIfSK.PDsOwExd5ePoe1zA9/94.IXB6y3PlOe	["homestay"]	t	2026-01-15 13:57:00.631269	2026-01-15 13:57:00.631269	\N
b7059504-fc6e-4716-a2b4-86dbac25fdf2	9403425931	Load Test 9403425931	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$2uPPy/wn7mwPFsPAapyrRedV6bzDEdccMeb2qlWXqUOb2./gOggNu	["homestay"]	t	2026-01-15 13:57:01.010566	2026-01-15 13:57:01.010566	\N
a2be5f8f-1d29-4527-8ed3-e65756e77118	9577152749	Load Test 9577152749	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$hIPxbqaBFDQS7tX1gNmiV.appOPYuQVIMVcjzXZgj4e6Dnj1soAg2	["homestay"]	t	2026-01-15 13:57:01.063536	2026-01-15 13:57:01.063536	\N
da6bfec4-3b41-4242-9cf6-6c0e886be883	9326811787	Load Test 9326811787	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$19keM37x6ROc.EboqWnoBuij4gXM5638aStrZcpYapP77To7VTz3W	["homestay"]	t	2026-01-15 13:57:01.094725	2026-01-15 13:57:01.094725	\N
ef4fb1ff-7832-4746-a9c5-bd441fe503f5	9876218792	Load Test 9876218792	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$G2EvM1kt5Ad/0gBqw51TnevIhVyvrz7tZcdhgWZ61HErTzaA1vhYa	["homestay"]	t	2026-01-15 13:57:01.307159	2026-01-15 13:57:01.307159	\N
7aad5caf-7a0a-4174-9a58-46383263e499	9348978631	Load Test 9348978631	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$a7amIq8e3Ub1NK8jNiZTtep9YwyqVDlFYxqttpm.dED8hHg.KoapG	["homestay"]	t	2026-01-15 13:57:01.986531	2026-01-15 13:57:01.986531	\N
09af5782-66ed-4b15-b173-fe2b9c8b3d8f	9534762328	Load Test 9534762328	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$sP5K8rb2wibSRZX9Bf0cz.JGCaBF.01xQcKM5CmUImp3.Bw0p2CiG	["homestay"]	t	2026-01-15 13:57:02.020951	2026-01-15 13:57:02.020951	\N
3de23620-9a5a-406c-8b06-0e3661950149	9303968472	Load Test 9303968472	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$xkyU97Nax0.yyxUs17566e7P.YT9q.HFlupRYQb48S/QHzaSoZN9q	["homestay"]	t	2026-01-15 13:57:02.438187	2026-01-15 13:57:02.438187	\N
b64fb697-751e-4c62-93ef-c9f41dd32352	9972334076	Load Test 9972334076	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$Lu53fDmhBYDXUdjZimTmj.f12xNXu8NbaLuDMvVOhBaKpeG1Sk7jW	["homestay"]	t	2026-01-15 13:57:02.496799	2026-01-15 13:57:02.496799	\N
bd44c2b3-d219-4b29-a18c-42a77b946178	9789844028	Load Test 9789844028	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$oi5E/hc7bWFTyk1Iu8BAC.4ljlKwyoEahWD0iwnBDRtulpzwjaf9m	["homestay"]	t	2026-01-15 13:57:02.696515	2026-01-15 13:57:02.696515	\N
170dc23c-ced4-4980-b8b4-b2e18b48e41b	9694950097	Load Test 9694950097	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$V48ojY1EbeVTb.PSmRMCn.oCWiaRhvo8GdOYhB7b0ClzrXmS.LECu	["homestay"]	t	2026-01-15 13:57:02.92719	2026-01-15 13:57:02.92719	\N
edd36979-eb2a-4da8-a99b-789b240f81f0	9952939609	Load Test 9952939609	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$5rZfJXCofl3sTy6TKUnylerqu4lJp8Lsd7odbjIX.MsAWziQgeKvO	["homestay"]	t	2026-01-15 13:56:59.349418	2026-01-15 13:56:59.349418	\N
afcf6eca-e9ec-4edc-baa0-7262a3011a8a	9155264920	Load Test 9155264920	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$r1piSzsqW2usgLQWdeBzlu61c9W5hAYknKyOAwj0PBjDScanwwxQS	["homestay"]	t	2026-01-15 13:56:59.460671	2026-01-15 13:56:59.460671	\N
2c688215-185c-48ce-b5fe-8ce3e6b95553	9839884362	Load Test 9839884362	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$DntPUx/gB92mEkVQ70naeeURMpyDZUjNXnM9aJSSJdDjospwswu5W	["homestay"]	t	2026-01-15 13:56:59.61066	2026-01-15 13:56:59.61066	\N
2cb960fa-b151-45cb-b272-ec3a308492b5	9978835542	Load Test 9978835542	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$TY8hReAla95Xt9azcAtt9u93pPJU4Xrv4Mdjsou8Oaog1rHcyklAm	["homestay"]	t	2026-01-15 13:56:59.671719	2026-01-15 13:56:59.671719	\N
8a6ed20b-e56d-4026-bc8d-e293e859bfb1	9704200378	Load Test 9704200378	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$0LDOFxR7NEtx7ll./Mi.JObp8GVfUvAAct5pkFBfD.Ey6WHhD/g.y	["homestay"]	t	2026-01-15 13:57:00.047415	2026-01-15 13:57:00.047415	\N
754337fd-58d9-4ef2-945a-c6dab90c9f00	9950581471	Load Test 9950581471	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$NWWyD7By3Pe6pEBtE3ZT6e8AdN7SBUJ/dJz9Rk15LQuFIbhRu399e	["homestay"]	t	2026-01-15 13:57:00.326536	2026-01-15 13:57:00.326536	\N
bb9243e6-77f2-4aa9-8a37-7b6359f4f58a	9708298040	Load Test 9708298040	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$WjFZhurS4trTuJHLy/MNwu./g3O0369woERdWUKUnsr0IG8Waw35O	["homestay"]	t	2026-01-15 13:57:00.403114	2026-01-15 13:57:00.403114	\N
37c8755e-96a5-492d-9ac1-be552a322634	9742240383	Load Test 9742240383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$.qq/Q73gUQCzH0g/lbqpfuA4bJ3FsRvI4DpLKCwPwb8qMuDBrt3ni	["homestay"]	t	2026-01-15 13:57:00.787535	2026-01-15 13:57:00.787535	\N
158595de-5d1d-4b34-88f2-d61de98a99e4	9418430176	Load Test 9418430176	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$Sv3gpfZ5aAEemRcKJ7S0neub3SFq25Br5K7udfrZo8RRqzlFIJsIe	["homestay"]	t	2026-01-15 13:57:00.855265	2026-01-15 13:57:00.855265	\N
6124fbd3-c9cd-43cf-b348-5c0f233c9e57	9500978777	Load Test 9500978777	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$N5yEy4yznjgqf6rYajtW0OqBkm3ydQc6uafmok.57W4bSpu/yyx2C	["homestay"]	t	2026-01-15 13:57:01.238173	2026-01-15 13:57:01.238173	\N
cd1b6c9b-625d-468f-93a6-8d4ee8d269b4	9878737286	Load Test 9878737286	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$MXVtcutEsR6go7RmMrXmGOe1JnAMU3tZrCiaYBtvYpCS2Zsc8Ae1S	["homestay"]	t	2026-01-15 13:57:01.730104	2026-01-15 13:57:01.730104	\N
9c469098-d812-4427-8b7c-ab635899e4e1	9107845177	Load Test 9107845177	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$Jhrxao.Uir/YfbZ3nYknUez87hIWm.ORXT7gfUcc0LIeetDmzhnz2	["homestay"]	t	2026-01-15 13:57:01.776454	2026-01-15 13:57:01.776454	\N
f07bf262-3abf-4db4-a767-9f89f2236723	9991794499	Load Test 9991794499	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$dm/OZ9SadTyrXMbAzMPEc.c5fU48zboLAT1/YPUS.qwap6XnwI2sS	["homestay"]	t	2026-01-15 13:57:01.821332	2026-01-15 13:57:01.821332	\N
a6fc9813-13b6-4de5-9f14-8e8505329a2a	9504634687	Load Test 9504634687	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$tI/na507JJ5yDyd8LsS6DuRn9Sejl709jiqqnOiKXVaos7h6IgMm6	["homestay"]	t	2026-01-15 13:57:01.874985	2026-01-15 13:57:01.874985	\N
32fa482a-3c77-44b6-bb62-1932046a01e2	9603739581	Load Test 9603739581	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$Ln5bxQ5pS6njGuGDJXQX0ekegW.pD70fdtQpIxZMKc1yCgVQ1hnbi	["homestay"]	t	2026-01-15 13:57:02.208518	2026-01-15 13:57:02.208518	\N
8d1ec217-1909-41c7-86c7-09c65f89c941	9646586184	Load Test 9646586184	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$0t/HsSWHoczQ6TwyaMnA.Oh9MoOkjEVYHeNtIkBWUjRNueVuP8oyy	["homestay"]	t	2026-01-15 13:57:02.26893	2026-01-15 13:57:02.26893	\N
a8d831f4-9caa-4ae0-9719-67bafb7811a7	9474805931	Load Test 9474805931	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$hvmlUB7xLFdjcZIstZB.wOenqNN2F/TQmwkuhVL0pvptFjWnAKRVK	["homestay"]	t	2026-01-15 13:57:02.305614	2026-01-15 13:57:02.305614	\N
d7f74aa5-6b78-4536-ad5b-c62df573e2ec	9812296982	Load Test 9812296982	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$AUFVi6NwTLaCGKKU2kvjKOunIakCRFCXeUbXTvJhYOJx9Wy/T2ZQW	["homestay"]	t	2026-01-15 13:57:02.511305	2026-01-15 13:57:02.511305	\N
074d042a-de29-43e8-8d43-e4192743bc0c	9898423895	Load Test 9898423895	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$u5yAzVqRBLECLgvLYWw1quvNTa0zJsKN1zywJJSAcFKw/0QMcvTfe	["homestay"]	t	2026-01-15 13:57:02.544164	2026-01-15 13:57:02.544164	\N
be935755-2dba-4b80-b321-007bb44d762e	9313249453	Load Test 9313249453	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$LJ.o8xjJ/YYoG6pamlpME.lIAr1bwLmq4lXyg5Wxnwvoy3IyCpDqu	["homestay"]	t	2026-01-15 13:57:02.679293	2026-01-15 13:57:02.679293	\N
13d8cb4c-bdce-4886-a1af-2891e3ab2ce1	9162355540	Load Test 9162355540	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$Pxc9YXBAunGWNs/QoYwn1OIQi9gZC3YbBuQ8Hhc0JsATFdS39iKJa	["homestay"]	t	2026-01-15 13:57:02.717919	2026-01-15 13:57:02.717919	\N
497f1c74-1828-4bac-9900-c193c25faecb	9182273482	Load Test 9182273482	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$ZVg..3ysVnYkt5dTfaIGk.I3CoAoTfHEQ1v.2al/PSp5j.QfVjzvy	["homestay"]	t	2026-01-15 13:57:02.780941	2026-01-15 13:57:02.780941	\N
54453845-500b-4bbf-8004-da0df57b1c7f	9125858773	Load Test 9125858773	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$MYkgmVK76Bp7Xh0A5OxyBOkqxD2PqSDgy4M6GGMF/y7UO8CCjsikm	["homestay"]	t	2026-01-15 13:57:02.966835	2026-01-15 13:57:02.966835	\N
84545c01-95ce-4a71-a2c1-838e6e932ab3	9804391497	Load Test 9804391497	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$bs2E86djEmJhhLfdI3jr9OYfmLdNFR7k1lm3HpJvEATzgJrk164ca	["homestay"]	t	2026-01-15 13:57:02.988173	2026-01-15 13:57:02.988173	\N
f200d4d5-d569-462c-88d9-1ea25fa7b766	9989906755	Load Test 9989906755	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$5/uaWetisQEwFFC0EGiU0uWo2VdOBIOVq0DymgQihYzOTvl/D7BUW	["homestay"]	t	2026-01-15 14:00:46.575111	2026-01-15 14:00:46.575111	\N
a96bef40-5b38-4b9c-befb-86092cdc5f7c	9563745587	Load Test 9563745587	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$sGYDRuw0CwucWEScUAD1Iu9u9RsDwyctV/rNUGvP0ltHxvtMpAnnS	["homestay"]	t	2026-01-15 14:00:46.584435	2026-01-15 14:00:46.584435	\N
b101b85e-abcb-49fe-b3f0-2f447c9a9f55	9223772067	Load Test 9223772067	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$0Hf5XqDtpCaL3wKRfX6QGe73FGZEwrY/8YNv.NgAYDg6tf5tIkPMy	["homestay"]	t	2026-01-15 14:00:46.587303	2026-01-15 14:00:46.587303	\N
d59bb89f-25a0-4fd3-8b47-2976ac3b3f9b	9197073696	Load Test 9197073696	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$Oj4KEgmIU4siKmER1OqCNeoYel5OQUEFKGJdTh7HSJ0ytYVssT2ta	["homestay"]	t	2026-01-15 14:00:46.590207	2026-01-15 14:00:46.590207	\N
e989b0ee-dd0c-4ce9-8af8-781e8ba02f8e	9503653791	Load Test 9503653791	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$IZ3VlvM.LmFDzneZd6TOHe5FHT6jANsIDJYomC5DbVD6VjBzofUgK	["homestay"]	t	2026-01-15 14:00:46.66237	2026-01-15 14:00:46.66237	\N
f7b801fa-0ef5-43e9-95e0-409790271f9e	9175774061	Load Test 9175774061	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$XYTj2PDNr4pix4OYxqky..4lEbrq9wE7Sr0sRfwuAhCurvCyH2Hiq	["homestay"]	t	2026-01-15 14:00:47.017346	2026-01-15 14:00:47.017346	\N
4831861c-2c25-419b-a820-3a1ddf62a080	9946349954	Load Test 9946349954	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$5o2UVdiRLQFpCa34s1ZyM.Ew0gHXLUUHCE3Svy9dX7rd/rKk3p/p2	["homestay"]	t	2026-01-15 14:00:47.030504	2026-01-15 14:00:47.030504	\N
a594f4f7-fd9f-40d6-a7d7-aeb205f64b0f	9829775880	Load Test 9829775880	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$XHmyaa0uhD7VPPIMf4AoN.rKGJ5H6ETlD8weBqznWSuSjbSazy6mq	["homestay"]	t	2026-01-15 14:00:47.038141	2026-01-15 14:00:47.038141	\N
9596014c-87b6-4e87-a28c-3c06c10ffba6	9252017646	Load Test 9252017646	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$0sS8QdLhF/p246zfbbJNjuoGAIBOtl/fjtD6Up31kW8EGd6x2RIR6	["homestay"]	t	2026-01-15 14:00:47.03853	2026-01-15 14:00:47.03853	\N
e24a09ce-1013-4dbf-8cfa-b13d0fb5aaf9	9162561900	Load Test 9162561900	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$sDfLDg30VLXvV1eaL4WYAecRVz0eAqXWe6b57fY4c47DWpIPFKs2O	["homestay"]	t	2026-01-15 14:00:47.104529	2026-01-15 14:00:47.104529	\N
a7562a1d-5b77-4b23-944b-6c44b3b416d3	9241632254	Load Test 9241632254	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$CheHrJgI30G5hDFnbkl.V.Cmo23Bf8LtL82qH7M7AgIvNrRw8h1Xu	["homestay"]	t	2026-01-15 14:00:47.484119	2026-01-15 14:00:47.484119	\N
cbef38fc-8cce-4eb9-ab5b-39cbb2d28038	9962889767	Load Test 9962889767	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$dP8lt1/xCwZRZWLXKegIp.gz.QS/hvznAyT9gVziKIEPhvj.4S8b.	["homestay"]	t	2026-01-15 14:00:47.490303	2026-01-15 14:00:47.490303	\N
b5b9fbf8-9ae8-4548-8299-83e455af8bfc	9514763560	Load Test 9514763560	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$PQt5aeuL49oxHnLW/FyrkO6yTQs8YGGgTFvYM.zvMqqg5nULoxXTu	["homestay"]	t	2026-01-15 14:00:47.553247	2026-01-15 14:00:47.553247	\N
e9813c7e-af8e-4fd1-8115-8849cd2ac909	9508773363	Load Test 9508773363	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$WSzfnWNnkV0ficIIatadAuc/Yzeda4GBrrQsjNVUuvJ.8W9yFgTZ6	["homestay"]	t	2026-01-15 14:00:47.574312	2026-01-15 14:00:47.574312	\N
8f167a42-a2e0-4fcf-bbd1-0853e57d6046	9779467155	Load Test 9779467155	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$/AR9WNhAiAB8nA8hcOMQ/ObMudiUqHodd8eaE5i9mns872wt6guTG	["homestay"]	t	2026-01-15 14:00:48.036522	2026-01-15 14:00:48.036522	\N
323f9bcd-7a71-47ba-8546-219347c8c03a	9357072687	Load Test 9357072687	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$a3oGo2od47/Bnkm6q1WffuPB0Y0lsUFqbaaZkImJZgr3fdjgtbeTa	["homestay"]	t	2026-01-15 14:00:48.124432	2026-01-15 14:00:48.124432	\N
792561d8-b915-4eaf-8854-e1b46099495a	9106394336	Load Test 9106394336	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$ImVLvDqf3PwcQatOfBSjY.QddFLz61toKBKXmLGuTc7ZLjbCZz1WK	["homestay"]	t	2026-01-15 14:00:48.49422	2026-01-15 14:00:48.49422	\N
e38a12af-59f4-4657-a6b7-f9444d0a131e	9446121812	Load Test 9446121812	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$djMIML7NVsNlRgoMMyeXKuzYbOFIAaMUaVvyBKy4x/c.xpVCKjp/a	["homestay"]	t	2026-01-15 14:00:49.359787	2026-01-15 14:00:49.359787	\N
945e7edc-69fc-45ea-a032-1432eb37f579	9498188042	Load Test 9498188042	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$jnKbq25KEI1tY/bmW2rH9OebtjV8ILF32SzLopnjjatI1qOOKAJxS	["homestay"]	t	2026-01-15 14:00:49.800376	2026-01-15 14:00:49.800376	\N
e7f15b4a-2b41-4a07-bd16-f956fb01daa4	9945480524	Load Test 9945480524	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$w3dhdgHNDq8y0X5mExRaTuJjyKtL59gbUutWpqVrBv5xE.yJQD326	["homestay"]	t	2026-01-15 14:00:50.261665	2026-01-15 14:00:50.261665	\N
8b7896de-7997-448c-bb8d-27e3c9731e85	9314605269	Load Test 9314605269	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$ib0oxOXKX6L/l.DY1il.v.Zxr/GitU4yOK1beJadbhwjPsPFkZCny	["homestay"]	t	2026-01-15 14:00:50.679602	2026-01-15 14:00:50.679602	\N
f625569e-44c7-4f5f-9e88-d1ebe5418f08	9896556910	Load Test 9896556910	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$Miwyq7d/zpd.Cjm8NJzkIeoTF4fJ63IE2rYFKNnmKl7okEMGn7dIG	["homestay"]	t	2026-01-15 14:00:51.078524	2026-01-15 14:00:51.078524	\N
e5bb23b9-51e4-450b-85c2-550162dc77d8	9491655937	Load Test 9491655937	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$VN2q7eAuM/0a7JFwSRaqT.l8qEyY4rRkEfHc3EHLRAOZGYeWA/PSa	["homestay"]	t	2026-01-15 14:00:51.486564	2026-01-15 14:00:51.486564	\N
c7424520-a888-4ddb-be2b-d1ad81902c4a	9795390824	Load Test 9795390824	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$NR127AAbljzHKPkbMj0LQOmXa2REu/5i7g9Hcf1eewQsQMJXB0eiO	["homestay"]	t	2026-01-15 14:00:51.882814	2026-01-15 14:00:51.882814	\N
fdf23724-9ca5-47be-93cb-3cf5340f7166	9517412851	Load Test 9517412851	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$6SMm8oGxOt4Yw1dqt1z83e7q0DyUoVcu0YR1HsXeVvwQZOdrcVsXm	["homestay"]	t	2026-01-15 14:00:47.580012	2026-01-15 14:00:47.580012	\N
f0e9b06e-a4da-453b-807a-aed75923e521	9337271202	Load Test 9337271202	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$PsRyNCp.vOD7GeSEMdFnsuCA6CdZYH6FR/a8J3Ei27fdmdKMGI/pO	["homestay"]	t	2026-01-15 14:00:48.040908	2026-01-15 14:00:48.040908	\N
0855fedb-bc57-44a6-80ea-6db0044f1f9c	9683754371	Load Test 9683754371	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$HsIhZUtz4qoba1BTghxnweygJT0RhkvmN/Qm4jihcUkySgvQ7A8ae	["homestay"]	t	2026-01-15 14:00:48.042037	2026-01-15 14:00:48.042037	\N
e4d444d9-e616-4f32-bf82-498726cf3969	9676103308	Load Test 9676103308	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$KleWdl9cG5H6r5oVExIi3udnaf7MeVvaBRSPh323zBK7MQFflwyFS	["homestay"]	t	2026-01-15 14:00:48.492701	2026-01-15 14:00:48.492701	\N
43815dc3-4cb4-41ae-983b-4a1e7d5315fa	9579733663	Load Test 9579733663	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$K1fXnmYKJUBLQetbEz/dA.B6snZkXxEFHZgHDOqirnU6yTmwBvUtK	["homestay"]	t	2026-01-15 14:00:48.494782	2026-01-15 14:00:48.494782	\N
036933d3-d229-49b1-9bbe-25e92800ce81	9743514252	Load Test 9743514252	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$WP2jothlrYFnjgNpZtTP8eUoKfBAgYpNRd5JQg3zDFR7NVLcHoJnG	["homestay"]	t	2026-01-15 14:00:48.583309	2026-01-15 14:00:48.583309	\N
4f0d7650-cf3e-4ed4-8a80-64e002cc6056	9705781325	Load Test 9705781325	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$G0hXyzwLOQY0uy2JSHca8eTBWyPo3w2M9lOhI.f.ESwW3BTdtZkQW	["homestay"]	t	2026-01-15 14:00:48.908052	2026-01-15 14:00:48.908052	\N
411c21e8-35c2-44a6-a02b-f356d5d0622c	9203852905	Load Test 9203852905	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$P2bZCB/HyPpdoD3UrvOscekPNkSlzML2m/qzvhCMRxi9.Yzt84Mme	["homestay"]	t	2026-01-15 14:00:48.922838	2026-01-15 14:00:48.922838	\N
8aefe55b-5e79-4a19-b105-eba4b6eba999	9839782758	Load Test 9839782758	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$U2i9DKTOEArUzsRujWzfh.MAca3gLOKk.n2jfXUQapFL.ebXv1yYy	["homestay"]	t	2026-01-15 14:00:48.990779	2026-01-15 14:00:48.990779	\N
7d7d96b1-2f68-433b-b9d3-72955888d279	9434955366	Load Test 9434955366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$XWS4T5XAOqmvPzjKPEpzdun9OH0e4m2ifMQ/moNEV6pnxNvhDRHCW	["homestay"]	t	2026-01-15 14:00:49.360617	2026-01-15 14:00:49.360617	\N
a1771b13-6785-41fe-987c-0a6cf789e278	9600728499	Load Test 9600728499	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$tGFjV6KnlEJ5ONjYBqdDHe3iiZTKby/HiPOJGHWKDJ50RGuIoIdNC	["homestay"]	t	2026-01-15 14:00:49.446879	2026-01-15 14:00:49.446879	\N
046e9240-3b2f-4463-a9c9-d22a00815ec7	9103841154	Load Test 9103841154	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$9Se2052w5kZMhV3O.uxVw.FDGcSSQdYxRUCZoJsad8Pu.zw.bR0Ie	["homestay"]	t	2026-01-15 14:00:49.803329	2026-01-15 14:00:49.803329	\N
a55511fc-f7db-4788-8015-4fc0b501856a	9399864397	Load Test 9399864397	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$xgBzqEq5KLvBOrYSqoqBZu4iUOY/LfRFcnVMvdmK7VLRyIlX5MshS	["homestay"]	t	2026-01-15 14:00:49.803287	2026-01-15 14:00:49.803287	\N
162158b1-c39a-48d0-a09c-1c1e12e83a9a	9745707674	Load Test 9745707674	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$rWn3a2yNUBbEz3jSndh/X.XhIlYWbby.1FmEBBl4WeMs465I2osK2	["homestay"]	t	2026-01-15 14:00:49.88316	2026-01-15 14:00:49.88316	\N
33d7ab6b-6701-4764-8185-63d89e2e6e34	9157284347	Load Test 9157284347	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$.kaSY8tHFMWKSxLExRdNNOlwYyYd3vpJMokA8247zm6zaWZWrxDea	["homestay"]	t	2026-01-15 14:00:50.262744	2026-01-15 14:00:50.262744	\N
6e8e1f43-15eb-42f6-a680-9e4c44192952	9183254736	Load Test 9183254736	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$wglCanpGUU6zC9iKlSiYL.KM30RNU4NXpchvlfgg79pbfYueNZdEu	["homestay"]	t	2026-01-15 14:00:50.342709	2026-01-15 14:00:50.342709	\N
f3941361-fb0b-4a28-b9a6-028fcd2e76f9	9883451148	Load Test 9883451148	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$sO9SReTuFij4TPA4ppBHkuwnd.tvLZhJaDzEPPsYX38qtk8KYUi0a	["homestay"]	t	2026-01-15 14:00:50.678895	2026-01-15 14:00:50.678895	\N
673fe948-c92f-4b68-85c2-9a2d7dfea971	9428928601	Load Test 9428928601	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$jcYC9cqY7/Q3DbmTLY.n3uFoH.nmI6GMJ4UoxNc35a7ebXVYBrO7S	["homestay"]	t	2026-01-15 14:00:50.680153	2026-01-15 14:00:50.680153	\N
380b5741-582b-4f6f-b858-9ae53ea54a87	9951344325	Load Test 9951344325	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$TqMHcIfyF4tbzZODn1p1t.nc.UK59sPJaHQyB/lzTqxythbP4uhr6	["homestay"]	t	2026-01-15 14:00:50.758363	2026-01-15 14:00:50.758363	\N
e10b5523-68cf-4bb5-b92a-e3aa1690e2df	9166104791	Load Test 9166104791	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$mF3m6gwJoNGTKsW0e34cYORq70r4pM/qxYuU/6cJc8u/vsYyJ3Pay	["homestay"]	t	2026-01-15 14:00:51.078768	2026-01-15 14:00:51.078768	\N
b125661e-cd86-46d8-a22d-8e5f2cc750fe	9412209388	Load Test 9412209388	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$.vS6cVn50dVrolHMOfTDvOUL7wlE2cofNqUiBSpR6i18DynNR7E9i	["homestay"]	t	2026-01-15 14:00:51.083044	2026-01-15 14:00:51.083044	\N
edb09e03-c176-459e-a2b4-5cffa2089a6e	9346256527	Load Test 9346256527	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$EAmoyyGBoRyD6U3Fu2nW1.H.H26EkG/TGzgHBmtinkHDI8Ym3W8fO	["homestay"]	t	2026-01-15 14:00:51.161311	2026-01-15 14:00:51.161311	\N
5d7509e3-6170-4772-a091-c9d1bf9a1a3c	9250839957	Load Test 9250839957	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$iNQOcMwv22TljSvxNHk9U.q6luo/ToBLQLq0edNv7xfIAN5qFS3vS	["homestay"]	t	2026-01-15 14:00:51.485822	2026-01-15 14:00:51.485822	\N
a2575f11-7e3f-48da-a03e-2b1f49b00e1d	9529684539	Load Test 9529684539	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$uQNaFctvLhSl.1EJGVvFoeZJACAymyHvZlrOjkeyhPkCfnpsQHipe	["homestay"]	t	2026-01-15 14:00:51.489819	2026-01-15 14:00:51.489819	\N
696a388e-c768-415b-b189-ab933b68572e	9615790852	Load Test 9615790852	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$W4D8WyXyTojZdELi/70FWuj.saXTBziJtb5kkK1/oyV/LiZEA3Jbi	["homestay"]	t	2026-01-15 14:00:51.574523	2026-01-15 14:00:51.574523	\N
ea7e35ec-cfcd-48c5-90e0-60c08b8dbd27	9646606801	Load Test 9646606801	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$/Ou7YT4rAGDiv6GX3SZD6uyVhF4TpQ6nDMQ9SCiHKEgEPFyKhz19q	["homestay"]	t	2026-01-15 14:00:51.883314	2026-01-15 14:00:51.883314	\N
dd25cdb7-53f5-46c2-a8c4-d80ea9550e28	9249046780	Load Test 9249046780	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$6CO837TjIvtkcj4TX9pJHuW1J9WFaC0aAY5o8SJd2hxvcDDJxj6U6	["homestay"]	t	2026-01-15 14:00:51.887827	2026-01-15 14:00:51.887827	\N
0988d42a-c1dc-4132-a11e-a8525c317065	9461205243	Load Test 9461205243	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$asVeUiouVoffCCBgpSTBTey4tWvxm6L5Cw1tV2utqh0AucbtF6XfW	["homestay"]	t	2026-01-15 14:00:51.962661	2026-01-15 14:00:51.962661	\N
54eb4664-f445-4e24-ab4c-6978bef45607	9484826171	Load Test 9484826171	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$1lu5gm15dN3s37FW3Q3swusOeCURyKiU3IdMquIlv.Aw7Nvd39HwO	["homestay"]	t	2026-01-15 14:00:52.252055	2026-01-15 14:00:52.252055	\N
b68f1178-5ef8-4655-8f2c-bea5ab0497a0	9858047317	Load Test 9858047317	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$.lUANBIWdkBjdLFrV.O.3OvD3T4Ace73m9ClxWefevDCDpfk93GP2	["homestay"]	t	2026-01-15 14:00:52.25261	2026-01-15 14:00:52.25261	\N
ca4eeec9-baa2-4bec-a33e-7d3993a6b89e	9495135166	Load Test 9495135166	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$lybSolk7smYxFAuYM2yVqOrehR2kU5kr.c9XgINmdykj.BDTUaqOe	["homestay"]	t	2026-01-15 14:00:52.255552	2026-01-15 14:00:52.255552	\N
6d94db75-af33-4cda-8497-ae8f76392493	9431406151	Load Test 9431406151	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$uXFBdn4.Txpqw8Kji3VOYegDkkov92Pa0s0c9BpOEPA2APdm0lpsC	["homestay"]	t	2026-01-15 14:00:52.680846	2026-01-15 14:00:52.680846	\N
d7ef0c54-60e5-4dec-b649-8d9f1d351888	9194574345	Load Test 9194574345	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$2iymo7zrXywGy7NofUhHc.OrCZVUP29a2JPeqUrSEixmmm5eArKL.	["homestay"]	t	2026-01-15 14:00:52.683313	2026-01-15 14:00:52.683313	\N
8ca9bb48-9ed8-4319-9f78-c675ad31e10e	9285416612	Load Test 9285416612	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$x//iGFnTKCJYNDobqVHZ2uZD3zoud0Bya4FnrzbR8dNofCBH0z9R6	["homestay"]	t	2026-01-15 14:00:52.764341	2026-01-15 14:00:52.764341	\N
c2803612-a34b-4ed7-a3fe-3295c2a91980	9356091186	Load Test 9356091186	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$1UnDhYnYojdy16QlAxRyZeX3tSlCLzEOjndX/E6eRlY0XNky9/mNW	["homestay"]	t	2026-01-15 14:00:53.074083	2026-01-15 14:00:53.074083	\N
14070c77-4ce8-44ac-af61-e325b9938a53	9853781935	Load Test 9853781935	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$qcO3c2eUiphGFI6viJY5KeOmJxNsHxniBJbuT7X87dWRT4y6ToFWK	["homestay"]	t	2026-01-15 14:00:53.079063	2026-01-15 14:00:53.079063	\N
3f250339-fb43-43c5-b1c1-24e8e213c14f	9888619744	Load Test 9888619744	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$qna1hDNPGI71qjQuCpJsmeKyYTBIrdtajksdabwYIPLB57J1zk8Ie	["homestay"]	t	2026-01-15 14:00:53.465515	2026-01-15 14:00:53.465515	\N
fe41e63b-04bf-4051-9588-c673afb3fbe4	9343338009	Load Test 9343338009	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$YaKmWEvZOoO.68jyOQKx6OrspRT6X1jzCAnbzEb9h3cW6iZXTP/H6	["homestay"]	t	2026-01-15 14:00:48.043351	2026-01-15 14:00:48.043351	\N
e9a64da4-b83d-4fa6-bcf7-7ba7efc32036	9574843713	Load Test 9574843713	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$kbxe.wahV7iLCpqs65wYE.WgJx0q8MAsB5Xb249RBHGSApmoTX2q2	["homestay"]	t	2026-01-15 14:00:48.495838	2026-01-15 14:00:48.495838	\N
f48891fe-0336-457e-9407-bcb7486b3247	9813576160	Load Test 9813576160	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$E.9hIjBYvep6KTxvMNZ9eea7HUFM0dolRM66n6sj2o2nzRUl3.TGC	["homestay"]	t	2026-01-15 14:00:49.365075	2026-01-15 14:00:49.365075	\N
01a776c9-bf4d-44e1-9124-729c088ab3fe	9511806935	Load Test 9511806935	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$RisOZ4t2MiXBhCDdHpYu8.L1JdG39QDG47qD7zbLj89cYawGlL4kO	["homestay"]	t	2026-01-15 14:00:49.804136	2026-01-15 14:00:49.804136	\N
e0e71fd9-a2cf-454e-a357-371aab801a02	9798480857	Load Test 9798480857	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$v3wjuFcUHr6fgukKNZrhVODQv8Hq6TnzTn6SfwD2KyhliWujkD5Z2	["homestay"]	t	2026-01-15 14:00:50.260533	2026-01-15 14:00:50.260533	\N
1fce905f-56b3-4cda-9c74-9d9f50d43e06	9474528189	Load Test 9474528189	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$RMzndk6KTEARJSFYsvoFze5cH1Go6xATveOTezzYSAle9Lg4deuuS	["homestay"]	t	2026-01-15 14:00:50.683794	2026-01-15 14:00:50.683794	\N
acf9c22d-3a81-4318-ba4a-79833503f9b5	9226123980	Load Test 9226123980	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$6VjMBKkkEfYf5/0L6S/ou.Nly4wv7oWwYR7or4jmxnZ1ckN/52LmC	["homestay"]	t	2026-01-15 14:00:51.083427	2026-01-15 14:00:51.083427	\N
fb07e036-4faa-4031-93a1-16f3cb827fa3	9647203911	Load Test 9647203911	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$BvUv/UbzA35WJfKwzHrVeug.Sq5EFSEkDKvAwSwIsZLdA3lcH4f/i	["homestay"]	t	2026-01-15 14:00:51.488255	2026-01-15 14:00:51.488255	\N
98a4acdd-e2f4-4a89-bd14-86ea24657d21	9279834117	Load Test 9279834117	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$4vh8h213N/3HGqOgjytdOewixhI6wdXyz6MA.qesVViZjbje241pK	["homestay"]	t	2026-01-15 14:00:51.883843	2026-01-15 14:00:51.883843	\N
3a57bd93-ec0a-498d-8002-791de5545758	9800516572	Load Test 9800516572	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$bhJk9Tf0kQx9NH4g4R5bPOYrl/MH/yjbHrGbmH/5BugSQrGWFhG.a	["homestay"]	t	2026-01-15 14:00:52.682867	2026-01-15 14:00:52.682867	\N
f46e48c4-b313-4733-bec4-89be2f78f354	9575405341	Load Test 9575405341	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$Fg/DPm4//tKAs0yuHYXT5OaNuJuGdyOdoJctb34bfrMiftV96sh2a	["homestay"]	t	2026-01-15 14:00:53.073464	2026-01-15 14:00:53.073464	\N
ead1848c-e771-4e43-9a19-dd316eeb552b	9521769682	Load Test 9521769682	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$YczZzsFbdavO5MbXANbH3uLI4hQZ/WNemYhWQVV6aeXttlpHamXRm	["homestay"]	t	2026-01-15 14:00:53.877693	2026-01-15 14:00:53.877693	\N
06dee0ec-a7be-4f88-a8be-261fee6102ff	9151628645	Load Test 9151628645	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$zmnw2efN8VBzvM2NW4HmDuH8d7Jm.ktY90CwURJFg5gEJwO7/seFW	["homestay"]	t	2026-01-15 14:00:53.890428	2026-01-15 14:00:53.890428	\N
621c5f05-bc0c-433e-b9c0-c18c8ccfe5b4	9734383522	Load Test 9734383522	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$RSuY2O0FAoF4rdLP97sMJuCh1uSm4gyAcG5HE1I6zquOvMEq4Sn/G	["homestay"]	t	2026-01-15 14:00:53.970025	2026-01-15 14:00:53.970025	\N
01237f8a-902b-4b14-b04a-38508d41c894	9649537544	Load Test 9649537544	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$QiZvN/2HOOHelcpXSicJj.RycLC.07DTPbZJeTNyrUvSnXwmG0LjS	["homestay"]	t	2026-01-15 14:00:54.29477	2026-01-15 14:00:54.29477	\N
ed6bb431-4be2-4abe-968e-6f7f801c6244	9193764919	Load Test 9193764919	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$7kTB9fPPtL5rfcPFJJ3M2.FYihw8nk/lScLXV45ALwfNe4JQHnHxi	["homestay"]	t	2026-01-15 14:00:54.910866	2026-01-15 14:00:54.910866	\N
c379e771-2fb9-444d-af77-f7037f9f85db	9957457277	Load Test 9957457277	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$5mEoaJiAJWInhyRkjOU3iOkJN5hEQUorDKGRxPtBHhVm5eseStvxC	["homestay"]	t	2026-01-15 14:00:48.908345	2026-01-15 14:00:48.908345	\N
11e60245-7268-4e93-9045-4d9ca1ea5b33	9661365225	Load Test 9661365225	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$uFVlpNWWraUU5zDGqGXYte1PyMNRXMnnqW5MzSaMx1XFewIGkdkvu	["homestay"]	t	2026-01-15 14:00:48.926078	2026-01-15 14:00:48.926078	\N
406c81de-5940-4e75-b942-aa769dca8b40	9784282893	Load Test 9784282893	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$gpkkjJjZPn0JwR4GElJNA.UTyMCzlpPYB2QNPBACcHOtPXwBOrrV.	["homestay"]	t	2026-01-15 14:00:49.361085	2026-01-15 14:00:49.361085	\N
a77b31b7-49fe-49a5-a01b-6197bd4d468e	9435083855	Load Test 9435083855	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$FV8JmBmx2amw8PHsW6bnp.o/y/n7VgRQyxdm16S7pO6A1e2OtuqSS	["homestay"]	t	2026-01-15 14:00:50.262093	2026-01-15 14:00:50.262093	\N
46aaeedd-b2f4-4161-99b9-6f4c182877af	9453263898	Load Test 9453263898	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$8Zb7seadUweUXjG/1D2oM.yp45/b7DUuYaquMMor0wJVS9aZvnh1S	["homestay"]	t	2026-01-15 14:00:52.250774	2026-01-15 14:00:52.250774	\N
95635d39-c9be-4c3d-8046-8462e3820449	9653908971	Load Test 9653908971	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$PgwO.8v6mpLJLrNwTPJHkO20LzcI8aBS8MnpuqH6zquvRpvANIEr.	["homestay"]	t	2026-01-15 14:00:52.334087	2026-01-15 14:00:52.334087	\N
a2bec987-4d03-418b-804e-69b9720b5f27	9405879103	Load Test 9405879103	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$tSEbzOcqez1aLc8qkkvOYuoGsqlC3b7nli3GWOC89nhF3qJOVPgvG	["homestay"]	t	2026-01-15 14:00:52.681582	2026-01-15 14:00:52.681582	\N
d6269133-c1b6-4ccb-96a7-071892d618ea	9479152559	Load Test 9479152559	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$nl1BEBQdmPDPYtSDh5ezneWHshg6Wy0VpZ1MgyyZVIWr9S3bIJljC	["homestay"]	t	2026-01-15 14:00:53.077255	2026-01-15 14:00:53.077255	\N
9a50c9f1-e9e6-4f51-9c12-56f66794b518	9817574824	Load Test 9817574824	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$cQMI7lEb56g/.ADHyZb.5.YAbO28sLGNiVhPOsPwKkOjQKl4f9cl2	["homestay"]	t	2026-01-15 14:00:53.154437	2026-01-15 14:00:53.154437	\N
05b04ffb-fc9c-4e98-86c3-9e458bb985e7	9501536910	Load Test 9501536910	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$JmKEdsjKTZ8TQmUUMR12AONhN43KVuyv40fMACVYaG/JcLtoyeH6q	["homestay"]	t	2026-01-15 14:00:53.463958	2026-01-15 14:00:53.463958	\N
1f736bea-42e4-48e9-884c-3510847a36cd	9800716814	Load Test 9800716814	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$4INTCTrW4xE9TfgE1z6UyOPr1K76Y0esuOldqmIPHtTcNWrKuk0cK	["homestay"]	t	2026-01-15 14:00:53.468358	2026-01-15 14:00:53.468358	\N
cdbf6366-ab5f-4456-b5d3-2e2dcd43f636	9959132601	Load Test 9959132601	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$z.urNJorrwCKCeqiFG6.8uuoAZaCbH7aa9b48ithhW.hVD5yQ8YRm	["homestay"]	t	2026-01-15 14:00:53.545158	2026-01-15 14:00:53.545158	\N
9e29b6ad-8a1b-47c8-a281-8396f616fafd	9256041176	Load Test 9256041176	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$KG7tDH85nH.aqCMtyYshwuv8O4FWf1q8.zjwDRE5SYoxxHyMwZUDy	["homestay"]	t	2026-01-15 14:00:53.874529	2026-01-15 14:00:53.874529	\N
e2599a1f-f9c6-4131-955d-006e836ee65c	9979316320	Load Test 9979316320	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$Q1fClODB/LPzWaUc/ODq4eHJxuLMK.PskBrmEW2OURIJJRkiiVJL2	["homestay"]	t	2026-01-15 14:00:54.27453	2026-01-15 14:00:54.27453	\N
d264c61b-c283-4506-945d-64d6c9e272b1	9436537980	Load Test 9436537980	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$to7pDx4Bom15.T9aTp81Nuw7Wmdm1kVin6/IWZEQvSs5QnfyEM3US	["homestay"]	t	2026-01-15 14:00:54.290992	2026-01-15 14:00:54.290992	\N
24ede4da-51f7-48bc-916e-41fb15f9e280	9140537016	Load Test 9140537016	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$SPtObQa/Ae4vxOljOpm3MOczVoeF7AslyP1r.0cyoUs//Rqsoah5e	["homestay"]	t	2026-01-15 14:00:54.29141	2026-01-15 14:00:54.29141	\N
e3d15330-af7c-47c4-848c-92a18df6bc0c	9284239068	Load Test 9284239068	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$NvaPDK19qpYz.3DRTep3FehaBy69WSbvZJWyJs8EHQrzv2EWnxEde	["homestay"]	t	2026-01-15 14:00:54.365552	2026-01-15 14:00:54.365552	\N
7f9fb533-90ca-4e92-bc5c-0c5282eca554	9522112869	Load Test 9522112869	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$XU/kVqjxByWiouEHSCh4euOCK.E7U5esaMJ2vw0tTQ9ecKBdw5lQm	["homestay"]	t	2026-01-15 14:00:54.76756	2026-01-15 14:00:54.76756	\N
c76fa3ef-24b5-4e46-af49-360b7d0f994e	9603304170	Load Test 9603304170	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$ZGw6jnP/rGbeV3jzZm8z4e4/LM9/7HgQncRtqZAsZowoNRh0JJrn6	["homestay"]	t	2026-01-15 14:00:53.467066	2026-01-15 14:00:53.467066	\N
b50d541a-07ba-4850-9bad-918f237557e4	9828093904	Load Test 9828093904	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$Lbbo3dHTjpbFcIMGgBO7c.LQnntcWtQRQi57.5SYehy6CT7KkPmue	["homestay"]	t	2026-01-15 14:00:53.884411	2026-01-15 14:00:53.884411	\N
cd61ce90-cb6c-4b6a-91b6-8a150b368f3d	9802339396	Load Test 9802339396	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$ztArpTbjaaRlYCK8zrcEru.37F5n9Cd3HoVNuPZ1MeLNkkDKVecaG	["homestay"]	t	2026-01-15 14:00:54.749291	2026-01-15 14:00:54.749291	\N
960466d6-6220-4429-bfa4-8c2659dcaae8	9252159510	Load Test 9252159510	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$Ue6ENoFFw4GserdALYPPqubIBi7yCtJcU4GKx1MGaJvnZiuZrg3Yq	["homestay"]	t	2026-01-15 14:00:54.781252	2026-01-15 14:00:54.781252	\N
690520d7-e491-43bd-a6f1-7fcf2369fa20	9985920238	Load Test 9985920238	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$dTUNSgYUJI1bXCK9Vumgiu8J8gLJNhV.B/qpA9lXtlloBFiYDk02u	["homestay"]	t	2026-01-15 14:00:54.717522	2026-01-15 14:00:54.717522	\N
2c95df7d-a843-44b0-b5ee-e9a3458650ce	9559345036	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$ijZoSUGXP3FrrFrAQNH.3e9z3OeWYOehFY5NVI7oaZ.WKJBLBumMe	["homestay"]	t	2026-01-16 05:31:49.970733	2026-01-16 05:31:49.970733	\N
14ec132d-0a83-437d-84cc-c2ba4b1e79fc	9335290214	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$e0rRmxiUEgks1wiqsNLZ7eEUwxoMsjtRHvJTvhImwBCmF2GEFFlOm	["homestay"]	t	2026-01-16 05:31:50.384371	2026-01-16 05:31:50.384371	\N
b6fa6422-dc6e-4d1b-ad0b-d8d6155ac133	9847079548	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$.M4VgTxWi8dQHLTNF1tuwerc7PR9cjcbU0yLUcQ1wMwbeU/qwD1yO	["homestay"]	t	2026-01-16 05:31:50.724775	2026-01-16 05:31:50.724775	\N
46a9bd6e-0895-46f1-9837-238ba478bc99	9606808974	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$M50DdwFLwlnmfdT29Azmf.McwAamZHc/ZbeRqoH9kiZdxsESnFKAG	["homestay"]	t	2026-01-16 05:31:51.020359	2026-01-16 05:31:51.020359	\N
1961069b-5b79-4334-ae5e-758545382c27	9206716444	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$ky9Bc.2ZJqYlkrM7wvQ8LetK5D8j7iF98I.Tgr3krA4tBtGQMXQiC	["homestay"]	t	2026-01-16 05:31:51.308964	2026-01-16 05:31:51.308964	\N
51c83d0e-9f80-4d79-8eb3-6301950b29d3	9301330440	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$uhWlLef./8682gDwsE059elj7zI/etZLGPROBRESKA.DPgYavv4La	["homestay"]	t	2026-01-16 05:31:51.590244	2026-01-16 05:31:51.590244	\N
d2c08f95-a3dd-42c0-9f49-b6363ea101aa	9695618367	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$kGsSoEaHRQ13JgxLywN3q.tGtI.cowYMUqwyMsQPACDhSvE0fu96C	["homestay"]	t	2026-01-16 05:31:51.88517	2026-01-16 05:31:51.88517	\N
87b4b2dd-d35f-461d-853f-957c31ee3364	9275216873	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$SBf/ilICQ5WjGA9uNJj9G..F5YtHWR6PqAPbCOVvr9SEPWkEtCHqC	["homestay"]	t	2026-01-16 05:31:52.197386	2026-01-16 05:31:52.197386	\N
a90d9e56-3d2d-45e0-8ca5-a8da134ffc5c	9499435951	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$CtCAJ2U5atFRvXYmSlRfde4y1DPHXhH07S/aASSPnd3StHT4f50k6	["homestay"]	t	2026-01-16 05:31:52.467384	2026-01-16 05:31:52.467384	\N
6af3e921-4c29-4eea-81c6-3ce45f97c261	9854390338	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$3phGnE2TM4Jz1BEawWWj/OVcIFH3H0U6xYCvkZ9NzjzcZ8vIFHihe	["homestay"]	t	2026-01-16 05:31:52.770402	2026-01-16 05:31:52.770402	\N
9462b151-1337-4344-bc94-5bc90b59ab03	9666748514	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$yUfT4iqeUJU65H5ld19KPuKlsSlYNbMntLwKdRhKqr4703CrgoBIa	["homestay"]	t	2026-01-16 05:31:53.065251	2026-01-16 05:31:53.065251	\N
f80dd5ab-6ca5-40f6-bf02-1e980b335e07	9715419216	Smoke Test Owner	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	\N	$2b$10$9q2z30BvBYSpeSAyiyJ.p.hGOBgI6PYvkkRqC6BrcykzmAhqd/HKe	["homestay"]	t	2026-01-16 05:31:53.352687	2026-01-16 05:31:53.352687	\N
\.


--
-- Name: application_actions application_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: certificates certificates_application_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_application_id_unique UNIQUE (application_id);


--
-- Name: certificates certificates_certificate_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_certificate_number_unique UNIQUE (certificate_number);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: clarifications clarifications_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_pkey PRIMARY KEY (id);


--
-- Name: ddo_codes ddo_codes_district_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ddo_codes
    ADD CONSTRAINT ddo_codes_district_unique UNIQUE (district);


--
-- Name: ddo_codes ddo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ddo_codes
    ADD CONSTRAINT ddo_codes_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: grievance_audit_log grievance_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_audit_log
    ADD CONSTRAINT grievance_audit_log_pkey PRIMARY KEY (id);


--
-- Name: grievance_comments grievance_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_comments
    ADD CONSTRAINT grievance_comments_pkey PRIMARY KEY (id);


--
-- Name: grievances grievances_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_pkey PRIMARY KEY (id);


--
-- Name: grievances grievances_ticket_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_ticket_number_unique UNIQUE (ticket_number);


--
-- Name: himkosh_transactions himkosh_transactions_app_ref_no_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_app_ref_no_unique UNIQUE (app_ref_no);


--
-- Name: himkosh_transactions himkosh_transactions_ech_txn_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_ech_txn_id_unique UNIQUE (ech_txn_id);


--
-- Name: himkosh_transactions himkosh_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_pkey PRIMARY KEY (id);


--
-- Name: homestay_applications homestay_applications_application_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_application_number_unique UNIQUE (application_number);


--
-- Name: homestay_applications homestay_applications_certificate_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_certificate_number_unique UNIQUE (certificate_number);


--
-- Name: homestay_applications homestay_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_pkey PRIMARY KEY (id);


--
-- Name: inspection_orders inspection_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_pkey PRIMARY KEY (id);


--
-- Name: inspection_reports inspection_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_pkey PRIMARY KEY (id);


--
-- Name: lgd_blocks lgd_blocks_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_blocks lgd_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_pkey PRIMARY KEY (id);


--
-- Name: lgd_districts lgd_districts_district_name_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_district_name_unique UNIQUE (district_name);


--
-- Name: lgd_districts lgd_districts_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_districts lgd_districts_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_pkey PRIMARY KEY (id);


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_pkey PRIMARY KEY (id);


--
-- Name: lgd_tehsils lgd_tehsils_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_tehsils lgd_tehsils_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_pkey PRIMARY KEY (id);


--
-- Name: lgd_urban_bodies lgd_urban_bodies_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_urban_bodies lgd_urban_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_pkey PRIMARY KEY (id);


--
-- Name: login_otp_challenges login_otp_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.login_otp_challenges
    ADD CONSTRAINT login_otp_challenges_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: objections objections_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_pkey PRIMARY KEY (id);


--
-- Name: password_reset_challenges password_reset_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.password_reset_challenges
    ADD CONSTRAINT password_reset_challenges_pkey PRIMARY KEY (id);


--
-- Name: payments payments_gateway_transaction_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_gateway_transaction_id_unique UNIQUE (gateway_transaction_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: payments payments_receipt_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_receipt_number_unique UNIQUE (receipt_number);


--
-- Name: production_stats production_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.production_stats
    ADD CONSTRAINT production_stats_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: storage_objects storage_objects_object_key_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_object_key_unique UNIQUE (object_key);


--
-- Name: storage_objects storage_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_ticket_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_ticket_number_unique UNIQUE (ticket_number);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_setting_key_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_setting_key_unique UNIQUE (setting_key);


--
-- Name: ticket_actions ticket_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_pkey PRIMARY KEY (id);


--
-- Name: ticket_messages ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_unique UNIQUE (user_id);


--
-- Name: users users_aadhaar_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_aadhaar_number_unique UNIQUE (aadhaar_number);


--
-- Name: users users_mobile_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_mobile_unique UNIQUE (mobile);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_sso_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_sso_id_unique UNIQUE (sso_id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: app_dashboard_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX app_dashboard_idx ON public.homestay_applications USING btree (district, status);


--
-- Name: app_district_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX app_district_idx ON public.homestay_applications USING btree (district);


--
-- Name: app_kind_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX app_kind_idx ON public.homestay_applications USING btree (application_kind);


--
-- Name: app_status_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX app_status_idx ON public.homestay_applications USING btree (status);


--
-- Name: app_user_id_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX app_user_id_idx ON public.homestay_applications USING btree (user_id);


--
-- Name: users_district_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX users_district_idx ON public.users USING btree (district);


--
-- Name: users_mobile_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX users_mobile_idx ON public.users USING btree (mobile);


--
-- Name: users_role_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX users_role_idx ON public.users USING btree (role);


--
-- Name: application_actions application_actions_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: application_actions application_actions_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_officer_id_users_id_fk FOREIGN KEY (officer_id) REFERENCES public.users(id);


--
-- Name: audit_logs audit_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: certificates certificates_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_issued_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_issued_by_users_id_fk FOREIGN KEY (issued_by) REFERENCES public.users(id);


--
-- Name: certificates certificates_renewal_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_renewal_application_id_homestay_applications_id_fk FOREIGN KEY (renewal_application_id) REFERENCES public.homestay_applications(id);


--
-- Name: certificates certificates_revoked_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_revoked_by_users_id_fk FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: clarifications clarifications_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: clarifications clarifications_objection_id_objections_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_objection_id_objections_id_fk FOREIGN KEY (objection_id) REFERENCES public.objections(id) ON DELETE CASCADE;


--
-- Name: clarifications clarifications_reviewed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_reviewed_by_users_id_fk FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: clarifications clarifications_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: documents documents_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: documents documents_verified_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_verified_by_users_id_fk FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: grievance_audit_log grievance_audit_log_grievance_id_grievances_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_audit_log
    ADD CONSTRAINT grievance_audit_log_grievance_id_grievances_id_fk FOREIGN KEY (grievance_id) REFERENCES public.grievances(id) ON DELETE CASCADE;


--
-- Name: grievance_audit_log grievance_audit_log_performed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_audit_log
    ADD CONSTRAINT grievance_audit_log_performed_by_users_id_fk FOREIGN KEY (performed_by) REFERENCES public.users(id);


--
-- Name: grievance_comments grievance_comments_grievance_id_grievances_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_comments
    ADD CONSTRAINT grievance_comments_grievance_id_grievances_id_fk FOREIGN KEY (grievance_id) REFERENCES public.grievances(id) ON DELETE CASCADE;


--
-- Name: grievance_comments grievance_comments_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_comments
    ADD CONSTRAINT grievance_comments_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: grievances grievances_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: grievances grievances_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: grievances grievances_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: himkosh_transactions himkosh_transactions_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: homestay_applications homestay_applications_da_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_da_id_users_id_fk FOREIGN KEY (da_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_district_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_district_officer_id_users_id_fk FOREIGN KEY (district_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_dtdo_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_dtdo_id_users_id_fk FOREIGN KEY (dtdo_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_site_inspection_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_site_inspection_officer_id_users_id_fk FOREIGN KEY (site_inspection_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_state_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_state_officer_id_users_id_fk FOREIGN KEY (state_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: inspection_orders inspection_orders_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: inspection_orders inspection_orders_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: inspection_orders inspection_orders_scheduled_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_scheduled_by_users_id_fk FOREIGN KEY (scheduled_by) REFERENCES public.users(id);


--
-- Name: inspection_reports inspection_reports_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: inspection_reports inspection_reports_inspection_order_id_inspection_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_inspection_order_id_inspection_orders_id_fk FOREIGN KEY (inspection_order_id) REFERENCES public.inspection_orders(id) ON DELETE CASCADE;


--
-- Name: inspection_reports inspection_reports_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: lgd_blocks lgd_blocks_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_blocks lgd_blocks_tehsil_id_lgd_tehsils_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_tehsil_id_lgd_tehsils_id_fk FOREIGN KEY (tehsil_id) REFERENCES public.lgd_tehsils(id) ON DELETE SET NULL;


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_block_id_lgd_blocks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_block_id_lgd_blocks_id_fk FOREIGN KEY (block_id) REFERENCES public.lgd_blocks(id) ON DELETE CASCADE;


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_tehsils lgd_tehsils_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_urban_bodies lgd_urban_bodies_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: login_otp_challenges login_otp_challenges_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.login_otp_challenges
    ADD CONSTRAINT login_otp_challenges_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: notifications notifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: objections objections_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: objections objections_inspection_report_id_inspection_reports_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_inspection_report_id_inspection_reports_id_fk FOREIGN KEY (inspection_report_id) REFERENCES public.inspection_reports(id);


--
-- Name: objections objections_raised_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_raised_by_users_id_fk FOREIGN KEY (raised_by) REFERENCES public.users(id);


--
-- Name: objections objections_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: password_reset_challenges password_reset_challenges_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.password_reset_challenges
    ADD CONSTRAINT password_reset_challenges_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payments payments_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: reviews reviews_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: reviews reviews_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: storage_objects storage_objects_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE SET NULL;


--
-- Name: storage_objects storage_objects_document_id_documents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_document_id_documents_id_fk FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: storage_objects storage_objects_uploaded_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_uploaded_by_users_id_fk FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_applicant_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_applicant_id_users_id_fk FOREIGN KEY (applicant_id) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: support_tickets support_tickets_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_escalated_from_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_escalated_from_users_id_fk FOREIGN KEY (escalated_from) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: system_settings system_settings_updated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_actor_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_actor_id_users_id_fk FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_new_assignee_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_new_assignee_users_id_fk FOREIGN KEY (new_assignee) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_previous_assignee_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_previous_assignee_users_id_fk FOREIGN KEY (previous_assignee) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_ticket_id_support_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_ticket_id_support_tickets_id_fk FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_messages ticket_messages_sender_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_sender_id_users_id_fk FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: ticket_messages ticket_messages_ticket_id_support_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_ticket_id_support_tickets_id_fk FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: user_profiles user_profiles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 4MqH7W8QZToWYtb4FItdOtZzQzDrLh7dALnjjrcsRDqTgCA4zfTb20TOy1m7mxx

