--
-- PostgreSQL database dump
--

\restrict t7rubc8qr5ukubGihF8VsduV0yEfVrA4MwIgWHVbsLd2jX5alApvXlJylsbphN4

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: application_actions; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.application_actions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    officer_id character varying NOT NULL,
    action character varying(50) NOT NULL,
    previous_status character varying(50),
    new_status character varying(50),
    feedback text,
    issues_found jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.application_actions OWNER TO hptourism_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    action character varying(100) NOT NULL,
    details jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO hptourism_user;

--
-- Name: certificates; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.certificates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    certificate_number character varying(50) NOT NULL,
    certificate_type character varying(50) DEFAULT 'homestay_registration'::character varying,
    issued_date timestamp without time zone NOT NULL,
    valid_from timestamp without time zone NOT NULL,
    valid_upto timestamp without time zone NOT NULL,
    property_name character varying(255) NOT NULL,
    category character varying(20) NOT NULL,
    address text NOT NULL,
    district character varying(100) NOT NULL,
    owner_name character varying(255) NOT NULL,
    owner_mobile character varying(15) NOT NULL,
    certificate_pdf_url text,
    qr_code_data text,
    digital_signature text,
    issued_by character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    revocation_reason text,
    revoked_by character varying,
    revoked_date timestamp without time zone,
    renewal_reminder_sent boolean DEFAULT false,
    renewal_application_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.certificates OWNER TO hptourism_user;

--
-- Name: clarifications; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.clarifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    objection_id character varying NOT NULL,
    application_id character varying NOT NULL,
    submitted_by character varying NOT NULL,
    submitted_date timestamp without time zone NOT NULL,
    clarification_text text NOT NULL,
    supporting_documents jsonb,
    reviewed_by character varying,
    reviewed_date timestamp without time zone,
    review_status character varying(50),
    review_notes text,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.clarifications OWNER TO hptourism_user;

--
-- Name: ddo_codes; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.ddo_codes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    district character varying(100) NOT NULL,
    ddo_code character varying(20) NOT NULL,
    ddo_description text NOT NULL,
    treasury_code character varying(10) NOT NULL,
    head1 character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ddo_codes OWNER TO hptourism_user;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.documents (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    document_type character varying(100) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path text NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(100) NOT NULL,
    upload_date timestamp without time zone DEFAULT now(),
    ai_verification_status character varying(50),
    ai_confidence_score numeric(5,2),
    ai_notes text,
    is_verified boolean DEFAULT false,
    verification_status character varying(50) DEFAULT 'pending'::character varying,
    verified_by character varying,
    verification_date timestamp without time zone,
    verification_notes text
);


ALTER TABLE public.documents OWNER TO hptourism_user;

--
-- Name: grievance_audit_log; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.grievance_audit_log (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    grievance_id character varying NOT NULL,
    action character varying(50) NOT NULL,
    old_value text,
    new_value text,
    performed_by character varying NOT NULL,
    performed_at timestamp without time zone DEFAULT now(),
    ip_address character varying(50),
    user_agent text
);


ALTER TABLE public.grievance_audit_log OWNER TO hptourism_user;

--
-- Name: grievance_comments; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.grievance_comments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    grievance_id character varying NOT NULL,
    user_id character varying NOT NULL,
    comment text NOT NULL,
    is_internal boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.grievance_comments OWNER TO hptourism_user;

--
-- Name: grievances; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.grievances (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_number character varying(50) NOT NULL,
    ticket_type character varying(20) DEFAULT 'owner_grievance'::character varying,
    user_id character varying,
    application_id character varying,
    category character varying(50) NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying,
    status character varying(20) DEFAULT 'open'::character varying,
    subject character varying(255) NOT NULL,
    description text NOT NULL,
    assigned_to character varying,
    resolution_notes text,
    attachments jsonb,
    last_comment_at timestamp without time zone,
    last_read_by_owner timestamp without time zone,
    last_read_by_officer timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone
);


ALTER TABLE public.grievances OWNER TO hptourism_user;

--
-- Name: himkosh_transactions; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.himkosh_transactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    dept_ref_no character varying(45) NOT NULL,
    app_ref_no character varying(20) NOT NULL,
    total_amount integer NOT NULL,
    tender_by character varying(70) NOT NULL,
    merchant_code character varying(15),
    dept_id character varying(10),
    service_code character varying(5),
    ddo character varying(12),
    head1 character varying(14),
    amount1 integer,
    head2 character varying(14),
    amount2 integer,
    head3 character varying(14),
    amount3 integer,
    head4 character varying(14),
    amount4 integer,
    head10 character varying(50),
    amount10 integer,
    period_from character varying(10),
    period_to character varying(10),
    encrypted_request text,
    request_checksum character varying(32),
    ech_txn_id character varying(10),
    bank_cin character varying(20),
    bank_name character varying(10),
    payment_date character varying(14),
    status character varying(70),
    status_cd character varying(1),
    response_checksum character varying(32),
    is_double_verified boolean DEFAULT false,
    double_verification_date timestamp without time zone,
    double_verification_data jsonb,
    challan_print_url text,
    portal_base_url text,
    transaction_status character varying(50) DEFAULT 'initiated'::character varying,
    initiated_at timestamp without time zone DEFAULT now(),
    responded_at timestamp without time zone,
    verified_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    is_archived boolean DEFAULT false
);


ALTER TABLE public.himkosh_transactions OWNER TO hptourism_user;

--
-- Name: homestay_applications; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.homestay_applications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    application_number character varying(50) NOT NULL,
    application_kind character varying(30) DEFAULT 'new_registration'::character varying NOT NULL,
    parent_application_id character varying,
    parent_application_number character varying(50),
    parent_certificate_number character varying(50),
    inherited_certificate_valid_upto timestamp without time zone,
    service_context jsonb,
    service_notes text,
    service_requested_at timestamp without time zone,
    application_type character varying(50) DEFAULT 'homestay'::character varying,
    water_sports_data jsonb,
    adventure_sports_data jsonb,
    property_name character varying(255) NOT NULL,
    category character varying(20) NOT NULL,
    location_type character varying(10) NOT NULL,
    total_rooms integer NOT NULL,
    district character varying(100) NOT NULL,
    district_other character varying(100),
    tehsil character varying(100) NOT NULL,
    tehsil_other character varying(100),
    block character varying(100),
    block_other character varying(100),
    gram_panchayat character varying(100),
    gram_panchayat_other character varying(100),
    urban_body character varying(200),
    urban_body_other character varying(200),
    ward character varying(50),
    address text NOT NULL,
    pincode character varying(10) NOT NULL,
    telephone character varying(20),
    fax character varying(20),
    latitude numeric(10,8),
    longitude numeric(11,8),
    owner_name character varying(255) NOT NULL,
    owner_gender character varying(10) NOT NULL,
    owner_mobile character varying(15) NOT NULL,
    owner_email character varying(255),
    guardian_name character varying(255),
    owner_aadhaar character varying(12) NOT NULL,
    guardian_relation character varying(20) DEFAULT 'father'::character varying,
    property_ownership character varying(10) DEFAULT 'owned'::character varying NOT NULL,
    proposed_room_rate numeric(10,2),
    project_type character varying(20) NOT NULL,
    property_area numeric(10,2) NOT NULL,
    property_area_unit character varying(10) DEFAULT 'sqm'::character varying,
    single_bed_rooms integer DEFAULT 0,
    single_bed_beds integer DEFAULT 1,
    single_bed_room_size numeric(10,2),
    single_bed_room_rate numeric(10,2),
    double_bed_rooms integer DEFAULT 0,
    double_bed_beds integer DEFAULT 2,
    double_bed_room_size numeric(10,2),
    double_bed_room_rate numeric(10,2),
    family_suites integer DEFAULT 0,
    family_suite_beds integer DEFAULT 4,
    family_suite_size numeric(10,2),
    family_suite_rate numeric(10,2),
    attached_washrooms integer NOT NULL,
    gstin character varying(15),
    selected_category character varying(20),
    average_room_rate numeric(10,2),
    highest_room_rate numeric(10,2),
    lowest_room_rate numeric(10,2),
    certificate_validity_years integer DEFAULT 1,
    is_pangi_sub_division boolean DEFAULT false,
    distance_airport numeric(10,2),
    distance_railway numeric(10,2),
    distance_city_center numeric(10,2),
    distance_shopping numeric(10,2),
    distance_bus_stand numeric(10,2),
    key_location_highlight1 text,
    key_location_highlight2 text,
    lobby_area numeric(10,2),
    dining_area numeric(10,2),
    parking_area text,
    eco_friendly_facilities text,
    differently_abled_facilities text,
    fire_equipment_details text,
    nearest_hospital character varying(255),
    amenities jsonb,
    nearby_attractions jsonb,
    mandatory_checklist jsonb,
    desirable_checklist jsonb,
    rooms jsonb,
    base_fee numeric(10,2),
    total_before_discounts numeric(10,2),
    validity_discount numeric(10,2) DEFAULT '0'::numeric,
    female_owner_discount numeric(10,2) DEFAULT '0'::numeric,
    pangi_discount numeric(10,2) DEFAULT '0'::numeric,
    total_discount numeric(10,2) DEFAULT '0'::numeric,
    total_fee numeric(10,2),
    per_room_fee numeric(10,2),
    gst_amount numeric(10,2),
    status character varying(50) DEFAULT 'draft'::character varying,
    current_stage character varying(50),
    current_page integer DEFAULT 1,
    district_officer_id character varying,
    district_review_date timestamp without time zone,
    district_notes text,
    da_id character varying,
    da_review_date timestamp without time zone,
    da_forwarded_date timestamp without time zone,
    da_remarks text,
    state_officer_id character varying,
    state_review_date timestamp without time zone,
    state_notes text,
    dtdo_id character varying,
    dtdo_review_date timestamp without time zone,
    correction_submission_count integer DEFAULT 0 NOT NULL,
    revert_count integer DEFAULT 0 NOT NULL,
    dtdo_remarks text,
    rejection_reason text,
    clarification_requested text,
    site_inspection_scheduled_date timestamp without time zone,
    site_inspection_completed_date timestamp without time zone,
    site_inspection_officer_id character varying,
    site_inspection_notes text,
    site_inspection_outcome character varying(50),
    site_inspection_findings jsonb,
    ownership_proof_url text,
    aadhaar_card_url text,
    pan_card_url text,
    gst_certificate_url text,
    fire_safety_noc_url text,
    pollution_clearance_url text,
    building_plan_url text,
    property_photos_urls jsonb,
    documents jsonb,
    certificate_number character varying(50),
    certificate_issued_date timestamp without time zone,
    certificate_expiry_date timestamp without time zone,
    payment_status character varying(20) DEFAULT 'pending'::character varying,
    payment_id character varying(100),
    payment_amount numeric(10,2),
    payment_date timestamp without time zone,
    refund_date timestamp without time zone,
    refund_reason text,
    submitted_at timestamp without time zone,
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    form_completion_time_seconds integer
);


ALTER TABLE public.homestay_applications OWNER TO hptourism_user;

--
-- Name: inspection_orders; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.inspection_orders (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    scheduled_by character varying NOT NULL,
    scheduled_date timestamp without time zone NOT NULL,
    assigned_to character varying NOT NULL,
    assigned_date timestamp without time zone NOT NULL,
    inspection_date timestamp without time zone NOT NULL,
    inspection_address text NOT NULL,
    special_instructions text,
    status character varying(50) DEFAULT 'scheduled'::character varying,
    dtdo_notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.inspection_orders OWNER TO hptourism_user;

--
-- Name: inspection_reports; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.inspection_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    inspection_order_id character varying NOT NULL,
    application_id character varying NOT NULL,
    submitted_by character varying NOT NULL,
    submitted_date timestamp without time zone NOT NULL,
    actual_inspection_date timestamp without time zone NOT NULL,
    room_count_verified boolean NOT NULL,
    actual_room_count integer,
    category_meets_standards boolean NOT NULL,
    recommended_category character varying(20),
    mandatory_checklist jsonb,
    mandatory_remarks text,
    desirable_checklist jsonb,
    desirable_remarks text,
    amenities_verified jsonb,
    amenities_issues text,
    fire_safety_compliant boolean,
    fire_safety_issues text,
    structural_safety boolean,
    structural_issues text,
    overall_satisfactory boolean NOT NULL,
    recommendation character varying(50) NOT NULL,
    detailed_findings text NOT NULL,
    inspection_photos jsonb,
    report_document_url text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.inspection_reports OWNER TO hptourism_user;

--
-- Name: lgd_blocks; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_blocks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    block_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    tehsil_id character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_blocks OWNER TO hptourism_user;

--
-- Name: lgd_districts; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_districts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    district_name character varying(100) NOT NULL,
    division_name character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_districts OWNER TO hptourism_user;

--
-- Name: lgd_gram_panchayats; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_gram_panchayats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    gram_panchayat_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    block_id character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_gram_panchayats OWNER TO hptourism_user;

--
-- Name: lgd_tehsils; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_tehsils (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    tehsil_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    tehsil_type character varying(50) DEFAULT 'tehsil'::character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_tehsils OWNER TO hptourism_user;

--
-- Name: lgd_urban_bodies; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_urban_bodies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    urban_body_name character varying(200) NOT NULL,
    district_id character varying NOT NULL,
    body_type character varying(50) NOT NULL,
    number_of_wards integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_urban_bodies OWNER TO hptourism_user;

--
-- Name: login_otp_challenges; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.login_otp_challenges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    otp_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.login_otp_challenges OWNER TO hptourism_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.notifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    application_id character varying,
    type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    channels jsonb,
    is_read boolean DEFAULT false,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO hptourism_user;

--
-- Name: objections; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.objections (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    inspection_report_id character varying,
    raised_by character varying NOT NULL,
    raised_date timestamp without time zone NOT NULL,
    objection_type character varying(50) NOT NULL,
    objection_title character varying(255) NOT NULL,
    objection_description text NOT NULL,
    severity character varying(20) NOT NULL,
    response_deadline timestamp without time zone,
    status character varying(50) DEFAULT 'pending'::character varying,
    resolution_notes text,
    resolved_by character varying,
    resolved_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.objections OWNER TO hptourism_user;

--
-- Name: password_reset_challenges; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.password_reset_challenges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    channel character varying(32) NOT NULL,
    recipient character varying(255),
    otp_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.password_reset_challenges OWNER TO hptourism_user;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.payments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    payment_type character varying(50) NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_gateway character varying(50),
    gateway_transaction_id character varying(255),
    payment_method character varying(50),
    payment_status character varying(50) DEFAULT 'pending'::character varying,
    payment_link text,
    qr_code_url text,
    payment_link_expiry_date timestamp without time zone,
    initiated_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    receipt_number character varying(100),
    receipt_url text
);


ALTER TABLE public.payments OWNER TO hptourism_user;

--
-- Name: production_stats; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.production_stats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    total_applications integer NOT NULL,
    approved_applications integer NOT NULL,
    rejected_applications integer NOT NULL,
    pending_applications integer NOT NULL,
    scraped_at timestamp without time zone DEFAULT now(),
    source_url text
);


ALTER TABLE public.production_stats OWNER TO hptourism_user;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.reviews (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    user_id character varying NOT NULL,
    rating integer NOT NULL,
    review_text text,
    is_verified_stay boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.reviews OWNER TO hptourism_user;

--
-- Name: session; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO hptourism_user;

--
-- Name: storage_objects; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.storage_objects (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    object_key text NOT NULL,
    storage_provider character varying(20) DEFAULT 'local'::character varying NOT NULL,
    file_type character varying(100) NOT NULL,
    category character varying(100) DEFAULT 'general'::character varying,
    mime_type character varying(100) DEFAULT 'application/octet-stream'::character varying,
    size_bytes integer DEFAULT 0 NOT NULL,
    checksum_sha256 character varying(128),
    uploaded_by character varying,
    application_id character varying,
    document_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    last_accessed_at timestamp without time zone
);


ALTER TABLE public.storage_objects OWNER TO hptourism_user;

--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.support_tickets (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_number character varying(50) NOT NULL,
    applicant_id character varying NOT NULL,
    application_id character varying,
    service_type character varying(50) DEFAULT 'homestay'::character varying,
    category character varying(50) NOT NULL,
    subject character varying(255) NOT NULL,
    description text NOT NULL,
    status character varying(30) DEFAULT 'open'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    assigned_to character varying,
    assigned_at timestamp without time zone,
    escalated_from character varying,
    escalated_at timestamp without time zone,
    escalation_level integer DEFAULT 0,
    sla_deadline timestamp without time zone,
    sla_breach boolean DEFAULT false,
    resolved_at timestamp without time zone,
    resolved_by character varying,
    resolution_notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.support_tickets OWNER TO hptourism_user;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.system_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value jsonb NOT NULL,
    description text,
    category character varying(50) DEFAULT 'general'::character varying,
    updated_by character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.system_settings OWNER TO hptourism_user;

--
-- Name: ticket_actions; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.ticket_actions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_id character varying NOT NULL,
    actor_id character varying,
    actor_role character varying(30),
    action character varying(50) NOT NULL,
    previous_status character varying(30),
    new_status character varying(30),
    previous_priority character varying(20),
    new_priority character varying(20),
    previous_assignee character varying,
    new_assignee character varying,
    notes text,
    metadata jsonb,
    ip_address character varying(45),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ticket_actions OWNER TO hptourism_user;

--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.ticket_messages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_id character varying NOT NULL,
    sender_id character varying NOT NULL,
    sender_role character varying(30) NOT NULL,
    message text NOT NULL,
    attachments jsonb,
    is_internal boolean DEFAULT false,
    is_read boolean DEFAULT false,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ticket_messages OWNER TO hptourism_user;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.user_profiles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    full_name character varying(255) NOT NULL,
    gender character varying(10) NOT NULL,
    aadhaar_number character varying(12),
    mobile character varying(15) NOT NULL,
    email character varying(255),
    district character varying(100),
    tehsil character varying(100),
    block character varying(100),
    gram_panchayat character varying(100),
    urban_body character varying(200),
    ward character varying(50),
    address text,
    pincode character varying(10),
    telephone character varying(20),
    fax character varying(20),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_profiles OWNER TO hptourism_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    mobile character varying(15) NOT NULL,
    full_name text NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    username character varying(50),
    email character varying(255),
    alternate_phone character varying(15),
    designation character varying(100),
    department character varying(100),
    employee_id character varying(50),
    office_address text,
    office_phone character varying(15),
    role character varying(50) DEFAULT 'property_owner'::character varying NOT NULL,
    aadhaar_number character varying(12),
    sso_id character varying(50),
    district character varying(100),
    password text,
    enabled_services jsonb DEFAULT '["homestay"]'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    signature_url text
);


ALTER TABLE public.users OWNER TO hptourism_user;

--
-- Data for Name: application_actions; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.application_actions (id, application_id, officer_id, action, previous_status, new_status, feedback, issues_found, created_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.audit_logs (id, user_id, action, details, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.certificates (id, application_id, certificate_number, certificate_type, issued_date, valid_from, valid_upto, property_name, category, address, district, owner_name, owner_mobile, certificate_pdf_url, qr_code_data, digital_signature, issued_by, status, revocation_reason, revoked_by, revoked_date, renewal_reminder_sent, renewal_application_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: clarifications; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.clarifications (id, objection_id, application_id, submitted_by, submitted_date, clarification_text, supporting_documents, reviewed_by, reviewed_date, review_status, review_notes, updated_at) FROM stdin;
\.


--
-- Data for Name: ddo_codes; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.ddo_codes (id, district, ddo_code, ddo_description, treasury_code, head1, is_active, created_at, updated_at) FROM stdin;
3e17fad9-a314-45c4-9011-62715b800447	Chamba	CHM00-532	D.T.D.O. CHAMBA	CHM00	\N	t	2026-01-08 00:45:19.964858	2026-01-08 00:45:19.964858
105c6a4c-2835-4bec-93ae-42f397d4ff65	Bharmour	CHM01-001	S.D.O.(CIVIL) BHARMOUR	CHM01	\N	t	2026-01-08 00:45:19.969389	2026-01-08 00:45:19.969389
20d73826-0cbe-4c2a-8ab7-65ad871f53eb	Shimla (Central)	CTO00-068	A.C. (TOURISM) SHIMLA	CTO00	\N	t	2026-01-08 00:45:19.973877	2026-01-08 00:45:19.973877
e649d099-d4ad-43b0-adc8-6c56a5948ba5	Hamirpur	HMR00-053	DISTRICT TOURISM DEVELOPMENT OFFICE HAMIRPUR (UNA)	HMR00	\N	t	2026-01-08 00:45:19.978198	2026-01-08 00:45:19.978198
341b6fdb-90b6-4aef-8be1-e7aef76e1007	Una	HMR00-053	DISTRICT TOURISM DEVELOPMENT OFFICE HAMIRPUR (UNA)	HMR00	\N	t	2026-01-08 00:45:19.981531	2026-01-08 00:45:19.981531
b6b13efb-7a04-4491-96ee-27780a158570	Kullu (Dhalpur)	KLU00-532	DEPUTY DIRECTOR TOURISM AND CIVIL AVIATION KULLU DHALPUR	KLU00	\N	t	2026-01-08 00:45:19.984693	2026-01-08 00:45:19.984693
b68125ad-74dd-4823-98aa-f356fd207c0a	Kangra	KNG00-532	DIV.TOURISM DEV.OFFICER(DTDO) DHARAMSALA	KNG00	\N	t	2026-01-08 00:45:19.988087	2026-01-08 00:45:19.988087
c22224d4-fd67-47a1-a052-b1f24714045d	Kinnaur	KNR00-031	DISTRICT TOURISM DEVELOPMENT OFFICER KINNAUR AT RECKONG PEO	KNR00	\N	t	2026-01-08 00:45:19.991257	2026-01-08 00:45:19.991257
653ac4fe-f953-403a-a24f-e3ebb706db53	Lahaul-Spiti (Kaza)	KZA00-011	PO ITDP KAZA	KZA00	\N	t	2026-01-08 00:45:19.994623	2026-01-08 00:45:19.994623
755d95b8-015b-4cff-8776-4a4a8d0dd739	Lahaul	LHL00-017	DISTRICT TOURISM DEVELOPMENT OFFICER	LHL00	\N	t	2026-01-08 00:45:19.997599	2026-01-08 00:45:19.997599
1cb81eb0-4d5d-49b4-a229-19e30b4e4503	Mandi	MDI00-532	DIV. TOURISM DEV. OFFICER MANDI	MDI00	\N	t	2026-01-08 00:45:20.009625	2026-01-08 00:45:20.009625
e02ef70f-a43f-4bcb-8e6f-bf3abe6e7dc0	Pangi	PNG00-003	PROJECT OFFICER ITDP PANGI	PNG00	\N	t	2026-01-08 00:45:20.012551	2026-01-08 00:45:20.012551
d029a110-a870-4763-b290-b924e32663a2	Shimla	SML00-532	DIVISIONAL TOURISM OFFICER SHIMLA	SML00	\N	t	2026-01-08 00:45:20.015202	2026-01-08 00:45:20.015202
419c683c-b1a8-4be2-baa5-f0c20066b313	Sirmour	SMR00-055	DISTRICT TOURISM DEVELOPMENT OFFICE NAHAN	SMR00	\N	t	2026-01-08 00:45:20.017584	2026-01-08 00:45:20.017584
4224a80f-800c-4ab0-a98f-61d0988b3120	Solan	SOL00-046	DTDO SOLAN	SOL00	\N	t	2026-01-08 00:45:20.019928	2026-01-08 00:45:20.019928
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.documents (id, application_id, document_type, file_name, file_path, file_size, mime_type, upload_date, ai_verification_status, ai_confidence_score, ai_notes, is_verified, verification_status, verified_by, verification_date, verification_notes) FROM stdin;
\.


--
-- Data for Name: grievance_audit_log; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.grievance_audit_log (id, grievance_id, action, old_value, new_value, performed_by, performed_at, ip_address, user_agent) FROM stdin;
\.


--
-- Data for Name: grievance_comments; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.grievance_comments (id, grievance_id, user_id, comment, is_internal, created_at) FROM stdin;
\.


--
-- Data for Name: grievances; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.grievances (id, ticket_number, ticket_type, user_id, application_id, category, priority, status, subject, description, assigned_to, resolution_notes, attachments, last_comment_at, last_read_by_owner, last_read_by_officer, created_at, updated_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: himkosh_transactions; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.himkosh_transactions (id, application_id, dept_ref_no, app_ref_no, total_amount, tender_by, merchant_code, dept_id, service_code, ddo, head1, amount1, head2, amount2, head3, amount3, head4, amount4, head10, amount10, period_from, period_to, encrypted_request, request_checksum, ech_txn_id, bank_cin, bank_name, payment_date, status, status_cd, response_checksum, is_double_verified, double_verification_date, double_verification_data, challan_print_url, portal_base_url, transaction_status, initiated_at, responded_at, verified_at, created_at, updated_at, is_archived) FROM stdin;
\.


--
-- Data for Name: homestay_applications; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.homestay_applications (id, user_id, application_number, application_kind, parent_application_id, parent_application_number, parent_certificate_number, inherited_certificate_valid_upto, service_context, service_notes, service_requested_at, application_type, water_sports_data, adventure_sports_data, property_name, category, location_type, total_rooms, district, district_other, tehsil, tehsil_other, block, block_other, gram_panchayat, gram_panchayat_other, urban_body, urban_body_other, ward, address, pincode, telephone, fax, latitude, longitude, owner_name, owner_gender, owner_mobile, owner_email, guardian_name, owner_aadhaar, guardian_relation, property_ownership, proposed_room_rate, project_type, property_area, property_area_unit, single_bed_rooms, single_bed_beds, single_bed_room_size, single_bed_room_rate, double_bed_rooms, double_bed_beds, double_bed_room_size, double_bed_room_rate, family_suites, family_suite_beds, family_suite_size, family_suite_rate, attached_washrooms, gstin, selected_category, average_room_rate, highest_room_rate, lowest_room_rate, certificate_validity_years, is_pangi_sub_division, distance_airport, distance_railway, distance_city_center, distance_shopping, distance_bus_stand, key_location_highlight1, key_location_highlight2, lobby_area, dining_area, parking_area, eco_friendly_facilities, differently_abled_facilities, fire_equipment_details, nearest_hospital, amenities, nearby_attractions, mandatory_checklist, desirable_checklist, rooms, base_fee, total_before_discounts, validity_discount, female_owner_discount, pangi_discount, total_discount, total_fee, per_room_fee, gst_amount, status, current_stage, current_page, district_officer_id, district_review_date, district_notes, da_id, da_review_date, da_forwarded_date, da_remarks, state_officer_id, state_review_date, state_notes, dtdo_id, dtdo_review_date, correction_submission_count, revert_count, dtdo_remarks, rejection_reason, clarification_requested, site_inspection_scheduled_date, site_inspection_completed_date, site_inspection_officer_id, site_inspection_notes, site_inspection_outcome, site_inspection_findings, ownership_proof_url, aadhaar_card_url, pan_card_url, gst_certificate_url, fire_safety_noc_url, pollution_clearance_url, building_plan_url, property_photos_urls, documents, certificate_number, certificate_issued_date, certificate_expiry_date, payment_status, payment_id, payment_amount, payment_date, refund_date, refund_reason, submitted_at, approved_at, created_at, updated_at, form_completion_time_seconds) FROM stdin;
67814812-4d4e-4a1b-8cd5-0af146bf41e2	13b5ef36-7b4a-40c8-ae5d-3aa376467a34	HP-HS-2026-SML-000001	new_registration	\N	\N	\N	\N	\N	\N	\N	homestay	\N	\N	Homestay 1	silver	gp	1	Shimla	\N	Chaupal	\N	\N	\N	Village AAA	\N		\N		Sondh Niwas, Lower Lakkar Bazar ,\nApple Tree	171710		\N	\N	\N	Test Test	female	6666666611	test@test.com	Test Test	666666666611	d_o	owned	0.00	new_project	1000.00	sqm	1	1	800.00	2498.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N				Fire Safety Equipment Details (Annexure-I #6g) *		{"cctv": true, "fireSafety": true}	{}	{"1": true, "2": true, "3": true, "4": true, "5": true, "6": true, "7": true, "8": true, "9": true, "10": true, "11": true, "12": true, "13": true, "14": true, "15": true, "16": true, "17": true, "18": true}	\N	\N	3000.00	3000.00	0.00	150.00	0.00	150.00	2850.00	0.00	0.00	draft	\N	5	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	2026-01-12 11:13:19.821657	2026-01-12 17:55:06.404	\N
\.


--
-- Data for Name: inspection_orders; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.inspection_orders (id, application_id, scheduled_by, scheduled_date, assigned_to, assigned_date, inspection_date, inspection_address, special_instructions, status, dtdo_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inspection_reports; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.inspection_reports (id, inspection_order_id, application_id, submitted_by, submitted_date, actual_inspection_date, room_count_verified, actual_room_count, category_meets_standards, recommended_category, mandatory_checklist, mandatory_remarks, desirable_checklist, desirable_remarks, amenities_verified, amenities_issues, fire_safety_compliant, fire_safety_issues, structural_safety, structural_issues, overall_satisfactory, recommendation, detailed_findings, inspection_photos, report_document_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_blocks; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_blocks (id, lgd_code, block_name, district_id, tehsil_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_districts; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_districts (id, lgd_code, district_name, division_name, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_gram_panchayats; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_gram_panchayats (id, lgd_code, gram_panchayat_name, district_id, block_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_tehsils; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_tehsils (id, lgd_code, tehsil_name, district_id, tehsil_type, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_urban_bodies; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_urban_bodies (id, lgd_code, urban_body_name, district_id, body_type, number_of_wards, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: login_otp_challenges; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.login_otp_challenges (id, user_id, otp_hash, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.notifications (id, user_id, application_id, type, title, message, channels, is_read, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: objections; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.objections (id, application_id, inspection_report_id, raised_by, raised_date, objection_type, objection_title, objection_description, severity, response_deadline, status, resolution_notes, resolved_by, resolved_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_reset_challenges; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.password_reset_challenges (id, user_id, channel, recipient, otp_hash, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.payments (id, application_id, payment_type, amount, payment_gateway, gateway_transaction_id, payment_method, payment_status, payment_link, qr_code_url, payment_link_expiry_date, initiated_at, completed_at, receipt_number, receipt_url) FROM stdin;
\.


--
-- Data for Name: production_stats; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.production_stats (id, total_applications, approved_applications, rejected_applications, pending_applications, scraped_at, source_url) FROM stdin;
c136ea40-b254-4614-a276-da40e98950c0	4	4	4	4	2026-01-08 00:46:39.924033	https://eservices.himachaltourism.gov.in/
48fdc8d0-692e-4a37-993a-e54688142566	4	4	4	4	2026-01-08 00:46:39.942396	https://eservices.himachaltourism.gov.in/
802136d7-fc57-4009-a736-eedb97a56554	4	4	4	4	2026-01-08 00:48:31.414282	https://eservices.himachaltourism.gov.in/
1acd27ac-af25-46cf-bc73-80471dd96616	4	4	4	4	2026-01-08 00:48:31.514408	https://eservices.himachaltourism.gov.in/
76463abc-4c37-4429-8ce4-9b10ec387da7	4	4	4	4	2026-01-08 01:05:36.499225	https://eservices.himachaltourism.gov.in/
9c6b11f1-f571-480b-960d-2a4968029dc7	4	4	4	4	2026-01-08 01:06:52.657354	https://eservices.himachaltourism.gov.in/
dd300da0-236e-4ce9-9d41-8771def9a5ab	4	4	4	4	2026-01-08 01:17:47.686854	https://eservices.himachaltourism.gov.in/
b47ebbb2-136d-4c0c-b62a-f9cc8c935e95	4	4	4	4	2026-01-08 01:39:30.119468	https://eservices.himachaltourism.gov.in/
8b18c48a-a4e5-498d-8eeb-79aa97c48d09	4	4	4	4	2026-01-08 01:40:36.11727	https://eservices.himachaltourism.gov.in/
58695279-7d14-4e30-8ac6-06607529780a	4	4	4	4	2026-01-08 01:48:31.397839	https://eservices.himachaltourism.gov.in/
ef38131c-6a0f-4bd2-8ce8-a61dfd138778	4	4	4	4	2026-01-08 01:48:31.49186	https://eservices.himachaltourism.gov.in/
3a91ea49-2635-4724-8310-82ac067c769d	4	4	4	4	2026-01-08 02:40:35.749051	https://eservices.himachaltourism.gov.in/
d3dc6040-b0aa-445c-a090-12eec34f953e	4	4	4	4	2026-01-08 02:48:31.378308	https://eservices.himachaltourism.gov.in/
f377dc4c-3c5e-4f42-a19e-93d2436e7478	4	4	4	4	2026-01-08 02:48:31.495727	https://eservices.himachaltourism.gov.in/
a86f12a0-5a76-46a0-9bfd-03228379303b	4	4	4	4	2026-01-08 03:40:35.75908	https://eservices.himachaltourism.gov.in/
01ce343e-13fa-4f55-879e-6fdd46b7e370	4	4	4	4	2026-01-08 03:48:31.393771	https://eservices.himachaltourism.gov.in/
bbc6a72c-1956-4ce6-ac8e-1f5ce6833763	4	4	4	4	2026-01-08 03:48:31.508194	https://eservices.himachaltourism.gov.in/
36d2c9ce-f454-4671-b4d6-3ecc2da85d78	4	4	4	4	2026-01-08 04:40:35.737525	https://eservices.himachaltourism.gov.in/
e268d4ee-db7d-4185-b52e-3c128a157f2c	4	4	4	4	2026-01-08 04:48:31.412989	https://eservices.himachaltourism.gov.in/
a04c8e3b-eff7-416f-8786-20ff83c17dca	4	4	4	4	2026-01-08 04:48:31.482347	https://eservices.himachaltourism.gov.in/
c7c30e56-e690-4f79-b7c0-046074eabd01	4	4	4	4	2026-01-08 05:40:35.773548	https://eservices.himachaltourism.gov.in/
625f50ee-bac5-4579-8449-5b841e33a3ba	4	4	4	4	2026-01-08 05:48:31.414763	https://eservices.himachaltourism.gov.in/
d132813f-6306-426a-8cfd-cf2ea510ac22	4	4	4	4	2026-01-08 05:48:31.497109	https://eservices.himachaltourism.gov.in/
d714c17e-8846-44a6-a1d8-fb6c97c2219c	4	4	4	4	2026-01-08 06:40:35.79278	https://eservices.himachaltourism.gov.in/
3fd8d835-8738-4aee-ac9a-81c2c9821907	4	4	4	4	2026-01-08 06:48:31.406364	https://eservices.himachaltourism.gov.in/
d7989282-a463-4584-a0c6-ec66eb13c5bc	4	4	4	4	2026-01-08 06:48:31.521966	https://eservices.himachaltourism.gov.in/
21b9f1ec-2781-4875-96c0-7c9d6b5fc34c	4	4	4	4	2026-01-08 07:40:35.796874	https://eservices.himachaltourism.gov.in/
3ca6d223-8e7d-47b6-a95e-45150a3d5da7	4	4	4	4	2026-01-08 07:48:31.407771	https://eservices.himachaltourism.gov.in/
be2976e8-f4a5-40de-b828-18005a94324b	4	4	4	4	2026-01-08 07:48:31.514086	https://eservices.himachaltourism.gov.in/
2d72a890-7c0f-4aa0-9216-29129f9812d2	4	4	4	4	2026-01-08 08:40:35.79803	https://eservices.himachaltourism.gov.in/
804298f3-e631-49d7-8211-bd11de1f2b09	4	4	4	4	2026-01-08 08:48:31.40491	https://eservices.himachaltourism.gov.in/
01a9aee3-f922-49dc-a706-acbb72e0bd6d	4	4	4	4	2026-01-08 08:48:31.503526	https://eservices.himachaltourism.gov.in/
45467045-23e8-47e5-acb8-48aa398bd3df	4	4	4	4	2026-01-08 09:40:35.815218	https://eservices.himachaltourism.gov.in/
f874ff17-5586-4ed7-b0f8-3d13068fa41a	4	4	4	4	2026-01-08 09:48:31.409262	https://eservices.himachaltourism.gov.in/
dbdcf2d4-1669-4473-bb33-b2a1e5c83618	4	4	4	4	2026-01-08 09:48:31.498021	https://eservices.himachaltourism.gov.in/
fc7e1bb1-8fd3-4f80-8525-6f0c5936ff55	4	4	4	4	2026-01-10 08:34:31.090238	https://eservices.himachaltourism.gov.in/
1138c7cd-bc27-4396-a72f-cac27296de7a	4	4	4	4	2026-01-10 08:46:15.956129	https://eservices.himachaltourism.gov.in/
04bd6fbe-e8aa-48e9-bf75-3e796b7d30d5	4	4	4	4	2026-01-10 08:49:30.002659	https://eservices.himachaltourism.gov.in/
2c498be3-39db-4ab4-bda2-9c9908530eba	4	4	4	4	2026-01-10 08:54:40.007042	https://eservices.himachaltourism.gov.in/
2961722f-c641-4435-aa24-00518ff8d759	4	4	4	4	2026-01-10 09:02:34.894845	https://eservices.himachaltourism.gov.in/
0441e383-f951-4d6e-a0a9-730ab55062a6	4	4	4	4	2026-01-10 09:06:48.620387	https://eservices.himachaltourism.gov.in/
b638656a-a1f9-45f3-a1c6-1ebb74b85bff	4	4	4	4	2026-01-10 10:06:49.699648	https://eservices.himachaltourism.gov.in/
88a2e931-8939-4cc1-898f-781e1029331d	4	4	4	4	2026-01-10 11:06:48.66553	https://eservices.himachaltourism.gov.in/
b941ab94-d037-42e5-bc30-a07d65c0888f	4	4	4	4	2026-01-10 12:06:48.721491	https://eservices.himachaltourism.gov.in/
83f4f499-807e-4c82-9a23-6a891da352f6	4	4	4	4	2026-01-10 13:06:48.72717	https://eservices.himachaltourism.gov.in/
f16657a8-5ec5-4ac7-bfa1-c923a1d50e31	4	4	4	4	2026-01-10 14:06:48.715277	https://eservices.himachaltourism.gov.in/
2bf72372-d7a4-45d6-8f38-f59a78a271f9	4	4	4	4	2026-01-10 15:06:48.702035	https://eservices.himachaltourism.gov.in/
89cd05d4-874b-4799-bd47-9aeb3d00d160	4	4	4	4	2026-01-10 16:06:48.734989	https://eservices.himachaltourism.gov.in/
b2aeb2f1-ab59-4c8a-a01d-c2949ab730d3	4	4	4	4	2026-01-10 17:06:48.733301	https://eservices.himachaltourism.gov.in/
4b54412d-f4f1-4ddf-bb25-a0fa70948903	4	4	4	4	2026-01-10 18:06:48.766655	https://eservices.himachaltourism.gov.in/
ba7ae7d1-126d-4db4-8b63-b99a1dd99c79	4	4	4	4	2026-01-10 19:06:48.782261	https://eservices.himachaltourism.gov.in/
49e0d5f7-76e9-477f-a8bc-723165f387dc	4	4	4	4	2026-01-10 20:06:48.771268	https://eservices.himachaltourism.gov.in/
79405365-55a3-469f-bf1b-15fa9a8cee0c	4	4	4	4	2026-01-10 21:06:48.824673	https://eservices.himachaltourism.gov.in/
b2374ced-a9cb-4165-aa27-f2ed311005f9	4	4	4	4	2026-01-10 22:06:48.901048	https://eservices.himachaltourism.gov.in/
53c4e5e2-7879-4e17-85db-86c16843d5ab	4	4	4	4	2026-01-10 23:06:48.833165	https://eservices.himachaltourism.gov.in/
ad7e00f2-b127-447c-9ffb-38dc304c13ee	4	4	4	4	2026-01-11 00:06:48.87723	https://eservices.himachaltourism.gov.in/
d8fb6566-32f0-439e-930b-9da7f05e2cb2	4	4	4	4	2026-01-11 01:06:48.890802	https://eservices.himachaltourism.gov.in/
7dc6aece-12a4-4354-9ffc-d8c09673515c	4	4	4	4	2026-01-11 02:06:48.921295	https://eservices.himachaltourism.gov.in/
a22d6e20-3d36-4f40-ad45-e062e9f00b6f	4	4	4	4	2026-01-11 03:06:48.926607	https://eservices.himachaltourism.gov.in/
0606f5b0-f939-43e3-85d2-7e5eae73a567	4	4	4	4	2026-01-11 04:06:48.934022	https://eservices.himachaltourism.gov.in/
f7b69f19-e0a2-4e21-b94b-5ecf84ba5e6e	4	4	4	4	2026-01-11 05:06:48.985722	https://eservices.himachaltourism.gov.in/
01e4df65-6f42-4f7f-9df3-e0ff8d421637	4	4	4	4	2026-01-11 06:06:48.932377	https://eservices.himachaltourism.gov.in/
ef5abf76-a145-422f-96c7-128879a5e14c	4	4	4	4	2026-01-11 07:06:48.952972	https://eservices.himachaltourism.gov.in/
48ec7697-0048-4ca6-983f-e53d4bf6198e	4	4	4	4	2026-01-11 08:06:48.9596	https://eservices.himachaltourism.gov.in/
3629979b-4715-4109-8587-cb42be96ddd4	4	4	4	4	2026-01-11 09:06:48.970047	https://eservices.himachaltourism.gov.in/
02e6ca18-79db-40a2-9773-a8f8598f2f94	4	4	4	4	2026-01-11 10:06:49.009207	https://eservices.himachaltourism.gov.in/
a30a63d0-1d38-4107-989f-03d9c2b3a9aa	4	4	4	4	2026-01-11 11:06:49.018401	https://eservices.himachaltourism.gov.in/
7e95937d-9c7c-48ca-8e2b-208a68860930	4	4	4	4	2026-01-11 12:06:49.048236	https://eservices.himachaltourism.gov.in/
0c5745ff-abf3-4cfe-8a33-90edab754a5f	4	4	4	4	2026-01-12 07:47:55.812886	https://eservices.himachaltourism.gov.in/
85f823af-9c5a-43b7-b372-4f185c78ceda	4	4	4	4	2026-01-12 07:47:56.074414	https://eservices.himachaltourism.gov.in/
36ca24a8-99d3-47d9-8eca-391d6344760d	4	4	4	4	2026-01-12 08:47:55.792272	https://eservices.himachaltourism.gov.in/
5f72041f-4b45-4056-af13-2dbd3ed8a1a9	4	4	4	4	2026-01-12 08:47:55.794146	https://eservices.himachaltourism.gov.in/
49a07067-2d56-4312-9ba0-964de24d7436	4	4	4	4	2026-01-12 09:04:08.56653	https://eservices.himachaltourism.gov.in/
e25da85d-103a-4359-9e0b-b7db92b8dfa6	4	4	4	4	2026-01-12 09:04:08.786371	https://eservices.himachaltourism.gov.in/
1bda1b41-4176-4957-a4b3-70d052a3d310	4	4	4	4	2026-01-12 09:09:53.748893	https://eservices.himachaltourism.gov.in/
963de838-95fb-4501-a148-22f1f161bc8c	4	4	4	4	2026-01-12 09:09:53.862423	https://eservices.himachaltourism.gov.in/
3861da7f-edf6-4cc6-b102-32827b22d805	4	4	4	4	2026-01-12 09:14:20.706822	https://eservices.himachaltourism.gov.in/
f6d8c895-ffa7-4741-8c0e-91fdaa8bc28c	4	4	4	4	2026-01-12 09:14:20.876452	https://eservices.himachaltourism.gov.in/
2b473e7a-9895-4b0e-82b1-62a54ac2b022	4	4	4	4	2026-01-12 09:18:56.194821	https://eservices.himachaltourism.gov.in/
e8c09698-c94b-4666-b6ff-2dcfe5c6a413	4	4	4	4	2026-01-12 09:18:56.376183	https://eservices.himachaltourism.gov.in/
2e18a09f-7141-434d-a54c-17c2bef32027	4	4	4	4	2026-01-12 09:23:12.24457	https://eservices.himachaltourism.gov.in/
d0360ca6-bc11-4e3a-9a40-c33abba22e9f	4	4	4	4	2026-01-12 09:23:12.508276	https://eservices.himachaltourism.gov.in/
977bb75f-616f-4c69-bd91-4660e550319c	4	4	4	4	2026-01-12 09:27:48.831671	https://eservices.himachaltourism.gov.in/
db7e3425-c738-4637-a13f-51fb0b373aa9	4	4	4	4	2026-01-12 09:27:49.19247	https://eservices.himachaltourism.gov.in/
350bd9b0-dee1-412f-b256-946c6d4eac35	4	4	4	4	2026-01-12 09:31:33.473609	https://eservices.himachaltourism.gov.in/
6665d6ad-9eaa-4940-a91d-5d3485e64676	4	4	4	4	2026-01-12 09:31:33.660097	https://eservices.himachaltourism.gov.in/
2a1f186d-56e2-4ea8-9275-30655b373352	4	4	4	4	2026-01-12 09:36:32.417717	https://eservices.himachaltourism.gov.in/
c848f405-a2f7-4bef-87bc-179f3797f0f4	4	4	4	4	2026-01-12 09:36:32.685821	https://eservices.himachaltourism.gov.in/
62233edc-c047-4a41-8c2f-090148d4bdac	4	4	4	4	2026-01-12 09:40:59.342522	https://eservices.himachaltourism.gov.in/
f100d868-d378-4f7c-9548-319ba88d182f	4	4	4	4	2026-01-12 09:40:59.56545	https://eservices.himachaltourism.gov.in/
76cb2899-44cc-499c-96f4-94f96be5e9b1	4	4	4	4	2026-01-12 09:44:57.115008	https://eservices.himachaltourism.gov.in/
467093f8-0e50-4b47-b164-32bceef79362	4	4	4	4	2026-01-12 09:44:57.339264	https://eservices.himachaltourism.gov.in/
cdd5d957-bd78-4f9f-9a84-6fe46d988c74	4	4	4	4	2026-01-12 09:47:40.692468	https://eservices.himachaltourism.gov.in/
5b70d3d5-1f64-471b-bc8c-9419bda61fea	4	4	4	4	2026-01-12 09:47:40.957531	https://eservices.himachaltourism.gov.in/
6ed7d7c9-cbff-4486-80b8-43bcd82935c5	4	4	4	4	2026-01-12 09:52:56.18153	https://eservices.himachaltourism.gov.in/
bd99bebe-77e5-465f-8750-52d0fc684e5d	4	4	4	4	2026-01-12 09:52:56.390072	https://eservices.himachaltourism.gov.in/
a6f62c88-8785-49dd-9502-6d56c464f634	4	4	4	4	2026-01-12 09:55:08.862526	https://eservices.himachaltourism.gov.in/
29222c65-6b30-48cd-a7a8-7e41315b8aa6	4	4	4	4	2026-01-12 09:55:08.964439	https://eservices.himachaltourism.gov.in/
849d1d0f-1b32-4de6-bdd3-109c6bb57b9c	4	4	4	4	2026-01-12 10:00:15.067817	https://eservices.himachaltourism.gov.in/
6680b3dc-313f-40cf-8ef7-729f38387353	4	4	4	4	2026-01-12 10:00:15.172538	https://eservices.himachaltourism.gov.in/
5528e273-7588-490b-a758-56f643b08232	4	4	4	4	2026-01-12 10:04:15.36109	https://eservices.himachaltourism.gov.in/
93990a25-6745-435e-b493-552b603f2e54	4	4	4	4	2026-01-12 10:04:15.532528	https://eservices.himachaltourism.gov.in/
4309462d-932c-48d4-96c3-a3b9eb0fce6c	4	4	4	4	2026-01-12 10:09:22.583528	https://eservices.himachaltourism.gov.in/
2db58972-9562-4ee8-a2bd-868499f9b424	4	4	4	4	2026-01-12 10:09:22.75306	https://eservices.himachaltourism.gov.in/
83241200-932c-4b01-b96a-08467c5d50d7	4	4	4	4	2026-01-12 10:11:58.306899	https://eservices.himachaltourism.gov.in/
b1c8cabf-09e1-4e38-8a5c-69d94ae879f1	4	4	4	4	2026-01-12 10:11:58.595419	https://eservices.himachaltourism.gov.in/
f34e3714-38bf-4c9c-a803-0c98fa0cec1e	4	4	4	4	2026-01-12 10:16:50.351598	https://eservices.himachaltourism.gov.in/
4f44941e-d4b4-4521-98e6-1a94c55d3d1b	4	4	4	4	2026-01-12 10:16:50.548143	https://eservices.himachaltourism.gov.in/
9d8e8be7-e283-494c-9d02-66008a313f6a	4	4	4	4	2026-01-12 10:20:20.656174	https://eservices.himachaltourism.gov.in/
4037ebbd-1b9b-43e2-a858-c32aca26c793	4	4	4	4	2026-01-12 10:20:21.953533	https://eservices.himachaltourism.gov.in/
71034ef9-0f09-4b5a-8bdd-123be57a1c18	4	4	4	4	2026-01-12 10:22:57.056537	https://eservices.himachaltourism.gov.in/
5f6baddd-1c56-4ac3-b032-6595576d5451	4	4	4	4	2026-01-12 10:22:57.28478	https://eservices.himachaltourism.gov.in/
df2e2f99-4d7c-4a79-ad22-1cb1e0e0c3a9	4	4	4	4	2026-01-12 10:26:15.56827	https://eservices.himachaltourism.gov.in/
8dc2fbed-7539-4597-b4b3-97e41f7ca25d	4	4	4	4	2026-01-12 10:26:15.679855	https://eservices.himachaltourism.gov.in/
87aac52e-c6c6-4846-aa5a-65cbcb3d4d56	4	4	4	4	2026-01-12 10:29:49.17847	https://eservices.himachaltourism.gov.in/
570bfb6e-0dc1-4c58-b3b1-2617f8409ac8	4	4	4	4	2026-01-12 10:29:49.363525	https://eservices.himachaltourism.gov.in/
6d2e69d8-3127-4c38-998b-5b5ef86216e4	4	4	4	4	2026-01-12 10:33:38.413936	https://eservices.himachaltourism.gov.in/
59d392fd-fa8b-4ad1-8a34-000cbc546f10	4	4	4	4	2026-01-12 10:33:38.676524	https://eservices.himachaltourism.gov.in/
686703a1-2160-4307-ac2d-64df1adb3763	4	4	4	4	2026-01-12 10:40:09.398648	https://eservices.himachaltourism.gov.in/
3b3b4bf8-e313-4ce5-b8d0-4a29350f5aec	4	4	4	4	2026-01-12 10:40:09.557678	https://eservices.himachaltourism.gov.in/
aae90c0c-cb24-4a53-81da-8953a2e313f6	4	4	4	4	2026-01-12 10:47:30.304298	https://eservices.himachaltourism.gov.in/
492517d9-a71c-4be1-a737-6d2ccbb65da2	4	4	4	4	2026-01-12 10:47:30.410521	https://eservices.himachaltourism.gov.in/
d3acfa19-c551-4f18-a3de-2c9499162d42	4	4	4	4	2026-01-12 10:52:05.781415	https://eservices.himachaltourism.gov.in/
924b0591-a200-4545-ac9b-2db57ba5b3bf	4	4	4	4	2026-01-12 10:52:06.105525	https://eservices.himachaltourism.gov.in/
f7f1306b-fa10-4103-89c7-50919de495b6	4	4	4	4	2026-01-12 11:09:56.727055	https://eservices.himachaltourism.gov.in/
ce63dd17-0b68-4bfc-840f-f35e7f6337e1	4	4	4	4	2026-01-12 11:09:57.042319	https://eservices.himachaltourism.gov.in/
68e94361-1623-49b4-bfd6-d7aeeacd7f2a	4	4	4	4	2026-01-12 11:11:36.615518	https://eservices.himachaltourism.gov.in/
26878741-079e-410c-93d7-3c267d6dfcc5	4	4	4	4	2026-01-12 11:11:36.863397	https://eservices.himachaltourism.gov.in/
1333fe32-bfe0-4bf7-8497-648f8518a138	4	4	4	4	2026-01-12 11:19:53.180936	https://eservices.himachaltourism.gov.in/
f4e494f9-0024-4c62-ad2c-bc266bddb607	4	4	4	4	2026-01-12 11:19:53.310524	https://eservices.himachaltourism.gov.in/
091f0414-48a9-4188-bc79-26249475ab8e	4	4	4	4	2026-01-12 12:19:53.179353	https://eservices.himachaltourism.gov.in/
6045c998-71c4-4149-8e38-ce774ee93441	4	4	4	4	2026-01-12 12:19:53.264092	https://eservices.himachaltourism.gov.in/
b15f107a-380f-4870-be61-ef68a6c82f73	4	4	4	4	2026-01-12 13:19:53.199418	https://eservices.himachaltourism.gov.in/
36176f28-8bfc-42f0-97ca-93a1ec46890b	4	4	4	4	2026-01-12 13:19:53.24063	https://eservices.himachaltourism.gov.in/
212f8c7c-4d90-4c98-b569-c22126ce8103	4	4	4	4	2026-01-12 14:19:53.18719	https://eservices.himachaltourism.gov.in/
0b4d04e5-b116-4546-b3d1-e1f02e160979	4	4	4	4	2026-01-12 14:19:53.266184	https://eservices.himachaltourism.gov.in/
2c749c2e-a0a0-4143-8ce9-70745ba9fe4d	4	4	4	4	2026-01-12 15:19:53.17421	https://eservices.himachaltourism.gov.in/
5859b66f-b46d-4278-86c1-d38d5c9a3651	4	4	4	4	2026-01-12 15:19:53.255743	https://eservices.himachaltourism.gov.in/
fd13899e-7ed3-47d8-948f-3226e854371e	4	4	4	4	2026-01-12 16:19:53.231376	https://eservices.himachaltourism.gov.in/
ad6bcd41-500f-452b-994f-f8776e74c4e5	4	4	4	4	2026-01-12 16:19:53.258689	https://eservices.himachaltourism.gov.in/
b44872a8-5621-4ef6-b3f5-71d9dd5ee3e6	4	4	4	4	2026-01-12 16:23:39.689518	https://eservices.himachaltourism.gov.in/
5010f28f-1fd2-47b6-bfdf-2ab65a9d4c69	4	4	4	4	2026-01-12 16:23:39.711413	https://eservices.himachaltourism.gov.in/
d9f525ee-35bc-4a74-80da-5e6fb5e65940	4	4	4	4	2026-01-12 16:37:12.751031	https://eservices.himachaltourism.gov.in/
2ba00f78-725c-47d9-8cbe-213b87af1c88	4	4	4	4	2026-01-12 16:37:12.934196	https://eservices.himachaltourism.gov.in/
74cf0532-e289-4a9c-9171-3bbd2a26f940	4	4	4	4	2026-01-12 16:37:49.998256	https://eservices.himachaltourism.gov.in/
3e649ab8-e891-405a-a2d7-79ade92f0791	4	4	4	4	2026-01-12 16:37:50.133188	https://eservices.himachaltourism.gov.in/
a7fc87e0-2e2c-4ff7-aa3f-88bcd8ed177e	4	4	4	4	2026-01-12 17:37:50.025296	https://eservices.himachaltourism.gov.in/
d9e47b55-a48c-4841-a2aa-3e36df3ca71e	4	4	4	4	2026-01-12 17:37:50.090106	https://eservices.himachaltourism.gov.in/
7630a2cf-6214-45d2-a81d-0321e4dae86e	4	4	4	4	2026-01-12 17:53:59.987779	https://eservices.himachaltourism.gov.in/
4b12d1d8-fa8b-4120-ba42-a0ec52d1a229	4	4	4	4	2026-01-12 17:54:00.299766	https://eservices.himachaltourism.gov.in/
9bffce57-8e68-4b22-82d0-3dc29c31c987	4	4	4	4	2026-01-12 18:48:14.836253	https://eservices.himachaltourism.gov.in/
d9880a3a-7a4c-4cf4-bb66-678e718e1500	4	4	4	4	2026-01-12 18:48:14.956369	https://eservices.himachaltourism.gov.in/
0effccf2-c532-44e5-b0dd-ccf3455db039	4	4	4	4	2026-01-12 18:53:33.40719	https://eservices.himachaltourism.gov.in/
d6929139-264f-4680-b536-2718c73406a2	4	4	4	4	2026-01-12 18:53:58.949378	https://eservices.himachaltourism.gov.in/
e0c80e94-e60b-4969-8603-ef0a4ea4498b	4	4	4	4	2026-01-12 18:59:29.414425	https://eservices.himachaltourism.gov.in/
2c00c733-a7a7-418e-87c3-505e1479a991	4	4	4	4	2026-01-12 19:59:29.4264	https://eservices.himachaltourism.gov.in/
e4e5a813-a20e-4189-8eb8-939ddb65b244	4	4	4	4	2026-01-12 20:59:29.450214	https://eservices.himachaltourism.gov.in/
7d5c7f17-e972-46fc-afe2-6037f676e61c	4	4	4	4	2026-01-12 21:59:29.474445	https://eservices.himachaltourism.gov.in/
347d61aa-4806-45b1-8b93-d22b326d10dd	4	4	4	4	2026-01-12 22:59:29.477494	https://eservices.himachaltourism.gov.in/
577952bd-24fd-4001-af92-fe0b346501aa	4	4	4	4	2026-01-12 23:59:29.502989	https://eservices.himachaltourism.gov.in/
bad0ae84-e0e5-4c38-a8b4-9530751912f7	4	4	4	4	2026-01-13 00:59:29.51108	https://eservices.himachaltourism.gov.in/
96bdf6d2-b72f-4e2e-a86e-e7cbe764d6a1	4	4	4	4	2026-01-13 01:48:00.81707	https://eservices.himachaltourism.gov.in/
111ffe40-b0c5-4fa6-ab11-a2015f7875c1	4	4	4	4	2026-01-13 02:08:08.833549	https://eservices.himachaltourism.gov.in/
0450ca71-eb4f-49ba-a2d3-78238ad07642	4	4	4	4	2026-01-13 03:08:08.873143	https://eservices.himachaltourism.gov.in/
5b3cb9e8-d482-4670-b8b4-263096ed8c80	4	4	4	4	2026-01-13 04:08:08.896945	https://eservices.himachaltourism.gov.in/
9080e125-aa84-4d59-9200-27c109c444d6	4	4	4	4	2026-01-13 04:21:05.40365	https://eservices.himachaltourism.gov.in/
b1a5f409-5d00-4f2c-9510-6cabfe9e0d1f	4	4	4	4	2026-01-13 04:21:05.867399	https://eservices.himachaltourism.gov.in/
250eddc9-e333-4821-962e-d98f1e5428de	4	4	4	4	2026-01-13 05:21:05.849938	https://eservices.himachaltourism.gov.in/
03cfe51a-d8f5-45c7-ad72-78ebdaafe616	4	4	4	4	2026-01-13 05:21:06.499713	https://eservices.himachaltourism.gov.in/
2ee01c1f-7054-4313-9a0f-4ca2b2f1b7ce	4	4	4	4	2026-01-13 06:21:05.436147	https://eservices.himachaltourism.gov.in/
b4d738ad-96a8-4dea-a0c4-19f35dd5caea	4	4	4	4	2026-01-13 06:21:05.831556	https://eservices.himachaltourism.gov.in/
30dd3674-4fbb-42af-942e-211345c4819c	4	4	4	4	2026-01-13 07:21:05.455464	https://eservices.himachaltourism.gov.in/
71390735-24c6-4c7a-8cec-f5f97af68a7f	4	4	4	4	2026-01-13 07:21:06.071967	https://eservices.himachaltourism.gov.in/
9e1db3bb-852b-4813-adb2-e9647be83c79	4	4	4	4	2026-01-13 08:21:05.415091	https://eservices.himachaltourism.gov.in/
7f688a2f-38d5-4a03-805d-c70647caa4cc	4	4	4	4	2026-01-13 08:21:05.832194	https://eservices.himachaltourism.gov.in/
83670fbf-887d-4916-800b-c86d9b38084a	4	4	4	4	2026-01-13 09:21:05.427022	https://eservices.himachaltourism.gov.in/
d8ab7896-bf1f-41e9-b64a-c4effef0c7f8	4	4	4	4	2026-01-13 09:21:05.834342	https://eservices.himachaltourism.gov.in/
7fd63bb3-9614-44c6-a26a-f66126315ae6	4	4	4	4	2026-01-13 10:21:05.44423	https://eservices.himachaltourism.gov.in/
abeef943-fe8e-432e-a8e7-92c0b5232253	4	4	4	4	2026-01-13 10:21:05.841331	https://eservices.himachaltourism.gov.in/
db6f6433-86a0-402d-a312-b2211810c0e3	4	4	4	4	2026-01-13 11:21:05.428023	https://eservices.himachaltourism.gov.in/
8809fe27-b632-4bf9-905b-80e7942925de	4	4	4	4	2026-01-13 11:21:05.822311	https://eservices.himachaltourism.gov.in/
8d13cad3-6227-4b4e-916b-06c8b225629b	4	4	4	4	2026-01-13 12:21:05.416646	https://eservices.himachaltourism.gov.in/
9a93a6dc-3201-4737-b029-02c7d1ebdd17	4	4	4	4	2026-01-13 12:21:05.82558	https://eservices.himachaltourism.gov.in/
29323220-65e3-4cd6-b58b-16e48c9e86c7	4	4	4	4	2026-01-13 13:21:05.425168	https://eservices.himachaltourism.gov.in/
e48101ac-6743-4ab8-89fc-1b500a444a28	4	4	4	4	2026-01-13 13:21:05.835926	https://eservices.himachaltourism.gov.in/
800af94d-5728-4685-b629-33f5ff6ac2b0	4	4	4	4	2026-01-13 14:21:15.440091	https://eservices.himachaltourism.gov.in/
48f11630-8178-473b-93c7-86a16c16da89	4	4	4	4	2026-01-13 14:21:15.592982	https://eservices.himachaltourism.gov.in/
2d27a7c7-f2c4-4a6a-a480-9a01abc8bbd6	4	4	4	4	2026-01-13 15:21:05.416737	https://eservices.himachaltourism.gov.in/
e9799fd1-5eb8-45ed-a156-5c550bcd1971	4	4	4	4	2026-01-13 15:21:05.819084	https://eservices.himachaltourism.gov.in/
d026c531-24f4-46f5-9b96-a675a73c1165	4	4	4	4	2026-01-13 16:21:05.424046	https://eservices.himachaltourism.gov.in/
6a85ccb4-2069-4d4f-8d5a-530b23216296	4	4	4	4	2026-01-13 16:21:05.829177	https://eservices.himachaltourism.gov.in/
6465d96b-d7ab-4f0c-9887-b36bee691f49	4	4	4	4	2026-01-13 17:21:05.421919	https://eservices.himachaltourism.gov.in/
682b6846-db64-4d93-9e1c-4d750b109660	4	4	4	4	2026-01-13 17:21:05.818878	https://eservices.himachaltourism.gov.in/
d009611f-bdcf-4907-95a9-49172793fa8d	4	4	4	4	2026-01-13 18:21:05.425576	https://eservices.himachaltourism.gov.in/
1d656942-60d5-4e02-9e81-4e4d1e86465c	4	4	4	4	2026-01-13 18:21:05.836415	https://eservices.himachaltourism.gov.in/
4eb752b6-ef8b-4d79-9fcf-636463d24da9	4	4	4	4	2026-01-13 19:21:05.468971	https://eservices.himachaltourism.gov.in/
630910a9-e288-439b-9ded-a2a7995b1890	4	4	4	4	2026-01-13 19:21:05.850276	https://eservices.himachaltourism.gov.in/
6478ba2b-c7e6-441c-8257-ba7e383b63c9	4	4	4	4	2026-01-13 20:21:05.493654	https://eservices.himachaltourism.gov.in/
1e6cb5ee-cf97-4150-a41b-65d52b1e6244	4	4	4	4	2026-01-13 20:21:05.854896	https://eservices.himachaltourism.gov.in/
082c8ea2-f79f-4bbd-a329-743ccbc2e651	4	4	4	4	2026-01-13 21:21:05.462372	https://eservices.himachaltourism.gov.in/
72b0d1be-cd5d-4851-a9e2-a20d98207866	4	4	4	4	2026-01-13 21:21:05.84791	https://eservices.himachaltourism.gov.in/
d6456e39-96cb-4e6e-a401-2055ee37f6cf	4	4	4	4	2026-01-13 22:21:05.440693	https://eservices.himachaltourism.gov.in/
76e93cfc-a04f-4264-8f47-43518839d330	4	4	4	4	2026-01-13 22:21:05.829698	https://eservices.himachaltourism.gov.in/
2de633ac-9a81-4944-a33a-2349e3f81c6a	4	4	4	4	2026-01-13 23:21:05.458137	https://eservices.himachaltourism.gov.in/
66975060-bddc-4055-933a-46ae153c258e	4	4	4	4	2026-01-13 23:21:05.827022	https://eservices.himachaltourism.gov.in/
faeefb66-d1ef-4ef9-b3fa-1302b9eddd56	4	4	4	4	2026-01-14 00:21:05.460239	https://eservices.himachaltourism.gov.in/
bdaaea1e-6af9-4444-b673-87663f77e396	4	4	4	4	2026-01-14 00:21:05.831032	https://eservices.himachaltourism.gov.in/
27fbd3cd-ce19-465c-8a5f-f599302ead20	4	4	4	4	2026-01-14 01:21:05.448262	https://eservices.himachaltourism.gov.in/
843a6967-bd68-44d1-b078-0ea96e155c4b	4	4	4	4	2026-01-14 01:21:05.83283	https://eservices.himachaltourism.gov.in/
6cc918c2-71e3-4c39-989a-42eef5656e9d	4	4	4	4	2026-01-14 02:21:05.447788	https://eservices.himachaltourism.gov.in/
a07c5fa9-3339-4a5f-9e4b-35b5434a39e5	4	4	4	4	2026-01-14 02:21:05.825839	https://eservices.himachaltourism.gov.in/
e762f417-b85a-4b86-8229-aaccc9500c7e	4	4	4	4	2026-01-14 03:21:19.445292	https://eservices.himachaltourism.gov.in/
e441277c-267e-4cb0-92ec-6943a8be2913	4	4	4	4	2026-01-14 03:21:19.529888	https://eservices.himachaltourism.gov.in/
70f8863e-d3f7-426a-aab0-9b2c1614af1d	4	4	4	4	2026-01-14 04:21:05.502667	https://eservices.himachaltourism.gov.in/
69d0b6b3-15b4-4803-a5af-654c003cab93	4	4	4	4	2026-01-14 04:21:05.849731	https://eservices.himachaltourism.gov.in/
02c6693d-07e9-467d-a740-0ea5a73f3f5e	4	4	4	4	2026-01-14 04:51:18.102644	https://eservices.himachaltourism.gov.in/
feca7eaf-7cb0-4dc2-a0b8-b635783cee1f	4	4	4	4	2026-01-14 05:21:05.930912	https://eservices.himachaltourism.gov.in/
5af76032-409e-4906-a037-2dc599b00d2c	4	4	4	4	2026-01-14 05:32:07.409858	https://eservices.himachaltourism.gov.in/
baf2c976-1cab-4e56-aa6c-ad03db46533a	4	4	4	4	2026-01-14 06:21:05.944665	https://eservices.himachaltourism.gov.in/
dcfc590f-d763-46b7-b1e9-bbaaa3d1363c	4	4	4	4	2026-01-14 06:32:07.391455	https://eservices.himachaltourism.gov.in/
1095561f-d14a-4946-b267-3502b444f005	4	4	4	4	2026-01-14 07:21:05.933522	https://eservices.himachaltourism.gov.in/
e2941c4c-8b73-4ce8-8161-380b213c1391	4	4	4	4	2026-01-14 07:30:16.440628	https://eservices.himachaltourism.gov.in/
465347f2-82dc-454b-902b-15beb1b51b42	4	4	4	4	2026-01-14 07:32:07.363196	https://eservices.himachaltourism.gov.in/
ee25cd31-4fd0-424f-b075-0ad8ae836a3b	4	4	4	4	2026-01-14 08:21:05.935886	https://eservices.himachaltourism.gov.in/
be548eaa-58fa-40fe-9843-51ba067fe549	4	4	4	4	2026-01-14 08:27:46.608507	https://eservices.himachaltourism.gov.in/
7f000f15-9b23-4460-bfac-3d0d3d2ebfb5	4	4	4	4	2026-01-14 08:32:07.417809	https://eservices.himachaltourism.gov.in/
9222b908-7dab-4fc2-8ae3-95cf6facc295	4	4	4	4	2026-01-14 08:35:14.704594	https://eservices.himachaltourism.gov.in/
c8900f3f-e72c-4c34-9675-9357a5de4d6d	4	4	4	4	2026-01-14 08:59:02.207824	https://eservices.himachaltourism.gov.in/
dd2f84aa-74ef-40a6-849c-3a1a37a2a794	4	4	4	4	2026-01-14 09:21:05.850169	https://eservices.himachaltourism.gov.in/
e5c67470-7766-4611-abf4-42a347e59bf9	4	4	4	4	2026-01-14 09:32:07.381709	https://eservices.himachaltourism.gov.in/
baa970a7-1db9-42dc-bf59-3b63cd767546	4	4	4	4	2026-01-14 10:21:05.937755	https://eservices.himachaltourism.gov.in/
913b9f3c-bf1b-4952-b769-18f753eee8ce	4	4	4	4	2026-01-14 10:22:22.499372	https://eservices.himachaltourism.gov.in/
9cde6ce8-0844-43aa-b26b-b2ca26daa36d	4	4	4	4	2026-01-14 10:32:07.392769	https://eservices.himachaltourism.gov.in/
d6229fb5-dc36-4a58-8be2-36bf7ef4a21c	4	4	4	4	2026-01-14 11:21:05.94618	https://eservices.himachaltourism.gov.in/
6e97e24d-926a-4521-bfb5-7e04eb99ab68	4	4	4	4	2026-01-14 11:22:21.900243	https://eservices.himachaltourism.gov.in/
a66bbaa3-6a43-4626-9c91-dbeb175ec58f	4	4	4	4	2026-01-14 11:32:07.469456	https://eservices.himachaltourism.gov.in/
ce6c118d-a09b-4dfc-aac4-6eefd9b51633	4	4	4	4	2026-01-14 12:21:05.927307	https://eservices.himachaltourism.gov.in/
31f38d7f-0775-4144-9bd2-33fbb0121f4a	4	4	4	4	2026-01-14 12:22:21.886596	https://eservices.himachaltourism.gov.in/
c55b48da-ecd9-4c46-bafe-5800797a9f18	4	4	4	4	2026-01-14 12:32:07.371363	https://eservices.himachaltourism.gov.in/
4f0a5c90-85f7-40b6-88ea-f9929c5877ec	4	4	4	4	2026-01-14 13:21:05.918789	https://eservices.himachaltourism.gov.in/
0e4fcf0f-7a4d-4f50-aeda-572d5718e4d8	4	4	4	4	2026-01-14 13:22:21.92683	https://eservices.himachaltourism.gov.in/
a27cc3d4-34a0-4acd-ac3f-06ef0bf3de83	4	4	4	4	2026-01-14 13:32:07.377658	https://eservices.himachaltourism.gov.in/
ffc38e62-4da1-45ec-a778-c9fe3975a7b5	4	4	4	4	2026-01-14 14:21:05.940473	https://eservices.himachaltourism.gov.in/
311aae32-aeb8-4864-b1a4-774bff526ff1	4	4	4	4	2026-01-14 14:22:21.876746	https://eservices.himachaltourism.gov.in/
300d1503-b460-40b3-b7b7-d68c2bc3f494	4	4	4	4	2026-01-14 14:32:07.397519	https://eservices.himachaltourism.gov.in/
48380520-2bfa-48fa-bcf7-81ebb721bf81	4	4	4	4	2026-01-14 15:21:05.940365	https://eservices.himachaltourism.gov.in/
da7d5110-cf14-41a5-ba05-c20357283ca1	4	4	4	4	2026-01-14 15:22:21.902932	https://eservices.himachaltourism.gov.in/
fd13afdb-2071-4974-bf6d-1d954b25b452	4	4	4	4	2026-01-14 15:32:07.427224	https://eservices.himachaltourism.gov.in/
c80ce6ca-a7d8-4914-93a0-124078d4e9e5	4	4	4	4	2026-01-14 15:37:04.793033	https://eservices.himachaltourism.gov.in/
cdc96304-8a03-4580-bb3f-d56510dbcd9a	4	4	4	4	2026-01-14 15:37:04.804291	https://eservices.himachaltourism.gov.in/
898ea7fb-e305-4d0f-aa4d-9f916e7a03c5	4	4	4	4	2026-01-14 15:38:22.957458	https://eservices.himachaltourism.gov.in/
7703e94c-667f-47ec-a24e-411fca00e7e9	4	4	4	4	2026-01-14 15:54:04.217212	https://eservices.himachaltourism.gov.in/
09fcd60f-156c-4b8c-8564-13de8368dc00	4	4	4	4	2026-01-14 15:54:58.248164	https://eservices.himachaltourism.gov.in/
a1063146-5dbd-42df-bb8b-065662e050d9	4	4	4	4	2026-01-14 15:55:46.126826	https://eservices.himachaltourism.gov.in/
45261ffe-a65d-4f16-9461-75d543289670	4	4	4	4	2026-01-14 16:55:45.78684	https://eservices.himachaltourism.gov.in/
a9664b94-7c99-4875-bc42-6db033792b2f	4	4	4	4	2026-01-14 17:55:45.721954	https://eservices.himachaltourism.gov.in/
b3b200e1-e4e8-4764-82bc-6dd10e4ee4d6	4	4	4	4	2026-01-14 18:55:45.719269	https://eservices.himachaltourism.gov.in/
98204179-5a13-4b4b-93e8-3e1cb4fb9cfe	4	4	4	4	2026-01-14 19:55:45.723353	https://eservices.himachaltourism.gov.in/
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.reviews (id, application_id, user_id, rating, review_text, is_verified_stay, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.session (sid, sess, expire) FROM stdin;
_1qqKhqm3v63ba74dfNxFPNofzPMvI6B	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-21T15:48:23.707Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-21 15:48:24
RZxPgiSh0HD96rIIXRnQfj4Ncb0vtdVm	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-18T08:02:59.655Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-18 09:17:29
dDcsMg-e5jh6oH00Ta2fZ0KnhurzdiWH	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-21T18:01:07.166Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-21 19:20:45
nKilmUDNI7SewEm5IDPiXFuRVpcjgHl0	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-15T05:36:24.048Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-15 05:36:25
C4FF4ws8TrmZkylxjOEeuaFa4hhEcr4G	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-20T01:47:43.767Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-20 02:12:02
ajhFiOUu1mb2OBFuVdjGDcBIICiJodwr	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-21T09:14:44.058Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-21 09:21:53
\.


--
-- Data for Name: storage_objects; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.storage_objects (id, object_key, storage_provider, file_type, category, mime_type, size_bytes, checksum_sha256, uploaded_by, application_id, document_id, created_at, last_accessed_at) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.support_tickets (id, ticket_number, applicant_id, application_id, service_type, category, subject, description, status, priority, assigned_to, assigned_at, escalated_from, escalated_at, escalation_level, sla_deadline, sla_breach, resolved_at, resolved_by, resolution_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.system_settings (id, setting_key, setting_value, description, category, updated_by, created_at, updated_at) FROM stdin;
498dbd8d-4322-416e-a72e-4002e6c06158	enforce_single_session	true	Enforce single concurrent session per user (kicks old sessions on new login)	general	\N	2026-01-08 03:01:48.867166	2026-01-08 03:01:48.867166
2d4bfeb6-2acb-478b-a5d3-ce16f183e5a9	backup_configuration	{"enabled": true, "schedule": "0 2 * * *", "includeEnv": true, "includeFiles": true, "lastBackupAt": "2026-01-13T20:30:00.075Z", "retentionDays": 30, "backupDirectory": "/home/subhash.thakur.india/Projects/hptourism-rc7/backups", "includeDatabase": true, "lastBackupStatus": "success"}	\N	general	\N	2026-01-10 20:30:00.481759	2026-01-13 20:30:00.498
3c29b1ac-6a6f-41c7-89f2-d26c34d6d43a	comm_email_gateway	{"custom": {"host": "mail.smtp2go.com", "port": 2525, "password": "osipl@2025", "username": "osipl.dev", "fromEmail": "Mail2Smtp"}, "provider": "custom"}	Email gateway configuration	communications	5e2c291b-e9f0-4ead-a6ed-3fe8098a7760	2026-01-14 06:39:24.099995	2026-01-14 06:48:24.932
1dd1247e-d747-4051-9521-81e47e51569f	comm_sms_gateway	{"nic": {"postUrl": "https://msdgweb.mgov.gov.in/esms/sendsmsrequestDLT", "password": "Tour@sml352", "senderId": "hpgovt", "username": "hpgovt-TACA", "templateId": "1007739248479536901", "departmentKey": "a63f7853-6297-44c7-820b-392541a47fc1"}, "provider": "nic"}	SMS gateway configuration	communications	5e2c291b-e9f0-4ead-a6ed-3fe8098a7760	2026-01-14 06:36:24.36111	2026-01-14 06:49:51.578
0c489058-71d4-4415-9e0a-b38096d0816b	payment_test_mode	{"enabled": true}	When enabled, payment requests send ₹1 to gateway instead of actual amount (for testing)	payment	5e2c291b-e9f0-4ead-a6ed-3fe8098a7760	2026-01-14 07:35:35.822385	2026-01-14 07:35:35.822385
581aad64-4af9-4801-9e3c-1529c44b4d99	woman_discount_mode	{"mode": "SEQUENTIAL"}	Configuration for woman owner discount calculation (Additive vs Sequential)	general	\N	2026-01-14 07:36:55.921742	2026-01-14 07:36:57.565
e6141603-69bb-449e-9fb4-d6832f992d95	admin_super_console_enabled	{"enabled": true}	Enable/disable super console	admin	5e2c291b-e9f0-4ead-a6ed-3fe8098a7760	2026-01-14 06:34:47.665642	2026-01-14 15:34:15.016
92818204-de11-4045-8ed0-1bdca9e1d651	maintenance_mode_config	{"enabled": false, "accessKey": "launch2026"}	Test Maintenance Mode	general	30d01ccb-a38d-44df-b1fe-f904926574b3	2026-01-14 07:25:23.431063	2026-01-14 15:38:33.827
\.


--
-- Data for Name: ticket_actions; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.ticket_actions (id, ticket_id, actor_id, actor_role, action, previous_status, new_status, previous_priority, new_priority, previous_assignee, new_assignee, notes, metadata, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: ticket_messages; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.ticket_messages (id, ticket_id, sender_id, sender_role, message, attachments, is_internal, is_read, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.user_profiles (id, user_id, full_name, gender, aadhaar_number, mobile, email, district, tehsil, block, gram_panchayat, urban_body, ward, address, pincode, telephone, fax, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.users (id, mobile, full_name, first_name, last_name, username, email, alternate_phone, designation, department, employee_id, office_address, office_phone, role, aadhaar_number, sso_id, district, password, enabled_services, is_active, created_at, updated_at, signature_url) FROM stdin;
30d01ccb-a38d-44df-b1fe-f904926574b3	9999999999	Admin Admin	Admin	Admin	admin	\N	\N	\N	\N	\N	\N	\N	admin	\N	\N	\N	$2b$10$J/OIXeqxtoZ06ZOWpsOlX.7IekDkhGOl6mplrEZ4wbFLrOyv62vpW	["homestay"]	t	2026-01-08 00:45:19.959719	2026-01-08 00:45:19.959719	\N
5e2c291b-e9f0-4ead-a6ed-3fe8098a7760	9999999998	Super Admin	Super	Admin	superadmin	superadmin@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	super_admin	\N	\N	\N	$2b$10$O3eLVm3tZzbzceNqeF6zh.z2sj0NEpzw5mNWRmDkuTDLjt9REl1/m	["homestay"]	t	2026-01-08 00:45:20.096523	2026-01-08 00:45:20.096523	\N
d244a912-8065-4604-9b58-ba9b69d93e11	7800001005	DA Kullu Manali	DA	Kullu Manali	da_kullu_manali	da.kullu-manali@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Kullu	$2b$10$MHZ7GFt1oo2ngK4Ivklx0.p/VPrPdCwrsJSlo8gcn8FZj5fX9hefK	["homestay"]	t	2026-01-08 00:45:20.821971	2026-01-08 00:45:20.821971	\N
29e9c380-3b7d-49aa-882e-94d37ec3e59d	7900001001	DTDO Chamba	DTDO	Chamba	dtdo_chamba	dtdo.chamba@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Chamba HQ	$2b$10$rG68dezaxlMn92IVOrfj3.XKHkFxekN2y/dQ5M9vc0HYbtoLaJqly	["homestay"]	t	2026-01-08 00:45:20.252529	2026-01-08 00:45:20.252529	\N
f284ccb8-33fc-42d0-a45a-eb231e6cac9a	7800001002	DA Bharmour	DA	Bharmour	da_bharmour	da.bharmour@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Bharmour Sub-Division	$2b$10$sMJhfYeImStwMpcj6sp.Aucyth7yE.Xx3sHKyZpaN1flFdVR.l4iC	["homestay"]	t	2026-01-08 00:45:20.328813	2026-01-08 00:45:20.328813	\N
ae0f4a20-aaad-4c76-8b3d-b914dfa561db	7900001002	DTDO Bharmour	DTDO	Bharmour	dtdo_bharmour	dtdo.bharmour@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Bharmour Sub-Division	$2b$10$sHx6adRSlHq4Yy0eDglQR.bQvRNc3oBsWP8OPgJKfrU5UR1pasqPa	["homestay"]	t	2026-01-08 00:45:20.40481	2026-01-08 00:45:20.40481	\N
94a33229-2eec-4bfe-a5ce-d01b06625974	7800001003	DA Shimla Hq	DA	Shimla Hq	da_shimla_hq	da.shimla-hq@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Shimla HQ (AC Tourism)	$2b$10$v9zOltOtsfYrLPM.n0TnaOVTxJ6q2ANjG/YkvTLmj3O7VSc8DXbLK	["homestay"]	t	2026-01-08 00:45:20.481319	2026-01-08 00:45:20.481319	\N
4a415c0e-67e4-4cb9-90ba-159a7877aaef	7900001003	DTDO Shimla Hq	DTDO	Shimla Hq	dtdo_shimla_hq	dtdo.shimla-hq@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Shimla HQ (AC Tourism)	$2b$10$0BfEb6/ak19z5U5AueaTIueRfcKCvPgHMsXzuQyLtEhQkaqFJikuW	["homestay"]	t	2026-01-08 00:45:20.56027	2026-01-08 00:45:20.56027	\N
6affed07-7898-4fc9-b86d-af1d610ad3ea	7800001004	DA Hamirpur	DA	Hamirpur	da_hamirpur	da.hamirpur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Hamirpur (serving Una)	$2b$10$wQ9Q6yaTLBl8FDd55YGbbePzknRJZ6xpIIxOT1p/jzo.gZ1yyNPe2	["homestay"]	t	2026-01-08 00:45:20.638833	2026-01-08 00:45:20.638833	\N
6536d907-78d1-419a-b023-8a6f141fdcf5	7900001004	DTDO Hamirpur	DTDO	Hamirpur	dtdo_hamirpur	dtdo.hamirpur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Hamirpur (serving Una)	$2b$10$89TiI0YVRNHSRmrJnKEEn.gB1sRItgPYW8if/oMFJ/CzbVFtu7XI6	["homestay"]	t	2026-01-08 00:45:20.733503	2026-01-08 00:45:20.733503	\N
4d890d65-0a0f-49f1-92cc-34d046586531	7900001005	DTDO Kullu Manali	DTDO	Kullu Manali	dtdo_kullu_manali	dtdo.kullu-manali@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Kullu	$2b$10$gF1BrGMyc4WYgGKNeGsqAe.bCdLyWOmuu3lpqU1.dCUCOtoN2skoa	["homestay"]	t	2026-01-08 00:45:20.975105	2026-01-08 00:45:20.975105	\N
adfed2b7-282f-4aa3-8ee3-8285c108d51c	7800001006	DA Kullu Dhalpur	DA	Kullu Dhalpur	da_kullu_dhalpur	da.kullu-dhalpur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Kullu Dhalpur	$2b$10$kOWCFRbHViZCy6HU4BKqTenX5QxgXWzbLhZAk90BeIS8H8LFtaHza	["homestay"]	t	2026-01-08 00:45:21.061375	2026-01-08 00:45:21.061375	\N
379057ec-a3f3-4e88-9950-fc96ecc97bdc	7900001006	DTDO Kullu Dhalpur	DTDO	Kullu Dhalpur	dtdo_kullu_dhalpur	dtdo.kullu-dhalpur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Kullu Dhalpur	$2b$10$RSlggXSjgUYZPxArMNPt8eso9GP7Yw1tFYSzeRNcEaP6u2v.mMCWW	["homestay"]	t	2026-01-08 00:45:21.24217	2026-01-08 00:45:21.24217	\N
b7987533-e127-4cad-8233-de0fdde7bbc7	7800001007	DA Dharamsala	DA	Dharamsala	da_dharamsala	da.dharamsala@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Dharamsala (Kangra)	$2b$10$LXLKHkYSa8qzvSHs/7xb9OaU2hPgN6yv8YalqNgJInWX5O04UeEIO	["homestay"]	t	2026-01-08 00:45:21.328771	2026-01-08 00:45:21.328771	\N
6181fa83-d0af-492e-9fca-840005f2600e	7900001007	DTDO Dharamsala	DTDO	Dharamsala	dtdo_dharamsala	dtdo.dharamsala@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Dharamsala (Kangra)	$2b$10$u.zamAdjGeeB5RjKF4qeGOtIrjCCCOFXeBJWNQY3bjaDaTs.TaABq	["homestay"]	t	2026-01-08 00:45:21.429953	2026-01-08 00:45:21.429953	\N
6d27a721-acb4-4dab-95d9-0b2c91645234	7800001008	DA Kinnaur	DA	Kinnaur	da_kinnaur	da.kinnaur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Kinnaur (Reckong Peo)	$2b$10$tSJbrAdjbbiKsSFnDZn9DeHJX1pvaYHzP5Jg/LgeKj9pRPmdQTBWG	["homestay"]	t	2026-01-08 00:45:21.531155	2026-01-08 00:45:21.531155	\N
1562faf8-b959-43ec-b3ef-936d901e3131	7900001008	DTDO Kinnaur	DTDO	Kinnaur	dtdo_kinnaur	dtdo.kinnaur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Kinnaur (Reckong Peo)	$2b$10$OOn9c0888hAIFIIRteMxl.5hr9KZ0MiytWwxD.foWYuCeQ79cIAqm	["homestay"]	t	2026-01-08 00:45:21.646263	2026-01-08 00:45:21.646263	\N
5da8ac27-6650-4982-b51a-a7e7c5257075	7800001009	DA Kaza	DA	Kaza	da_kaza	da.kaza@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Kaza (Spiti ITDP)	$2b$10$uNTEF00Gyeslt/J9KldzmOpwkaJh9V0JdJXBJoTQXGj6G9NloxOtK	["homestay"]	t	2026-01-08 00:45:21.743951	2026-01-08 00:45:21.743951	\N
422d1de0-8342-42b3-9767-d71d3297cd57	7900001009	DTDO Kaza	DTDO	Kaza	dtdo_kaza	dtdo.kaza@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Kaza (Spiti ITDP)	$2b$10$pebO29e2NSc9R5laVsSHyea3GINQziRCQBXbGqt1jQHlqKn5/K6Lu	["homestay"]	t	2026-01-08 00:45:21.82239	2026-01-08 00:45:21.82239	\N
249b7155-1f20-404f-b377-b0202b66a8a8	7800001010	DA Lahaul	DA	Lahaul	da_lahaul	da.lahaul@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Lahaul (Keylong)	$2b$10$CwFfmkmo7SmojEOO8aVYcOwmxo.JHp1.X3vaeKVjcyRC3Plb3iNuy	["homestay"]	t	2026-01-08 00:45:21.898119	2026-01-08 00:45:21.898119	\N
a7aea641-74c2-451f-8c5b-c3d01dd2d5fd	7900001010	DTDO Lahaul	DTDO	Lahaul	dtdo_lahaul	dtdo.lahaul@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Lahaul (Keylong)	$2b$10$xRA9wM4PCuJ/LUqetVJKEu/63hyKfcjKO0RV4mAw4o6QGd9amjGM2	["homestay"]	t	2026-01-08 00:45:21.974547	2026-01-08 00:45:21.974547	\N
38b25f9c-a43e-47c9-a74c-ee74519eadb8	7800001011	DA Mandi	DA	Mandi	da_mandi	da.mandi@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Mandi Division	$2b$10$9.TJqxViaXqxjyDlDeH5LOM3rWQCNj1xCTwhFB0egiqyQ2bPvpBPe	["homestay"]	t	2026-01-08 00:45:22.053293	2026-01-08 00:45:22.053293	\N
e058334e-e9c3-47e3-938b-5a9a273ff1a0	7900001011	DTDO Mandi	DTDO	Mandi	dtdo_mandi	dtdo.mandi@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Mandi Division	$2b$10$upZvMNll/06Sl7HGe2QpN.f0vGeox4nG5q4s8XomYp3lVg/VrVY8m	["homestay"]	t	2026-01-08 00:45:22.137953	2026-01-08 00:45:22.137953	\N
efde4df9-1dcf-4d85-a9d3-151d17c8011d	7800001001	DA Chamba	DA	Chamba	da_chamba	da.chamba@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Chamba HQ	$2b$10$x6zoLjUZ6vEloSnonobJnO0DAIDpBmdJai2aebgfoSgnYiPP0Wl1u	["homestay"]	t	2026-01-08 00:45:20.176033	2026-01-08 00:45:20.176033	\N
1a8bab46-2d4c-4694-9009-12d50f644ec8	7800001012	DA Pangi	DA	Pangi	da_pangi	da.pangi@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Pangi (ITDP)	$2b$10$Tc8Cvo5TIS.FzwyvoQ83CO1SWNl7njXXPNMCsINBLWF2HQ3SJNOQ.	["homestay"]	t	2026-01-08 00:45:22.237459	2026-01-08 00:45:22.237459	\N
683e4272-6948-451a-bffe-2aeac46f9137	7900001015	DTDO Solan	DTDO	Solan	dtdo_solan	dtdo.solan@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Solan Division	$2b$10$n19IXU7XSIlL.EcAh5o59O6OoE2I70aTMbbltJy4mxu6fx76/AB9u	["homestay"]	t	2026-01-08 00:45:22.776118	2026-01-08 00:45:22.776118	\N
01e17065-3ce4-46af-8a36-97cf24502482	7900001012	DTDO Pangi	DTDO	Pangi	dtdo_pangi	dtdo.pangi@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Pangi (ITDP)	$2b$10$rF6pX5Ce8B.b3muMtJiCkudj1zHN03gQ8ThECxKfc5BdwCDUhb5em	["homestay"]	t	2026-01-08 00:45:22.313669	2026-01-08 00:45:22.313669	\N
13b5ef36-7b4a-40c8-ae5d-3aa376467a34	6666666611	Test Test	Test	Test	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	666666666611	\N	\N	$2b$10$uykQlcieHiSCqyAIb6rdFOsELygne14iN2ekc8waPkExvqkKn.jhG	["homestay"]	t	2026-01-08 01:13:30.082175	2026-01-08 01:13:30.082175	\N
b8f573d3-9eee-48f7-a2a4-ea670ce192d1	9800000001	State HQ Supervisor	\N	\N	supervisor_hq	supervisor.hq@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	state_officer	\N	\N	\N	$2b$10$SsQEe6nCWNRIXHjgPbGv6.A8AJs7uWo6ltuI/a08vXXLFux65peIa	["homestay"]	t	2026-01-12 18:20:44.944366	2026-01-12 18:20:44.944366	\N
5ff8dbe4-2fe2-44a2-82ab-0588baab4da6	7800001014	DA Sirmaur	DA	Sirmaur	da_sirmaur	da.sirmaur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Sirmaur (Nahan)	$2b$10$v1hJNJovpqrji7l1cGFKZ.tc41pFR.7B.i3jWfnVrDsT6qnni6QuK	["homestay"]	t	2026-01-08 00:45:22.544892	2026-01-08 00:45:22.544892	\N
a9a95a58-c2be-4175-83ed-7352a709c3c8	7800001013	DA Shimla	DA	Shimla	da_shimla	da.shimla@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Shimla	$2b$10$/DblSM4weUyFFTZ25lmHwOQOHdSmFsBvvjMpAuWJ8N87/B7ZknfgW	["homestay"]	t	2026-01-08 00:45:22.390449	2026-01-08 00:45:22.390449	\N
32d7d290-8270-4aa9-977b-6b67743b953a	7900001014	DTDO Sirmaur	DTDO	Sirmaur	dtdo_sirmaur	dtdo.sirmaur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Sirmaur (Nahan)	$2b$10$rWcH.wzttAMNrG5JAdJjTO8boMxEhtfsNyxNyhHLiudgmOmcJkZGC	["homestay"]	t	2026-01-08 00:45:22.62149	2026-01-08 00:45:22.62149	\N
2803bd35-34f0-4751-86ae-6cc3918c7165	7900001013	DTDO Shimla	DTDO	Shimla	dtdo_shimla	dtdo.shimla@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	\N	Shimla	$2b$10$cfWkjaIcTuE144WemxbDaeTGyaU3B7kzFpODatKhjXpIuLT8cVUmS	["homestay"]	t	2026-01-08 00:45:22.466632	2026-01-08 00:45:22.466632	\N
cdb880ee-4ba6-4441-b5b1-0852c2cb4b55	7800001015	DA Solan	DA	Solan	da_solan	da.solan@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	\N	Solan Division	$2b$10$zVM9/k8FNXOVX1k5XcslUu2N82Rqw0l4RJ9eKetTcGrdp9JgzuL1e	["homestay"]	t	2026-01-08 00:45:22.698356	2026-01-08 00:45:22.698356	\N
abc973c9-0b50-44f5-9df2-2aca18d9ccfa	8091441005	Subhash Thakur	Subhash	Thakur	\N	subhash.thakur2010@gmail.com	\N	\N	\N	\N	\N	\N	property_owner	313881022691	\N	\N	$2b$10$huvvdSGBm8Bomth8WRULs.n.kZvWsGKvECwbaUasLuLdhHTn5CHoW	["homestay"]	t	2026-01-14 15:48:14.149796	2026-01-14 15:48:14.149796	\N
\.


--
-- Name: application_actions application_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: certificates certificates_application_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_application_id_unique UNIQUE (application_id);


--
-- Name: certificates certificates_certificate_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_certificate_number_unique UNIQUE (certificate_number);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: clarifications clarifications_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_pkey PRIMARY KEY (id);


--
-- Name: ddo_codes ddo_codes_district_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ddo_codes
    ADD CONSTRAINT ddo_codes_district_unique UNIQUE (district);


--
-- Name: ddo_codes ddo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ddo_codes
    ADD CONSTRAINT ddo_codes_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: grievance_audit_log grievance_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_audit_log
    ADD CONSTRAINT grievance_audit_log_pkey PRIMARY KEY (id);


--
-- Name: grievance_comments grievance_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_comments
    ADD CONSTRAINT grievance_comments_pkey PRIMARY KEY (id);


--
-- Name: grievances grievances_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_pkey PRIMARY KEY (id);


--
-- Name: grievances grievances_ticket_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_ticket_number_unique UNIQUE (ticket_number);


--
-- Name: himkosh_transactions himkosh_transactions_app_ref_no_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_app_ref_no_unique UNIQUE (app_ref_no);


--
-- Name: himkosh_transactions himkosh_transactions_ech_txn_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_ech_txn_id_unique UNIQUE (ech_txn_id);


--
-- Name: himkosh_transactions himkosh_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_pkey PRIMARY KEY (id);


--
-- Name: homestay_applications homestay_applications_application_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_application_number_unique UNIQUE (application_number);


--
-- Name: homestay_applications homestay_applications_certificate_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_certificate_number_unique UNIQUE (certificate_number);


--
-- Name: homestay_applications homestay_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_pkey PRIMARY KEY (id);


--
-- Name: inspection_orders inspection_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_pkey PRIMARY KEY (id);


--
-- Name: inspection_reports inspection_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_pkey PRIMARY KEY (id);


--
-- Name: lgd_blocks lgd_blocks_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_blocks lgd_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_pkey PRIMARY KEY (id);


--
-- Name: lgd_districts lgd_districts_district_name_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_district_name_unique UNIQUE (district_name);


--
-- Name: lgd_districts lgd_districts_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_districts lgd_districts_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_pkey PRIMARY KEY (id);


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_pkey PRIMARY KEY (id);


--
-- Name: lgd_tehsils lgd_tehsils_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_tehsils lgd_tehsils_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_pkey PRIMARY KEY (id);


--
-- Name: lgd_urban_bodies lgd_urban_bodies_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_urban_bodies lgd_urban_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_pkey PRIMARY KEY (id);


--
-- Name: login_otp_challenges login_otp_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.login_otp_challenges
    ADD CONSTRAINT login_otp_challenges_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: objections objections_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_pkey PRIMARY KEY (id);


--
-- Name: password_reset_challenges password_reset_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.password_reset_challenges
    ADD CONSTRAINT password_reset_challenges_pkey PRIMARY KEY (id);


--
-- Name: payments payments_gateway_transaction_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_gateway_transaction_id_unique UNIQUE (gateway_transaction_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: payments payments_receipt_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_receipt_number_unique UNIQUE (receipt_number);


--
-- Name: production_stats production_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.production_stats
    ADD CONSTRAINT production_stats_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: storage_objects storage_objects_object_key_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_object_key_unique UNIQUE (object_key);


--
-- Name: storage_objects storage_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_ticket_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_ticket_number_unique UNIQUE (ticket_number);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_setting_key_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_setting_key_unique UNIQUE (setting_key);


--
-- Name: ticket_actions ticket_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_pkey PRIMARY KEY (id);


--
-- Name: ticket_messages ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_unique UNIQUE (user_id);


--
-- Name: users users_aadhaar_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_aadhaar_number_unique UNIQUE (aadhaar_number);


--
-- Name: users users_mobile_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_mobile_unique UNIQUE (mobile);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_sso_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_sso_id_unique UNIQUE (sso_id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: users_district_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX users_district_idx ON public.users USING btree (district);


--
-- Name: users_mobile_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX users_mobile_idx ON public.users USING btree (mobile);


--
-- Name: users_role_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX users_role_idx ON public.users USING btree (role);


--
-- Name: application_actions application_actions_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: application_actions application_actions_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_officer_id_users_id_fk FOREIGN KEY (officer_id) REFERENCES public.users(id);


--
-- Name: audit_logs audit_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: certificates certificates_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_issued_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_issued_by_users_id_fk FOREIGN KEY (issued_by) REFERENCES public.users(id);


--
-- Name: certificates certificates_renewal_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_renewal_application_id_homestay_applications_id_fk FOREIGN KEY (renewal_application_id) REFERENCES public.homestay_applications(id);


--
-- Name: certificates certificates_revoked_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_revoked_by_users_id_fk FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: clarifications clarifications_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: clarifications clarifications_objection_id_objections_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_objection_id_objections_id_fk FOREIGN KEY (objection_id) REFERENCES public.objections(id) ON DELETE CASCADE;


--
-- Name: clarifications clarifications_reviewed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_reviewed_by_users_id_fk FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: clarifications clarifications_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: documents documents_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: documents documents_verified_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_verified_by_users_id_fk FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: grievance_audit_log grievance_audit_log_grievance_id_grievances_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_audit_log
    ADD CONSTRAINT grievance_audit_log_grievance_id_grievances_id_fk FOREIGN KEY (grievance_id) REFERENCES public.grievances(id) ON DELETE CASCADE;


--
-- Name: grievance_audit_log grievance_audit_log_performed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_audit_log
    ADD CONSTRAINT grievance_audit_log_performed_by_users_id_fk FOREIGN KEY (performed_by) REFERENCES public.users(id);


--
-- Name: grievance_comments grievance_comments_grievance_id_grievances_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_comments
    ADD CONSTRAINT grievance_comments_grievance_id_grievances_id_fk FOREIGN KEY (grievance_id) REFERENCES public.grievances(id) ON DELETE CASCADE;


--
-- Name: grievance_comments grievance_comments_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_comments
    ADD CONSTRAINT grievance_comments_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: grievances grievances_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: grievances grievances_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: grievances grievances_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: himkosh_transactions himkosh_transactions_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: homestay_applications homestay_applications_da_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_da_id_users_id_fk FOREIGN KEY (da_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_district_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_district_officer_id_users_id_fk FOREIGN KEY (district_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_dtdo_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_dtdo_id_users_id_fk FOREIGN KEY (dtdo_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_site_inspection_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_site_inspection_officer_id_users_id_fk FOREIGN KEY (site_inspection_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_state_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_state_officer_id_users_id_fk FOREIGN KEY (state_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: inspection_orders inspection_orders_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: inspection_orders inspection_orders_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: inspection_orders inspection_orders_scheduled_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_scheduled_by_users_id_fk FOREIGN KEY (scheduled_by) REFERENCES public.users(id);


--
-- Name: inspection_reports inspection_reports_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: inspection_reports inspection_reports_inspection_order_id_inspection_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_inspection_order_id_inspection_orders_id_fk FOREIGN KEY (inspection_order_id) REFERENCES public.inspection_orders(id) ON DELETE CASCADE;


--
-- Name: inspection_reports inspection_reports_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: lgd_blocks lgd_blocks_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_blocks lgd_blocks_tehsil_id_lgd_tehsils_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_tehsil_id_lgd_tehsils_id_fk FOREIGN KEY (tehsil_id) REFERENCES public.lgd_tehsils(id) ON DELETE SET NULL;


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_block_id_lgd_blocks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_block_id_lgd_blocks_id_fk FOREIGN KEY (block_id) REFERENCES public.lgd_blocks(id) ON DELETE CASCADE;


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_tehsils lgd_tehsils_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_urban_bodies lgd_urban_bodies_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: login_otp_challenges login_otp_challenges_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.login_otp_challenges
    ADD CONSTRAINT login_otp_challenges_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: notifications notifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: objections objections_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: objections objections_inspection_report_id_inspection_reports_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_inspection_report_id_inspection_reports_id_fk FOREIGN KEY (inspection_report_id) REFERENCES public.inspection_reports(id);


--
-- Name: objections objections_raised_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_raised_by_users_id_fk FOREIGN KEY (raised_by) REFERENCES public.users(id);


--
-- Name: objections objections_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: password_reset_challenges password_reset_challenges_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.password_reset_challenges
    ADD CONSTRAINT password_reset_challenges_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payments payments_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: reviews reviews_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: reviews reviews_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: storage_objects storage_objects_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE SET NULL;


--
-- Name: storage_objects storage_objects_document_id_documents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_document_id_documents_id_fk FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: storage_objects storage_objects_uploaded_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_uploaded_by_users_id_fk FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_applicant_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_applicant_id_users_id_fk FOREIGN KEY (applicant_id) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: support_tickets support_tickets_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_escalated_from_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_escalated_from_users_id_fk FOREIGN KEY (escalated_from) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: system_settings system_settings_updated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_actor_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_actor_id_users_id_fk FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_new_assignee_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_new_assignee_users_id_fk FOREIGN KEY (new_assignee) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_previous_assignee_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_previous_assignee_users_id_fk FOREIGN KEY (previous_assignee) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_ticket_id_support_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_ticket_id_support_tickets_id_fk FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_messages ticket_messages_sender_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_sender_id_users_id_fk FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: ticket_messages ticket_messages_ticket_id_support_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_ticket_id_support_tickets_id_fk FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: user_profiles user_profiles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict t7rubc8qr5ukubGihF8VsduV0yEfVrA4MwIgWHVbsLd2jX5alApvXlJylsbphN4

