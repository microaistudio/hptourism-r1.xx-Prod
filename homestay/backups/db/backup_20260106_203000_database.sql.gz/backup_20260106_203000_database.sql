--
-- PostgreSQL database dump
--

\restrict V8zIZ7NFSHSZRJLMXnGtTZVJwDjm3W3Z2ckkLyxVZAPZ0gvc0hzusWTaMYKUSKo

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: hptourism_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO hptourism_user;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: hptourism_user
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: application_actions; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.application_actions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    officer_id character varying NOT NULL,
    action character varying(50) NOT NULL,
    previous_status character varying(50),
    new_status character varying(50),
    feedback text,
    issues_found jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.application_actions OWNER TO hptourism_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    action character varying(100) NOT NULL,
    details jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO hptourism_user;

--
-- Name: certificates; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.certificates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    certificate_number character varying(50) NOT NULL,
    certificate_type character varying(50) DEFAULT 'homestay_registration'::character varying,
    issued_date timestamp without time zone NOT NULL,
    valid_from timestamp without time zone NOT NULL,
    valid_upto timestamp without time zone NOT NULL,
    property_name character varying(255) NOT NULL,
    category character varying(20) NOT NULL,
    address text NOT NULL,
    district character varying(100) NOT NULL,
    owner_name character varying(255) NOT NULL,
    owner_mobile character varying(15) NOT NULL,
    certificate_pdf_url text,
    qr_code_data text,
    digital_signature text,
    issued_by character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    revocation_reason text,
    revoked_by character varying,
    revoked_date timestamp without time zone,
    renewal_reminder_sent boolean DEFAULT false,
    renewal_application_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.certificates OWNER TO hptourism_user;

--
-- Name: clarifications; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.clarifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    objection_id character varying NOT NULL,
    application_id character varying NOT NULL,
    submitted_by character varying NOT NULL,
    submitted_date timestamp without time zone NOT NULL,
    clarification_text text NOT NULL,
    supporting_documents jsonb,
    reviewed_by character varying,
    reviewed_date timestamp without time zone,
    review_status character varying(50),
    review_notes text,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.clarifications OWNER TO hptourism_user;

--
-- Name: ddo_codes; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.ddo_codes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    district character varying(100) NOT NULL,
    ddo_code character varying(20) NOT NULL,
    ddo_description text NOT NULL,
    treasury_code character varying(10) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    head1 character varying(50)
);


ALTER TABLE public.ddo_codes OWNER TO hptourism_user;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.documents (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    document_type character varying(100) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path text NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(100) NOT NULL,
    upload_date timestamp without time zone DEFAULT now(),
    ai_verification_status character varying(50),
    ai_confidence_score numeric(5,2),
    ai_notes text,
    is_verified boolean DEFAULT false,
    verification_status character varying(50) DEFAULT 'pending'::character varying,
    verified_by character varying,
    verification_date timestamp without time zone,
    verification_notes text
);


ALTER TABLE public.documents OWNER TO hptourism_user;

--
-- Name: grievance_audit_log; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.grievance_audit_log (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    grievance_id character varying NOT NULL,
    action character varying(50) NOT NULL,
    old_value text,
    new_value text,
    performed_by character varying NOT NULL,
    performed_at timestamp without time zone DEFAULT now(),
    ip_address character varying(50),
    user_agent text
);


ALTER TABLE public.grievance_audit_log OWNER TO hptourism_user;

--
-- Name: grievance_comments; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.grievance_comments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    grievance_id character varying NOT NULL,
    user_id character varying NOT NULL,
    comment text NOT NULL,
    is_internal boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.grievance_comments OWNER TO hptourism_user;

--
-- Name: grievances; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.grievances (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_number character varying(50) NOT NULL,
    ticket_type character varying(20) DEFAULT 'owner_grievance'::character varying,
    user_id character varying,
    application_id character varying,
    category character varying(50) NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying,
    status character varying(20) DEFAULT 'open'::character varying,
    subject character varying(255) NOT NULL,
    description text NOT NULL,
    assigned_to character varying,
    resolution_notes text,
    attachments jsonb,
    last_comment_at timestamp without time zone,
    last_read_by_owner timestamp without time zone,
    last_read_by_officer timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone
);


ALTER TABLE public.grievances OWNER TO hptourism_user;

--
-- Name: himkosh_transactions; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.himkosh_transactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    dept_ref_no character varying(45) NOT NULL,
    app_ref_no character varying(20) NOT NULL,
    total_amount integer NOT NULL,
    tender_by character varying(70) NOT NULL,
    merchant_code character varying(15),
    dept_id character varying(10),
    service_code character varying(5),
    ddo character varying(12),
    head1 character varying(14),
    amount1 integer,
    head2 character varying(14),
    amount2 integer,
    head3 character varying(14),
    amount3 integer,
    head4 character varying(14),
    amount4 integer,
    head10 character varying(50),
    amount10 integer,
    period_from character varying(10),
    period_to character varying(10),
    encrypted_request text,
    request_checksum character varying(32),
    ech_txn_id character varying(10),
    bank_cin character varying(20),
    bank_name character varying(10),
    payment_date character varying(14),
    status character varying(70),
    status_cd character varying(1),
    response_checksum character varying(32),
    is_double_verified boolean DEFAULT false,
    double_verification_date timestamp without time zone,
    double_verification_data jsonb,
    challan_print_url text,
    transaction_status character varying(50) DEFAULT 'initiated'::character varying,
    initiated_at timestamp without time zone DEFAULT now(),
    responded_at timestamp without time zone,
    verified_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    portal_base_url text,
    is_archived boolean DEFAULT false
);


ALTER TABLE public.himkosh_transactions OWNER TO hptourism_user;

--
-- Name: homestay_applications; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.homestay_applications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    application_number character varying(50) NOT NULL,
    property_name character varying(255) NOT NULL,
    category character varying(20) NOT NULL,
    location_type character varying(10) NOT NULL,
    total_rooms integer NOT NULL,
    district character varying(100) NOT NULL,
    district_other character varying(100),
    tehsil character varying(100) NOT NULL,
    tehsil_other character varying(100),
    block character varying(100),
    block_other character varying(100),
    gram_panchayat character varying(100),
    gram_panchayat_other character varying(100),
    urban_body character varying(200),
    urban_body_other character varying(200),
    ward character varying(50),
    address text NOT NULL,
    pincode character varying(10) NOT NULL,
    telephone character varying(20),
    fax character varying(20),
    latitude numeric(10,8),
    longitude numeric(11,8),
    owner_name character varying(255) NOT NULL,
    owner_gender character varying(10) NOT NULL,
    owner_mobile character varying(15) NOT NULL,
    owner_email character varying(255),
    owner_aadhaar character varying(12) NOT NULL,
    property_ownership character varying(10) DEFAULT 'owned'::character varying NOT NULL,
    proposed_room_rate numeric(10,2),
    project_type character varying(20) NOT NULL,
    property_area numeric(10,2) NOT NULL,
    single_bed_rooms integer DEFAULT 0,
    single_bed_room_size numeric(10,2),
    single_bed_room_rate numeric(10,2),
    double_bed_rooms integer DEFAULT 0,
    double_bed_room_size numeric(10,2),
    double_bed_room_rate numeric(10,2),
    family_suites integer DEFAULT 0,
    family_suite_size numeric(10,2),
    family_suite_rate numeric(10,2),
    attached_washrooms integer NOT NULL,
    gstin character varying(15),
    selected_category character varying(20),
    average_room_rate numeric(10,2),
    highest_room_rate numeric(10,2),
    lowest_room_rate numeric(10,2),
    certificate_validity_years integer DEFAULT 1,
    is_pangi_sub_division boolean DEFAULT false,
    distance_airport numeric(10,2),
    distance_railway numeric(10,2),
    distance_city_center numeric(10,2),
    distance_shopping numeric(10,2),
    distance_bus_stand numeric(10,2),
    lobby_area numeric(10,2),
    dining_area numeric(10,2),
    parking_area text,
    eco_friendly_facilities text,
    differently_abled_facilities text,
    fire_equipment_details text,
    nearest_hospital character varying(255),
    amenities jsonb,
    rooms jsonb,
    base_fee numeric(10,2),
    total_before_discounts numeric(10,2),
    validity_discount numeric(10,2) DEFAULT '0'::numeric,
    female_owner_discount numeric(10,2) DEFAULT '0'::numeric,
    pangi_discount numeric(10,2) DEFAULT '0'::numeric,
    total_discount numeric(10,2) DEFAULT '0'::numeric,
    total_fee numeric(10,2),
    per_room_fee numeric(10,2),
    gst_amount numeric(10,2),
    status character varying(50) DEFAULT 'draft'::character varying,
    current_stage character varying(50),
    current_page integer DEFAULT 1,
    district_officer_id character varying,
    district_review_date timestamp without time zone,
    district_notes text,
    da_id character varying,
    da_review_date timestamp without time zone,
    da_forwarded_date timestamp without time zone,
    state_officer_id character varying,
    state_review_date timestamp without time zone,
    state_notes text,
    dtdo_id character varying,
    dtdo_review_date timestamp without time zone,
    dtdo_remarks text,
    rejection_reason text,
    clarification_requested text,
    site_inspection_scheduled_date timestamp without time zone,
    site_inspection_completed_date timestamp without time zone,
    site_inspection_officer_id character varying,
    site_inspection_notes text,
    site_inspection_outcome character varying(50),
    site_inspection_findings jsonb,
    ownership_proof_url text,
    aadhaar_card_url text,
    pan_card_url text,
    gst_certificate_url text,
    fire_safety_noc_url text,
    pollution_clearance_url text,
    building_plan_url text,
    property_photos_urls jsonb,
    documents jsonb,
    certificate_number character varying(50),
    certificate_issued_date timestamp without time zone,
    certificate_expiry_date timestamp without time zone,
    submitted_at timestamp without time zone,
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    single_bed_beds integer DEFAULT 1,
    double_bed_beds integer DEFAULT 2,
    family_suite_beds integer DEFAULT 4,
    application_kind character varying(30) DEFAULT 'new_registration'::character varying NOT NULL,
    parent_application_id character varying,
    parent_application_number character varying(50),
    parent_certificate_number character varying(50),
    inherited_certificate_valid_upto timestamp without time zone,
    service_context jsonb,
    service_notes text,
    service_requested_at timestamp without time zone,
    guardian_name character varying(255),
    da_remarks text,
    correction_submission_count integer DEFAULT 0 NOT NULL,
    application_type character varying(50) DEFAULT 'homestay'::character varying,
    water_sports_data jsonb,
    adventure_sports_data jsonb,
    guardian_relation character varying(20) DEFAULT 'father'::character varying,
    property_area_unit character varying(10) DEFAULT 'sqm'::character varying,
    key_location_highlight1 text,
    key_location_highlight2 text,
    nearby_attractions jsonb,
    mandatory_checklist jsonb,
    desirable_checklist jsonb,
    revert_count integer DEFAULT 0 NOT NULL,
    payment_status character varying(20) DEFAULT 'pending'::character varying,
    payment_id character varying(100),
    payment_amount numeric(10,2),
    payment_date timestamp without time zone,
    refund_date timestamp without time zone,
    refund_reason text,
    form_completion_time_seconds integer
);


ALTER TABLE public.homestay_applications OWNER TO hptourism_user;

--
-- Name: inspection_orders; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.inspection_orders (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    scheduled_by character varying NOT NULL,
    scheduled_date timestamp without time zone NOT NULL,
    assigned_to character varying NOT NULL,
    assigned_date timestamp without time zone NOT NULL,
    inspection_date timestamp without time zone NOT NULL,
    inspection_address text NOT NULL,
    special_instructions text,
    status character varying(50) DEFAULT 'scheduled'::character varying,
    dtdo_notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.inspection_orders OWNER TO hptourism_user;

--
-- Name: inspection_reports; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.inspection_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    inspection_order_id character varying NOT NULL,
    application_id character varying NOT NULL,
    submitted_by character varying NOT NULL,
    submitted_date timestamp without time zone NOT NULL,
    actual_inspection_date timestamp without time zone NOT NULL,
    room_count_verified boolean NOT NULL,
    actual_room_count integer,
    category_meets_standards boolean NOT NULL,
    recommended_category character varying(20),
    mandatory_checklist jsonb,
    mandatory_remarks text,
    desirable_checklist jsonb,
    desirable_remarks text,
    amenities_verified jsonb,
    amenities_issues text,
    fire_safety_compliant boolean,
    fire_safety_issues text,
    structural_safety boolean,
    structural_issues text,
    overall_satisfactory boolean NOT NULL,
    recommendation character varying(50) NOT NULL,
    detailed_findings text NOT NULL,
    inspection_photos jsonb,
    report_document_url text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.inspection_reports OWNER TO hptourism_user;

--
-- Name: lgd_blocks; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_blocks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    block_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    tehsil_id character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_blocks OWNER TO hptourism_user;

--
-- Name: lgd_districts; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_districts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    district_name character varying(100) NOT NULL,
    division_name character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_districts OWNER TO hptourism_user;

--
-- Name: lgd_gram_panchayats; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_gram_panchayats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    gram_panchayat_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    block_id character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_gram_panchayats OWNER TO hptourism_user;

--
-- Name: lgd_tehsils; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_tehsils (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    tehsil_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    tehsil_type character varying(50) DEFAULT 'tehsil'::character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_tehsils OWNER TO hptourism_user;

--
-- Name: lgd_urban_bodies; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_urban_bodies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    urban_body_name character varying(200) NOT NULL,
    district_id character varying NOT NULL,
    body_type character varying(50) NOT NULL,
    number_of_wards integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_urban_bodies OWNER TO hptourism_user;

--
-- Name: login_otp_challenges; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.login_otp_challenges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    otp_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.login_otp_challenges OWNER TO hptourism_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.notifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    application_id character varying,
    type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    channels jsonb,
    is_read boolean DEFAULT false,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO hptourism_user;

--
-- Name: objections; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.objections (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    inspection_report_id character varying,
    raised_by character varying NOT NULL,
    raised_date timestamp without time zone NOT NULL,
    objection_type character varying(50) NOT NULL,
    objection_title character varying(255) NOT NULL,
    objection_description text NOT NULL,
    severity character varying(20) NOT NULL,
    response_deadline timestamp without time zone,
    status character varying(50) DEFAULT 'pending'::character varying,
    resolution_notes text,
    resolved_by character varying,
    resolved_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.objections OWNER TO hptourism_user;

--
-- Name: password_reset_challenges; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.password_reset_challenges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    channel character varying(32) NOT NULL,
    recipient character varying(255),
    otp_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.password_reset_challenges OWNER TO hptourism_user;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.payments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    payment_type character varying(50) NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_gateway character varying(50),
    gateway_transaction_id character varying(255),
    payment_method character varying(50),
    payment_status character varying(50) DEFAULT 'pending'::character varying,
    payment_link text,
    qr_code_url text,
    payment_link_expiry_date timestamp without time zone,
    initiated_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    receipt_number character varying(100),
    receipt_url text
);


ALTER TABLE public.payments OWNER TO hptourism_user;

--
-- Name: production_stats; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.production_stats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    total_applications integer NOT NULL,
    approved_applications integer NOT NULL,
    rejected_applications integer NOT NULL,
    pending_applications integer NOT NULL,
    scraped_at timestamp without time zone DEFAULT now(),
    source_url text
);


ALTER TABLE public.production_stats OWNER TO hptourism_user;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.reviews (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    user_id character varying NOT NULL,
    rating integer NOT NULL,
    review_text text,
    is_verified_stay boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.reviews OWNER TO hptourism_user;

--
-- Name: session; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO hptourism_user;

--
-- Name: storage_objects; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.storage_objects (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    object_key text NOT NULL,
    storage_provider character varying(20) DEFAULT 'local'::character varying NOT NULL,
    file_type character varying(100) NOT NULL,
    category character varying(100) DEFAULT 'general'::character varying,
    mime_type character varying(100) DEFAULT 'application/octet-stream'::character varying,
    size_bytes integer DEFAULT 0 NOT NULL,
    checksum_sha256 character varying(128),
    uploaded_by character varying,
    application_id character varying,
    document_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    last_accessed_at timestamp without time zone
);


ALTER TABLE public.storage_objects OWNER TO hptourism_user;

--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.support_tickets (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_number character varying(50) NOT NULL,
    applicant_id character varying NOT NULL,
    application_id character varying,
    service_type character varying(50) DEFAULT 'homestay'::character varying,
    category character varying(50) NOT NULL,
    subject character varying(255) NOT NULL,
    description text NOT NULL,
    status character varying(30) DEFAULT 'open'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    assigned_to character varying,
    assigned_at timestamp without time zone,
    escalated_from character varying,
    escalated_at timestamp without time zone,
    escalation_level integer DEFAULT 0,
    sla_deadline timestamp without time zone,
    sla_breach boolean DEFAULT false,
    resolved_at timestamp without time zone,
    resolved_by character varying,
    resolution_notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.support_tickets OWNER TO hptourism_user;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.system_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value jsonb NOT NULL,
    description text,
    category character varying(50) DEFAULT 'general'::character varying,
    updated_by character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.system_settings OWNER TO hptourism_user;

--
-- Name: ticket_actions; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.ticket_actions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_id character varying NOT NULL,
    actor_id character varying,
    actor_role character varying(30),
    action character varying(50) NOT NULL,
    previous_status character varying(30),
    new_status character varying(30),
    previous_priority character varying(20),
    new_priority character varying(20),
    previous_assignee character varying,
    new_assignee character varying,
    notes text,
    metadata jsonb,
    ip_address character varying(45),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ticket_actions OWNER TO hptourism_user;

--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.ticket_messages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_id character varying NOT NULL,
    sender_id character varying NOT NULL,
    sender_role character varying(30) NOT NULL,
    message text NOT NULL,
    attachments jsonb,
    is_internal boolean DEFAULT false,
    is_read boolean DEFAULT false,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ticket_messages OWNER TO hptourism_user;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.user_profiles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    full_name character varying(255) NOT NULL,
    gender character varying(10) NOT NULL,
    aadhaar_number character varying(12),
    mobile character varying(15) NOT NULL,
    email character varying(255),
    district character varying(100),
    tehsil character varying(100),
    block character varying(100),
    gram_panchayat character varying(100),
    urban_body character varying(200),
    ward character varying(50),
    address text,
    pincode character varying(10),
    telephone character varying(20),
    fax character varying(20),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_profiles OWNER TO hptourism_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    mobile character varying(15) NOT NULL,
    full_name text NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    username character varying(50),
    email character varying(255),
    alternate_phone character varying(15),
    designation character varying(100),
    department character varying(100),
    employee_id character varying(50),
    office_address text,
    office_phone character varying(15),
    role character varying(50) DEFAULT 'property_owner'::character varying NOT NULL,
    aadhaar_number character varying(12),
    district character varying(100),
    password text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    sso_id character varying(50),
    enabled_services jsonb DEFAULT '["homestay"]'::jsonb
);


ALTER TABLE public.users OWNER TO hptourism_user;

--
-- Data for Name: application_actions; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.application_actions (id, application_id, officer_id, action, previous_status, new_status, feedback, issues_found, created_at) FROM stdin;
bf5f7de1-c6b9-43be-a6f3-baa5835fa50b	f92123b1-9025-4152-9957-a3d35a388a9b	876f6ff4-8e8b-42cb-8927-e8d74399a947	forwarded_to_dtdo	legacy_rc_review	forwarded_to_dtdo	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.\n\nOverall Scrutiny Remarks (Optional)	\N	2026-01-04 13:35:04.679041
19d4f945-7408-4042-a8b2-29f6e00f1c5f	f92123b1-9025-4152-9957-a3d35a388a9b	18122a8d-04cb-4616-87f6-ca91e130b5b1	approved_bypass_inspection	forwarded_to_dtdo	approved	This will approve the application immediately without an inspection field visit.\n\nRemarks (Required)	\N	2026-01-04 16:57:17.666983
eecf3476-c36b-4dbb-ab05-3193faeb6eb9	2cd779b9-9004-43b8-b91f-78728a4174ff	5b5005d2-738d-45dd-8664-f53fd0544f3d	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A26A139612). Application submitted.	\N	2026-01-04 18:15:37.423458
88067473-b50a-4130-bb96-9b37d4a52f23	2cd779b9-9004-43b8-b91f-78728a4174ff	876f6ff4-8e8b-42cb-8927-e8d74399a947	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-04 18:30:25.79518
69b48d81-9775-40f4-beab-c99126ba8582	2cd779b9-9004-43b8-b91f-78728a4174ff	876f6ff4-8e8b-42cb-8927-e8d74399a947	reverted_by_da	under_scrutiny	reverted_to_applicant	Send Back to Applicant\nSpecify corrections required. DTDO authorization (OTP) is required to proceed.\n\nReason for Sending Back *	\N	2026-01-04 19:11:03.568131
532e10a1-a24f-477f-b0b3-7c7c17282c48	591c7126-d5e4-4665-952a-4da7a49bf6bb	876f6ff4-8e8b-42cb-8927-e8d74399a947	forwarded_to_dtdo	legacy_rc_review	forwarded_to_dtdo	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.\n\nOverall Scrutiny Remarks (Optional)	\N	2026-01-04 19:11:29.54211
65dfe564-52f0-4f5a-88e9-c87bb322a939	591c7126-d5e4-4665-952a-4da7a49bf6bb	18122a8d-04cb-4616-87f6-ca91e130b5b1	approved_bypass_inspection	forwarded_to_dtdo	approved	This will approve the application immediately without an inspection field visit.\n\nRemarks (Required)	\N	2026-01-04 19:12:57.380693
dd3fde9f-3923-4f6a-a146-64c48ca7747f	2cd779b9-9004-43b8-b91f-78728a4174ff	5b5005d2-738d-45dd-8664-f53fd0544f3d	correction_resubmitted	reverted_to_applicant	dtdo_review	I confirm that every issue highlighted by DA/DTDO has been fully addressed. I understand that my application may be rejected if the corrections remain unsatisfactory. (cycle 1)	\N	2026-01-04 19:14:07.560332
c41a1480-2337-44f2-8ac8-a3e828e6a6ee	2cd779b9-9004-43b8-b91f-78728a4174ff	18122a8d-04cb-4616-87f6-ca91e130b5b1	inspection_scheduled	dtdo_review	inspection_scheduled	Inspection scheduled for 1/7/2026. Instructions: Accept & Schedule Inspection\nSchedule the site inspection and assign a Dealing Assistant.\n\nInstructions for Inspection Team	\N	2026-01-04 19:14:34.153743
46417b6a-2552-4831-b528-d8a40be1c8cc	2cd779b9-9004-43b8-b91f-78728a4174ff	876f6ff4-8e8b-42cb-8927-e8d74399a947	inspection_acknowledged	inspection_scheduled	inspection_scheduled	Auto-acknowledged after inspection completion.	\N	2026-01-04 19:15:30.264699
7e008def-08af-41ce-8bc2-44b86f22adcb	2cd779b9-9004-43b8-b91f-78728a4174ff	876f6ff4-8e8b-42cb-8927-e8d74399a947	inspection_completed	inspection_scheduled	inspection_under_review	Reason for Early Inspection\nProvide context for DTDO on why the visit was advanced (minimum 15 characters).	\N	2026-01-04 19:15:30.269423
c2ba8e6c-c19e-4c88-98ba-5dbcc6fde8b3	2cd779b9-9004-43b8-b91f-78728a4174ff	18122a8d-04cb-4616-87f6-ca91e130b5b1	approved	inspection_under_review	approved	Certificate HP-HST-2026-73146 issued. Payment was already completed upfront.	\N	2026-01-04 19:16:06.260744
c3ae75d0-35ec-4176-85f3-52501ba923bc	648b914b-0eaa-4c64-a675-119ba3aef889	5b5005d2-738d-45dd-8664-f53fd0544f3d	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A26A139643). Application submitted.	\N	2026-01-04 19:20:06.925638
00558334-d54b-4711-b9cd-fadd718a2a19	648b914b-0eaa-4c64-a675-119ba3aef889	876f6ff4-8e8b-42cb-8927-e8d74399a947	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-04 19:22:23.889472
0b2246c3-4c8a-46c8-b2b0-34d9a5523d2a	648b914b-0eaa-4c64-a675-119ba3aef889	876f6ff4-8e8b-42cb-8927-e8d74399a947	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.\n\nOverall Scrutiny Remarks (Optional)	\N	2026-01-04 19:22:32.113419
361ce90b-394a-4db7-a4f1-26e2e0bc9798	648b914b-0eaa-4c64-a675-119ba3aef889	18122a8d-04cb-4616-87f6-ca91e130b5b1	inspection_scheduled	forwarded_to_dtdo	inspection_scheduled	Inspection scheduled for 1/8/2026. Instructions: Instructions for Inspection Team	\N	2026-01-04 19:23:01.181799
6d1e75bf-7fa2-4ad2-96fa-5aa781195c1e	648b914b-0eaa-4c64-a675-119ba3aef889	876f6ff4-8e8b-42cb-8927-e8d74399a947	inspection_acknowledged	inspection_scheduled	inspection_scheduled	Auto-acknowledged after inspection completion.	\N	2026-01-04 19:23:48.436034
e4136f2a-312e-4996-b281-23ea1a85fb25	648b914b-0eaa-4c64-a675-119ba3aef889	876f6ff4-8e8b-42cb-8927-e8d74399a947	inspection_completed	inspection_scheduled	inspection_under_review	Log Earlier Visit\nEnable if the physical inspection happened up to 7 days before the scheduled date.	\N	2026-01-04 19:23:48.442175
5626a350-179a-4f30-bd21-f6b5d4a199c1	648b914b-0eaa-4c64-a675-119ba3aef889	18122a8d-04cb-4616-87f6-ca91e130b5b1	approved	inspection_under_review	approved	Certificate HP-HST-2026-66339 issued. Payment was already completed upfront.	\N	2026-01-04 19:24:06.248347
06ecbffa-81ca-4999-bac4-ec38d002e606	bbb01f07-1af1-4265-a9ee-3b16185b733c	5b5005d2-738d-45dd-8664-f53fd0544f3d	owner_submitted	draft	submitted	Existing application finalized and submitted.	\N	2026-01-04 19:29:55.538185
6c342f66-41a1-46c8-bfc6-c504bc674e8c	bbb01f07-1af1-4265-a9ee-3b16185b733c	876f6ff4-8e8b-42cb-8927-e8d74399a947	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-04 19:30:15.466867
6ce3aad2-3433-403b-9adf-5b1ae094f824	bbb01f07-1af1-4265-a9ee-3b16185b733c	876f6ff4-8e8b-42cb-8927-e8d74399a947	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.\n\nOverall Scrutiny Remarks (Optional)	\N	2026-01-04 19:38:33.748006
f6955d78-a4d0-489e-992c-46001706e1c8	bbb01f07-1af1-4265-a9ee-3b16185b733c	18122a8d-04cb-4616-87f6-ca91e130b5b1	cancellation_approved	forwarded_to_dtdo	certificate_cancelled	Remarks (Required)	\N	2026-01-04 19:39:05.43183
337250da-3a65-43f9-bb35-479420e3da54	648b914b-0eaa-4c64-a675-119ba3aef889	18122a8d-04cb-4616-87f6-ca91e130b5b1	certificate_revoked	approved	certificate_cancelled	Revoked via request #HP-HS-2026-SML-000004	\N	2026-01-04 19:39:05.437167
1f61fe39-0e4e-46fa-a285-ec2e026bb990	bc9687c7-32f1-42b5-ba84-9f55dc4b404b	20b4f9ce-0ff3-4235-847c-29b2bded0d51	owner_submitted	draft	submitted	Existing application finalized and submitted.	\N	2026-01-05 04:09:48.224916
02d5c401-bd53-4492-a494-9d84988a9189	bc9687c7-32f1-42b5-ba84-9f55dc4b404b	876f6ff4-8e8b-42cb-8927-e8d74399a947	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-05 04:10:13.755224
61c801e4-353c-4a57-b55c-039a451aca3a	bc9687c7-32f1-42b5-ba84-9f55dc4b404b	876f6ff4-8e8b-42cb-8927-e8d74399a947	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Add your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	\N	2026-01-05 04:42:31.167473
ac4b614a-414b-4003-85c2-88331bab4141	bc9687c7-32f1-42b5-ba84-9f55dc4b404b	18122a8d-04cb-4616-87f6-ca91e130b5b1	approved_bypass_inspection	forwarded_to_dtdo	approved	This will approve the application immediately without an inspection field visit.	\N	2026-01-05 04:43:24.005689
269a6483-934f-4fc5-8e52-ddce5b2a0e15	08240a35-8245-45d0-8cf0-f1e25d66580d	a801a2d0-336e-45df-a1f2-950c7001817f	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A26A141088). Application submitted.	\N	2026-01-05 05:12:14.318573
74144e1d-1cfb-46c5-9713-3c7f0f209955	08240a35-8245-45d0-8cf0-f1e25d66580d	876f6ff4-8e8b-42cb-8927-e8d74399a947	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-05 05:13:02.399058
2eae5d09-5650-4413-bfe8-32d5a129d655	08240a35-8245-45d0-8cf0-f1e25d66580d	876f6ff4-8e8b-42cb-8927-e8d74399a947	reverted_by_da	under_scrutiny	reverted_to_applicant	Specify corrections required. DTDO authorization (OTP) is required to proceed.	\N	2026-01-05 05:23:02.616391
880d10b7-b5ea-4894-ac45-805eddfda8ae	08240a35-8245-45d0-8cf0-f1e25d66580d	a801a2d0-336e-45df-a1f2-950c7001817f	correction_resubmitted	reverted_to_applicant	dtdo_review	I confirm that every issue highlighted by DA/DTDO has been fully addressed. I understand that my application may be rejected if the corrections remain unsatisfactory. (cycle 1)	\N	2026-01-05 05:24:56.087669
eebeeb0c-e1e7-49d1-9aa8-24e1a78885b8	08240a35-8245-45d0-8cf0-f1e25d66580d	18122a8d-04cb-4616-87f6-ca91e130b5b1	inspection_scheduled	dtdo_review	inspection_scheduled	Inspection scheduled for 1/9/2026. Instructions: Accept & Schedule Inspection\nSchedule the site inspection and assign a Dealing Assistant.	\N	2026-01-05 05:27:17.731269
dae3d3c0-5ecd-43e1-8db5-2e78fc18fe4a	08240a35-8245-45d0-8cf0-f1e25d66580d	876f6ff4-8e8b-42cb-8927-e8d74399a947	inspection_acknowledged	inspection_scheduled	inspection_scheduled	Auto-acknowledged after inspection completion.	\N	2026-01-05 05:28:36.284866
3632c21d-8262-4dd1-bf3f-6d2df7677323	08240a35-8245-45d0-8cf0-f1e25d66580d	876f6ff4-8e8b-42cb-8927-e8d74399a947	inspection_completed	inspection_scheduled	inspection_under_review	Category Meets Standards\nDoes the property meet the standards for SILVER category?	\N	2026-01-05 05:28:36.28989
662621d7-50e0-4391-9d2c-d1f4682f4ebf	08240a35-8245-45d0-8cf0-f1e25d66580d	18122a8d-04cb-4616-87f6-ca91e130b5b1	approved	inspection_under_review	approved	Certificate HP-HST-2026-36933 issued. Payment was already completed upfront.	\N	2026-01-05 06:14:55.731772
804bb3ba-03e9-411b-af11-0847dd4a06a7	b891d186-598b-4b02-beed-e63d1ceb8e25	876f6ff4-8e8b-42cb-8927-e8d74399a947	forwarded_to_dtdo	legacy_rc_review	forwarded_to_dtdo	Add your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	\N	2026-01-05 06:46:05.468003
dd671b71-c651-4720-b5fa-234a0f212ece	b891d186-598b-4b02-beed-e63d1ceb8e25	18122a8d-04cb-4616-87f6-ca91e130b5b1	approved_bypass_inspection	forwarded_to_dtdo	approved	This will approve the application immediately without an inspection field visit.	\N	2026-01-05 06:58:19.872765
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.audit_logs (id, user_id, action, details, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.certificates (id, application_id, certificate_number, certificate_type, issued_date, valid_from, valid_upto, property_name, category, address, district, owner_name, owner_mobile, certificate_pdf_url, qr_code_data, digital_signature, issued_by, status, revocation_reason, revoked_by, revoked_date, renewal_reminder_sent, renewal_application_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: clarifications; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.clarifications (id, objection_id, application_id, submitted_by, submitted_date, clarification_text, supporting_documents, reviewed_by, reviewed_date, review_status, review_notes, updated_at) FROM stdin;
\.


--
-- Data for Name: ddo_codes; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.ddo_codes (id, district, ddo_code, ddo_description, treasury_code, is_active, created_at, updated_at, head1) FROM stdin;
ddo-chamba	Chamba	CHM00-532	D.T.D.O. CHAMBA	CHB	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238	1452-00-800-01
ddo-kullu	Kullu	KLU00-532	DEPUTY DIRECTOR TOURISM & CIVIL AVIATION, KULLU DHALPUR	KLU	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238	1452-00-800-01
ddo-kangra	Kangra	KNG00-532	DIV.TOURISM DEV.OFFICER(DTDO) DHARAMSALA	KGR	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238	1452-00-800-01
ddo-kinnaur	Kinnaur	KNR00-031	DISTRICT TOURISM DEVELOPMENT OFFICER KINNAUR AT RECKONG PEO	KNR	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238	1452-00-800-01
ddo-lahaul	Lahaul and Spiti	KZA00-011	PROJECT OFFICER ITDP KAZA	LSP	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238	1452-00-800-01
ddo-mandi	Mandi	MDI00-532	DIV. TOURISM DEV. OFFICER MANDI	MND	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238	1452-00-800-01
ddo-shimla	Shimla	SML00-532	DIVISIONAL TOURISM OFFICER SHIMLA	SML	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238	1452-00-800-01
ddo-hamirpur	Hamirpur	HMR00-053	DISTRICT TOURISM DEVELOPMENT OFFICE HAMIRPUR (UNA)	HMP	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238	1452-00-800-01
ddo-una	Una	HMR00-053	DISTRICT TOURISM DEVELOPMENT OFFICE HAMIRPUR (UNA)	UNA	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238	1452-00-800-01
ddo-sirmaur	Sirmaur	SMR00-055	DISTRICT TOURISM DEVELOPMENT OFFICE NAHAN	SMR	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238	1452-00-800-01
ddo-solan	Solan	SOL00-046	DTDO SOLAN	SLN	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238	1452-00-800-01
ddo-bilaspur	Bilaspur	CHM00-532	D.T.D.O. CHAMBA	BLP	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238	1452-00-800-01
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.documents (id, application_id, document_type, file_name, file_path, file_size, mime_type, upload_date, ai_verification_status, ai_confidence_score, ai_notes, is_verified, verification_status, verified_by, verification_date, verification_notes) FROM stdin;
3e58ad18-d364-44ad-9a06-44dd18b9123f	f92123b1-9025-4152-9957-a3d35a388a9b	legacy_certificate	Test_Doc01-Hindi.pdf	/api/local-object/download/ac1f0ec5-2b76-494d-9dda-01a3e16f42b8?type=document	61398	application/pdf	2026-01-04 13:34:13.559415	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 13:34:46.073	\N
92193374-9342-4c92-af1f-ff7a944ca4af	f92123b1-9025-4152-9957-a3d35a388a9b	owner_identity_proof	Test_Doc01-Hindi.pdf	/api/local-object/download/04538150-5bd6-4fa5-a763-e7e3107f4597?type=document	61398	application/pdf	2026-01-04 13:34:13.573329	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 13:34:46.076	\N
5aa90ace-4e02-413f-affd-e7086b5f0443	2cd779b9-9004-43b8-b91f-78728a4174ff	additional_document	view of Karsog valley.jpg	/api/local-object/download/d30308ae-af16-4d45-b478-8a746c797285?type=additional-document	425434	image/jpeg	2026-01-04 19:14:07.59278	\N	\N	\N	f	pending	\N	\N	\N
05c7dc6f-0b9a-4680-91fb-e6d08a7c37c0	2cd779b9-9004-43b8-b91f-78728a4174ff	additional_document	view of Kee monastery.jpg	/api/local-object/download/96e1af5e-3c7c-4fc2-9368-da54fd2119b5?type=additional-document	508854	image/jpeg	2026-01-04 19:14:07.595725	\N	\N	\N	f	pending	\N	\N	\N
348ad86f-138a-4545-a892-663fbf132b7c	2cd779b9-9004-43b8-b91f-78728a4174ff	additional_document	HP_Tourism_Security_Audit_Request_v3.pdf	/api/local-object/download/98abcea1-aa88-4686-9a09-aa7bb1abbf7f?type=additional-document	6658	application/pdf	2026-01-04 19:14:07.598892	\N	\N	\N	f	pending	\N	\N	\N
ce9d84f9-1075-4248-910d-846d2adcfe25	591c7126-d5e4-4665-952a-4da7a49bf6bb	legacy_certificate	HP-GEN-ORD-202510-28-001059.pdf	/api/local-object/download/18ef4b3b-fb2f-4297-adcb-1247d51b8a61?type=document	2753978	application/pdf	2026-01-04 18:20:14.078638	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:11:18.958	\N
c668c22d-fbfd-430a-811a-b722a26ee351	591c7126-d5e4-4665-952a-4da7a49bf6bb	owner_identity_proof	HP-GEN-ORD-202510-28-001059.pdf	/api/local-object/download/49ba9d24-5dcc-4e68-bf70-bf12b8223499?type=document	2753978	application/pdf	2026-01-04 18:20:14.085978	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:11:18.96	\N
ce5f97fb-b67c-4c6e-99e1-7ad89ee6c8a5	591c7126-d5e4-4665-952a-4da7a49bf6bb	legacy_certificate	HP-GEN-ORD-202510-28-001059.pdf	/api/local-object/download/18ef4b3b-fb2f-4297-adcb-1247d51b8a61?type=document	2753978	application/pdf	2026-01-04 18:28:34.921871	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:11:18.961	\N
5f6641ad-3322-4265-8709-31cc3a2f5e5d	591c7126-d5e4-4665-952a-4da7a49bf6bb	owner_identity_proof	HP-GEN-ORD-202510-28-001059.pdf	/api/local-object/download/49ba9d24-5dcc-4e68-bf70-bf12b8223499?type=document	2753978	application/pdf	2026-01-04 18:28:34.928142	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:11:18.962	\N
273b157d-af69-4dbe-bcb4-2c2627f54b24	2cd779b9-9004-43b8-b91f-78728a4174ff	revenue_papers	HP-GEN-ORD-202510-28-001059.pdf	/api/local-object/download/57ae25a2-6a63-4963-80e5-2387bdee3fe4?type=revenue-papers	2753978	application/pdf	2026-01-04 19:14:07.565806	\N	\N	\N	f	pending	\N	\N	\N
c7a85f0b-e3f2-4934-b93c-e3203ec29a2e	2cd779b9-9004-43b8-b91f-78728a4174ff	affidavit_section_29	HP-GEN-ORD-202510-28-001059.pdf	/api/local-object/download/ff732166-b0de-4ee4-b4f3-f56b4b6e8036?type=affidavit-section29	2753978	application/pdf	2026-01-04 19:14:07.570544	\N	\N	\N	f	pending	\N	\N	\N
2001a2a3-ebae-49d7-843b-0207e9b69ce4	2cd779b9-9004-43b8-b91f-78728a4174ff	undertaking_form_c	HP-GEN-ORD-202510-28-001059.pdf	/api/local-object/download/f8321ece-5b46-4aea-9801-f2f06bb1af8f?type=undertaking-form-c	2753978	application/pdf	2026-01-04 19:14:07.574677	\N	\N	\N	f	pending	\N	\N	\N
6fbbac33-b628-4e33-b426-3575cd35c7a5	2cd779b9-9004-43b8-b91f-78728a4174ff	property_photo	View from Haripurdhar (Sirmaur).jpg	/api/local-object/download/1a675657-b154-4fbd-8c90-a2f5707849be?type=property-photo	480003	image/jpeg	2026-01-04 19:14:07.578049	\N	\N	\N	f	pending	\N	\N	\N
cbd6d86f-0268-4f2d-a50d-5627260c62ac	2cd779b9-9004-43b8-b91f-78728a4174ff	property_photo	View from Kaumik village, Spiti.jpg	/api/local-object/download/bb66c07c-fbdf-450a-9e05-25f25e9d9d89?type=property-photo	514031	image/jpeg	2026-01-04 19:14:07.58184	\N	\N	\N	f	pending	\N	\N	\N
1fed3e12-59bf-44d0-9d95-2eb15d15fb5b	2cd779b9-9004-43b8-b91f-78728a4174ff	property_photo	view from Naddi village.jpg	/api/local-object/download/eaca8504-5fb5-4e63-8b7b-182f36b635b0?type=property-photo	400821	image/jpeg	2026-01-04 19:14:07.585988	\N	\N	\N	f	pending	\N	\N	\N
6dabc967-3ce7-4b6e-b155-4ba3a525772f	2cd779b9-9004-43b8-b91f-78728a4174ff	property_photo	view of Chitkul  valley.jpg	/api/local-object/download/5b833b34-121b-42d1-be0d-955432596e7b?type=property-photo	411316	image/jpeg	2026-01-04 19:14:07.589701	\N	\N	\N	f	pending	\N	\N	\N
cc580518-7d68-4203-98c9-eebd9b55941a	648b914b-0eaa-4c64-a675-119ba3aef889	revenue_papers	Test_Doc01-Hindi.pdf	/api/local-object/download/67232f5b-79ec-4c2a-892c-51f2fd1ab6e6?type=revenue-papers	61398	application/pdf	2026-01-04 19:20:06.930244	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:22:26.979	\N
0a50c93c-22d4-4c38-9cfc-8f934b2fdbde	648b914b-0eaa-4c64-a675-119ba3aef889	affidavit_section_29	Test_Doc01-Hindi.pdf	/api/local-object/download/9a562bcd-2c20-48bd-a687-95ef531c0423?type=affidavit-section29	61398	application/pdf	2026-01-04 19:20:06.930244	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:22:26.981	\N
d240f779-ca5c-4d6b-8367-beb5564e93b0	648b914b-0eaa-4c64-a675-119ba3aef889	undertaking_form_c	Test_Doc01-Hindi.pdf	/api/local-object/download/ee98d28b-d32a-40aa-b6d6-7f06af4c5458?type=undertaking-form-c	61398	application/pdf	2026-01-04 19:20:06.930244	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:22:26.982	\N
cc86ceea-5775-4190-8a10-93b6f114171f	648b914b-0eaa-4c64-a675-119ba3aef889	commercial_electricity_bill	Test_Doc01-Hindi.pdf	/api/local-object/download/3695e269-8acf-46f3-8e13-3ba4e1b11b6d?type=commercial-electricity-bill	61398	application/pdf	2026-01-04 19:20:06.930244	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:22:26.984	\N
4ae35f93-10b9-4554-b5fa-84a43a7cf3bf	648b914b-0eaa-4c64-a675-119ba3aef889	commercial_water_bill	Test_Doc01-Hindi.pdf	/api/local-object/download/5438f625-381b-4714-bf0a-1f6080561433?type=commercial-water-bill	61398	application/pdf	2026-01-04 19:20:06.930244	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:22:26.985	\N
05f1bf84-ece3-4516-ae47-dec9580e492b	648b914b-0eaa-4c64-a675-119ba3aef889	property_photo	519109575.jpg	/api/local-object/download/fa535538-aea8-4ab9-aeac-65224d125da8?type=property-photo	96524	image/jpeg	2026-01-04 19:20:06.930244	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:22:26.986	\N
3b66442b-c74f-4b17-b5a6-f66b1374c021	648b914b-0eaa-4c64-a675-119ba3aef889	property_photo	529253340.jpg	/api/local-object/download/1e61d8be-f0d8-410e-b4ee-151fc6ce842e?type=property-photo	13584	image/jpeg	2026-01-04 19:20:06.930244	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:22:26.987	\N
c1856344-f587-4133-93b3-5412cd299005	648b914b-0eaa-4c64-a675-119ba3aef889	property_photo	529253372.jpg	/api/local-object/download/870d007e-49c4-4c1b-ba59-97dcee76e073?type=property-photo	98782	image/jpeg	2026-01-04 19:20:06.930244	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:22:26.988	\N
7cb4e59c-c12d-4309-8f13-6131b3e0de74	08240a35-8245-45d0-8cf0-f1e25d66580d	revenue_papers	HP_Tourism_Security_Audit_Request_v3.pdf	/api/local-object/download/f62991df-b598-413f-9e2d-a9d19708e288?type=revenue-papers	6658	application/pdf	2026-01-05 05:24:56.091942	\N	\N	\N	f	pending	\N	\N	\N
179cd7bb-dc15-4f39-95c2-9c508bfe7ab7	08240a35-8245-45d0-8cf0-f1e25d66580d	affidavit_section_29	Test_Doc01-Hindi.pdf	/api/local-object/download/538293b2-f2a8-4acf-ba0f-9f0caeb93ac7?type=affidavit-section29	61398	application/pdf	2026-01-05 05:24:56.096012	\N	\N	\N	f	pending	\N	\N	\N
1e57fbc3-7d57-43ca-878d-5000f3383a56	08240a35-8245-45d0-8cf0-f1e25d66580d	undertaking_form_c	Test_Doc01-Hindi.pdf	/api/local-object/download/62679019-98a1-4895-9384-84377f516545?type=undertaking-form-c	61398	application/pdf	2026-01-05 05:24:56.099068	\N	\N	\N	f	pending	\N	\N	\N
97a6106c-9e36-442d-a3bb-32451b0f253e	08240a35-8245-45d0-8cf0-f1e25d66580d	property_photo	519109575.jpg	/api/local-object/download/adc1b906-186a-4af7-ba34-fa9f51d6a198?type=property-photo	96524	image/jpeg	2026-01-05 05:24:56.102134	\N	\N	\N	f	pending	\N	\N	\N
11514b98-1567-4c45-abcb-626d557e9dcd	08240a35-8245-45d0-8cf0-f1e25d66580d	property_photo	529253340.jpg	/api/local-object/download/acc357d9-b998-4e2b-8543-279d64faf1d7?type=property-photo	13584	image/jpeg	2026-01-05 05:24:56.10562	\N	\N	\N	f	pending	\N	\N	\N
0d474c67-4c4f-4222-ac15-a57e117b6b41	08240a35-8245-45d0-8cf0-f1e25d66580d	additional_document	Test_Doc01-Hindi.pdf	/api/local-object/download/77cfa216-9b85-430d-920c-0451b1204385?type=additional-document	61398	application/pdf	2026-01-05 05:24:56.108735	\N	\N	\N	f	pending	\N	\N	\N
85cd5d1f-a7c9-4e2e-b64d-1fbb80112e51	08240a35-8245-45d0-8cf0-f1e25d66580d	additional_document	529253398.jpg	/api/local-object/download/d463a38e-e9cd-43e6-8cba-8c347f8096eb?type=additional-document	117294	image/jpeg	2026-01-05 05:24:56.112786	\N	\N	\N	f	pending	\N	\N	\N
5d5a3cd8-3b2e-49d5-a982-11f90767e1a4	08240a35-8245-45d0-8cf0-f1e25d66580d	additional_document	529253417.jpg	/api/local-object/download/e5d59b61-ab8b-4b62-b287-a1406ecd61c9?type=additional-document	123434	image/jpeg	2026-01-05 05:24:56.116512	\N	\N	\N	f	pending	\N	\N	\N
91b5e5a6-f52a-4043-b880-8ceaecb7cc22	08240a35-8245-45d0-8cf0-f1e25d66580d	additional_document	Test_Doc01-Hindi.pdf	/api/local-object/download/0df2675b-80da-49b7-8444-55f36d112ec0?type=additional-document	61398	application/pdf	2026-01-05 05:24:56.11936	\N	\N	\N	f	pending	\N	\N	\N
c7c25b98-45b8-4005-8ebc-304a937e1dfb	b891d186-598b-4b02-beed-e63d1ceb8e25	legacy_certificate	Test_Doc01-Hindi.pdf	/api/local-object/download/3bb7b935-41d1-4ea6-aba3-2b5a7bc8e96e?type=document	61398	application/pdf	2026-01-05 06:45:37.466812	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-05 06:45:59.329	\N
83c8f8c0-c09b-4e64-ada0-bdd61f66b4b4	b891d186-598b-4b02-beed-e63d1ceb8e25	owner_identity_proof	Test_Doc01-Hindi.pdf	/api/local-object/download/837fcf1e-7a68-4c35-8ecf-4564b887f1b1?type=document	61398	application/pdf	2026-01-05 06:45:37.471844	\N	\N	\N	t	verified	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-05 06:45:59.332	\N
\.


--
-- Data for Name: grievance_audit_log; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.grievance_audit_log (id, grievance_id, action, old_value, new_value, performed_by, performed_at, ip_address, user_agent) FROM stdin;
4b0ce19a-81a9-417e-9dc2-a94b1e5b231c	3cb9b3a7-3dbf-4b2f-9992-a890740247d3	created	\N	Ticket GRV-2026-GUOYOY created (owner_grievance)	20b4f9ce-0ff3-4235-847c-29b2bded0d51	2026-01-04 13:33:11.449105	223.178.213.122	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0
39051adb-1496-44fa-a3e9-3cd819cd86b8	3cb9b3a7-3dbf-4b2f-9992-a890740247d3	status_changed	open	in_progress	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 16:29:38.700454	223.178.213.122	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0
4656bf8d-b2f0-4047-98df-09b6de4cadff	3cb9b3a7-3dbf-4b2f-9992-a890740247d3	priority_changed	medium	high	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 16:29:38.702922	223.178.213.122	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0
74fd867c-c186-4d02-b2c9-eb718864a2ab	3cb9b3a7-3dbf-4b2f-9992-a890740247d3	resolution_notes_updated	\N	Resolution notes updated	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 16:29:38.704434	223.178.213.122	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0
a79e4a04-05c6-471c-ae97-161cc3b63e0b	8c9d8df7-a991-49a0-9173-7c3fc8f41129	created	\N	Ticket INT-2026-M5ZTVT created (internal_ticket)	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 16:46:04.567704	223.178.213.122	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0
21b4db40-a559-4fec-b73c-fc9417ac0f19	4f5a5df6-c5b0-49a3-92eb-ccafb8664121	created	\N	Ticket INT-2026-GEL3RB created (internal_ticket)	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 16:47:13.093398	223.178.213.122	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0
da836350-291f-4de3-bc31-d98257a62469	8c9d8df7-a991-49a0-9173-7c3fc8f41129	resolution_notes_updated	\N	Resolution notes updated	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 16:47:51.94371	223.178.213.122	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0
c6785324-1fa2-4b53-a5a4-ad077f8ab513	8c9d8df7-a991-49a0-9173-7c3fc8f41129	status_changed	open	resolved	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 16:48:35.266923	223.178.213.122	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0
9d90c860-4cc9-420a-b8c4-673b27083d09	8c9d8df7-a991-49a0-9173-7c3fc8f41129	comment_added	\N	Comment added by DA Shimla	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-05 06:31:29.03752	223.178.213.122	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36
\.


--
-- Data for Name: grievance_comments; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.grievance_comments (id, grievance_id, user_id, comment, is_internal, created_at) FROM stdin;
523b8c7f-538b-4a8b-b92d-fcc6065899da	8c9d8df7-a991-49a0-9173-7c3fc8f41129	876f6ff4-8e8b-42cb-8927-e8d74399a947	Test	f	2026-01-05 06:31:29.032713
\.


--
-- Data for Name: grievances; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.grievances (id, ticket_number, ticket_type, user_id, application_id, category, priority, status, subject, description, assigned_to, resolution_notes, attachments, last_comment_at, last_read_by_owner, last_read_by_officer, created_at, updated_at, resolved_at) FROM stdin;
3cb9b3a7-3dbf-4b2f-9992-a890740247d3	GRV-2026-GUOYOY	owner_grievance	20b4f9ce-0ff3-4235-847c-29b2bded0d51	\N	payment	high	in_progress	Testing Grievance	Testing Testing and Testing only	\N	Yeah, the complaint is being investigated.	\N	\N	2026-01-04 13:33:11.445	2026-01-04 16:46:40.327	2026-01-04 13:33:11.445904	2026-01-04 16:32:51.766	\N
4f5a5df6-c5b0-49a3-92eb-ccafb8664121	INT-2026-GEL3RB	internal_ticket	18122a8d-04cb-4616-87f6-ca91e130b5b1	\N	policy_query	medium	open	Testing	OK agreed we goto check this out??	\N	\N	\N	\N	\N	2026-01-04 16:48:50.147	2026-01-04 16:47:13.091253	2026-01-04 16:47:13.091253	\N
8c9d8df7-a991-49a0-9173-7c3fc8f41129	INT-2026-M5ZTVT	internal_ticket	18122a8d-04cb-4616-87f6-ca91e130b5b1	\N	policy_query	medium	resolved	This is interna Matter for discussion.	Testing internal matter and discussion between da dtdo.	\N	This is testig not.	\N	2026-01-05 06:31:29.035	\N	2026-01-05 06:31:29.148	2026-01-04 16:46:04.5646	2026-01-05 06:31:29.035	2026-01-04 16:48:35.264
\.


--
-- Data for Name: himkosh_transactions; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.himkosh_transactions (id, application_id, dept_ref_no, app_ref_no, total_amount, tender_by, merchant_code, dept_id, service_code, ddo, head1, amount1, head2, amount2, head3, amount3, head4, amount4, head10, amount10, period_from, period_to, encrypted_request, request_checksum, ech_txn_id, bank_cin, bank_name, payment_date, status, status_cd, response_checksum, is_double_verified, double_verification_date, double_verification_data, challan_print_url, transaction_status, initiated_at, responded_at, verified_at, created_at, updated_at, portal_base_url, is_archived) FROM stdin;
\.


--
-- Data for Name: homestay_applications; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.homestay_applications (id, user_id, application_number, property_name, category, location_type, total_rooms, district, district_other, tehsil, tehsil_other, block, block_other, gram_panchayat, gram_panchayat_other, urban_body, urban_body_other, ward, address, pincode, telephone, fax, latitude, longitude, owner_name, owner_gender, owner_mobile, owner_email, owner_aadhaar, property_ownership, proposed_room_rate, project_type, property_area, single_bed_rooms, single_bed_room_size, single_bed_room_rate, double_bed_rooms, double_bed_room_size, double_bed_room_rate, family_suites, family_suite_size, family_suite_rate, attached_washrooms, gstin, selected_category, average_room_rate, highest_room_rate, lowest_room_rate, certificate_validity_years, is_pangi_sub_division, distance_airport, distance_railway, distance_city_center, distance_shopping, distance_bus_stand, lobby_area, dining_area, parking_area, eco_friendly_facilities, differently_abled_facilities, fire_equipment_details, nearest_hospital, amenities, rooms, base_fee, total_before_discounts, validity_discount, female_owner_discount, pangi_discount, total_discount, total_fee, per_room_fee, gst_amount, status, current_stage, current_page, district_officer_id, district_review_date, district_notes, da_id, da_review_date, da_forwarded_date, state_officer_id, state_review_date, state_notes, dtdo_id, dtdo_review_date, dtdo_remarks, rejection_reason, clarification_requested, site_inspection_scheduled_date, site_inspection_completed_date, site_inspection_officer_id, site_inspection_notes, site_inspection_outcome, site_inspection_findings, ownership_proof_url, aadhaar_card_url, pan_card_url, gst_certificate_url, fire_safety_noc_url, pollution_clearance_url, building_plan_url, property_photos_urls, documents, certificate_number, certificate_issued_date, certificate_expiry_date, submitted_at, approved_at, created_at, updated_at, single_bed_beds, double_bed_beds, family_suite_beds, application_kind, parent_application_id, parent_application_number, parent_certificate_number, inherited_certificate_valid_upto, service_context, service_notes, service_requested_at, guardian_name, da_remarks, correction_submission_count, application_type, water_sports_data, adventure_sports_data, guardian_relation, property_area_unit, key_location_highlight1, key_location_highlight2, nearby_attractions, mandatory_checklist, desirable_checklist, revert_count, payment_status, payment_id, payment_amount, payment_date, refund_date, refund_reason, form_completion_time_seconds) FROM stdin;
2cd779b9-9004-43b8-b91f-78728a4174ff	5b5005d2-738d-45dd-8664-f53fd0544f3d	HP-HS-2026-SML-000002	Test Homestay	silver	mc	4	Shimla	\N	Chaupal	\N	\N	\N			Village AAA			Test Property  \nAddress	171002		\N	\N	\N	Test AAA	female	7777777712	test@test.com	777777777712	owned	0.00	new_project	5.00	4	7000.00	2500.00	0	\N	0.00	0	\N	0.00	4		silver	\N	\N	\N	3	f	\N	\N	\N	\N	\N	\N	\N				Fire Safety Equipment Details (Annexure-I #6g) *		{}	\N	8000.00	24000.00	2400.00	1200.00	0.00	3600.00	20400.00	0.00	0.00	superseded	inspection_completed	6	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 19:16:06.256	Superseded by application HP-HS-2026-SML-000003	\N	\N	\N	\N	\N	\N	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 19:14:34.146	Accept & Schedule Inspection\nSchedule the site inspection and assign a Dealing Assistant.\n\nInstructions for Inspection Team	\N	\N	\N	2026-01-04 19:15:30.265	\N	Reason for Early Inspection\nProvide context for DTDO on why the visit was advanced (minimum 15 characters).	recommended	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "9e738e70-f9e4-4cd0-9d43-9e5ea1fb1860", "url": "/api/local-object/download/57ae25a2-6a63-4963-80e5-2387bdee3fe4?type=revenue-papers", "name": "HP-GEN-ORD-202510-28-001059.pdf", "type": "revenue_papers", "fileName": "HP-GEN-ORD-202510-28-001059.pdf", "filePath": "/api/local-object/download/57ae25a2-6a63-4963-80e5-2387bdee3fe4?type=revenue-papers", "fileSize": 2753978, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "0b3e96d1-f5af-41eb-8555-9e70861fec65", "url": "/api/local-object/download/ff732166-b0de-4ee4-b4f3-f56b4b6e8036?type=affidavit-section29", "name": "HP-GEN-ORD-202510-28-001059.pdf", "type": "affidavit_section_29", "fileName": "HP-GEN-ORD-202510-28-001059.pdf", "filePath": "/api/local-object/download/ff732166-b0de-4ee4-b4f3-f56b4b6e8036?type=affidavit-section29", "fileSize": 2753978, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "bf0df635-66ec-4ac8-9e94-fa8e48e28811", "url": "/api/local-object/download/f8321ece-5b46-4aea-9801-f2f06bb1af8f?type=undertaking-form-c", "name": "HP-GEN-ORD-202510-28-001059.pdf", "type": "undertaking_form_c", "fileName": "HP-GEN-ORD-202510-28-001059.pdf", "filePath": "/api/local-object/download/f8321ece-5b46-4aea-9801-f2f06bb1af8f?type=undertaking-form-c", "fileSize": 2753978, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "446a4bb3-20eb-44ea-89a9-416e26fc4d39", "url": "/api/local-object/download/1a675657-b154-4fbd-8c90-a2f5707849be?type=property-photo", "name": "View from Haripurdhar (Sirmaur).jpg", "type": "property_photo", "fileName": "View from Haripurdhar (Sirmaur).jpg", "filePath": "/api/local-object/download/1a675657-b154-4fbd-8c90-a2f5707849be?type=property-photo", "fileSize": 480003, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "d7622c03-4e9b-4a71-a60d-58cbf7853c4f", "url": "/api/local-object/download/bb66c07c-fbdf-450a-9e05-25f25e9d9d89?type=property-photo", "name": "View from Kaumik village, Spiti.jpg", "type": "property_photo", "fileName": "View from Kaumik village, Spiti.jpg", "filePath": "/api/local-object/download/bb66c07c-fbdf-450a-9e05-25f25e9d9d89?type=property-photo", "fileSize": 514031, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "d2e984d5-a0ea-4f17-82fd-e786417e6f97", "url": "/api/local-object/download/eaca8504-5fb5-4e63-8b7b-182f36b635b0?type=property-photo", "name": "view from Naddi village.jpg", "type": "property_photo", "fileName": "view from Naddi village.jpg", "filePath": "/api/local-object/download/eaca8504-5fb5-4e63-8b7b-182f36b635b0?type=property-photo", "fileSize": 400821, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "466a7640-22b6-4f23-b51d-99fe217534ba", "url": "/api/local-object/download/5b833b34-121b-42d1-be0d-955432596e7b?type=property-photo", "name": "view of Chitkul  valley.jpg", "type": "property_photo", "fileName": "view of Chitkul  valley.jpg", "filePath": "/api/local-object/download/5b833b34-121b-42d1-be0d-955432596e7b?type=property-photo", "fileSize": 411316, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "2f755b91-7245-48af-879c-cbdc888fc9e6", "url": "/api/local-object/download/d30308ae-af16-4d45-b478-8a746c797285?type=additional-document", "name": "view of Karsog valley.jpg", "type": "additional_document", "fileName": "view of Karsog valley.jpg", "filePath": "/api/local-object/download/d30308ae-af16-4d45-b478-8a746c797285?type=additional-document", "fileSize": 425434, "mimeType": "image/jpeg", "documentType": "additional_document"}, {"id": "71ff3986-21b6-45ed-ab00-2d95dcd4a8ef", "url": "/api/local-object/download/96e1af5e-3c7c-4fc2-9368-da54fd2119b5?type=additional-document", "name": "view of Kee monastery.jpg", "type": "additional_document", "fileName": "view of Kee monastery.jpg", "filePath": "/api/local-object/download/96e1af5e-3c7c-4fc2-9368-da54fd2119b5?type=additional-document", "fileSize": 508854, "mimeType": "image/jpeg", "documentType": "additional_document"}, {"id": "eb2d5eb4-2f3f-4f41-8b5a-5277047c3688", "url": "/api/local-object/download/98abcea1-aa88-4686-9a09-aa7bb1abbf7f?type=additional-document", "name": "HP_Tourism_Security_Audit_Request_v3.pdf", "type": "additional_document", "fileName": "HP_Tourism_Security_Audit_Request_v3.pdf", "filePath": "/api/local-object/download/98abcea1-aa88-4686-9a09-aa7bb1abbf7f?type=additional-document", "fileSize": 6658, "mimeType": "application/pdf", "documentType": "additional_document"}]	HP-HST-2026-73146	2026-01-04 19:16:06.256	2027-01-04 19:16:06.256	2026-01-04 19:14:07.553	2026-01-04 19:16:06.256	2026-01-04 18:10:47.046778	2026-01-04 19:24:06.244	1	2	4	new_registration	\N	\N	\N	\N	\N	\N	\N	Test Test	\N	1	homestay	\N	\N	d_o	kanal	\N	\N	{}	{"1": true, "2": true, "3": true, "4": true, "5": true, "6": true, "7": true, "8": true, "9": true, "10": true, "11": true, "12": true, "13": true, "14": true, "15": true, "16": true, "17": true, "18": true}	\N	1	paid	A26A139612	1.00	2026-01-04 00:00:00	\N	\N	\N
bbb01f07-1af1-4265-a9ee-3b16185b733c	5b5005d2-738d-45dd-8664-f53fd0544f3d	HP-HS-2026-SML-000004	Test Homestay	gold	mc	4	Shimla	\N	Chaupal	\N	\N	\N	\N	\N	Village AAA	\N	\N	Test Property  \nAddress	171002	\N	\N	\N	\N	Test AAA	male	7777777712	test@test.com	777777777712	owned	0.00	existing_property	5.00	4	\N	5500.00	0	\N	0.00	0	\N	0.00	4	222222222222222	gold	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Fire Safety Equipment Details (Annexure-I #6g) *	\N	{"cctv": true, "fireSafety": true}	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	certificate_cancelled	\N	4	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 19:39:05.424	Remarks (Required)	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:38:33.74	2026-01-04 19:38:33.74	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	2026-01-04 19:39:05.424	2026-01-04 19:29:55.528	2026-01-04 19:39:05.424	2026-01-04 19:25:03.889291	2026-01-04 19:39:05.425	1	2	4	cancel_certificate	648b914b-0eaa-4c64-a675-119ba3aef889	HP-HS-2026-SML-000003	HP-HST-2026-66339	\N	\N	\N	\N	Test Test	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.\n\nOverall Scrutiny Remarks (Optional)	0	homestay	\N	\N	father	kanal	\N	\N	{}	{"1": true, "2": true, "7": true}	\N	0	pending	\N	\N	\N	\N	\N	221
bc9687c7-32f1-42b5-ba84-9f55dc4b404b	20b4f9ce-0ff3-4235-847c-29b2bded0d51	HP-HS-2026-SML-000005	Test Homestay	silver	gp	1	Shimla	\N	Chaupal	\N	\N	\N	\N	\N	\N	\N	\N	Test Property  \nAddress	171205	\N	\N	\N	\N	Test BBB	male	7777777711	test@test.com	777777777711	owned	1500.00	existing_property	120.00	1	\N	1500.00	0	\N	0.00	0	\N	0.00	1	\N	silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"cctv": false, "fireSafety": false}	[{"size": 0, "count": 4, "roomType": "Declared Rooms"}]	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	approved	\N	6	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-05 04:43:23.992	This will approve the application immediately without an inspection field visit.	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-05 04:42:31.156	2026-01-05 04:42:31.156	\N	\N	\N	18122a8d-04cb-4616-87f6-ca91e130b5b1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	HP-HST-2026-45669	2026-01-05 04:43:23.992	2027-01-05 04:43:23.992	2026-01-05 04:09:48.203	2026-01-05 04:43:23.992	2026-01-05 04:00:12.868151	2026-01-05 04:43:23.992	1	2	4	delete_rooms	f92123b1-9025-4152-9957-a3d35a388a9b	LG-HS-2026-SML-000001	HP-HST-2026-30076	2027-01-04 16:57:17.656	{"renewalWindow": {"end": "2027-01-04T16:57:17.656Z", "start": "2026-10-06T16:57:17.656Z"}, "requestedRooms": {"total": 3, "double": 0, "family": 0, "single": 3}, "requiresPayment": false, "requestedDeletions": [{"count": 1, "roomType": "single"}], "requestedRoomDelta": -1, "inheritsCertificateExpiry": "2027-01-04T16:57:17.656Z"}	\N	2026-01-05 04:00:12.863	Test	Add your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	0	homestay	\N	\N	father	sqm	\N	\N	{}	{"1": true, "2": true, "7": true}	\N	0	pending	\N	\N	\N	\N	\N	337
08240a35-8245-45d0-8cf0-f1e25d66580d	a801a2d0-336e-45df-a1f2-950c7001817f	HP-HS-2026-SML-000006	Test Property 1	silver	mc	2	Shimla	\N	Chaupal	\N	\N	\N			Shimla			Sondh Niwas, Near Saw Mill,\nLower Lakkar Bazar,	171001		\N	\N	\N	Test AAA	female	8888888811	test@test.com	888888888811	owned	0.00	new_project	5.00	1	700.00	1500.00	1	1500.00	2500.00	0	\N	0.00	2		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N				Fire Safety Equipment Details (Annexure-I #6g) *		{}	\N	8000.00	8000.00	0.00	400.00	0.00	400.00	7600.00	0.00	0.00	approved	inspection_completed	6	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-05 06:14:55.724	RC Approval\nThe owner will be allowed to proceed with payment.\n\nRemarks (Optional)	\N	\N	\N	\N	\N	\N	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-05 05:27:17.724	Accept & Schedule Inspection\nSchedule the site inspection and assign a Dealing Assistant.	\N	\N	\N	2026-01-05 05:28:36.285	\N	Category Meets Standards\nDoes the property meet the standards for SILVER category?	recommended	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "3e543d2f-f006-48b1-a1d1-f430e76e1403", "url": "/api/local-object/download/f62991df-b598-413f-9e2d-a9d19708e288?type=revenue-papers", "name": "HP_Tourism_Security_Audit_Request_v3.pdf", "type": "revenue_papers", "fileName": "HP_Tourism_Security_Audit_Request_v3.pdf", "filePath": "/api/local-object/download/f62991df-b598-413f-9e2d-a9d19708e288?type=revenue-papers", "fileSize": 6658, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "e9e9add7-3b90-4412-a993-2519e5be059e", "url": "/api/local-object/download/538293b2-f2a8-4acf-ba0f-9f0caeb93ac7?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/538293b2-f2a8-4acf-ba0f-9f0caeb93ac7?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "a502cd74-b6a1-4cf6-b284-811dc32cac33", "url": "/api/local-object/download/62679019-98a1-4895-9384-84377f516545?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/62679019-98a1-4895-9384-84377f516545?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "e35b926a-6c1f-4bd4-a208-40d5ef8dbc9c", "url": "/api/local-object/download/adc1b906-186a-4af7-ba34-fa9f51d6a198?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/adc1b906-186a-4af7-ba34-fa9f51d6a198?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "0ce1902b-73e5-49b6-840f-f5edac17a2dd", "url": "/api/local-object/download/acc357d9-b998-4e2b-8543-279d64faf1d7?type=property-photo", "name": "529253340.jpg", "type": "property_photo", "fileName": "529253340.jpg", "filePath": "/api/local-object/download/acc357d9-b998-4e2b-8543-279d64faf1d7?type=property-photo", "fileSize": 13584, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "f6f01771-f286-4acc-b44a-7ad09887af2e", "url": "/api/local-object/download/77cfa216-9b85-430d-920c-0451b1204385?type=additional-document", "name": "Test_Doc01-Hindi.pdf", "type": "additional_document", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/77cfa216-9b85-430d-920c-0451b1204385?type=additional-document", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "additional_document"}, {"id": "54fdb881-5040-417e-afc9-bc7217713169", "url": "/api/local-object/download/d463a38e-e9cd-43e6-8cba-8c347f8096eb?type=additional-document", "name": "529253398.jpg", "type": "additional_document", "fileName": "529253398.jpg", "filePath": "/api/local-object/download/d463a38e-e9cd-43e6-8cba-8c347f8096eb?type=additional-document", "fileSize": 117294, "mimeType": "image/jpeg", "documentType": "additional_document"}, {"id": "973a4d90-ea0b-4fd6-b36d-55b9c5e7a9da", "url": "/api/local-object/download/e5d59b61-ab8b-4b62-b287-a1406ecd61c9?type=additional-document", "name": "529253417.jpg", "type": "additional_document", "fileName": "529253417.jpg", "filePath": "/api/local-object/download/e5d59b61-ab8b-4b62-b287-a1406ecd61c9?type=additional-document", "fileSize": 123434, "mimeType": "image/jpeg", "documentType": "additional_document"}, {"id": "71e24a5a-5e3f-4f06-a1e1-55f7af8f6f5c", "url": "/api/local-object/download/0df2675b-80da-49b7-8444-55f36d112ec0?type=additional-document", "name": "Test_Doc01-Hindi.pdf", "type": "additional_document", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/0df2675b-80da-49b7-8444-55f36d112ec0?type=additional-document", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "additional_document"}]	HP-HST-2026-36933	2026-01-05 06:14:55.724	2027-01-05 06:14:55.724	2026-01-05 05:24:56.081	2026-01-05 06:14:55.724	2026-01-05 05:07:48.639961	2026-01-05 06:14:55.724	1	2	4	new_registration	\N	\N	\N	\N	\N	\N	\N	Test Owner 5	\N	1	homestay	\N	\N	d_o	kanal	\N	\N	{}	{"1": true, "2": true, "3": true, "4": true, "5": true, "6": true, "7": true, "8": true, "9": true, "10": true, "11": true, "12": true, "13": true, "14": true, "15": true, "16": true, "17": true, "18": true}	\N	1	paid	A26A141088	1.00	2026-01-05 00:00:00	\N	\N	\N
591c7126-d5e4-4665-952a-4da7a49bf6bb	81dff758-3726-43dc-9d59-41ef0f2eda2a	LG-HS-2026-SML-000002	Test Homestay	silver	gp	4	Shimla	\N	Chaupal	\N	\N	\N	\N	\N	\N	\N	\N	Test Property  \nAddress	171205	\N	\N	\N	\N	Test  BBB	other	7777777713	test@test.com	777777777713	owned	\N	existing_property	120.00	4	\N	\N	0	\N	\N	0	\N	\N	4	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"size": 0, "count": 4, "roomType": "Declared Rooms"}]	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	approved	legacy_rc_review	1	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 19:12:57.375	This will approve the application immediately without an inspection field visit.\n\nRemarks (Required)	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:11:29.537	2026-01-04 19:11:29.537	\N	\N	\N	18122a8d-04cb-4616-87f6-ca91e130b5b1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	HP-HST-2026-11077	2026-01-04 19:12:57.375	2027-01-04 19:12:57.375	2026-01-04 18:28:34.913	2026-01-04 19:12:57.375	2026-01-04 18:20:14.061	2026-01-04 19:12:57.375	1	2	4	renewal	\N	17/1655/2025-DTDSO-SML	17/1655/2025-DTDSO-SML	\N	{"requestedRooms": {"total": 4}, "requiresPayment": false, "legacyOnboarding": true, "legacyGuardianName": "Owner XXX", "inheritsCertificateExpiry": "2027-01-01T00:00:00.000Z"}	Existing owner onboarding request captured on 1/4/2026 with RC #17/1655/2025-DTDSO-SML.	\N	Owner XXX	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.\n\nOverall Scrutiny Remarks (Optional)	0	homestay	\N	\N	father	sqm	\N	\N	\N	\N	\N	0	pending	\N	\N	\N	\N	\N	\N
f92123b1-9025-4152-9957-a3d35a388a9b	20b4f9ce-0ff3-4235-847c-29b2bded0d51	LG-HS-2026-SML-000001	Test Homestay	silver	gp	4	Shimla	\N	Chaupal	\N	\N	\N	\N	\N	\N	\N	\N	Test Property  \nAddress	171205	\N	\N	\N	\N	Test  BBB	other	7777777711	test@test.com	777777777711	owned	1500.00	existing_property	120.00	4	\N	1500.00	0	\N	2500.00	0	\N	\N	4	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"size": 0, "count": 4, "roomType": "Declared Rooms"}]	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	superseded	legacy_rc_review	1	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 16:57:17.656	Superseded by application HP-HS-2026-SML-000005	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 13:35:04.671	2026-01-04 13:35:04.671	\N	\N	\N	18122a8d-04cb-4616-87f6-ca91e130b5b1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	HP-HST-2026-30076	2026-01-04 16:57:17.656	2027-01-04 16:57:17.656	2026-01-04 13:34:13.538	2026-01-04 16:57:17.656	2026-01-04 13:34:13.538	2026-01-05 04:43:23.999	1	2	4	renewal	\N	16/1655/2025-DTDSO-SML	16/1655/2025-DTDSO-SML	\N	{"requestedRooms": {"total": 4}, "requiresPayment": false, "legacyOnboarding": true, "legacyGuardianName": "Test", "inheritsCertificateExpiry": "2029-01-01T00:00:00.000Z"}	Existing owner onboarding request captured on 1/4/2026 with RC #16/1655/2025-DTDSO-SML.	\N	Test	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.\n\nOverall Scrutiny Remarks (Optional)	0	homestay	\N	\N	father	sqm	\N	\N	\N	\N	\N	0	pending	\N	\N	\N	\N	\N	\N
b891d186-598b-4b02-beed-e63d1ceb8e25	56a9b001-bfce-4c86-ab8b-42b07c735f1a	LG-HS-2026-SML-000003	Draft Homestay 31	silver	gp	1	Shimla	\N	Chaupal	\N	\N	\N	\N	\N	\N	\N	\N	Sondh Niwas, Near Saw Mill,\nLower Lakkar Bazar,	1717001	\N	\N	\N	\N	Test  GGG	other	6666666631	test@test.com	666666666663	owned	\N	existing_property	50.00	1	\N	\N	0	\N	\N	0	\N	\N	1	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"size": 0, "count": 1, "roomType": "Declared Rooms"}]	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	approved	legacy_rc_review	1	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-05 06:58:19.867	This will approve the application immediately without an inspection field visit.	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-05 06:46:05.462	2026-01-05 06:46:05.462	\N	\N	\N	18122a8d-04cb-4616-87f6-ca91e130b5b1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	HP-HST-2026-67886	2026-01-05 06:58:19.867	2027-01-05 06:58:19.867	2026-01-05 06:45:37.455	2026-01-05 06:58:19.867	2026-01-05 06:45:37.455	2026-01-05 06:58:19.867	1	2	4	renewal	\N	11-1558/2025-DTDO-SML	11-1558/2025-DTDO-SML	\N	{"note": "Additional Notes (optional)", "requestedRooms": {"total": 1}, "requiresPayment": false, "legacyOnboarding": true, "legacyGuardianName": "Subhash Thakur", "inheritsCertificateExpiry": "2027-01-02T00:00:00.000Z"}	Additional Notes (optional)	\N	Subhash Thakur	Add your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	0	homestay	\N	\N	father	sqm	\N	\N	\N	\N	\N	0	pending	\N	\N	\N	\N	\N	\N
648b914b-0eaa-4c64-a675-119ba3aef889	5b5005d2-738d-45dd-8664-f53fd0544f3d	HP-HS-2026-SML-000003	Test Homestay	gold	mc	4	Shimla	\N	Chaupal	\N	\N	\N			Village AAA			Test Property  \nAddress	171002		\N	\N	\N	Test AAA	male	7777777712	test@test.com	777777777712	owned	0.00	existing_property	5.00	4	\N	5500.00	0	\N	0.00	0	\N	0.00	4	222222222222222	gold	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N				Fire Safety Equipment Details (Annexure-I #6g) *		{"cctv": true, "fireSafety": true}	\N	12000.00	12000.00	0.00	0.00	0.00	0.00	12000.00	0.00	0.00	certificate_cancelled	inspection_completed	6	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 19:24:06.239	Certificate revoked via cancellation request #HP-HS-2026-SML-000004. Remarks: Remarks (Required)	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:22:32.107	2026-01-04 19:22:32.107	\N	\N	\N	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 19:23:01.174	Instructions for Inspection Team	\N	\N	\N	2026-01-04 19:23:48.437	\N	Log Earlier Visit\nEnable if the physical inspection happened up to 7 days before the scheduled date.	recommended	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "cc4d005e-9e68-40d1-9dd4-e3551a34443d", "url": "/api/local-object/download/67232f5b-79ec-4c2a-892c-51f2fd1ab6e6?type=revenue-papers", "name": "Test_Doc01-Hindi.pdf", "type": "revenue_papers", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/67232f5b-79ec-4c2a-892c-51f2fd1ab6e6?type=revenue-papers", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "751c6993-6e26-4407-b888-f2f872fa5d99", "url": "/api/local-object/download/9a562bcd-2c20-48bd-a687-95ef531c0423?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/9a562bcd-2c20-48bd-a687-95ef531c0423?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "5e9d1fdf-e516-4c06-a5d0-1992f14e4123", "url": "/api/local-object/download/ee98d28b-d32a-40aa-b6d6-7f06af4c5458?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/ee98d28b-d32a-40aa-b6d6-7f06af4c5458?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "e5eeca8c-526f-4370-b5e9-1d565772cdf7", "url": "/api/local-object/download/3695e269-8acf-46f3-8e13-3ba4e1b11b6d?type=commercial-electricity-bill", "name": "Test_Doc01-Hindi.pdf", "type": "commercial_electricity_bill", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/3695e269-8acf-46f3-8e13-3ba4e1b11b6d?type=commercial-electricity-bill", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "commercial_electricity_bill"}, {"id": "fd83b165-7705-4b6e-aba4-57d5301ebb3a", "url": "/api/local-object/download/5438f625-381b-4714-bf0a-1f6080561433?type=commercial-water-bill", "name": "Test_Doc01-Hindi.pdf", "type": "commercial_water_bill", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/5438f625-381b-4714-bf0a-1f6080561433?type=commercial-water-bill", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "commercial_water_bill"}, {"id": "5948b88b-b23f-4511-9b8b-3b6b8cd0c0a6", "url": "/api/local-object/download/fa535538-aea8-4ab9-aeac-65224d125da8?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/fa535538-aea8-4ab9-aeac-65224d125da8?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "9101fae2-d37f-465b-8cf6-5ebac50779d0", "url": "/api/local-object/download/1e61d8be-f0d8-410e-b4ee-151fc6ce842e?type=property-photo", "name": "529253340.jpg", "type": "property_photo", "fileName": "529253340.jpg", "filePath": "/api/local-object/download/1e61d8be-f0d8-410e-b4ee-151fc6ce842e?type=property-photo", "fileSize": 13584, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "17622898-b3fb-4699-9a4f-ca6b284d8c75", "url": "/api/local-object/download/870d007e-49c4-4c1b-ba59-97dcee76e073?type=property-photo", "name": "529253372.jpg", "type": "property_photo", "fileName": "529253372.jpg", "filePath": "/api/local-object/download/870d007e-49c4-4c1b-ba59-97dcee76e073?type=property-photo", "fileSize": 98782, "mimeType": "image/jpeg", "documentType": "property_photo"}]	HP-HST-2026-66339	2026-01-04 19:24:06.239	2026-01-04 19:39:05.433	2026-01-04 19:20:06.923	2026-01-04 19:24:06.239	2026-01-04 19:16:27.479467	2026-01-04 19:39:05.433	1	2	4	change_category	2cd779b9-9004-43b8-b91f-78728a4174ff	HP-HS-2026-SML-000002	HP-HST-2026-73146	\N	\N	\N	\N	Test Test	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.\n\nOverall Scrutiny Remarks (Optional)	0	homestay	\N	\N	s_o	kanal	\N	\N	{}	{"1": true, "2": true, "3": true, "4": true, "5": true, "6": true, "7": true, "8": true, "9": true, "10": true, "11": true, "12": true, "13": true, "14": true, "15": true, "16": true, "17": true, "18": true}	\N	0	paid	A26A139643	1.00	2026-01-05 00:00:00	\N	\N	\N
\.


--
-- Data for Name: inspection_orders; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.inspection_orders (id, application_id, scheduled_by, scheduled_date, assigned_to, assigned_date, inspection_date, inspection_address, special_instructions, status, dtdo_notes, created_at, updated_at) FROM stdin;
2691a4a5-bc1b-4bac-827f-edc8d236e845	2cd779b9-9004-43b8-b91f-78728a4174ff	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 19:14:34.15	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:14:34.15	2026-01-07 09:00:00	Test Property  \nAddress	Accept & Schedule Inspection\nSchedule the site inspection and assign a Dealing Assistant.\n\nInstructions for Inspection Team	completed	\N	2026-01-04 19:14:34.151449	2026-01-04 19:15:30.262
43827d4c-17cd-4b9b-be60-31875ea8d3d3	648b914b-0eaa-4c64-a675-119ba3aef889	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-04 19:23:01.178	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:23:01.178	2026-01-08 05:45:00	Test Property  \nAddress	Instructions for Inspection Team	completed	\N	2026-01-04 19:23:01.178845	2026-01-04 19:23:48.433
66120d82-05ae-4d02-bf4b-80b36d2fc4cf	08240a35-8245-45d0-8cf0-f1e25d66580d	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-05 05:27:17.728	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-05 05:27:17.728	2026-01-09 07:30:00	Sondh Niwas, Near Saw Mill,\nLower Lakkar Bazar,	Accept & Schedule Inspection\nSchedule the site inspection and assign a Dealing Assistant.	completed	\N	2026-01-05 05:27:17.728782	2026-01-05 05:28:36.282
\.


--
-- Data for Name: inspection_reports; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.inspection_reports (id, inspection_order_id, application_id, submitted_by, submitted_date, actual_inspection_date, room_count_verified, actual_room_count, category_meets_standards, recommended_category, mandatory_checklist, mandatory_remarks, desirable_checklist, desirable_remarks, amenities_verified, amenities_issues, fire_safety_compliant, fire_safety_issues, structural_safety, structural_issues, overall_satisfactory, recommendation, detailed_findings, inspection_photos, report_document_url, created_at, updated_at) FROM stdin;
1777c83d-eb9d-4550-a56c-bb4635af5586	2691a4a5-bc1b-4bac-827f-edc8d236e845	2cd779b9-9004-43b8-b91f-78728a4174ff	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:15:30.255	2026-01-02 00:00:00	t	\N	t	\N	{"roomSize": true, "documents": true, "cleanRooms": true, "cctvCameras": true, "visitorBook": true, "cleanKitchen": true, "doctorDetails": true, "fireEquipment": true, "guestRegister": true, "onlinePayment": true, "wasteDisposal": true, "waterFacility": true, "wellMaintained": true, "applicationForm": true, "cutleryCrockery": true, "luggageAssistance": true, "comfortableBedding": true, "energySavingLights": true}	Early inspection override: Conducted 5 days before the scheduled date (January 7th, 2026). Reason: Reason for Early Inspection\nProvide context for DTDO on why the visit was advanced (minimum 15 characters).	{"lounge": false, "laundry": false, "parking": false, "storage": false, "wardrobe": false, "furniture": false, "diningArea": false, "luggageHelp": false, "safeStorage": false, "hotColdWater": false, "refrigerator": false, "securityGuard": false, "heatingCooling": false, "himachaliCrafts": false, "toiletAmenities": false, "attachedBathroom": false, "waterConservation": false, "rainwaterHarvesting": false}	\N	\N	\N	f	\N	f	\N	t	approve	Reason for Early Inspection\nProvide context for DTDO on why the visit was advanced (minimum 15 characters).	\N	\N	2026-01-04 19:15:30.259933	2026-01-04 19:15:30.259933
3206861e-5046-44a6-a697-b5c648399373	43827d4c-17cd-4b9b-be60-31875ea8d3d3	648b914b-0eaa-4c64-a675-119ba3aef889	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-04 19:23:48.427	2026-01-04 00:00:00	t	\N	t	\N	{"roomSize": true, "documents": true, "cleanRooms": true, "cctvCameras": true, "visitorBook": true, "cleanKitchen": true, "doctorDetails": true, "fireEquipment": true, "guestRegister": true, "onlinePayment": true, "wasteDisposal": true, "waterFacility": true, "wellMaintained": true, "applicationForm": true, "cutleryCrockery": true, "luggageAssistance": true, "comfortableBedding": true, "energySavingLights": true}	Early inspection override: Conducted 4 days before the scheduled date (January 8th, 2026). Reason: Log Earlier Visit\nEnable if the physical inspection happened up to 7 days before the scheduled date.	{"lounge": false, "laundry": false, "parking": false, "storage": false, "wardrobe": false, "furniture": false, "diningArea": false, "luggageHelp": false, "safeStorage": false, "hotColdWater": false, "refrigerator": false, "securityGuard": false, "heatingCooling": false, "himachaliCrafts": false, "toiletAmenities": false, "attachedBathroom": false, "waterConservation": false, "rainwaterHarvesting": false}	\N	\N	\N	f	\N	f	\N	t	approve	Log Earlier Visit\nEnable if the physical inspection happened up to 7 days before the scheduled date.	\N	\N	2026-01-04 19:23:48.431862	2026-01-04 19:23:48.431862
f85bbbb5-007e-4d08-a61c-30e16a3a4841	66120d82-05ae-4d02-bf4b-80b36d2fc4cf	08240a35-8245-45d0-8cf0-f1e25d66580d	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-05 05:28:36.274	2026-01-04 00:00:00	t	\N	t	\N	{"roomSize": true, "documents": true, "cleanRooms": true, "cctvCameras": true, "visitorBook": true, "cleanKitchen": true, "doctorDetails": true, "fireEquipment": true, "guestRegister": true, "onlinePayment": true, "wasteDisposal": true, "waterFacility": true, "wellMaintained": true, "applicationForm": true, "cutleryCrockery": true, "luggageAssistance": true, "comfortableBedding": true, "energySavingLights": true}	Early inspection override: Conducted 5 days before the scheduled date (January 9th, 2026). Reason: Reason for Early Inspection\nProvide context for DTDO on why the visit was advanced (minimum 15 characters).	{"lounge": false, "laundry": false, "parking": false, "storage": false, "wardrobe": false, "furniture": false, "diningArea": false, "luggageHelp": false, "safeStorage": false, "hotColdWater": false, "refrigerator": false, "securityGuard": false, "heatingCooling": false, "himachaliCrafts": false, "toiletAmenities": false, "attachedBathroom": false, "waterConservation": false, "rainwaterHarvesting": false}	\N	\N	\N	f	\N	f	\N	t	approve	Category Meets Standards\nDoes the property meet the standards for SILVER category?	\N	\N	2026-01-05 05:28:36.280207	2026-01-05 05:28:36.280207
\.


--
-- Data for Name: lgd_blocks; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_blocks (id, lgd_code, block_name, district_id, tehsil_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_districts; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_districts (id, lgd_code, district_name, division_name, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_gram_panchayats; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_gram_panchayats (id, lgd_code, gram_panchayat_name, district_id, block_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_tehsils; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_tehsils (id, lgd_code, tehsil_name, district_id, tehsil_type, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_urban_bodies; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_urban_bodies (id, lgd_code, urban_body_name, district_id, body_type, number_of_wards, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: login_otp_challenges; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.login_otp_challenges (id, user_id, otp_hash, expires_at, consumed_at, created_at) FROM stdin;
c601764c-4a0a-4849-9677-2d868180ae3e	26852f3d-3ac9-4c66-a348-1a2f637bf7c1	$2b$10$.kL.HOq0pyR4F62uq1GS9OWqy.7LDQN4rHLowjsk51q1bYhPoEBpO	2026-01-04 13:16:29.553	\N	2026-01-04 13:06:29.557378
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.notifications (id, user_id, application_id, type, title, message, channels, is_read, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: objections; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.objections (id, application_id, inspection_report_id, raised_by, raised_date, objection_type, objection_title, objection_description, severity, response_deadline, status, resolution_notes, resolved_by, resolved_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_reset_challenges; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.password_reset_challenges (id, user_id, channel, recipient, otp_hash, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.payments (id, application_id, payment_type, amount, payment_gateway, gateway_transaction_id, payment_method, payment_status, payment_link, qr_code_url, payment_link_expiry_date, initiated_at, completed_at, receipt_number, receipt_url) FROM stdin;
\.


--
-- Data for Name: production_stats; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.production_stats (id, total_applications, approved_applications, rejected_applications, pending_applications, scraped_at, source_url) FROM stdin;
3e67ed63-46a7-4f68-ae04-3390f95dfb5d	4	4	4	4	2026-01-02 09:43:40.160146	https://eservices.himachaltourism.gov.in/
c96b013d-890c-4e62-8f5e-743b2ea6b7a2	4	4	4	4	2026-01-02 10:29:21.383096	https://eservices.himachaltourism.gov.in/
7eaf3de7-8ccb-4db4-a8b9-65a856ef279e	4	4	4	4	2026-01-02 10:34:51.163198	https://eservices.himachaltourism.gov.in/
a75cc721-eb02-4892-906d-489eff06c7a0	4	4	4	4	2026-01-02 10:38:52.131863	https://eservices.himachaltourism.gov.in/
35adce3f-60ad-4083-9310-219d166c4b10	4	4	4	4	2026-01-02 10:39:43.483885	https://eservices.himachaltourism.gov.in/
2dcc2288-c18e-45ea-9ec0-904e9e354c96	4	4	4	4	2026-01-02 10:41:39.193065	https://eservices.himachaltourism.gov.in/
2ea42974-755c-440a-ada4-07aecb4a9c5f	4	4	4	4	2026-01-02 10:47:34.020694	https://eservices.himachaltourism.gov.in/
ee57f053-324f-4567-99da-3a2311c02acc	4	4	4	4	2026-01-02 11:31:52.433049	https://eservices.himachaltourism.gov.in/
a9ec50fc-1ac6-4525-9bc8-f9cc19ec294b	4	4	4	4	2026-01-02 11:51:13.137363	https://eservices.himachaltourism.gov.in/
11119f05-6f1c-4347-82e9-2abab7e30975	4	4	4	4	2026-01-02 12:13:06.092186	https://eservices.himachaltourism.gov.in/
79436bb6-f50c-4227-9fd9-6fc641b631cb	4	4	4	4	2026-01-02 12:33:05.884996	https://eservices.himachaltourism.gov.in/
239a94df-4822-4325-a946-79f7d1ebb83d	4	4	4	4	2026-01-02 13:05:23.615602	https://eservices.himachaltourism.gov.in/
da66dd37-fbc1-4c81-94c3-7b3e195a98c0	4	4	4	4	2026-01-02 14:05:23.288935	https://eservices.himachaltourism.gov.in/
397cceba-b6f7-4139-b8f6-45480e9f1720	4	4	4	4	2026-01-02 14:29:38.89863	https://eservices.himachaltourism.gov.in/
4c1d467c-3e88-4213-a381-9ea05c06260d	4	4	4	4	2026-01-02 14:40:02.055573	https://eservices.himachaltourism.gov.in/
2898eb29-7efd-41c7-9f36-834a66f59360	4	4	4	4	2026-01-02 15:40:01.746559	https://eservices.himachaltourism.gov.in/
7bc73fe2-6105-4e8a-aea3-6dda87847784	4	4	4	4	2026-01-02 15:49:13.57419	https://eservices.himachaltourism.gov.in/
3eb8b2b7-c236-4f4d-83b8-6f7133e9204c	4	4	4	4	2026-01-02 15:49:37.614106	https://eservices.himachaltourism.gov.in/
ae5d5011-104a-4dca-8be6-8eb7f020d52b	4	4	4	4	2026-01-02 15:50:38.698067	https://eservices.himachaltourism.gov.in/
7a970811-0f88-4073-8ade-b9f543a65c24	4	4	4	4	2026-01-02 15:51:32.8478	https://eservices.himachaltourism.gov.in/
ee1208ee-f904-4724-8409-2f82edfacb22	4	4	4	4	2026-01-02 15:51:58.843756	https://eservices.himachaltourism.gov.in/
b00615c5-4334-4ba3-8af2-b307cc8439c4	4	4	4	4	2026-01-02 15:52:23.882779	https://eservices.himachaltourism.gov.in/
3134f016-dd42-4e69-b2ef-364c3e7bf0ba	4	4	4	4	2026-01-02 15:54:09.313615	https://eservices.himachaltourism.gov.in/
a6480955-2e6b-46cf-9128-6f002c9e1540	4	4	4	4	2026-01-02 15:54:14.833838	https://eservices.himachaltourism.gov.in/
98dbb682-70e9-40d9-b8f3-3a4fe913bd3a	4	4	4	4	2026-01-02 16:07:38.477806	https://eservices.himachaltourism.gov.in/
ad1234c4-61d1-4f9b-93cf-4ab200ce10dd	4	4	4	4	2026-01-02 16:07:40.935602	https://eservices.himachaltourism.gov.in/
60c1014b-645d-4079-bc1b-177aa7831baa	4	4	4	4	2026-01-02 16:07:51.25527	https://eservices.himachaltourism.gov.in/
7e7c708f-f20e-46eb-8515-387aa8db5dc3	4	4	4	4	2026-01-02 16:07:54.164059	https://eservices.himachaltourism.gov.in/
8ce432d1-f93f-4721-ac10-dcc1fd53c702	4	4	4	4	2026-01-02 16:07:57.210586	https://eservices.himachaltourism.gov.in/
4d5430f8-2fcf-400b-b307-94ed3837cf42	4	4	4	4	2026-01-02 16:08:00.543218	https://eservices.himachaltourism.gov.in/
e8851a8b-cfbe-4757-b553-534bed54cac1	4	4	4	4	2026-01-02 16:08:03.703224	https://eservices.himachaltourism.gov.in/
0267d905-bd82-4d3d-a4b9-27963e5bc513	4	4	4	4	2026-01-02 16:08:08.241318	https://eservices.himachaltourism.gov.in/
7bb4bc3d-3652-4e76-8906-cd79b3bab9c4	4	4	4	4	2026-01-02 16:08:11.02991	https://eservices.himachaltourism.gov.in/
a9ba52b2-1ae5-4689-ab41-a1eea74f2f32	4	4	4	4	2026-01-02 16:08:13.796702	https://eservices.himachaltourism.gov.in/
880b46c8-87b8-44af-9652-199d7a2386a8	4	4	4	4	2026-01-02 16:08:18.706008	https://eservices.himachaltourism.gov.in/
70ff135b-a012-4b9b-bf44-35ad81e5e676	4	4	4	4	2026-01-02 16:08:25.540416	https://eservices.himachaltourism.gov.in/
5547eb02-07f8-49e2-bb10-6733619656ea	4	4	4	4	2026-01-02 16:08:28.398643	https://eservices.himachaltourism.gov.in/
8f4ed13b-c871-4aee-83b6-417aa49649bd	4	4	4	4	2026-01-02 16:08:30.709703	https://eservices.himachaltourism.gov.in/
064b12df-f551-44a6-852d-fd28a5f66be0	4	4	4	4	2026-01-02 16:08:33.582674	https://eservices.himachaltourism.gov.in/
5b73701c-0e4f-4380-9b04-b8a3791227c6	4	4	4	4	2026-01-02 16:08:36.945069	https://eservices.himachaltourism.gov.in/
1258d891-9e1b-42e9-9f85-78839392c5d7	4	4	4	4	2026-01-02 16:08:45.283933	https://eservices.himachaltourism.gov.in/
6a0f8211-bd1a-4aa3-a301-8bbd5d12b6fd	4	4	4	4	2026-01-02 16:08:51.755049	https://eservices.himachaltourism.gov.in/
1d7e12be-a388-4986-a3e4-c8caffe00281	4	4	4	4	2026-01-02 16:08:57.174372	https://eservices.himachaltourism.gov.in/
193a8008-2732-4fbe-8b97-5b6538230cb8	4	4	4	4	2026-01-02 16:09:05.61468	https://eservices.himachaltourism.gov.in/
11747263-7e91-408e-9500-b65ffbae1eca	4	4	4	4	2026-01-02 16:09:14.96569	https://eservices.himachaltourism.gov.in/
8fcf8226-5ae0-49ee-94f9-0980d2784d29	4	4	4	4	2026-01-02 16:09:38.427541	https://eservices.himachaltourism.gov.in/
3b59fadf-1946-4036-9d2b-48392eccef00	4	4	4	4	2026-01-02 16:10:23.864198	https://eservices.himachaltourism.gov.in/
901d7d6e-dfb4-4f07-81fa-bdd06041475d	4	4	4	4	2026-01-02 16:10:26.205227	https://eservices.himachaltourism.gov.in/
95547f30-28b5-45fc-9b7b-ced896b57586	4	4	4	4	2026-01-02 16:10:28.625907	https://eservices.himachaltourism.gov.in/
a8b9bb73-a56a-4c59-9324-2091cce22937	4	4	4	4	2026-01-02 16:10:54.17977	https://eservices.himachaltourism.gov.in/
f9e811ca-f39b-4803-a34a-bb773aebd7ea	4	4	4	4	2026-01-02 16:11:03.554837	https://eservices.himachaltourism.gov.in/
8b095070-9260-43c4-9253-403c236f00ee	4	4	4	4	2026-01-02 16:11:46.916445	https://eservices.himachaltourism.gov.in/
bd2253a4-a9fe-44cf-a0bc-e700cc972ff0	4	4	4	4	2026-01-02 16:11:57.590296	https://eservices.himachaltourism.gov.in/
6b797566-b8db-401e-9d8f-25979c910e59	4	4	4	4	2026-01-02 16:13:29.996725	https://eservices.himachaltourism.gov.in/
2a86a30e-2a97-40df-923a-891062b6c254	4	4	4	4	2026-01-02 16:13:58.620754	https://eservices.himachaltourism.gov.in/
4b062342-d27f-472c-8342-540715fe7d57	4	4	4	4	2026-01-02 17:13:58.574363	https://eservices.himachaltourism.gov.in/
76ae21d4-2671-466d-a3d2-5f0e05cecd72	4	4	4	4	2026-01-02 18:01:02.437438	https://eservices.himachaltourism.gov.in/
e6e2b03f-bfe5-4a08-bbad-5c51b24412b3	4	4	4	4	2026-01-02 18:05:02.212064	https://eservices.himachaltourism.gov.in/
360c9801-213f-414a-880d-11f68ea417a2	4	4	4	4	2026-01-02 18:13:00.904385	https://eservices.himachaltourism.gov.in/
e6c99585-5e50-4c78-b8ab-ec849b9468f7	4	4	4	4	2026-01-02 19:13:00.909765	https://eservices.himachaltourism.gov.in/
a5311189-3646-438b-ab10-28928d4406cb	4	4	4	4	2026-01-02 20:13:00.907111	https://eservices.himachaltourism.gov.in/
152be07d-c7d7-4ff6-9a78-b4e79fd3fde0	4	4	4	4	2026-01-02 20:50:54.611383	https://eservices.himachaltourism.gov.in/
104f0082-7896-4958-9683-1387b22258ea	4	4	4	4	2026-01-02 20:53:30.438065	https://eservices.himachaltourism.gov.in/
4960257b-9281-4e32-a336-5c57ba1a8e72	4	4	4	4	2026-01-02 20:55:04.351227	https://eservices.himachaltourism.gov.in/
e8b54d28-f54e-4ba0-a3aa-2c9e562209ba	4	4	4	4	2026-01-02 21:02:51.954654	https://eservices.himachaltourism.gov.in/
5117f3da-bdbf-42e7-8c59-272dfcdc9505	4	4	4	4	2026-01-02 21:14:48.218921	https://eservices.himachaltourism.gov.in/
bcebce91-5908-49cb-b25d-fcf09190011f	4	4	4	4	2026-01-02 21:21:03.689874	https://eservices.himachaltourism.gov.in/
54bcc274-b518-4824-aa27-f87ca17bbc3c	4	4	4	4	2026-01-02 21:25:33.419139	https://eservices.himachaltourism.gov.in/
ee2a283a-17f0-4223-8d9e-bfe4fd5820e6	4	4	4	4	2026-01-02 21:28:02.519147	https://eservices.himachaltourism.gov.in/
17d716ed-2de8-40ec-a4de-07ca1dd2009d	4	4	4	4	2026-01-02 21:29:59.062179	https://eservices.himachaltourism.gov.in/
3c45f5ba-25ed-4f4d-aaa0-98a730e2eac6	4	4	4	4	2026-01-02 21:32:09.324763	https://eservices.himachaltourism.gov.in/
386e7caf-406e-4c58-b536-4798fdbd5bc7	4	4	4	4	2026-01-02 21:39:16.071654	https://eservices.himachaltourism.gov.in/
4298e868-4a92-4cbc-bd3e-7f602622ad66	4	4	4	4	2026-01-02 21:42:19.723069	https://eservices.himachaltourism.gov.in/
71df2958-5a97-4501-b9b3-77c7222598b8	4	4	4	4	2026-01-02 21:46:30.799897	https://eservices.himachaltourism.gov.in/
7413f54d-c5bd-4a84-8268-90c247c8dde2	4	4	4	4	2026-01-02 21:52:04.844067	https://eservices.himachaltourism.gov.in/
060a8f34-df76-4685-b0c4-04d71a6799b0	4	4	4	4	2026-01-02 22:17:15.392887	https://eservices.himachaltourism.gov.in/
d0e6e3ba-0c60-4975-a3b2-e6cd1865e59c	4	4	4	4	2026-01-02 22:29:33.725485	https://eservices.himachaltourism.gov.in/
5187cab7-55e6-42cb-9f43-c5e03bfd8fe6	4	4	4	4	2026-01-02 22:36:33.29451	https://eservices.himachaltourism.gov.in/
1f2f5ec8-4bff-4614-bafd-01f26a919562	4	4	4	4	2026-01-02 22:44:04.331635	https://eservices.himachaltourism.gov.in/
e1e28f16-ac04-4d17-8847-b32ce7198089	4	4	4	4	2026-01-02 22:48:04.603065	https://eservices.himachaltourism.gov.in/
a866b079-cebb-431b-ad20-dc21a929918c	4	4	4	4	2026-01-02 23:01:00.846546	https://eservices.himachaltourism.gov.in/
301cf24e-b4f9-470b-a87f-c3fbf69484ba	4	4	4	4	2026-01-02 23:13:23.769263	https://eservices.himachaltourism.gov.in/
272b54c4-1be9-43a5-a288-8794d1d38279	4	4	4	4	2026-01-02 23:21:22.604068	https://eservices.himachaltourism.gov.in/
ee6ff772-ac04-4c57-b39c-213fdc7982c0	4	4	4	4	2026-01-02 23:38:11.987641	https://eservices.himachaltourism.gov.in/
d2fd06fb-467f-4bb4-b453-6c4bb5cc7c6f	4	4	4	4	2026-01-02 23:40:46.313507	https://eservices.himachaltourism.gov.in/
78fef236-826e-47c9-abe3-2a280c5302c2	4	4	4	4	2026-01-03 00:03:14.963787	https://eservices.himachaltourism.gov.in/
31b9213b-bbb4-4f8c-85d9-141a8dbb6206	4	4	4	4	2026-01-03 00:11:02.128971	https://eservices.himachaltourism.gov.in/
6879ed4d-96a5-463b-875b-62aeaa183915	4	4	4	4	2026-01-03 01:11:02.030762	https://eservices.himachaltourism.gov.in/
5c09b966-59ab-4f22-b0b2-c80d7ebb40c4	4	4	4	4	2026-01-03 02:11:02.026159	https://eservices.himachaltourism.gov.in/
4a5044e8-dee9-4c19-9d79-2642e7eeebf2	4	4	4	4	2026-01-03 03:11:02.030071	https://eservices.himachaltourism.gov.in/
8a2bf4a5-60bc-4c87-a06a-7f11ab46df4a	4	4	4	4	2026-01-03 04:11:02.027186	https://eservices.himachaltourism.gov.in/
da79901a-3f1f-44c8-a4a3-7e4b5d7de23c	4	4	4	4	2026-01-03 05:11:02.042569	https://eservices.himachaltourism.gov.in/
cd74b2bb-a7a2-4c17-a050-5bc26c63e5b1	4	4	4	4	2026-01-03 05:39:38.205665	https://eservices.himachaltourism.gov.in/
d1a0f34f-929f-433a-9b4a-eacce9204b65	4	4	4	4	2026-01-03 06:39:38.270869	https://eservices.himachaltourism.gov.in/
7a1b950c-e3f8-43e8-9a99-b0d78ac4c613	4	4	4	4	2026-01-03 07:20:43.219864	https://eservices.himachaltourism.gov.in/
8dc98a52-7d44-4f0a-8af8-07819c4917bd	4	4	4	4	2026-01-03 16:40:53.625971	https://eservices.himachaltourism.gov.in/
5e65ca7d-cb07-4450-a09e-659698d1a4aa	4	4	4	4	2026-01-03 16:42:11.122728	https://eservices.himachaltourism.gov.in/
bebb156e-8fb2-4986-83cb-d327aeef48ba	4	4	4	4	2026-01-03 17:33:40.225853	https://eservices.himachaltourism.gov.in/
cb550e2f-1dab-40ba-b8d7-03477896ec77	4	4	4	4	2026-01-03 18:13:05.303426	https://eservices.himachaltourism.gov.in/
3ab4d464-33eb-46c5-8246-c10c82469e1e	4	4	4	4	2026-01-03 18:25:22.049178	https://eservices.himachaltourism.gov.in/
7b786bde-3e97-4391-b0ad-de8669ed369f	4	4	4	4	2026-01-03 19:25:22.041633	https://eservices.himachaltourism.gov.in/
14992d8e-d9ad-4784-abbd-952ef4683369	4	4	4	4	2026-01-03 19:54:34.843629	https://eservices.himachaltourism.gov.in/
b28b3c2b-8032-43e1-9bfe-2c3b40af51a9	4	4	4	4	2026-01-03 19:54:56.697746	https://eservices.himachaltourism.gov.in/
26b54268-5d29-4246-8b04-3ec2b8706b9e	4	4	4	4	2026-01-03 19:59:51.207439	https://eservices.himachaltourism.gov.in/
f45b1555-456a-4ecd-8e1d-917998879bda	4	4	4	4	2026-01-03 20:06:36.833039	https://eservices.himachaltourism.gov.in/
f8bad917-6b8c-43c7-a274-bd1ab5787b79	4	4	4	4	2026-01-03 20:26:19.643434	https://eservices.himachaltourism.gov.in/
bd57d067-5114-47e1-a612-b1a2d513b919	4	4	4	4	2026-01-03 20:29:52.577538	https://eservices.himachaltourism.gov.in/
7451129e-ed4f-4389-8c55-257775aa8f75	4	4	4	4	2026-01-03 20:34:16.226333	https://eservices.himachaltourism.gov.in/
2c4c9014-5c6a-4a1a-af1a-1952be72d816	4	4	4	4	2026-01-03 21:12:13.620994	https://eservices.himachaltourism.gov.in/
9de71147-30b6-4637-8c45-92f46ed60cfa	4	4	4	4	2026-01-03 21:34:45.18302	https://eservices.himachaltourism.gov.in/
b82daae3-4324-42ac-99b1-7a51245235ae	4	4	4	4	2026-01-03 21:39:20.699493	https://eservices.himachaltourism.gov.in/
88b25ced-58fb-49b6-a05a-2b14b986115d	4	4	4	4	2026-01-03 21:42:10.033148	https://eservices.himachaltourism.gov.in/
b0816d44-a541-4cd0-bb75-e2e5c3d34d5f	4	4	4	4	2026-01-03 21:45:58.735345	https://eservices.himachaltourism.gov.in/
31e33202-02e7-4a9b-aa45-1de96e7b3037	4	4	4	4	2026-01-03 21:51:36.253114	https://eservices.himachaltourism.gov.in/
85f94351-a49c-41af-84f9-0a80c41ec032	4	4	4	4	2026-01-03 22:07:00.226828	https://eservices.himachaltourism.gov.in/
8212a753-df4d-4122-90b2-e50652f6cdf4	4	4	4	4	2026-01-03 22:10:44.312874	https://eservices.himachaltourism.gov.in/
dd9ab6d9-189b-41c0-b029-202b6e37f979	4	4	4	4	2026-01-03 22:13:32.895862	https://eservices.himachaltourism.gov.in/
edcb8a2c-569e-4075-8cf8-ed15949afe82	4	4	4	4	2026-01-03 22:24:38.606008	https://eservices.himachaltourism.gov.in/
6d1285a5-65e6-4f23-8fd8-2a3418079a56	4	4	4	4	2026-01-03 22:31:49.962567	https://eservices.himachaltourism.gov.in/
dde9c456-eca7-480a-bad0-6a98e37b65e8	4	4	4	4	2026-01-03 22:40:05.519948	https://eservices.himachaltourism.gov.in/
c3cfa075-f174-40ab-a028-328c3615599e	4	4	4	4	2026-01-03 23:05:17.522716	https://eservices.himachaltourism.gov.in/
c08d8a4e-8bed-4f2a-ac84-f48af5ec85f7	4	4	4	4	2026-01-03 23:09:16.99486	https://eservices.himachaltourism.gov.in/
3a7ec2d2-ffb0-49cf-b6f2-a201b2905bd8	4	4	4	4	2026-01-03 23:14:05.745045	https://eservices.himachaltourism.gov.in/
0d466dd2-a296-45cd-b3ed-9a55f98a3076	4	4	4	4	2026-01-04 00:14:05.65584	https://eservices.himachaltourism.gov.in/
00a3a76d-61a6-467f-a35f-96c3baed3a82	4	4	4	4	2026-01-04 01:14:05.677228	https://eservices.himachaltourism.gov.in/
055671b1-aa0d-455c-9b04-076ea00bb9a7	4	4	4	4	2026-01-04 02:14:05.704594	https://eservices.himachaltourism.gov.in/
5e26800e-b2d1-482c-a4e6-b061ff066f3d	4	4	4	4	2026-01-04 03:14:05.718781	https://eservices.himachaltourism.gov.in/
551f1826-e6cb-4547-9d27-4fe7f03759ee	4	4	4	4	2026-01-04 04:14:05.73381	https://eservices.himachaltourism.gov.in/
1ca14d51-aa5e-4fa5-8a15-8f85b6e13827	4	4	4	4	2026-01-04 05:14:05.750545	https://eservices.himachaltourism.gov.in/
da7f7767-8d31-4beb-81fd-2690c61fb3fb	4	4	4	4	2026-01-04 06:14:05.755902	https://eservices.himachaltourism.gov.in/
8e0ffba0-2a26-4205-afd1-e2a9665461dc	4	4	4	4	2026-01-04 07:14:05.750183	https://eservices.himachaltourism.gov.in/
6e411825-9b39-4384-94b2-d8434a1301fd	4	4	4	4	2026-01-04 08:14:05.760595	https://eservices.himachaltourism.gov.in/
50fff7d8-05ef-4e80-b284-80d1f5c51f5d	4	4	4	4	2026-01-04 09:14:05.78746	https://eservices.himachaltourism.gov.in/
cb296572-762d-4c9b-abeb-79933d324397	4	4	4	4	2026-01-04 10:14:05.783653	https://eservices.himachaltourism.gov.in/
4e9e1e06-35a2-45c8-8623-490994cd7c3a	4	4	4	4	2026-01-04 11:14:05.776783	https://eservices.himachaltourism.gov.in/
6c44ddc2-13c9-45a4-9c4c-f1dca99bf8cf	4	4	4	4	2026-01-04 12:14:05.807184	https://eservices.himachaltourism.gov.in/
f3455d78-7306-434a-b7b4-9389dc88b0e9	4	4	4	4	2026-01-04 12:46:11.784395	https://eservices.himachaltourism.gov.in/
73bc9da5-63cd-45d7-891b-4cae29e38fe5	4	4	4	4	2026-01-04 13:00:03.367316	https://eservices.himachaltourism.gov.in/
9b82049a-5706-4510-8685-9df460ebd170	4	4	4	4	2026-01-04 13:02:33.645432	https://eservices.himachaltourism.gov.in/
aaadcef8-f11d-4d61-a43f-c1e12f93ba71	4	4	4	4	2026-01-04 13:15:09.265129	https://eservices.himachaltourism.gov.in/
f20068a2-79f8-47ae-a493-a66e3456b6df	4	4	4	4	2026-01-04 13:39:59.685701	https://eservices.himachaltourism.gov.in/
62fbd5dd-4559-4b42-a0a3-6944a724f4f8	4	4	4	4	2026-01-04 13:59:33.712694	https://eservices.himachaltourism.gov.in/
70931c90-2548-4ea8-b00d-f2d4ce2c5840	4	4	4	4	2026-01-04 14:21:44.858673	https://eservices.himachaltourism.gov.in/
b7814d78-4316-4183-a3bc-372f3198b63e	4	4	4	4	2026-01-04 14:30:51.561598	https://eservices.himachaltourism.gov.in/
7a991436-9efe-4f27-aff2-7f23d768f0e5	4	4	4	4	2026-01-04 14:30:51.791322	https://eservices.himachaltourism.gov.in/
168692ec-e632-4e84-99e7-76be21ee4b15	4	4	4	4	2026-01-04 14:30:52.089933	https://eservices.himachaltourism.gov.in/
4f2b5a8f-261a-4d55-a89e-01ef77255c00	4	4	4	4	2026-01-04 14:30:52.592332	https://eservices.himachaltourism.gov.in/
d2c69ffe-c367-40a2-8627-efc5c762532b	4	4	4	4	2026-01-04 15:02:08.328055	https://eservices.himachaltourism.gov.in/
7f5c5429-bae1-4b45-8e4b-fc9b544e73a5	4	4	4	4	2026-01-04 15:02:08.381635	https://eservices.himachaltourism.gov.in/
1398cf24-9837-43c3-9c0b-a0b6b7e9fe89	4	4	4	4	2026-01-04 15:02:08.402918	https://eservices.himachaltourism.gov.in/
9cfca19b-02d6-4066-abaf-7b1afa21e5a4	4	4	4	4	2026-01-04 15:02:08.793412	https://eservices.himachaltourism.gov.in/
5e2f914d-1572-4de8-8e68-67f2df0f2c7c	4	4	4	4	2026-01-04 15:11:39.271578	https://eservices.himachaltourism.gov.in/
78558109-57df-4a23-bfe0-b5fc9cc47bc6	4	4	4	4	2026-01-04 15:11:39.272313	https://eservices.himachaltourism.gov.in/
4b6a9a1e-be96-4e90-a67b-920536aac70d	4	4	4	4	2026-01-04 15:59:28.062328	https://eservices.himachaltourism.gov.in/
b3d39dc8-1506-4a79-9408-3ac61240a1b8	4	4	4	4	2026-01-04 15:59:28.410382	https://eservices.himachaltourism.gov.in/
061ba860-895d-4394-8a9f-21a8d8ec1603	4	4	4	4	2026-01-04 16:04:14.813111	https://eservices.himachaltourism.gov.in/
02f4e09c-bd3e-47f4-ae90-b9b8d8ceaa31	4	4	4	4	2026-01-04 16:04:15.006404	https://eservices.himachaltourism.gov.in/
323c1bff-2340-4833-b143-8115201ed896	4	4	4	4	2026-01-04 16:06:47.236168	https://eservices.himachaltourism.gov.in/
4bd137de-8f91-4049-a41a-81b1ab2a79d8	4	4	4	4	2026-01-04 16:06:47.699845	https://eservices.himachaltourism.gov.in/
21dce800-19a5-4c2b-a950-880cd1a7002b	4	4	4	4	2026-01-04 16:15:29.206202	https://eservices.himachaltourism.gov.in/
e096dfb8-02f5-4bf1-a69e-7397956b5116	4	4	4	4	2026-01-04 16:15:29.473096	https://eservices.himachaltourism.gov.in/
25b8ed5d-b4c4-49d8-995a-07b6b5cd180b	4	4	4	4	2026-01-04 16:24:18.490325	https://eservices.himachaltourism.gov.in/
b9f56e4d-a2cc-4ec6-88bb-9c6c5cb554eb	4	4	4	4	2026-01-04 16:24:19.008418	https://eservices.himachaltourism.gov.in/
79f3e0cc-5d0c-4d63-a1ca-6fe7f82d9ba6	4	4	4	4	2026-01-04 16:33:09.922308	https://eservices.himachaltourism.gov.in/
220e7aee-e2ed-4cb6-be20-c2428a54ac62	4	4	4	4	2026-01-04 16:33:09.933472	https://eservices.himachaltourism.gov.in/
5d586d18-593e-4f30-b7ae-eb12a784a284	4	4	4	4	2026-01-04 16:54:02.773403	https://eservices.himachaltourism.gov.in/
d0746fe4-1211-470b-b6d1-cd5532115732	4	4	4	4	2026-01-04 16:54:03.095037	https://eservices.himachaltourism.gov.in/
ae7d9421-3a2f-403d-af24-6957b1bd55f9	4	4	4	4	2026-01-04 17:18:35.471309	https://eservices.himachaltourism.gov.in/
61544cd7-85b3-4632-a8db-ede38b560069	4	4	4	4	2026-01-04 17:18:35.55647	https://eservices.himachaltourism.gov.in/
787760ce-f5dc-4947-8c1b-6b03de5a4477	4	4	4	4	2026-01-04 18:18:35.434676	https://eservices.himachaltourism.gov.in/
6d78ddeb-b7f3-4578-86d0-596154c9f3fd	4	4	4	4	2026-01-04 18:18:35.439949	https://eservices.himachaltourism.gov.in/
c7c6a2d7-40af-4ded-95c6-b3cbc967c27c	4	4	4	4	2026-01-04 18:25:47.075325	https://eservices.himachaltourism.gov.in/
32e3c427-d6c5-40a9-bec9-77552619e6bb	4	4	4	4	2026-01-04 18:25:47.271902	https://eservices.himachaltourism.gov.in/
6fb71fbf-57fb-4bb0-a2ca-7f29c89bc5f6	4	4	4	4	2026-01-04 18:57:00.494097	https://eservices.himachaltourism.gov.in/
84c6220f-06fb-475a-aff4-89a560dcb442	4	4	4	4	2026-01-04 18:57:00.824732	https://eservices.himachaltourism.gov.in/
5ee7c83a-38d5-4da1-8a76-c61c2e5236f7	4	4	4	4	2026-01-04 19:29:41.511166	https://eservices.himachaltourism.gov.in/
7c747e3d-9519-4a5b-aa90-ee7e063dd244	4	4	4	4	2026-01-04 19:29:41.868327	https://eservices.himachaltourism.gov.in/
c83fef5e-7b89-4e7a-81ea-411f8d58af8c	4	4	4	4	2026-01-04 19:33:47.574019	https://eservices.himachaltourism.gov.in/
5847c6af-a183-4fe5-8f86-e4cb85da14f0	4	4	4	4	2026-01-04 19:33:47.747647	https://eservices.himachaltourism.gov.in/
730c5d77-8064-4e4a-958f-d1246ddefb45	4	4	4	4	2026-01-04 19:55:02.587678	https://eservices.himachaltourism.gov.in/
4badc78a-1b54-4b43-95bd-e48d0a7a74bc	4	4	4	4	2026-01-04 19:55:02.903955	https://eservices.himachaltourism.gov.in/
4220cfe6-ee98-46a4-b6a5-3e7bc0dd8ce3	4	4	4	4	2026-01-04 20:34:05.63131	https://eservices.himachaltourism.gov.in/
d5964402-6d43-40cf-970c-c685f257fbf4	4	4	4	4	2026-01-04 20:34:05.773397	https://eservices.himachaltourism.gov.in/
a85a81a7-9b1a-4b85-94df-eb1593588bfe	4	4	4	4	2026-01-04 21:34:05.596986	https://eservices.himachaltourism.gov.in/
131c46b7-85f6-43ee-bc2b-95b0a384ef01	4	4	4	4	2026-01-04 21:34:05.730646	https://eservices.himachaltourism.gov.in/
0f57ac42-b56e-4d9a-9931-3a0214920236	4	4	4	4	2026-01-04 22:34:05.556092	https://eservices.himachaltourism.gov.in/
c9b95175-a462-4e91-acb7-d29faa774aeb	4	4	4	4	2026-01-04 22:34:05.735727	https://eservices.himachaltourism.gov.in/
0e8202e6-7f3a-4d72-8772-e7a4a1a2d8c1	4	4	4	4	2026-01-04 23:34:05.562519	https://eservices.himachaltourism.gov.in/
24cdd131-8de4-4a29-80bc-3171609e0dd9	4	4	4	4	2026-01-04 23:34:05.733562	https://eservices.himachaltourism.gov.in/
b93afd32-e502-485d-8357-c3acbc80fcb0	4	4	4	4	2026-01-05 00:34:05.569813	https://eservices.himachaltourism.gov.in/
af869b35-cb46-4ec3-ad12-c4630a0b97c4	4	4	4	4	2026-01-05 00:34:05.730156	https://eservices.himachaltourism.gov.in/
0b4af313-4222-466a-a391-b30e3d24e9d7	4	4	4	4	2026-01-05 01:34:05.57434	https://eservices.himachaltourism.gov.in/
75150b87-f0e9-4bc1-9243-988a7b692fed	4	4	4	4	2026-01-05 01:34:05.734028	https://eservices.himachaltourism.gov.in/
fb9eadc8-e155-468e-a649-6175b648a969	4	4	4	4	2026-01-05 02:06:56.200898	https://eservices.himachaltourism.gov.in/
ff375a71-9f5b-4699-81c3-27de3c67c45b	4	4	4	4	2026-01-05 02:06:56.30685	https://eservices.himachaltourism.gov.in/
fddea3f9-a508-4ab9-91d0-b5af878f507c	4	4	4	4	2026-01-05 03:04:03.688399	https://eservices.himachaltourism.gov.in/
5dd1ad95-0d38-4fde-b0bf-a6a1f0be7621	4	4	4	4	2026-01-05 03:04:03.914168	https://eservices.himachaltourism.gov.in/
b877b45d-3759-4a83-a7fa-e3206c4b651a	4	4	4	4	2026-01-05 03:15:55.636588	https://eservices.himachaltourism.gov.in/
2a7b3f1f-4f9a-4cf1-b7e3-e4f4969bf6be	4	4	4	4	2026-01-05 03:15:55.789195	https://eservices.himachaltourism.gov.in/
8e131e23-70f1-42d2-976c-eb97ea75356f	4	4	4	4	2026-01-05 03:22:57.929798	https://eservices.himachaltourism.gov.in/
9c3cf66d-e429-4dfb-b180-0ebf3d21275a	4	4	4	4	2026-01-05 03:22:57.936352	https://eservices.himachaltourism.gov.in/
f991deec-9848-41a0-bd82-baf02ee52104	4	4	4	4	2026-01-05 03:28:50.999608	https://eservices.himachaltourism.gov.in/
53c62dd8-37ef-446c-b948-b56df1ce93f4	4	4	4	4	2026-01-05 03:28:51.039615	https://eservices.himachaltourism.gov.in/
8e40343c-23e4-4620-bbf4-bcdcfd0b5867	4	4	4	4	2026-01-05 03:35:35.992902	https://eservices.himachaltourism.gov.in/
61e96ff8-8eee-4324-a408-72c28c863e94	4	4	4	4	2026-01-05 03:35:36.350327	https://eservices.himachaltourism.gov.in/
2adab75b-2d8e-46d6-bff9-3cfd0da68f5f	4	4	4	4	2026-01-05 03:41:02.035332	https://eservices.himachaltourism.gov.in/
0f7dae18-4fc6-41e9-bf6a-70cec57a8f91	4	4	4	4	2026-01-05 03:41:02.517534	https://eservices.himachaltourism.gov.in/
bd35a238-05fc-4a8f-a008-d0ec65d6a9d1	4	4	4	4	2026-01-05 03:45:00.28931	https://eservices.himachaltourism.gov.in/
65f06911-09ff-4815-9616-35adbdad0787	4	4	4	4	2026-01-05 03:45:00.291714	https://eservices.himachaltourism.gov.in/
060504e5-fc16-461d-8891-8d7db8e109c3	4	4	4	4	2026-01-05 04:06:35.338864	https://eservices.himachaltourism.gov.in/
11af5fa3-471c-415a-abe5-aa266df68f5d	4	4	4	4	2026-01-05 04:06:35.734575	https://eservices.himachaltourism.gov.in/
ea7247e1-5a6a-455a-b590-e018013c90ad	4	4	4	4	2026-01-05 04:18:45.971608	https://eservices.himachaltourism.gov.in/
82af944d-4cca-4cad-9ac8-a65257548704	4	4	4	4	2026-01-05 04:18:46.084722	https://eservices.himachaltourism.gov.in/
dc48b89d-1f89-40ed-a707-9fe5be1d94db	4	4	4	4	2026-01-05 04:25:54.985226	https://eservices.himachaltourism.gov.in/
b69f5c3b-8e6d-4b5e-9075-c1032a865264	4	4	4	4	2026-01-05 04:25:55.956319	https://eservices.himachaltourism.gov.in/
3881fa24-4a31-4026-a004-1520ef14e002	4	4	4	4	2026-01-05 04:42:18.873213	https://eservices.himachaltourism.gov.in/
1a5619b4-1784-447a-997a-cb912d3327f6	4	4	4	4	2026-01-05 04:42:19.158235	https://eservices.himachaltourism.gov.in/
2aa24bdc-649b-4a8b-a076-2a58c23f47d6	4	4	4	4	2026-01-05 05:36:11.052058	https://eservices.himachaltourism.gov.in/
9829725e-5728-4272-a156-92c914b3bc48	4	4	4	4	2026-01-05 06:07:32.756728	https://eservices.himachaltourism.gov.in/
dd3c0a2f-2c50-45ba-8541-dad2ce768cd2	4	4	4	4	2026-01-05 06:13:12.878523	https://eservices.himachaltourism.gov.in/
48a7357f-562a-4dae-8962-bc97388c93f4	4	4	4	4	2026-01-05 06:33:49.429515	https://eservices.himachaltourism.gov.in/
7bea6f38-8675-4bd9-9d60-f395d770f513	4	4	4	4	2026-01-05 07:33:49.450289	https://eservices.himachaltourism.gov.in/
bee2cded-9527-4443-b430-aa05ebbeda6f	4	4	4	4	2026-01-05 08:33:49.444663	https://eservices.himachaltourism.gov.in/
81db1101-f604-4cf5-889b-e071e478e291	4	4	4	4	2026-01-05 09:33:49.449239	https://eservices.himachaltourism.gov.in/
28347103-fca7-47f6-89ec-14ebee6ac529	4	4	4	4	2026-01-05 10:33:49.443372	https://eservices.himachaltourism.gov.in/
d931e704-fbb4-45fc-80f7-f008080ed500	4	4	4	4	2026-01-05 11:33:49.457164	https://eservices.himachaltourism.gov.in/
8c0b320c-7452-4857-8104-0b52bd9a3f45	4	4	4	4	2026-01-05 12:33:50.4559	https://eservices.himachaltourism.gov.in/
65ae5035-4dd0-4ef2-81dd-2a601e2c5dfa	4	4	4	4	2026-01-05 13:33:49.472887	https://eservices.himachaltourism.gov.in/
ff95cdd7-4edf-4dde-b53f-1f84bf290006	4	4	4	4	2026-01-05 14:33:49.453712	https://eservices.himachaltourism.gov.in/
151d87bd-ff61-4ace-bd0b-826942cfbc70	4	4	4	4	2026-01-05 15:33:49.503306	https://eservices.himachaltourism.gov.in/
6c83a914-44f9-4cbc-a8e1-56be531ea824	4	4	4	4	2026-01-05 16:33:49.481873	https://eservices.himachaltourism.gov.in/
9342d64d-1e4c-4e25-a4be-5823c680459a	4	4	4	4	2026-01-05 17:33:49.485533	https://eservices.himachaltourism.gov.in/
b100dd24-b150-4ed0-a297-e72002ffb326	4	4	4	4	2026-01-05 18:33:49.484365	https://eservices.himachaltourism.gov.in/
8dc9f6e7-adda-450f-8a1b-685ac4a846e1	4	4	4	4	2026-01-05 19:33:49.487246	https://eservices.himachaltourism.gov.in/
14b3ddf9-96ab-43ea-8c89-c410cb3b19dd	4	4	4	4	2026-01-05 20:33:49.473526	https://eservices.himachaltourism.gov.in/
c63639a1-9d66-4027-b565-d615b04db45b	4	4	4	4	2026-01-05 21:33:49.475496	https://eservices.himachaltourism.gov.in/
e2501acc-e3bd-44cc-a931-5a621ddbf3a0	4	4	4	4	2026-01-05 22:33:49.482236	https://eservices.himachaltourism.gov.in/
961ac319-ccb3-41da-8abf-6b715b389ea1	4	4	4	4	2026-01-05 23:33:49.489087	https://eservices.himachaltourism.gov.in/
710e8ce4-c402-4a36-95bb-d1be96a2beae	4	4	4	4	2026-01-06 00:33:49.483798	https://eservices.himachaltourism.gov.in/
82ff3526-7a98-4c25-a4d7-6376bcd2fa81	4	4	4	4	2026-01-06 01:33:49.534896	https://eservices.himachaltourism.gov.in/
c5593bb3-5836-458b-97a9-dad8be67fb4b	4	4	4	4	2026-01-06 02:33:49.483164	https://eservices.himachaltourism.gov.in/
8cba060f-88b7-495e-bdfa-d709cf66a222	4	4	4	4	2026-01-06 03:33:49.489438	https://eservices.himachaltourism.gov.in/
439e8b31-e035-4b06-9f6d-d295bc56010e	4	4	4	4	2026-01-06 04:33:49.498147	https://eservices.himachaltourism.gov.in/
a7ab3718-60d9-4af1-bb9c-9bc02a8f4605	4	4	4	4	2026-01-06 05:33:49.504644	https://eservices.himachaltourism.gov.in/
2cf5a452-9e7f-4870-852a-e78a9fd29b9f	4	4	4	4	2026-01-06 06:33:49.544039	https://eservices.himachaltourism.gov.in/
1511a75f-eb33-4613-bc87-7933a44d439f	4	4	4	4	2026-01-06 07:33:49.493149	https://eservices.himachaltourism.gov.in/
4fd6e32e-56fd-41e4-92d5-00466651ef42	4	4	4	4	2026-01-06 08:33:49.480486	https://eservices.himachaltourism.gov.in/
c4c951c8-9ce1-4982-a0f7-0e5c7f95ae8b	4	4	4	4	2026-01-06 09:33:49.495905	https://eservices.himachaltourism.gov.in/
ea336995-a83e-4b78-800d-bec9d5614ea1	4	4	4	4	2026-01-06 10:33:49.510668	https://eservices.himachaltourism.gov.in/
6c0b9ad5-1439-4c50-af33-f6579a8465d8	4	4	4	4	2026-01-06 11:33:49.464841	https://eservices.himachaltourism.gov.in/
2a2148f5-ab38-4914-9d98-1ceecaccf1ed	4	4	4	4	2026-01-06 12:33:49.482213	https://eservices.himachaltourism.gov.in/
a16a5dfd-b228-4aef-aa50-33f638a0902f	4	4	4	4	2026-01-06 13:33:49.499528	https://eservices.himachaltourism.gov.in/
539da69f-6bd4-495a-b82a-c03f9dc90914	4	4	4	4	2026-01-06 14:33:49.499134	https://eservices.himachaltourism.gov.in/
0d288f97-1ca4-439b-8db6-d175b6c847bb	4	4	4	4	2026-01-06 15:33:49.480228	https://eservices.himachaltourism.gov.in/
219aacc3-09bc-4f8d-b47c-6f7b9768f875	4	4	4	4	2026-01-06 16:33:49.492407	https://eservices.himachaltourism.gov.in/
9fbdb9bf-3f5e-479b-af2d-8a43782b617d	4	4	4	4	2026-01-06 17:33:49.462798	https://eservices.himachaltourism.gov.in/
9994b3a9-45a8-478a-b54b-cf50f2dbb769	4	4	4	4	2026-01-06 18:33:49.48565	https://eservices.himachaltourism.gov.in/
39b261b1-ecf9-4bd2-81c4-25878025e5f9	4	4	4	4	2026-01-06 19:33:49.48394	https://eservices.himachaltourism.gov.in/
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.reviews (id, application_id, user_id, rating, review_text, is_verified_stay, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.session (sid, sess, expire) FROM stdin;
lHBfCm0SraBNkT8EDFLdZlwoX-W0p8vm	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:33:49.577Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:33:50
nDVMlLFZS4AZlPzibcp5G9udass1oN0m	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T19:21:31.110Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 19:21:32
eeitImVQmjqkOpU2OTrNJEvG18UayYwF	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:34:07.657Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:34:08
fqsYSa5A-ge1gbUOndBC8Wb3h-cGOuFJ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T19:21:53.791Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 19:21:54
erblTuG49toS26A2VVzBxyse6IoabtVe	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:34:27.528Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:34:28
Yl0D_al8_6GiqB2m0mF7jnt3hgLXZuKQ	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:34:43.808Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:34:44
z6xtW9HdjB2pCErcB4YWeSwCFYh3AEp6	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:35:00.877Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:35:01
kVDWR1DnFTbdzAhLgEt3q7KvQph_4MFA	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:35:13.514Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:35:14
iMyMjgBLh5Nx8gn_TpPCNLbmKWylokkZ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T19:21:58.062Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 19:21:59
7-i9GOEWtB7FLC_wEjEOLoJthDjrU9Vc	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T19:22:02.272Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 19:22:03
PZfTQeUv4fJB6TvMfyQGMpmtnxiCUM7W	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:35:30.517Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:35:31
wpcGGnddDnflSmSfafceiaJ4a87DRhgl	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:13:42.092Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "63e4c7b7-0359-4fc7-8210-97a6d5675267", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:13:43
9dHPPhnbeupk87dAccG05dmGup7orHtD	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-09T21:03:08.611Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 21:03:09
iYliXMihRcCPNs3NlJ1gwccWeIkmssru	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T19:22:06.071Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 19:22:07
YTRs8oyPPgwDHHiD0PunHuf0xQm2U3b_	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T18:06:35.076Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 18:06:40
lJ2RwL1GGYaxewn8mLBDwQ3dn_tVGhSC	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:42:40.666Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:42:44
jWZYScGykX01JoMcTQm0WtmMGu-75uzD	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:13:42.182Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "9a4b7d15-77b9-4df9-8781-cbec927b3423", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:13:43
or7X0EBVR1-inYwoqGFoRcmIqdai9CY4	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:45:23.601Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:45:28
mWtx4DQdpadpisrmhF4gfcPwBig6AUe5	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-12T08:01:09.143Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "super-admin-001", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-12 08:17:06
QIN5-gHSwcjc2gkKdTyEWuEIheLAMOh0	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:45:23.513Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:45:29
2jDItXq-ymNfD3r5BhhBHtQwxnpzE0rY	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:45:56.247Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:45:59
Vx_T1eHSLC_1MnJCBQqffygbQOtXV6sU	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:45:56.160Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:46:00
ZJ2vnHFbM7zoSSgIGOEbY_AjIaQaHTot	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:46:30.835Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:46:35
_d43zNLbJvtWTO4re2FnmgzEkWYWX-7K	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:46:30.744Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:46:36
nDY9zDAhAelz3SMOm-rSw17COwbfhOAq	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:49:09.510Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:49:14
rZ5L3aBE8PDMX4bVd0b0wWrG8Il9sTeV	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:49:09.406Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:49:15
fXz77GvBcjMOvZUsWMikeXNoMnrASFox	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:49:48.643Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:49:53
9iopj4qJJZ0EXXeGYdkUKR4ijNGpXRMV	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:49:48.549Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:49:55
tuHRlk98NdDsZ8wry9thtYH3FSERd6HB	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T18:06:34.977Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 18:06:42
CA4PwqCvVP8LN9ltHFqIMRviuuBbcGwm	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:16:33.233Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:16:34
b55w-V93BaE4fxEbi0C4CwE7wMkcMdzE	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-12T20:10:19.438Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "23c01613-84fa-4e75-8fee-49413fb0ef21", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-12 20:10:24
624M2k4mTMENFQ28XTkAAQPYbKCXmtlx	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:17:24.212Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:17:25
uzLQsGWbFJv6hRGbSX1IzJwBby46Xp64	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:17:27.891Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:17:28
wlm2m-OHd8n9pU2LPjTxRqxmNbyNRLXl	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:20:00.493Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ab8e9913-6574-4d6e-8085-052c03027961", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:20:01
7vy3nztSnSIPel5pDvfrmN-VwkxULZb1	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T18:07:34.487Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 18:07:41
T0X0YnPpGRI-_DDI_n5H5dzY4pWyoflu	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T18:07:34.580Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 18:07:39
4BpVOH1XuFLFzLFCufgHRnhP3uxcVFm-	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:08:07.663Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "81df93f9-9adb-49e5-b635-a49190c26f8c", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:09:00
-4MCFMWSi84Dr8j2-x0kqWBgMAyjuCqf	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:46:56.157Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "3", "captchaIssuedAt": 1767386816157}	2026-01-09 20:46:57
6giyhCAHewnYwpWHLr70XtGZ9qnRVwBH	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:47:13.042Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:47:14
BRnJQMfWVLpTu_sfYF6sSQkec_hnGNN8	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:47:13.073Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "-1", "captchaIssuedAt": 1767386833073}	2026-01-09 20:47:14
MHMgys58bGCoo5mojukWwranf-AdmFC2	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:47:29.562Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:47:30
oisBZ-s8L0b89HNJg4rQPgQ2nlnn2-m3	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:47:29.591Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "8", "captchaIssuedAt": 1767386849591}	2026-01-09 20:47:30
T_M_mvAEtgoxpeEMSYvBNuNGd668g21c	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:47:40.882Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:47:41
ZDlN1sN4b6TkPiH2ERkU7V4bL7bRycYr	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:47:40.919Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "7", "captchaIssuedAt": 1767386860919}	2026-01-09 20:47:41
URFGVM64PXEIvSEXqxz_LlMA-lvla1nb	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:47:53.879Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:47:54
NHCTFlxLNwCoxRtk1r-5A1BH60RZuLXo	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:47:53.913Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "3", "captchaIssuedAt": 1767386873912}	2026-01-09 20:47:54
S1K1q_cv_9lBC771uHcBRTFobKY_c41c	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:48:09.344Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:48:10
87lz8u1GPm7P35-N60VEWOVQbAu2mCLN	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:48:09.382Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "28", "captchaIssuedAt": 1767386889382}	2026-01-09 20:48:10
EBhWcvgs46TJPOASzmCswlQWn1v1EGNA	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:48:20.901Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:48:21
jL4eei5xI2WEaCi5rGTz3mhKWyBAhiW-	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:48:20.933Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "13", "captchaIssuedAt": 1767386900933}	2026-01-09 20:48:21
QRB1jB27Plj5UIz2HQfBHLH9CvJY1M0M	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:48:31.925Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "4", "captchaIssuedAt": 1767386911925}	2026-01-09 20:48:32
fKxGnbHrRP08tRNfWdmNX_qHHTZ00K6a	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:48:35.304Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:48:36
xdCI8D-r_KHxBDKH6dTxo29LJHpKZ8jt	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:48:35.344Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "1", "captchaIssuedAt": 1767386915344}	2026-01-09 20:48:36
DcrrKDjszcRqb_v7y6y1TQh1mFt1HS4_	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:50:47.098Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:50:48
j9oyIJg_KBNhRv9eBF8A0-72xphxFukT	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:50:47.153Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "1", "captchaIssuedAt": 1767387047153}	2026-01-09 20:50:48
PZc6I1sEoryxpNnNdUG7PEkWOh1Mcx3p	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:51:08.165Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:51:09
_aEBucAu8MAQnE4D9y4ABe4iBM-AFsBz	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:51:08.211Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "0", "captchaIssuedAt": 1767387068210}	2026-01-09 20:51:09
ML-5DexN9uavWBaqha0SHgpWhxd3VNVQ	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:51:26.143Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:51:27
xvTHlxu-jgqcmyhdVp23PBNAwv08KrpM	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:51:26.189Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "72", "captchaIssuedAt": 1767387086189}	2026-01-09 20:51:27
ixj3aOngxvDSQqoeGQq5zh8RgerZSrg4	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:51:50.231Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:51:51
uamY6QY7Gbl4pyV1xNf_h-SNDDlPjIY1	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:51:50.261Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "8", "captchaIssuedAt": 1767387110261}	2026-01-09 20:51:51
YOXQFie6yOd2CFzlDuUwFV83vf2jMAkM	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:52:02.615Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:52:03
d4yJf5xkZdCg8GIFQe-qB3_fvHLrejFi	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:52:02.653Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "-2", "captchaIssuedAt": 1767387122653}	2026-01-09 20:52:03
lEbp6caRJk1c49dvV6I0DQkPWqqjauHT	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:52:13.013Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:52:14
Zy63oazS4Zv2S4kFzDcgsyuLmBueOF8u	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:52:13.058Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "13", "captchaIssuedAt": 1767387133058}	2026-01-09 20:52:14
rksarvR383bgwz74sQX8jG4p8Vp__STa	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:52:33.012Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:52:34
t5lLG5J1qn2D2fAmwjbt4V8eDrc5DrzJ	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:52:33.066Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "20", "captchaIssuedAt": 1767387153066}	2026-01-09 20:52:34
ydZTzBNuhRCYQ4TVxJi3e6xIUCeJT1lD	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:54:07.831Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:54:08
Hzm7zgChmcsQsEgO2lcEUCeyTk5tYJRM	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:54:07.861Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "5", "captchaIssuedAt": 1767387247861}	2026-01-09 20:54:08
3LsTgEE4NenH3JGigKt6dw3FXDL1JS87	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:54:11.184Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "36", "captchaIssuedAt": 1767387251184}	2026-01-09 20:54:12
8wk7xvDfowcWnIhMsYyFEna-p2NnDYrw	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:54:16.608Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:54:17
dH7x6AZVAadxL-Fann6E28IDQV3uB_2f	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:54:16.637Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "32", "captchaIssuedAt": 1767387256637}	2026-01-09 20:54:17
h4DwwImYNj4filhdo2CHx_0zoIpy1x3G	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:54:28.556Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:54:29
67NOlxds0YXcy0IN8M5G1806aVQ7NJah	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:54:28.637Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "-2", "captchaIssuedAt": 1767387268637}	2026-01-09 20:54:29
CxVoAowC_9qYD9ibDdWrG4pF50sj2fIt	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:55:25.771Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:55:26
XW8_n_uvKehz9Z9qS_8WR3xQuXu14GEX	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:55:25.810Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "5", "captchaIssuedAt": 1767387325810}	2026-01-09 20:55:26
xQyASp_9OJM6mXEN3A0HzKf9HQiqm0EW	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:55:41.616Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "36", "captchaIssuedAt": 1767387341616}	2026-01-09 20:55:42
vaqfO_5rrlGjdSVlES5jxzJsLFTCZWBz	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:55:48.059Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:55:49
0L4mC8X0VdCx-QKYGk27ylBexCgaUOTO	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:55:48.100Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "15", "captchaIssuedAt": 1767387348100}	2026-01-09 20:55:49
tfwewUE6GGErdgEfOgGNYPFf5PSoBJ3v	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:55:57.917Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "48", "captchaIssuedAt": 1767387357917}	2026-01-09 20:55:58
AWrhqn8ovO4ghxqtAUru8IpD65EW99pA	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:56:03.681Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:56:04
KyeGKCf1MwI-UXlmnTOfEprMFDN6_U8t	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:56:03.713Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "6", "captchaIssuedAt": 1767387363712}	2026-01-09 20:56:04
jDwLhH9lf0oHc07mnUoRDUiNbVb6ddro	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:59:02.332Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:59:03
tHtOgkN9aG5tKbIXscltYdqFFLX9znIC	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:59:02.384Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "-3", "captchaIssuedAt": 1767387542384}	2026-01-09 20:59:03
dtbmBxWCotYeHqBMHnxs32_MJltGW9nY	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:59:05.456Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "18", "captchaIssuedAt": 1767387545456}	2026-01-09 20:59:06
7E1_OBIU6b22cgU2x663YZB8ku3qAx3T	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:59:07.216Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "12", "captchaIssuedAt": 1767387547216}	2026-01-09 20:59:08
kODoa3P_Q8Umnpm4GhzioBoV7JEU0PSP	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:59:13.393Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:59:14
rA-5QQcjKZ7ee81JFmBjjZTX9YSy_Skj	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:59:13.433Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "11", "captchaIssuedAt": 1767387553433}	2026-01-09 20:59:14
MJ9eAvX54hGe1DwIhlHWgOOEBwdzz6rW	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:59:45.064Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "-2", "captchaIssuedAt": 1767387585064}	2026-01-09 20:59:46
xd1AUucirA9a1NxI_AiCDWE6oXC492oD	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:59:53.467Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:59:54
NK9XLmEmk6awwg0rwG9MmZMMOlxKkKXQ	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:59:53.501Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "16", "captchaIssuedAt": 1767387593501}	2026-01-09 20:59:54
E0HJD-wnIlqOY4RAXwOlfiMz4mgsyEwd	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T21:01:59.117Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 21:02:00
fzlg_Ye4htCQ88fSS78D9b3Wx4COyYiI	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T21:01:59.151Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "14", "captchaIssuedAt": 1767387719150}	2026-01-09 21:02:00
0jMFxmWTgD3gqxrvbWLBjcMJ9e1pB0HD	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T21:02:12.809Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 21:02:13
fikzcJkXAvoAWxzDjpfVyv24AypDXtei	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T21:02:12.836Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "10", "captchaIssuedAt": 1767387732836}	2026-01-09 21:02:13
XgLlMmaMFHk57zgqYgbX866xmYwxvFrq	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T21:02:37.833Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 21:02:38
0XpymWb3VLz2M0Wfup0E1WHHh4IgiivY	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T21:02:37.866Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": "12", "captchaIssuedAt": 1767387757866}	2026-01-09 21:02:38
5C3qEUj5fey1eNhk9zYLsDTLCgXwXdrV	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:14:38.880Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d13ddb2c-478e-402c-b536-f203f16ac411", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:14:41
qxloczX8aTejtbQsR2CIrUoJUqzKd2_4	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:14:38.690Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "63e4c7b7-0359-4fc7-8210-97a6d5675267", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:14:45
q6Gm5PtHpHQnSGGYYBSQD5D_hV-UKxBh	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:14:38.782Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "9a4b7d15-77b9-4df9-8781-cbec927b3423", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:14:44
zc1FEzyeQ5B3YWRXEF26k6F_q9hEYDlj	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-10T04:58:20.235Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "81df93f9-9adb-49e5-b635-a49190c26f8c", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-10 05:03:25
30fGeerzO8ZrWAUH4Ar5oZ87ujBWdONF	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:17:16.878Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:17:17
cX0R3A9lqTG5lWh4qShm2HKz6yLhofxc	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:17:34.060Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "9a4b7d15-77b9-4df9-8781-cbec927b3423", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:17:39
aPpybtORrMe-GP6NXh2tdK_jy1VP0n17	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:17:34.151Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d13ddb2c-478e-402c-b536-f203f16ac411", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:17:39
LTvJ5LhvR74M6s_vPaqm-QrEP9nwxv2f	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:17:33.963Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "63e4c7b7-0359-4fc7-8210-97a6d5675267", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:17:41
kQJGWkX4pVP-Tu82DYHwCwXjAjagzYF1	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:18:11.829Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:18:12
NJwOWkyAIjQHbbFNE7FeV30WicH1D7b5	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:56:45.193Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d13ddb2c-478e-402c-b536-f203f16ac411", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:56:46
9fOpMGct2UC3qkD_L-tPDXTBr82xoNva	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T11:56:45.095Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ab8e9913-6574-4d6e-8085-052c03027961", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 11:56:47
qkX9IGMZlr0SaPi2PAZLzfQgS91cwOLq	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:00:50.804Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ab8e9913-6574-4d6e-8085-052c03027961", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:00:51
XagJpxMgfIOAfeKGV58cz84m3Wgs1pI6	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:00:50.902Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d13ddb2c-478e-402c-b536-f203f16ac411", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:00:51
r-i4wznzyUR0wo3nzO178sGBBjPG1DIp	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:20:00.631Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d13ddb2c-478e-402c-b536-f203f16ac411", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:20:01
otYNRAV0tAGJy-3TetsM9Woparwfpp7k	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:02:17.263Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ab8e9913-6574-4d6e-8085-052c03027961", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:02:18
OqkSMYjmoJ_h9ZANX-ubEWu7MaxE6Ir2	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:02:17.354Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d13ddb2c-478e-402c-b536-f203f16ac411", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:02:18
WLblgg9jTLXSvh8Xx61HZOA43WBWt0l2	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:03:15.513Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ab8e9913-6574-4d6e-8085-052c03027961", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:03:16
7AEuHYkrP5E0eq7_ozGO5inWBIGNDY5e	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:03:15.606Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d13ddb2c-478e-402c-b536-f203f16ac411", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:03:16
SVQdh7Wf2kC2s3CTTtxZOoNVLjw7JeqY	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:04:23.037Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ab8e9913-6574-4d6e-8085-052c03027961", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:04:24
18Cpkms53I5eHZM-zeJbMLXUMsy6lTH1	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:04:23.129Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d13ddb2c-478e-402c-b536-f203f16ac411", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:04:24
VggPIi560opCiM1RjYdJHCHXKluR1LMQ	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:12:21.302Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ab8e9913-6574-4d6e-8085-052c03027961", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:12:22
Jyx9S7cqsOKd4YmahkAprco0V4vQgfE-	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:12:21.397Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d13ddb2c-478e-402c-b536-f203f16ac411", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:12:22
74tI2rRQtIlruR8QoOPmLFNX28PYvxAC	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:13:54.226Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ab8e9913-6574-4d6e-8085-052c03027961", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:13:55
pMV4g4sRU-ff8sXKDK_RwGhtd-peNmB1	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:13:54.339Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d13ddb2c-478e-402c-b536-f203f16ac411", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:13:55
YKq4bZPFEWLWYv9Byzc-XA3jgDLLPwBd	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:15:15.214Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ab8e9913-6574-4d6e-8085-052c03027961", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:15:16
E1qy7zxin9kDr3TwR1e0Jp6IEzD0SUpW	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:15:15.306Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d13ddb2c-478e-402c-b536-f203f16ac411", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:15:16
GekfmUsDpUqbpVm4K2FdobYWHJ7_55S_	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:16:49.076Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "ab8e9913-6574-4d6e-8085-052c03027961", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:16:50
CUtHjTgW5W9Hfo_qnG9MtCgFa3KdW4BV	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-11T12:16:49.166Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "d13ddb2c-478e-402c-b536-f203f16ac411", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-11 12:16:50
\.


--
-- Data for Name: storage_objects; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.storage_objects (id, object_key, storage_provider, file_type, category, mime_type, size_bytes, checksum_sha256, uploaded_by, application_id, document_id, created_at, last_accessed_at) FROM stdin;
ef20e435-5273-422a-95d1-955cf56b44a0	revenue-paperss/57ae25a2-6a63-4963-80e5-2387bdee3fe4	local	revenue-papers	revenue_papers	application/pdf	2753978	\N	\N	2cd779b9-9004-43b8-b91f-78728a4174ff	273b157d-af69-4dbe-bcb4-2c2627f54b24	2026-01-04 18:12:15.326908	\N
5e67578a-5f78-471d-9dd5-2508cd5bad96	affidavit-section29s/ff732166-b0de-4ee4-b4f3-f56b4b6e8036	local	affidavit-section29	affidavit_section_29	application/pdf	2753978	\N	\N	2cd779b9-9004-43b8-b91f-78728a4174ff	c7a85f0b-e3f2-4934-b93c-e3203ec29a2e	2026-01-04 18:12:19.611388	\N
71b884bb-64e4-4f65-be3e-51717633310d	undertaking-form-cs/f8321ece-5b46-4aea-9801-f2f06bb1af8f	local	undertaking-form-c	undertaking_form_c	application/pdf	2753978	\N	\N	2cd779b9-9004-43b8-b91f-78728a4174ff	2001a2a3-ebae-49d7-843b-0207e9b69ce4	2026-01-04 18:12:23.876258	\N
61188518-e57e-46ef-abfb-4ed499e1d21c	property-photos/1a675657-b154-4fbd-8c90-a2f5707849be	local	property-photo	property_photo	image/jpeg	480003	\N	\N	2cd779b9-9004-43b8-b91f-78728a4174ff	6fbbac33-b628-4e33-b426-3575cd35c7a5	2026-01-04 18:12:43.792619	\N
3a590f23-087f-4fd7-91f9-57c4b9988427	property-photos/bb66c07c-fbdf-450a-9e05-25f25e9d9d89	local	property-photo	property_photo	image/jpeg	514031	\N	\N	2cd779b9-9004-43b8-b91f-78728a4174ff	cbd6d86f-0268-4f2d-a50d-5627260c62ac	2026-01-04 18:12:43.902926	\N
34644157-1297-45ea-8250-5fb18345f462	property-photos/eaca8504-5fb5-4e63-8b7b-182f36b635b0	local	property-photo	property_photo	image/jpeg	400821	\N	\N	2cd779b9-9004-43b8-b91f-78728a4174ff	1fed3e12-59bf-44d0-9d95-2eb15d15fb5b	2026-01-04 18:12:44.00599	\N
1462c275-2eac-47c9-9a77-e5ab1e9216b2	property-photos/5b833b34-121b-42d1-be0d-955432596e7b	local	property-photo	property_photo	image/jpeg	411316	\N	\N	2cd779b9-9004-43b8-b91f-78728a4174ff	6dabc967-3ce7-4b6e-b155-4ba3a525772f	2026-01-04 18:12:58.06787	\N
63c7ca01-d592-4759-96d3-940c86c1e876	additional-documents/d30308ae-af16-4d45-b478-8a746c797285	local	additional-document	additional_document	image/jpeg	425434	\N	\N	2cd779b9-9004-43b8-b91f-78728a4174ff	5aa90ace-4e02-413f-affd-e7086b5f0443	2026-01-04 18:13:09.187463	\N
3e66f201-0761-4c42-add8-cd50748585c4	additional-documents/96e1af5e-3c7c-4fc2-9368-da54fd2119b5	local	additional-document	additional_document	image/jpeg	508854	\N	\N	2cd779b9-9004-43b8-b91f-78728a4174ff	05c7dc6f-0b9a-4680-91fb-e6d08a7c37c0	2026-01-04 18:13:09.285146	\N
b82d43a8-5831-41b1-852c-44c11feca00a	additional-documents/98abcea1-aa88-4686-9a09-aa7bb1abbf7f	local	additional-document	additional_document	application/pdf	6658	\N	\N	2cd779b9-9004-43b8-b91f-78728a4174ff	348ad86f-138a-4545-a892-663fbf132b7c	2026-01-04 18:13:16.356655	\N
b8c44e43-a755-4afa-8c1c-f04c6c098a91	documents/ac1f0ec5-2b76-494d-9dda-01a3e16f42b8	local	document	legacy_certificate	application/pdf	61398	\N	\N	f92123b1-9025-4152-9957-a3d35a388a9b	3e58ad18-d364-44ad-9a06-44dd18b9123f	2026-01-04 13:34:10.69782	\N
506950e0-4338-49e7-b360-6d28625578db	documents/04538150-5bd6-4fa5-a763-e7e3107f4597	local	document	owner_identity_proof	application/pdf	61398	\N	\N	f92123b1-9025-4152-9957-a3d35a388a9b	92193374-9342-4c92-af1f-ff7a944ca4af	2026-01-04 13:34:03.584025	\N
06252890-bf1a-43c8-adbf-f700bc39433d	revenue-paperss/f62991df-b598-413f-9e2d-a9d19708e288	local	revenue-papers	revenue_papers	application/pdf	6658	\N	\N	08240a35-8245-45d0-8cf0-f1e25d66580d	7cb4e59c-c12d-4309-8f13-6131b3e0de74	2026-01-05 05:10:15.014757	\N
38f9e636-5434-410d-9f15-a4b8c7dd217d	affidavit-section29s/538293b2-f2a8-4acf-ba0f-9f0caeb93ac7	local	affidavit-section29	affidavit_section_29	application/pdf	61398	\N	\N	08240a35-8245-45d0-8cf0-f1e25d66580d	179cd7bb-dc15-4f39-95c2-9c508bfe7ab7	2026-01-05 05:10:35.902501	\N
2ff7187e-6e9a-466f-8868-057b001d7194	documents/31b5252e-c9c0-4926-8af7-71ed083296ce	local	document	photos	image/jpeg	411316	faa69cf804339b201231a491f5bcafbb214e9f513e9ebdf3f9e618712e8c82a9	81dff758-3726-43dc-9d59-41ef0f2eda2a	\N	\N	2026-01-04 18:28:27.685552	\N
e421f12f-de63-4385-8826-104610d90c0c	documents/ef1e99d2-483b-4775-971c-aa7b9df78df0	local	document	photos	image/jpeg	425434	fa20b96c1984595473572ae977b89507258db0f068421c709a6ef34f2b096dff	81dff758-3726-43dc-9d59-41ef0f2eda2a	\N	\N	2026-01-04 18:28:27.798031	\N
c6d21fe8-f77f-4d3f-9cc7-6e57e30718ed	documents/4dd7d1fd-d556-4587-8a52-0cce809be857	local	document	photos	image/jpeg	508854	65f552bc0c9f5577aa00f68271e298455f0dc47d126c56ce822897d0621b14ee	81dff758-3726-43dc-9d59-41ef0f2eda2a	\N	\N	2026-01-04 18:28:27.91631	\N
4acad8d8-075c-4dff-8efc-a5d4a3382484	documents/18ef4b3b-fb2f-4297-adcb-1247d51b8a61	local	document	legacy_certificate	application/pdf	2753978	\N	\N	591c7126-d5e4-4665-952a-4da7a49bf6bb	ce5f97fb-b67c-4c6e-99e1-7ad89ee6c8a5	2026-01-04 18:18:02.654899	\N
358fcaea-ead7-4611-a026-af80a0e16553	documents/49ba9d24-5dcc-4e68-bf70-bf12b8223499	local	document	owner_identity_proof	application/pdf	2753978	\N	\N	591c7126-d5e4-4665-952a-4da7a49bf6bb	5f6641ad-3322-4265-8709-31cc3a2f5e5d	2026-01-04 18:17:57.478989	\N
d02b2316-8624-4a30-9056-9e45e35ba79c	revenue-paperss/67232f5b-79ec-4c2a-892c-51f2fd1ab6e6	local	revenue-papers	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	5b5005d2-738d-45dd-8664-f53fd0544f3d	\N	\N	2026-01-04 19:17:26.778637	\N
86610374-cde7-4f05-8d84-04f0a1347282	affidavit-section29s/9a562bcd-2c20-48bd-a687-95ef531c0423	local	affidavit-section29	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	5b5005d2-738d-45dd-8664-f53fd0544f3d	\N	\N	2026-01-04 19:17:36.504469	\N
344c8f35-eddd-47de-8f41-b65f6f6b710e	undertaking-form-cs/ee98d28b-d32a-40aa-b6d6-7f06af4c5458	local	undertaking-form-c	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	5b5005d2-738d-45dd-8664-f53fd0544f3d	\N	\N	2026-01-04 19:17:39.957542	\N
20fd419c-28fa-47a0-bcfd-bc90a7c38615	commercial-electricity-bills/3695e269-8acf-46f3-8e13-3ba4e1b11b6d	local	commercial-electricity-bill	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	5b5005d2-738d-45dd-8664-f53fd0544f3d	\N	\N	2026-01-04 19:17:44.51925	\N
ecd3d6d3-1ddf-49ab-ab6e-8f8b2e9f0226	commercial-water-bills/5438f625-381b-4714-bf0a-1f6080561433	local	commercial-water-bill	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	5b5005d2-738d-45dd-8664-f53fd0544f3d	\N	\N	2026-01-04 19:17:48.600881	\N
d6e11361-4fc4-40b8-8a33-5dcca6efc208	property-photos/fa535538-aea8-4ab9-aeac-65224d125da8	local	property-photo	photos	image/jpeg	96524	02f226a52cfa9b5054adcfe008a6b8885b9a5f56adc2d53ad3382d9502cbd6dd	5b5005d2-738d-45dd-8664-f53fd0544f3d	\N	\N	2026-01-04 19:17:54.811007	\N
c9930463-abe7-4ef9-a8fd-bcfc52665982	property-photos/1e61d8be-f0d8-410e-b4ee-151fc6ce842e	local	property-photo	photos	image/jpeg	13584	12434b6deb0704e02e9f467b990ca3498923894c9c205a1ab3acff0f3eb8a846	5b5005d2-738d-45dd-8664-f53fd0544f3d	\N	\N	2026-01-04 19:17:54.903145	\N
784aa092-7915-4ce2-bbaa-209188871b9b	property-photos/870d007e-49c4-4c1b-ba59-97dcee76e073	local	property-photo	photos	image/jpeg	98782	52f471ee0bc0cc8de607df7bab4787266c5b4ead1cf339e7a0316bae2f1a4cee	5b5005d2-738d-45dd-8664-f53fd0544f3d	\N	\N	2026-01-04 19:17:54.967985	\N
168f8c9c-3a69-4e2d-b2a6-d3a5ed9c8f11	undertaking-form-cs/62679019-98a1-4895-9384-84377f516545	local	undertaking-form-c	undertaking_form_c	application/pdf	61398	\N	\N	08240a35-8245-45d0-8cf0-f1e25d66580d	1e57fbc3-7d57-43ca-878d-5000f3383a56	2026-01-05 05:10:41.771579	\N
92e01012-adfb-44ba-a131-660ef94e10e0	property-photos/adc1b906-186a-4af7-ba34-fa9f51d6a198	local	property-photo	property_photo	image/jpeg	96524	\N	\N	08240a35-8245-45d0-8cf0-f1e25d66580d	97a6106c-9e36-442d-a3bb-32451b0f253e	2026-01-05 05:10:48.323455	\N
070ddb8c-f068-44ee-9da0-f100f7a1338a	property-photos/acc357d9-b998-4e2b-8543-279d64faf1d7	local	property-photo	property_photo	image/jpeg	13584	\N	\N	08240a35-8245-45d0-8cf0-f1e25d66580d	11514b98-1567-4c45-abcb-626d557e9dcd	2026-01-05 05:10:48.396487	\N
2ad1fda7-3f07-4546-a802-54c05e85501c	additional-documents/77cfa216-9b85-430d-920c-0451b1204385	local	additional-document	additional_document	application/pdf	61398	\N	\N	08240a35-8245-45d0-8cf0-f1e25d66580d	0d474c67-4c4f-4222-ac15-a57e117b6b41	2026-01-05 05:24:32.837669	\N
a945ee10-5874-4405-8854-9fd5814244b0	additional-documents/d463a38e-e9cd-43e6-8cba-8c347f8096eb	local	additional-document	additional_document	image/jpeg	117294	\N	\N	08240a35-8245-45d0-8cf0-f1e25d66580d	85cd5d1f-a7c9-4e2e-b64d-1fbb80112e51	2026-01-05 05:24:44.057002	\N
e69ba39f-2309-484b-9a2c-22293d37f5f8	additional-documents/e5d59b61-ab8b-4b62-b287-a1406ecd61c9	local	additional-document	additional_document	image/jpeg	123434	\N	\N	08240a35-8245-45d0-8cf0-f1e25d66580d	5d5a3cd8-3b2e-49d5-a982-11f90767e1a4	2026-01-05 05:24:44.129075	\N
558d3957-a05b-4760-b39b-ec16c97a30a9	additional-documents/0df2675b-80da-49b7-8444-55f36d112ec0	local	additional-document	additional_document	application/pdf	61398	\N	\N	08240a35-8245-45d0-8cf0-f1e25d66580d	91b5e5a6-f52a-4043-b880-8ceaecb7cc22	2026-01-05 05:24:44.202768	\N
ce7abef3-5dee-4e06-bbea-1f59c42d62fe	documents/3bb7b935-41d1-4ea6-aba3-2b5a7bc8e96e	local	document	legacy_certificate	application/pdf	61398	\N	\N	b891d186-598b-4b02-beed-e63d1ceb8e25	c7c25b98-45b8-4005-8ebc-304a937e1dfb	2026-01-05 06:45:10.021897	\N
45650960-75b9-4035-980f-b7b7e72f27ca	documents/837fcf1e-7a68-4c35-8ecf-4564b887f1b1	local	document	owner_identity_proof	application/pdf	61398	\N	\N	b891d186-598b-4b02-beed-e63d1ceb8e25	83c8f8c0-c09b-4e64-ada0-bdd61f66b4b4	2026-01-05 06:45:04.691601	\N
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.support_tickets (id, ticket_number, applicant_id, application_id, service_type, category, subject, description, status, priority, assigned_to, assigned_at, escalated_from, escalated_at, escalation_level, sla_deadline, sla_breach, resolved_at, resolved_by, resolution_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.system_settings (id, setting_key, setting_value, description, category, updated_by, created_at, updated_at) FROM stdin;
6baecb91-b1af-4dbf-940f-7eb5cfc49f23	admin_super_console_enabled	{"enabled": true}	Enable/disable super console	admin	super-admin-001	2026-01-02 16:27:55.175802	2026-01-02 16:28:02.879
5ddbde43-60c5-4bfd-8476-44c766019381	payment_workflow	{"workflow": "upfront", "upfrontSubmitMode": "auto"}	Payment workflow: 'upfront' = pay before submission, 'on_approval' = pay after approval	payment	super-admin-001	2026-01-02 17:53:41.452534	2026-01-02 17:53:41.452534
0202f0df-1322-467b-aaec-b53e4f540a48	woman_discount_mode	{"mode": "SEQUENTIAL"}	Configuration for woman owner discount calculation (Additive vs Sequential)	general	\N	2026-01-03 18:17:32.307371	2026-01-05 08:16:55.693
753dd4ae-1664-4711-b8a0-937032d387c6	backup_configuration	{"enabled": true, "schedule": "0 2 * * *", "includeEnv": true, "includeFiles": true, "lastBackupAt": "2026-01-05T20:30:00.039Z", "retentionDays": 30, "backupDirectory": "/home/subhash.thakur.india/Projects/hptourism-rc6/backups", "includeDatabase": true, "lastBackupError": "File sync failed: Command failed: rsync -av --delete \\"/home/subhash.thakur.india/Projects/hptourism-rc6/local-object-storage/\\" \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/\\"\\nrsync: [receiver] mkstemp \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/additional-documents/.0df2675b-80da-49b7-8444-55f36d112ec0.7IgIYV\\" failed: No such file or directory (2)\\nrsync: [receiver] mkstemp \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/additional-documents/.77cfa216-9b85-430d-920c-0451b1204385.MrQy1E\\" failed: No such file or directory (2)\\nrsync: [receiver] mkstemp \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/additional-documents/.d463a38e-e9cd-43e6-8cba-8c347f8096eb.SmWnsm\\" failed: No such file or directory (2)\\nrsync: [receiver] mkstemp \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/additional-documents/.e5d59b61-ab8b-4b62-b287-a1406ecd61c9.q04bp5\\" failed: No such file or directory (2)\\nrsync: [receiver] mkstemp \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/documents/.04538150-5bd6-4fa5-a763-e7e3107f4597.EMMZML\\" failed: No such file or directory (2)\\nrsync: [receiver] mkstemp \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/documents/.18ef4b3b-fb2f-4297-adcb-1247d51b8a61.wELz0b\\" failed: No such file or directory (2)\\nrsync: [receiver] mkstemp \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/documents/.31b5252e-c9c0-4926-8af7-71ed083296ce.akx73b\\" failed: No such file or directory (2)\\nrsync: [receiver] mkstemp \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/documents/.3bb7b935-41d1-4ea6-aba3-2b5a7bc8e96e.SIOwlK\\" failed: No such file or directory (2)\\nrsync: [receiver] mkstemp \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/documents/.49ba9d24-5dcc-4e68-bf70-bf12b8223499.BQEonN\\" failed: No such file or directory (2)\\nrsync: [receiver] mkstemp \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/documents/.4dd7d1fd-d556-4587-8a52-0cce809be857.5eW4RA\\" failed: No such file or directory (2)\\nrsync: [receiver] mkstemp \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/documents/.837fcf1e-7a68-4c35-8ecf-4564b887f1b1.Ywr6nB\\" failed: No such file or directory (2)\\nrsync: [receiver] mkstemp \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/documents/.ac1f0ec5-2b76-494d-9dda-01a3e16f42b8.C2f44P\\" failed: No such file or directory (2)\\nrsync: [receiver] mkstemp \\"/home/subhash.thakur.india/Projects/hptourism-rc6/backups/files/documents/.ef1e99d2-483b-4775-971c-aa7b9df78df0.ZPVhQV\\" failed: No such file or directory (2)\\nrsync error: some files/attrs were not transferred (see previous errors) (code 23) at main.c(1338) [sender=3.2.7]\\n", "lastBackupStatus": "failed"}	\N	general	\N	2026-01-02 20:30:00.674255	2026-01-05 20:30:00.547
78f644d2-9106-42ca-9818-f47574189ae4	upload_policy	{"photos": {"maxFileSizeMB": 20, "allowedMimeTypes": ["image/jpeg", "image/png", "image/jpg", "application/pdf"], "allowedExtensions": [".jpg", ".jpeg", ".png", ".pdf"]}, "documents": {"maxFileSizeMB": 5, "allowedMimeTypes": ["application/pdf", "image/jpeg", "image/png", "image/jpg"], "allowedExtensions": [".pdf", ".jpg", ".jpeg", ".png"]}, "totalPerApplicationMB": 25}	\N	general	super-admin-001	2026-01-02 17:50:13.290179	2026-01-02 23:21:44.367
c6c99748-4dfe-444d-ace2-7402f3d088f8	payment_test_mode	{"enabled": true}	When enabled, payment requests send ₹1 to gateway instead of actual amount (for testing)	payment	super-admin-001	2026-01-02 23:47:16.138069	2026-01-02 23:47:16.138069
02d5fe48-fb8b-4a4c-accf-c41a5e0af3ba	service_visibility_config	{"hotels": false, "homestay": true, "transport": false, "restaurants": false, "guest_houses": false, "winter_sports": false, "travel_agencies": false, "adventure_tourism": false}	Controls which services are visible on the portal	portal	super-admin-001	2026-01-03 05:38:36.051787	2026-01-03 05:38:36.051787
8d5a8a10-21d6-4073-9e66-f5098526b160	inspection_config	{"optionalKinds": ["existing_rc_onboarding", "delete_rooms", "cancel_certificate"]}	Configuration for inspection workflows (e.g. optional inspections)	workflow	super-admin-001	2026-01-03 05:38:43.345432	2026-01-03 05:38:45.569
629044c7-bda9-4911-9723-e49b3825e8c9	da_send_back_enabled	true	\N	general	super-admin-001	2026-01-03 17:04:42.147607	2026-01-03 17:04:42.147607
67b21915-bee4-43f8-87a3-829db1abe594	existing_owner_min_issue_date	"2022-01-01"	\N	general	super-admin-001	2026-01-03 17:04:51.212787	2026-01-03 17:04:51.212787
a922a67c-62ec-431b-9936-47c10b62b3ad	comm_email_gateway	{"custom": {"host": "mail.smtp2go.com", "port": 2525, "password": "osipl@2025", "username": "osipl.dev", "fromEmail": "hptourism@osipl.dev"}, "provider": "custom"}	Email gateway configuration	communications	super-admin-001	2026-01-03 17:21:32.840321	2026-01-03 17:21:32.840321
4568fe44-df40-4b96-aa8a-5f19f7e36aa5	comm_sms_gateway	{"nic": {"postUrl": "https://msdgweb.mgov.gov.in/esms/sendsmsrequestDLT", "password": "Tour@sml352", "senderId": "hpgovt", "username": "hpgovt-TACA", "templateId": "1007739248479536901", "departmentKey": "a63f7853-6297-44c7-820b-392541a47fc1"}, "provider": "nic"}	SMS gateway configuration	communications	super-admin-001	2026-01-03 17:18:58.070855	2026-01-04 18:41:45.263
\.


--
-- Data for Name: ticket_actions; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.ticket_actions (id, ticket_id, actor_id, actor_role, action, previous_status, new_status, previous_priority, new_priority, previous_assignee, new_assignee, notes, metadata, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: ticket_messages; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.ticket_messages (id, ticket_id, sender_id, sender_role, message, attachments, is_internal, is_read, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.user_profiles (id, user_id, full_name, gender, aadhaar_number, mobile, email, district, tehsil, block, gram_panchayat, urban_body, ward, address, pincode, telephone, fax, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.users (id, mobile, full_name, first_name, last_name, username, email, alternate_phone, designation, department, employee_id, office_address, office_phone, role, aadhaar_number, district, password, is_active, created_at, updated_at, sso_id, enabled_services) FROM stdin;
super-admin-001	9999999998	Super Admin	Super	Admin	superadmin	superadmin@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	super_admin	\N	Shimla	$2a$06$S7mxp03EketNPtR1BBdvGuwRvD9nWipdQ/PbMwQ.cl.hcKp8HPn7O	t	2026-01-02 09:42:21.026827	2026-01-02 09:42:21.026827	\N	["homestay"]
admin-001	9999999999	System Admin	System	Admin	admin	admin@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	admin	\N	Shimla	$2a$06$.f4u2sghE4IXU/dzFEzLPunbLsL28l85O6opHGo3YU2Lmmb.XDn8a	t	2026-01-02 09:42:21.035195	2026-01-02 09:42:21.035195	\N	["homestay"]
f6cb4b30-6ee5-4e8a-a9bb-4d64fdb9429e	9999999997	Admin RC Console	Admin	RC	adminrc	admin.rc@hp.gov.in	\N	\N	\N	\N	\N	\N	admin_rc	\N	Shimla	$2a$06$0QYufUVwpp5N5OMNbSRAOOKpL/dqgiTbMeAW8cc/FrtC5lwv0IuE6	t	2026-01-02 09:42:21.041465	2026-01-02 09:42:21.041465	\N	["homestay"]
3952942f-f717-4b22-9bc4-d5e27c6db818	7900001004	DTDO Hamirpur	DTDO	Hamirpur	dtdo_hamirpur	dtdo.hamirpur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Hamirpur (serving Una)	$2a$06$2eirr6ezhKJ3fUz5c7RV9.l6G6I.2sMCMWbtfGZGi38A9UVA9BqiW	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
0a4a9b95-7d3d-4bd1-9c9d-ca479bb2daa9	7900001001	DTDO Chamba	DTDO	Chamba	dtdo_chamba	dtdo.chamba@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Chamba HQ	$2a$06$ZPTeZyZQXiXpasJ0DbFmZuvHcXq3EBpq1ijViyegSdUZGG.5RGxTm	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
1e65a65b-ca18-45ea-925e-7577bd7b0cd8	7800001002	DA Bharmour	DA	Bharmour	da_bharmour	da.bharmour@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Bharmour Sub-Division	$2a$06$RmVRJRTQcQi0gD5bPwSnZewZC9L4uqw5ZVCDZXX8O3JdBhEtgFgCS	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
232b7c09-4c62-458a-b8d2-6164c7afcd63	7900001002	DTDO Bharmour	DTDO	Bharmour	dtdo_bharmour	dtdo.bharmour@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Bharmour Sub-Division	$2a$06$bqN65raMjajQzftm5QbJ5OZGR.dMk5HrsO8SkeuM4YcXvuIi5oqLG	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
aa6fd747-8e36-48d4-bc27-74a4ee53fe6c	7900001003	DTDO Shimla Hq	DTDO	Shimla Hq	dtdo_shimla_hq	dtdo.shimla-hq@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Shimla HQ (AC Tourism)	$2a$06$8umQQi9wcQKf7gquMbSRZOnkQKnW1QCXTsz8Vbd.sQt1SDYH.xfg6	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
9eaffff0-3c8d-4ce2-83b7-b45121d38c45	7800001004	DA Hamirpur	DA	Hamirpur	da_hamirpur	da.hamirpur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Hamirpur (serving Una)	$2a$06$P9GH4j3NN4MeRnC8KKLrqOvynSyM.Ugm1oF/xfIUG9Tiob5nmYOqa	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
cea141d1-5e8d-4d71-9043-3683940e7b05	7800001005	DA Kullu Manali	DA	Kullu Manali	da_kullu_manali	da.kullu-manali@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Kullu (Bhuntar/Manali)	$2a$06$6fbm/earBOOIULfkxOY6SOZ2YvdEzBjuiQpEe/Z54CrVc/fHE9/P6	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
e5c91f84-4bd0-427d-82e2-37e3a22df4bd	7800001006	DA Kullu Dhalpur	DA	Kullu Dhalpur	da_kullu_dhalpur	da.kullu-dhalpur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Kullu Dhalpur	$2a$06$TN7MPT2uxkQMr23yaZsMOet0acKY88s7Ja/KMIdPBOhDt90lGUGWG	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
3a1487c1-fa79-456d-a038-4943579ee6f9	7900001006	DTDO Kullu Dhalpur	DTDO	Kullu Dhalpur	dtdo_kullu_dhalpur	dtdo.kullu-dhalpur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Kullu Dhalpur	$2a$06$sto0cPSmLo4AcINcage.O.MZn4sGMAQbdoY9RrG35EfeLab4T681u	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
83b8f7c5-67ef-4dad-835f-6baf939d46f7	7800001007	DA Dharamsala	DA	Dharamsala	da_dharamsala	da.dharamsala@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Dharamsala (Kangra)	$2a$06$ZyuCshGSVUXdDrsQlLWE9.Do9qWj4/o/JFXhoV0/nbfkMq6ZwX/Hy	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
3238f961-8f9a-4965-a429-9a4faedfa7fc	7900001007	DTDO Dharamsala	DTDO	Dharamsala	dtdo_dharamsala	dtdo.dharamsala@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Dharamsala (Kangra)	$2a$06$OL1LQkyZpho8cipFS2Zc0ed2rJKfOyn.fDAOValGd53w4ncrWKUKq	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
82a9811b-1801-4f1e-b0e9-38ceec06cefb	7800001008	DA Kinnaur	DA	Kinnaur	da_kinnaur	da.kinnaur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Kinnaur (Reckong Peo)	$2a$06$.gzgb6k/69EJz6rXhua8kuytrOe8ohqhYMF8dylHjMqcLmgJIRQFC	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
2b9f5017-9c17-4a4c-8277-21824cef2807	7900001008	DTDO Kinnaur	DTDO	Kinnaur	dtdo_kinnaur	dtdo.kinnaur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Kinnaur (Reckong Peo)	$2a$06$E0qZ14KG4DqoZ9rPCeQaEOowCDGvcuo1gU4SVPxkYpKCINyZJ1Z6e	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
a11d16af-df2c-4d9e-b2df-b8b22fbf97fc	7800001009	DA Kaza	DA	Kaza	da_kaza	da.kaza@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Kaza (Spiti ITDP)	$2a$06$LoiNzL5uoGo2eJyVTnUcVu.lPZ0dtUYCzOv/hm8InF9t.UNY0G4gy	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
36570f96-a7ba-4000-90c3-1015283ade5d	7900001009	DTDO Kaza	DTDO	Kaza	dtdo_kaza	dtdo.kaza@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Kaza (Spiti ITDP)	$2a$06$Xt..lBZyVaOdVeaH4DynauEhNonb8qu9/TMqGAatfaorMPo3Z9vsm	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
84de0c4a-9349-4f33-8b14-ad6bb4e8e4f2	7800001010	DA Lahaul	DA	Lahaul	da_lahaul	da.lahaul@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Lahaul (Keylong)	$2a$06$1YengHAWHIBpEfej2zAVgufaHIgGwEQnRYmYzVYJMEWvcWnZyyXey	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
3155aff1-2f1d-476c-8095-b8e9ce541549	7900001010	DTDO Lahaul	DTDO	Lahaul	dtdo_lahaul	dtdo.lahaul@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Lahaul (Keylong)	$2a$06$3OPusg.brcYP8Y2OPuWzf.kz4uO.p3Lny4.qDSZ16.ylap7EPHwqa	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
bc1485b6-e522-4488-87f9-3cb18cc84e7c	7800001011	DA Mandi	DA	Mandi	da_mandi	da.mandi@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Mandi Division	$2a$06$GZer5E6So3zcphlHvbzUP.xaBWp5jnI9ZrghvjGg3KP.WZHdScvae	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
87010e8d-b6c2-44d7-ac9a-591040976b61	7800001012	DA Pangi	DA	Pangi	da_pangi	da.pangi@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Pangi (ITDP)	$2a$06$0qyZ.zKq6zzgJs6eHxQ7bOvgsaSqf6pq.wJP1WRMBMfwspPUZGw..	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
de6c5054-5b19-40ad-8cf6-b830b6128f31	7900001012	DTDO Pangi	DTDO	Pangi	dtdo_pangi	dtdo.pangi@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Pangi (ITDP)	$2a$06$luJS26EhGkSn/mrZRbn0K.NRMBbzZguG1rtkLX6kRhb09IFDNMxT2	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
876f6ff4-8e8b-42cb-8927-e8d74399a947	7800001013	DA Shimla	DA	Shimla	da_shimla	da.shimla@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Shimla Division	$2a$06$YAzDlWOn4gIpC.3b7oyjDuu5CGa3ePDtQMSoc64vFSOxfR/za18Lm	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
18122a8d-04cb-4616-87f6-ca91e130b5b1	8091444005	DTDO Shimla	DTDO	Shimla	dtdo_shimla	dtdo.shimla@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Shimla Division	$2a$06$qrFb3A6/3Tl0tUBftYd4EuWbu7JQbf8cKy2woAywJ9r06KNUmJ9Nm	t	2026-01-02 09:42:21.117699	2026-01-04 19:09:18.084	\N	["homestay"]
e24d0090-3e83-48c8-bd99-d863e7c1af20	7800001001	DA Chamba	DA	Chamba	da_chamba	da.chamba@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Chamba HQ	$2a$06$VTji/sOXykmoIaihztgOxeEJ.C9F5Rq3JMMDbl88k2ugS3x1iouYm	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
23c01613-84fa-4e75-8fee-49413fb0ef21	7777777714	Test Test	Test	Test	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	777777777714	\N	$2b$10$btCZN3vmj.FZaEvUAyyiJ.s1WxqbZXFHVNafcfTPi0YPvuASy3KAK	t	2026-01-05 04:37:08.534874	2026-01-05 04:37:08.534874	\N	["homestay"]
a801a2d0-336e-45df-a1f2-950c7001817f	8888888811	Test AAA	Test	AAA	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	888888888811	\N	$2b$10$NvAhTJS71OWq0vg8yep3dOO/VXoTDiY/WJFlH6hAcBQZv2vghZOGG	t	2026-01-05 04:46:23.387743	2026-01-05 04:46:23.387743	\N	["homestay"]
56a9b001-bfce-4c86-ab8b-42b07c735f1a	6666666631	Test  GGG	Test 	GGG	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	666666666663	\N	$2b$10$fdqZyW4Vflws8ntVSmj7G.5YNF2CcqNYkRXkmoV/jJrbyESszsYyq	t	2026-01-05 06:44:06.345336	2026-01-05 06:44:06.345336	\N	["homestay"]
219cd5e8-7198-41e0-855a-1300ceb67afc	7800001003	DA Shimla Hq	DA	Shimla Hq	da_shimla_hq	da.shimla-hq@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Shimla HQ (AC Tourism)	$2a$06$Kdcciy9jw8FcPJsV1osdC.f9haYFrYBS3wQriWt2ZKVpUGRN9qM4e	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
e589f645-db21-4bb7-92a3-a115f014353e	7900001005	DTDO Kullu Manali	DTDO	Kullu Manali	dtdo_kullu_manali	dtdo.kullu-manali@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Kullu (Bhuntar/Manali)	$2a$06$.sAtXNWaAKU2dZJ0a7uKFOhG69GCgd5AM7RCdNJr3mEfkaWkQQKGq	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
c11c4ddc-ca3e-4675-a234-1eb74c566be4	7900001011	DTDO Mandi	DTDO	Mandi	dtdo_mandi	dtdo.mandi@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Mandi Division	$2a$06$83q68Va2K/cnPCw.374jiuuXUOFY.3WAnTZ.RAZ/wUigxe8tjVbJO	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
cac03a4a-004b-41fc-b4d0-58ddb3116147	7800001014	DA Sirmaur	DA	Sirmaur	da_sirmaur	da.sirmaur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Sirmaur (Nahan)	$2a$06$coMO.MbkPT6Ujj611Gr8PeL69f9RjyytXMctg4w7VHn3ptyeF4peS	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
3e9ea3f8-a125-42ec-a04c-c561569f6490	7900001014	DTDO Sirmaur	DTDO	Sirmaur	dtdo_sirmaur	dtdo.sirmaur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Sirmaur (Nahan)	$2a$06$573cF2SpHXQL.SWJa45PeOLtsGyk9UTlkbT/oRXVsFLIX4lskeHnC	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
8a8343ea-91df-4be5-8c09-c1b56bb00d77	7800001015	DA Solan	DA	Solan	da_solan	da.solan@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Solan Division	$2a$06$NZ.GEGTdYWqIST6ps6PjL.UsEMAlDTrRyYQVCFGXNpnZa2RSPx/3S	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
2e330128-1d31-4e63-b67d-9db26b7f7844	7900001015	DTDO Solan	DTDO	Solan	dtdo_solan	dtdo.solan@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Solan Division	$2a$06$XUprb.iyJ5m9fd6thUbYyuK5nhCZFSMOWTlF0NNJwbsDJ5IN/5/7u	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
eeaa24d4-42e2-4328-aade-77c888c3b536	6666666610	Smoke Test User	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	Shimla	$2b$10$OEnfuI/apZs4aHXm9fq0UuRJzXvNC8nWeYzsR3bhnQaIUigh7Rq2K	t	2026-01-04 11:54:08.236231	2026-01-04 11:54:08.236231	\N	["homestay"]
ab8e9913-6574-4d6e-8085-052c03027961	6666666611	Smoke Test User	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	Shimla	$2b$10$OEnfuI/apZs4aHXm9fq0UuRJzXvNC8nWeYzsR3bhnQaIUigh7Rq2K	t	2026-01-04 11:54:08.331632	2026-01-04 11:54:08.331632	\N	["homestay"]
26852f3d-3ac9-4c66-a348-1a2f637bf7c1	8091441005	Subhash Thakur	Subhash	Thakur	\N	hptourism@osipl.com	\N	\N	\N	\N	\N	\N	property_owner	666666666661	\N	$2b$10$ldzOr3KkfCbUk1A3aaHaQOxz.mfb1IqiO5U/DDYwbr1RSTNVLEgai	t	2026-01-04 12:39:59.43469	2026-01-04 12:39:59.43469	\N	["homestay"]
20b4f9ce-0ff3-4235-847c-29b2bded0d51	7777777711	Test  BBB	Test 	BBB	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	777777777711	\N	$2b$10$7/9qBBfoirL2tSYX5P9jHeHxYha1JOsEXgibgTQ4SY68/9xrBjp7y	t	2026-01-04 13:32:40.026657	2026-01-04 13:32:40.026657	\N	["homestay"]
5b5005d2-738d-45dd-8664-f53fd0544f3d	7777777712	Test  AAA	Test 	AAA	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	777777777712	\N	$2b$10$hIuKm6B8TCCq.3qXSCixpOweAcHVPergBPg0RpNvmvCbE2Qsgfnrq	t	2026-01-04 18:10:10.905804	2026-01-04 18:10:10.905804	\N	["homestay"]
81dff758-3726-43dc-9d59-41ef0f2eda2a	7777777713	Test  BBB	Test 	BBB	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	777777777713	\N	$2b$10$rdpKWg4HxIpWCd1GilpACuo/2u7htssQPxUZnQh9V9m4XFb4iQzVK	t	2026-01-04 18:16:40.147459	2026-01-04 18:16:40.147459	\N	["homestay"]
d13ddb2c-478e-402c-b536-f203f16ac411	7900001013	DTDO Shimla	DTDO	Shimla	dtdo_shimla	dtdo.shimla@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Shimla Division	$2b$10$kGQ0TBTzVkbh0rNyP.uq0OQS6AYjt4ZM6Wy0ciR00KfrfwKQNTqVC	t	2026-01-04 11:14:15.102	2026-01-04 11:14:15.102	\N	["homestay"]
\.


--
-- Name: application_actions application_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: certificates certificates_application_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_application_id_unique UNIQUE (application_id);


--
-- Name: certificates certificates_certificate_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_certificate_number_unique UNIQUE (certificate_number);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: clarifications clarifications_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_pkey PRIMARY KEY (id);


--
-- Name: ddo_codes ddo_codes_district_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ddo_codes
    ADD CONSTRAINT ddo_codes_district_unique UNIQUE (district);


--
-- Name: ddo_codes ddo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ddo_codes
    ADD CONSTRAINT ddo_codes_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: grievance_audit_log grievance_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_audit_log
    ADD CONSTRAINT grievance_audit_log_pkey PRIMARY KEY (id);


--
-- Name: grievance_comments grievance_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_comments
    ADD CONSTRAINT grievance_comments_pkey PRIMARY KEY (id);


--
-- Name: grievances grievances_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_pkey PRIMARY KEY (id);


--
-- Name: grievances grievances_ticket_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_ticket_number_unique UNIQUE (ticket_number);


--
-- Name: himkosh_transactions himkosh_transactions_app_ref_no_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_app_ref_no_unique UNIQUE (app_ref_no);


--
-- Name: himkosh_transactions himkosh_transactions_ech_txn_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_ech_txn_id_unique UNIQUE (ech_txn_id);


--
-- Name: himkosh_transactions himkosh_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_pkey PRIMARY KEY (id);


--
-- Name: homestay_applications homestay_applications_application_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_application_number_unique UNIQUE (application_number);


--
-- Name: homestay_applications homestay_applications_certificate_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_certificate_number_unique UNIQUE (certificate_number);


--
-- Name: homestay_applications homestay_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_pkey PRIMARY KEY (id);


--
-- Name: inspection_orders inspection_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_pkey PRIMARY KEY (id);


--
-- Name: inspection_reports inspection_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_pkey PRIMARY KEY (id);


--
-- Name: lgd_blocks lgd_blocks_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_blocks lgd_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_pkey PRIMARY KEY (id);


--
-- Name: lgd_districts lgd_districts_district_name_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_district_name_unique UNIQUE (district_name);


--
-- Name: lgd_districts lgd_districts_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_districts lgd_districts_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_pkey PRIMARY KEY (id);


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_pkey PRIMARY KEY (id);


--
-- Name: lgd_tehsils lgd_tehsils_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_tehsils lgd_tehsils_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_pkey PRIMARY KEY (id);


--
-- Name: lgd_urban_bodies lgd_urban_bodies_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_urban_bodies lgd_urban_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_pkey PRIMARY KEY (id);


--
-- Name: login_otp_challenges login_otp_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.login_otp_challenges
    ADD CONSTRAINT login_otp_challenges_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: objections objections_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_pkey PRIMARY KEY (id);


--
-- Name: password_reset_challenges password_reset_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.password_reset_challenges
    ADD CONSTRAINT password_reset_challenges_pkey PRIMARY KEY (id);


--
-- Name: payments payments_gateway_transaction_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_gateway_transaction_id_unique UNIQUE (gateway_transaction_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: payments payments_receipt_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_receipt_number_unique UNIQUE (receipt_number);


--
-- Name: production_stats production_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.production_stats
    ADD CONSTRAINT production_stats_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: storage_objects storage_objects_object_key_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_object_key_unique UNIQUE (object_key);


--
-- Name: storage_objects storage_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_ticket_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_ticket_number_unique UNIQUE (ticket_number);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_setting_key_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_setting_key_unique UNIQUE (setting_key);


--
-- Name: ticket_actions ticket_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_pkey PRIMARY KEY (id);


--
-- Name: ticket_messages ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_unique UNIQUE (user_id);


--
-- Name: users users_aadhaar_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_aadhaar_number_unique UNIQUE (aadhaar_number);


--
-- Name: users users_mobile_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_mobile_unique UNIQUE (mobile);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_sso_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_sso_id_unique UNIQUE (sso_id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: users_district_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX users_district_idx ON public.users USING btree (district);


--
-- Name: users_mobile_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX users_mobile_idx ON public.users USING btree (mobile);


--
-- Name: users_role_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX users_role_idx ON public.users USING btree (role);


--
-- Name: application_actions application_actions_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: application_actions application_actions_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_officer_id_users_id_fk FOREIGN KEY (officer_id) REFERENCES public.users(id);


--
-- Name: audit_logs audit_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: certificates certificates_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_issued_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_issued_by_users_id_fk FOREIGN KEY (issued_by) REFERENCES public.users(id);


--
-- Name: certificates certificates_renewal_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_renewal_application_id_homestay_applications_id_fk FOREIGN KEY (renewal_application_id) REFERENCES public.homestay_applications(id);


--
-- Name: certificates certificates_revoked_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_revoked_by_users_id_fk FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: clarifications clarifications_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: clarifications clarifications_objection_id_objections_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_objection_id_objections_id_fk FOREIGN KEY (objection_id) REFERENCES public.objections(id) ON DELETE CASCADE;


--
-- Name: clarifications clarifications_reviewed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_reviewed_by_users_id_fk FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: clarifications clarifications_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: documents documents_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: documents documents_verified_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_verified_by_users_id_fk FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: grievance_audit_log grievance_audit_log_grievance_id_grievances_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_audit_log
    ADD CONSTRAINT grievance_audit_log_grievance_id_grievances_id_fk FOREIGN KEY (grievance_id) REFERENCES public.grievances(id) ON DELETE CASCADE;


--
-- Name: grievance_audit_log grievance_audit_log_performed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_audit_log
    ADD CONSTRAINT grievance_audit_log_performed_by_users_id_fk FOREIGN KEY (performed_by) REFERENCES public.users(id);


--
-- Name: grievance_comments grievance_comments_grievance_id_grievances_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_comments
    ADD CONSTRAINT grievance_comments_grievance_id_grievances_id_fk FOREIGN KEY (grievance_id) REFERENCES public.grievances(id) ON DELETE CASCADE;


--
-- Name: grievance_comments grievance_comments_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_comments
    ADD CONSTRAINT grievance_comments_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: grievances grievances_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: grievances grievances_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: grievances grievances_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: himkosh_transactions himkosh_transactions_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: homestay_applications homestay_applications_da_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_da_id_users_id_fk FOREIGN KEY (da_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_district_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_district_officer_id_users_id_fk FOREIGN KEY (district_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_dtdo_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_dtdo_id_users_id_fk FOREIGN KEY (dtdo_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_site_inspection_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_site_inspection_officer_id_users_id_fk FOREIGN KEY (site_inspection_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_state_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_state_officer_id_users_id_fk FOREIGN KEY (state_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: inspection_orders inspection_orders_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: inspection_orders inspection_orders_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: inspection_orders inspection_orders_scheduled_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_scheduled_by_users_id_fk FOREIGN KEY (scheduled_by) REFERENCES public.users(id);


--
-- Name: inspection_reports inspection_reports_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: inspection_reports inspection_reports_inspection_order_id_inspection_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_inspection_order_id_inspection_orders_id_fk FOREIGN KEY (inspection_order_id) REFERENCES public.inspection_orders(id) ON DELETE CASCADE;


--
-- Name: inspection_reports inspection_reports_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: lgd_blocks lgd_blocks_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_blocks lgd_blocks_tehsil_id_lgd_tehsils_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_tehsil_id_lgd_tehsils_id_fk FOREIGN KEY (tehsil_id) REFERENCES public.lgd_tehsils(id) ON DELETE SET NULL;


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_block_id_lgd_blocks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_block_id_lgd_blocks_id_fk FOREIGN KEY (block_id) REFERENCES public.lgd_blocks(id) ON DELETE CASCADE;


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_tehsils lgd_tehsils_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_urban_bodies lgd_urban_bodies_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: login_otp_challenges login_otp_challenges_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.login_otp_challenges
    ADD CONSTRAINT login_otp_challenges_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: notifications notifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: objections objections_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: objections objections_inspection_report_id_inspection_reports_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_inspection_report_id_inspection_reports_id_fk FOREIGN KEY (inspection_report_id) REFERENCES public.inspection_reports(id);


--
-- Name: objections objections_raised_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_raised_by_users_id_fk FOREIGN KEY (raised_by) REFERENCES public.users(id);


--
-- Name: objections objections_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: password_reset_challenges password_reset_challenges_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.password_reset_challenges
    ADD CONSTRAINT password_reset_challenges_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payments payments_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: reviews reviews_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: reviews reviews_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: storage_objects storage_objects_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE SET NULL;


--
-- Name: storage_objects storage_objects_document_id_documents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_document_id_documents_id_fk FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: storage_objects storage_objects_uploaded_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_uploaded_by_users_id_fk FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_applicant_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_applicant_id_users_id_fk FOREIGN KEY (applicant_id) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: support_tickets support_tickets_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_escalated_from_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_escalated_from_users_id_fk FOREIGN KEY (escalated_from) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: system_settings system_settings_updated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_actor_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_actor_id_users_id_fk FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_new_assignee_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_new_assignee_users_id_fk FOREIGN KEY (new_assignee) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_previous_assignee_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_previous_assignee_users_id_fk FOREIGN KEY (previous_assignee) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_ticket_id_support_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_ticket_id_support_tickets_id_fk FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_messages ticket_messages_sender_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_sender_id_users_id_fk FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: ticket_messages ticket_messages_ticket_id_support_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_ticket_id_support_tickets_id_fk FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: user_profiles user_profiles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: hptourism_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict V8zIZ7NFSHSZRJLMXnGtTZVJwDjm3W3Z2ckkLyxVZAPZ0gvc0hzusWTaMYKUSKo

