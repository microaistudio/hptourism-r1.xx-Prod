--
-- PostgreSQL database dump
--

\restrict B1pmODCOpFIyzgKWdhxUc2dgTwRU3SlWF73wIgwrZ4e4LdxjXm8erl2LOuTVXMO

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: hptourism_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO hptourism_user;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: hptourism_user
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: application_actions; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.application_actions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    officer_id character varying NOT NULL,
    action character varying(50) NOT NULL,
    previous_status character varying(50),
    new_status character varying(50),
    feedback text,
    issues_found jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.application_actions OWNER TO hptourism_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    action character varying(100) NOT NULL,
    details jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO hptourism_user;

--
-- Name: certificates; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.certificates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    certificate_number character varying(50) NOT NULL,
    certificate_type character varying(50) DEFAULT 'homestay_registration'::character varying,
    issued_date timestamp without time zone NOT NULL,
    valid_from timestamp without time zone NOT NULL,
    valid_upto timestamp without time zone NOT NULL,
    property_name character varying(255) NOT NULL,
    category character varying(20) NOT NULL,
    address text NOT NULL,
    district character varying(100) NOT NULL,
    owner_name character varying(255) NOT NULL,
    owner_mobile character varying(15) NOT NULL,
    certificate_pdf_url text,
    qr_code_data text,
    digital_signature text,
    issued_by character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    revocation_reason text,
    revoked_by character varying,
    revoked_date timestamp without time zone,
    renewal_reminder_sent boolean DEFAULT false,
    renewal_application_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.certificates OWNER TO hptourism_user;

--
-- Name: clarifications; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.clarifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    objection_id character varying NOT NULL,
    application_id character varying NOT NULL,
    submitted_by character varying NOT NULL,
    submitted_date timestamp without time zone NOT NULL,
    clarification_text text NOT NULL,
    supporting_documents jsonb,
    reviewed_by character varying,
    reviewed_date timestamp without time zone,
    review_status character varying(50),
    review_notes text,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.clarifications OWNER TO hptourism_user;

--
-- Name: ddo_codes; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.ddo_codes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    district character varying(100) NOT NULL,
    ddo_code character varying(20) NOT NULL,
    ddo_description text NOT NULL,
    treasury_code character varying(10) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ddo_codes OWNER TO hptourism_user;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.documents (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    document_type character varying(100) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path text NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(100) NOT NULL,
    upload_date timestamp without time zone DEFAULT now(),
    ai_verification_status character varying(50),
    ai_confidence_score numeric(5,2),
    ai_notes text,
    is_verified boolean DEFAULT false,
    verification_status character varying(50) DEFAULT 'pending'::character varying,
    verified_by character varying,
    verification_date timestamp without time zone,
    verification_notes text
);


ALTER TABLE public.documents OWNER TO hptourism_user;

--
-- Name: grievance_audit_log; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.grievance_audit_log (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    grievance_id character varying NOT NULL,
    action character varying(50) NOT NULL,
    old_value text,
    new_value text,
    performed_by character varying NOT NULL,
    performed_at timestamp without time zone DEFAULT now(),
    ip_address character varying(50),
    user_agent text
);


ALTER TABLE public.grievance_audit_log OWNER TO hptourism_user;

--
-- Name: grievance_comments; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.grievance_comments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    grievance_id character varying NOT NULL,
    user_id character varying NOT NULL,
    comment text NOT NULL,
    is_internal boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.grievance_comments OWNER TO hptourism_user;

--
-- Name: grievances; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.grievances (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_number character varying(50) NOT NULL,
    ticket_type character varying(20) DEFAULT 'owner_grievance'::character varying,
    user_id character varying,
    application_id character varying,
    category character varying(50) NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying,
    status character varying(20) DEFAULT 'open'::character varying,
    subject character varying(255) NOT NULL,
    description text NOT NULL,
    assigned_to character varying,
    resolution_notes text,
    attachments jsonb,
    last_comment_at timestamp without time zone,
    last_read_by_owner timestamp without time zone,
    last_read_by_officer timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone
);


ALTER TABLE public.grievances OWNER TO hptourism_user;

--
-- Name: himkosh_transactions; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.himkosh_transactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    dept_ref_no character varying(45) NOT NULL,
    app_ref_no character varying(20) NOT NULL,
    total_amount integer NOT NULL,
    tender_by character varying(70) NOT NULL,
    merchant_code character varying(15),
    dept_id character varying(10),
    service_code character varying(5),
    ddo character varying(12),
    head1 character varying(14),
    amount1 integer,
    head2 character varying(14),
    amount2 integer,
    head3 character varying(14),
    amount3 integer,
    head4 character varying(14),
    amount4 integer,
    head10 character varying(50),
    amount10 integer,
    period_from character varying(10),
    period_to character varying(10),
    encrypted_request text,
    request_checksum character varying(32),
    ech_txn_id character varying(10),
    bank_cin character varying(20),
    bank_name character varying(10),
    payment_date character varying(14),
    status character varying(70),
    status_cd character varying(1),
    response_checksum character varying(32),
    is_double_verified boolean DEFAULT false,
    double_verification_date timestamp without time zone,
    double_verification_data jsonb,
    challan_print_url text,
    transaction_status character varying(50) DEFAULT 'initiated'::character varying,
    initiated_at timestamp without time zone DEFAULT now(),
    responded_at timestamp without time zone,
    verified_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    portal_base_url text,
    is_archived boolean DEFAULT false
);


ALTER TABLE public.himkosh_transactions OWNER TO hptourism_user;

--
-- Name: homestay_applications; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.homestay_applications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    application_number character varying(50) NOT NULL,
    property_name character varying(255) NOT NULL,
    category character varying(20) NOT NULL,
    location_type character varying(10) NOT NULL,
    total_rooms integer NOT NULL,
    district character varying(100) NOT NULL,
    district_other character varying(100),
    tehsil character varying(100) NOT NULL,
    tehsil_other character varying(100),
    block character varying(100),
    block_other character varying(100),
    gram_panchayat character varying(100),
    gram_panchayat_other character varying(100),
    urban_body character varying(200),
    urban_body_other character varying(200),
    ward character varying(50),
    address text NOT NULL,
    pincode character varying(10) NOT NULL,
    telephone character varying(20),
    fax character varying(20),
    latitude numeric(10,8),
    longitude numeric(11,8),
    owner_name character varying(255) NOT NULL,
    owner_gender character varying(10) NOT NULL,
    owner_mobile character varying(15) NOT NULL,
    owner_email character varying(255),
    owner_aadhaar character varying(12) NOT NULL,
    property_ownership character varying(10) DEFAULT 'owned'::character varying NOT NULL,
    proposed_room_rate numeric(10,2),
    project_type character varying(20) NOT NULL,
    property_area numeric(10,2) NOT NULL,
    single_bed_rooms integer DEFAULT 0,
    single_bed_room_size numeric(10,2),
    single_bed_room_rate numeric(10,2),
    double_bed_rooms integer DEFAULT 0,
    double_bed_room_size numeric(10,2),
    double_bed_room_rate numeric(10,2),
    family_suites integer DEFAULT 0,
    family_suite_size numeric(10,2),
    family_suite_rate numeric(10,2),
    attached_washrooms integer NOT NULL,
    gstin character varying(15),
    selected_category character varying(20),
    average_room_rate numeric(10,2),
    highest_room_rate numeric(10,2),
    lowest_room_rate numeric(10,2),
    certificate_validity_years integer DEFAULT 1,
    is_pangi_sub_division boolean DEFAULT false,
    distance_airport numeric(10,2),
    distance_railway numeric(10,2),
    distance_city_center numeric(10,2),
    distance_shopping numeric(10,2),
    distance_bus_stand numeric(10,2),
    lobby_area numeric(10,2),
    dining_area numeric(10,2),
    parking_area text,
    eco_friendly_facilities text,
    differently_abled_facilities text,
    fire_equipment_details text,
    nearest_hospital character varying(255),
    amenities jsonb,
    rooms jsonb,
    base_fee numeric(10,2),
    total_before_discounts numeric(10,2),
    validity_discount numeric(10,2) DEFAULT '0'::numeric,
    female_owner_discount numeric(10,2) DEFAULT '0'::numeric,
    pangi_discount numeric(10,2) DEFAULT '0'::numeric,
    total_discount numeric(10,2) DEFAULT '0'::numeric,
    total_fee numeric(10,2),
    per_room_fee numeric(10,2),
    gst_amount numeric(10,2),
    status character varying(50) DEFAULT 'draft'::character varying,
    current_stage character varying(50),
    current_page integer DEFAULT 1,
    district_officer_id character varying,
    district_review_date timestamp without time zone,
    district_notes text,
    da_id character varying,
    da_review_date timestamp without time zone,
    da_forwarded_date timestamp without time zone,
    state_officer_id character varying,
    state_review_date timestamp without time zone,
    state_notes text,
    dtdo_id character varying,
    dtdo_review_date timestamp without time zone,
    dtdo_remarks text,
    rejection_reason text,
    clarification_requested text,
    site_inspection_scheduled_date timestamp without time zone,
    site_inspection_completed_date timestamp without time zone,
    site_inspection_officer_id character varying,
    site_inspection_notes text,
    site_inspection_outcome character varying(50),
    site_inspection_findings jsonb,
    ownership_proof_url text,
    aadhaar_card_url text,
    pan_card_url text,
    gst_certificate_url text,
    fire_safety_noc_url text,
    pollution_clearance_url text,
    building_plan_url text,
    property_photos_urls jsonb,
    documents jsonb,
    certificate_number character varying(50),
    certificate_issued_date timestamp without time zone,
    certificate_expiry_date timestamp without time zone,
    submitted_at timestamp without time zone,
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    single_bed_beds integer DEFAULT 1,
    double_bed_beds integer DEFAULT 2,
    family_suite_beds integer DEFAULT 4,
    application_kind character varying(30) DEFAULT 'new_registration'::character varying NOT NULL,
    parent_application_id character varying,
    parent_application_number character varying(50),
    parent_certificate_number character varying(50),
    inherited_certificate_valid_upto timestamp without time zone,
    service_context jsonb,
    service_notes text,
    service_requested_at timestamp without time zone,
    guardian_name character varying(255),
    da_remarks text,
    correction_submission_count integer DEFAULT 0 NOT NULL,
    application_type character varying(50) DEFAULT 'homestay'::character varying,
    water_sports_data jsonb,
    adventure_sports_data jsonb,
    guardian_relation character varying(20) DEFAULT 'father'::character varying,
    property_area_unit character varying(10) DEFAULT 'sqm'::character varying,
    key_location_highlight1 text,
    key_location_highlight2 text,
    nearby_attractions jsonb,
    mandatory_checklist jsonb,
    desirable_checklist jsonb,
    revert_count integer DEFAULT 0 NOT NULL,
    payment_status character varying(20) DEFAULT 'pending'::character varying,
    payment_id character varying(100),
    payment_amount numeric(10,2),
    payment_date timestamp without time zone,
    refund_date timestamp without time zone,
    refund_reason text,
    form_completion_time_seconds integer
);


ALTER TABLE public.homestay_applications OWNER TO hptourism_user;

--
-- Name: inspection_orders; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.inspection_orders (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    scheduled_by character varying NOT NULL,
    scheduled_date timestamp without time zone NOT NULL,
    assigned_to character varying NOT NULL,
    assigned_date timestamp without time zone NOT NULL,
    inspection_date timestamp without time zone NOT NULL,
    inspection_address text NOT NULL,
    special_instructions text,
    status character varying(50) DEFAULT 'scheduled'::character varying,
    dtdo_notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.inspection_orders OWNER TO hptourism_user;

--
-- Name: inspection_reports; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.inspection_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    inspection_order_id character varying NOT NULL,
    application_id character varying NOT NULL,
    submitted_by character varying NOT NULL,
    submitted_date timestamp without time zone NOT NULL,
    actual_inspection_date timestamp without time zone NOT NULL,
    room_count_verified boolean NOT NULL,
    actual_room_count integer,
    category_meets_standards boolean NOT NULL,
    recommended_category character varying(20),
    mandatory_checklist jsonb,
    mandatory_remarks text,
    desirable_checklist jsonb,
    desirable_remarks text,
    amenities_verified jsonb,
    amenities_issues text,
    fire_safety_compliant boolean,
    fire_safety_issues text,
    structural_safety boolean,
    structural_issues text,
    overall_satisfactory boolean NOT NULL,
    recommendation character varying(50) NOT NULL,
    detailed_findings text NOT NULL,
    inspection_photos jsonb,
    report_document_url text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.inspection_reports OWNER TO hptourism_user;

--
-- Name: lgd_blocks; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_blocks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    block_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    tehsil_id character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_blocks OWNER TO hptourism_user;

--
-- Name: lgd_districts; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_districts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    district_name character varying(100) NOT NULL,
    division_name character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_districts OWNER TO hptourism_user;

--
-- Name: lgd_gram_panchayats; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_gram_panchayats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    gram_panchayat_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    block_id character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_gram_panchayats OWNER TO hptourism_user;

--
-- Name: lgd_tehsils; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_tehsils (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    tehsil_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    tehsil_type character varying(50) DEFAULT 'tehsil'::character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_tehsils OWNER TO hptourism_user;

--
-- Name: lgd_urban_bodies; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.lgd_urban_bodies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    urban_body_name character varying(200) NOT NULL,
    district_id character varying NOT NULL,
    body_type character varying(50) NOT NULL,
    number_of_wards integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_urban_bodies OWNER TO hptourism_user;

--
-- Name: login_otp_challenges; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.login_otp_challenges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    otp_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.login_otp_challenges OWNER TO hptourism_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.notifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    application_id character varying,
    type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    channels jsonb,
    is_read boolean DEFAULT false,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO hptourism_user;

--
-- Name: objections; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.objections (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    inspection_report_id character varying,
    raised_by character varying NOT NULL,
    raised_date timestamp without time zone NOT NULL,
    objection_type character varying(50) NOT NULL,
    objection_title character varying(255) NOT NULL,
    objection_description text NOT NULL,
    severity character varying(20) NOT NULL,
    response_deadline timestamp without time zone,
    status character varying(50) DEFAULT 'pending'::character varying,
    resolution_notes text,
    resolved_by character varying,
    resolved_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.objections OWNER TO hptourism_user;

--
-- Name: password_reset_challenges; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.password_reset_challenges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    channel character varying(32) NOT NULL,
    recipient character varying(255),
    otp_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.password_reset_challenges OWNER TO hptourism_user;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.payments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    payment_type character varying(50) NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_gateway character varying(50),
    gateway_transaction_id character varying(255),
    payment_method character varying(50),
    payment_status character varying(50) DEFAULT 'pending'::character varying,
    payment_link text,
    qr_code_url text,
    payment_link_expiry_date timestamp without time zone,
    initiated_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    receipt_number character varying(100),
    receipt_url text
);


ALTER TABLE public.payments OWNER TO hptourism_user;

--
-- Name: production_stats; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.production_stats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    total_applications integer NOT NULL,
    approved_applications integer NOT NULL,
    rejected_applications integer NOT NULL,
    pending_applications integer NOT NULL,
    scraped_at timestamp without time zone DEFAULT now(),
    source_url text
);


ALTER TABLE public.production_stats OWNER TO hptourism_user;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.reviews (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    user_id character varying NOT NULL,
    rating integer NOT NULL,
    review_text text,
    is_verified_stay boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.reviews OWNER TO hptourism_user;

--
-- Name: session; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO hptourism_user;

--
-- Name: storage_objects; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.storage_objects (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    object_key text NOT NULL,
    storage_provider character varying(20) DEFAULT 'local'::character varying NOT NULL,
    file_type character varying(100) NOT NULL,
    category character varying(100) DEFAULT 'general'::character varying,
    mime_type character varying(100) DEFAULT 'application/octet-stream'::character varying,
    size_bytes integer DEFAULT 0 NOT NULL,
    checksum_sha256 character varying(128),
    uploaded_by character varying,
    application_id character varying,
    document_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    last_accessed_at timestamp without time zone
);


ALTER TABLE public.storage_objects OWNER TO hptourism_user;

--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.support_tickets (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_number character varying(50) NOT NULL,
    applicant_id character varying NOT NULL,
    application_id character varying,
    service_type character varying(50) DEFAULT 'homestay'::character varying,
    category character varying(50) NOT NULL,
    subject character varying(255) NOT NULL,
    description text NOT NULL,
    status character varying(30) DEFAULT 'open'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    assigned_to character varying,
    assigned_at timestamp without time zone,
    escalated_from character varying,
    escalated_at timestamp without time zone,
    escalation_level integer DEFAULT 0,
    sla_deadline timestamp without time zone,
    sla_breach boolean DEFAULT false,
    resolved_at timestamp without time zone,
    resolved_by character varying,
    resolution_notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.support_tickets OWNER TO hptourism_user;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.system_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value jsonb NOT NULL,
    description text,
    category character varying(50) DEFAULT 'general'::character varying,
    updated_by character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.system_settings OWNER TO hptourism_user;

--
-- Name: ticket_actions; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.ticket_actions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_id character varying NOT NULL,
    actor_id character varying,
    actor_role character varying(30),
    action character varying(50) NOT NULL,
    previous_status character varying(30),
    new_status character varying(30),
    previous_priority character varying(20),
    new_priority character varying(20),
    previous_assignee character varying,
    new_assignee character varying,
    notes text,
    metadata jsonb,
    ip_address character varying(45),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ticket_actions OWNER TO hptourism_user;

--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.ticket_messages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_id character varying NOT NULL,
    sender_id character varying NOT NULL,
    sender_role character varying(30) NOT NULL,
    message text NOT NULL,
    attachments jsonb,
    is_internal boolean DEFAULT false,
    is_read boolean DEFAULT false,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ticket_messages OWNER TO hptourism_user;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.user_profiles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    full_name character varying(255) NOT NULL,
    gender character varying(10) NOT NULL,
    aadhaar_number character varying(12),
    mobile character varying(15) NOT NULL,
    email character varying(255),
    district character varying(100),
    tehsil character varying(100),
    block character varying(100),
    gram_panchayat character varying(100),
    urban_body character varying(200),
    ward character varying(50),
    address text,
    pincode character varying(10),
    telephone character varying(20),
    fax character varying(20),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_profiles OWNER TO hptourism_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: hptourism_user
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    mobile character varying(15) NOT NULL,
    full_name text NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    username character varying(50),
    email character varying(255),
    alternate_phone character varying(15),
    designation character varying(100),
    department character varying(100),
    employee_id character varying(50),
    office_address text,
    office_phone character varying(15),
    role character varying(50) DEFAULT 'property_owner'::character varying NOT NULL,
    aadhaar_number character varying(12),
    district character varying(100),
    password text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    sso_id character varying(50),
    enabled_services jsonb DEFAULT '["homestay"]'::jsonb
);


ALTER TABLE public.users OWNER TO hptourism_user;

--
-- Data for Name: application_actions; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.application_actions (id, application_id, officer_id, action, previous_status, new_status, feedback, issues_found, created_at) FROM stdin;
b7b818a3-f959-455a-bd18-d9f04bcb75b8	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	264d453c-cbf8-403b-b36a-ccc671f1c705	owner_submitted	draft	submitted	Existing application finalized and submitted.	\N	2026-01-02 17:51:01.721009
a0820368-68a0-475f-8841-474599e166e9	726868b7-598d-44d3-92df-b9506a0d7376	f8b11841-95be-465d-814e-2dd2f5936b4a	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-02 18:07:34.841542
a5116697-f9bb-4562-8ff8-5f998b7f78db	726868b7-598d-44d3-92df-b9506a0d7376	876f6ff4-8e8b-42cb-8927-e8d74399a947	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-02 18:07:35.175044
8464fd3f-a176-410e-8fa8-86f194f585df	726868b7-598d-44d3-92df-b9506a0d7376	876f6ff4-8e8b-42cb-8927-e8d74399a947	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Smoke-test automated forwarding.	\N	2026-01-02 18:07:35.586954
e6d73e61-9e4b-4e70-831b-11e8d50e632c	726868b7-598d-44d3-92df-b9506a0d7376	18122a8d-04cb-4616-87f6-ca91e130b5b1	dtdo_accept	forwarded_to_dtdo	dtdo_review	Smoke-test: accepting application.	\N	2026-01-02 18:07:35.912737
6d3d7a2d-6c9f-4907-be14-2810477155f6	1346b4e4-9e80-40b6-9d1a-b2029c31342c	5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0	owner_submitted	\N	submitted	New application submitted.	\N	2026-01-02 18:07:37.72336
4078bbce-e0b9-48af-a6c4-b4f07977c578	1346b4e4-9e80-40b6-9d1a-b2029c31342c	876f6ff4-8e8b-42cb-8927-e8d74399a947	start_scrutiny	submitted	under_scrutiny	\N	\N	2026-01-02 18:07:38.121559
06257869-7e20-4bed-b8e2-929df6ae73e8	1346b4e4-9e80-40b6-9d1a-b2029c31342c	876f6ff4-8e8b-42cb-8927-e8d74399a947	reverted_by_da	under_scrutiny	reverted_to_applicant	Please upload clearer documents	\N	2026-01-02 18:07:38.440566
3a6badc2-01c0-4cec-adb1-ee88bddfebd6	1346b4e4-9e80-40b6-9d1a-b2029c31342c	5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0	correction_resubmitted	reverted_to_applicant	under_scrutiny	I confirm that every issue highlighted by DA/DTDO has been fully addressed. I understand that my application may be rejected if the corrections remain unsatisfactory. (cycle 1)	\N	2026-01-02 18:07:38.758231
b0fe04c9-9267-4de6-8c13-217e92df6420	1346b4e4-9e80-40b6-9d1a-b2029c31342c	876f6ff4-8e8b-42cb-8927-e8d74399a947	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Smoke-test automated forwarding.	\N	2026-01-02 18:07:39.078228
270dde03-8288-4004-91cc-34730fa1b52b	1346b4e4-9e80-40b6-9d1a-b2029c31342c	18122a8d-04cb-4616-87f6-ca91e130b5b1	dtdo_accept	forwarded_to_dtdo	dtdo_review	Smoke-test: accepting application.	\N	2026-01-02 18:07:39.398452
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.audit_logs (id, user_id, action, details, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.certificates (id, application_id, certificate_number, certificate_type, issued_date, valid_from, valid_upto, property_name, category, address, district, owner_name, owner_mobile, certificate_pdf_url, qr_code_data, digital_signature, issued_by, status, revocation_reason, revoked_by, revoked_date, renewal_reminder_sent, renewal_application_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: clarifications; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.clarifications (id, objection_id, application_id, submitted_by, submitted_date, clarification_text, supporting_documents, reviewed_by, reviewed_date, review_status, review_notes, updated_at) FROM stdin;
\.


--
-- Data for Name: ddo_codes; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.ddo_codes (id, district, ddo_code, ddo_description, treasury_code, is_active, created_at, updated_at) FROM stdin;
ddo-chamba	Chamba	CHM00-532	D.T.D.O. CHAMBA	CHB	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238
ddo-kullu	Kullu	KLU00-532	DEPUTY DIRECTOR TOURISM & CIVIL AVIATION, KULLU DHALPUR	KLU	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238
ddo-kangra	Kangra	KNG00-532	DIV.TOURISM DEV.OFFICER(DTDO) DHARAMSALA	KGR	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238
ddo-kinnaur	Kinnaur	KNR00-031	DISTRICT TOURISM DEVELOPMENT OFFICER KINNAUR AT RECKONG PEO	KNR	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238
ddo-lahaul	Lahaul and Spiti	KZA00-011	PROJECT OFFICER ITDP KAZA	LSP	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238
ddo-mandi	Mandi	MDI00-532	DIV. TOURISM DEV. OFFICER MANDI	MND	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238
ddo-shimla	Shimla	SML00-532	DIVISIONAL TOURISM OFFICER SHIMLA	SML	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238
ddo-hamirpur	Hamirpur	HMR00-053	DISTRICT TOURISM DEVELOPMENT OFFICE HAMIRPUR (UNA)	HMP	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238
ddo-una	Una	HMR00-053	DISTRICT TOURISM DEVELOPMENT OFFICE HAMIRPUR (UNA)	UNA	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238
ddo-sirmaur	Sirmaur	SMR00-055	DISTRICT TOURISM DEVELOPMENT OFFICE NAHAN	SMR	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238
ddo-solan	Solan	SOL00-046	DTDO SOLAN	SLN	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238
ddo-bilaspur	Bilaspur	CHM00-532	D.T.D.O. CHAMBA	BLP	t	2025-11-03 06:23:04.249238	2025-11-03 06:23:04.249238
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.documents (id, application_id, document_type, file_name, file_path, file_size, mime_type, upload_date, ai_verification_status, ai_confidence_score, ai_notes, is_verified, verification_status, verified_by, verification_date, verification_notes) FROM stdin;
5e436c5c-b123-4666-89aa-b6b3d3dbfef5	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	revenue_papers	Test_Doc01-Hindi.pdf	/api/local-object/download/f64d0313-b617-4aa3-b523-f41f10e23943?type=revenue-papers	61398	application/pdf	2026-01-02 17:51:01.690231	\N	\N	\N	f	pending	\N	\N	\N
d9541df0-5db2-4488-b47c-5302099c25e9	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	affidavit_section_29	Test_Doc01-Hindi.pdf	/api/local-object/download/720701ca-c954-4cd6-b94e-d027153a2e53?type=affidavit-section29	61398	application/pdf	2026-01-02 17:51:01.695781	\N	\N	\N	f	pending	\N	\N	\N
46f565bc-7f43-4b3c-9ea1-d7e0b3ed58f8	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	undertaking_form_c	Test_Doc01-Hindi.pdf	/api/local-object/download/d669ab4b-3632-40d0-9037-aebee5230d65?type=undertaking-form-c	61398	application/pdf	2026-01-02 17:51:01.700145	\N	\N	\N	f	pending	\N	\N	\N
718eaa54-f6b1-4b62-952b-4e3ceed79919	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	property_photo	Renuka ji lake at Renuka (Sirmaur).jpg	/api/local-object/download/4850da77-5f65-48a0-b993-a93ef23623b1?type=property-photo	373585	image/jpeg	2026-01-02 17:51:01.704495	\N	\N	\N	f	pending	\N	\N	\N
4588e9b2-41c5-482b-b0a8-d7460657fdad	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	property_photo	View from Haripurdhar (Sirmaur).jpg	/api/local-object/download/6528ea51-3053-4c66-935c-1d5d350b9711?type=property-photo	480003	image/jpeg	2026-01-02 17:51:01.708573	\N	\N	\N	f	pending	\N	\N	\N
8ab8abe1-7921-4b59-b2c4-45852174fd1a	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	property_photo	View from Kaumik village, Spiti.jpg	/api/local-object/download/ae6faaa0-999b-4eff-bb03-72956ad05c02?type=property-photo	514031	image/jpeg	2026-01-02 17:51:01.712548	\N	\N	\N	f	pending	\N	\N	\N
bb0dde1a-784e-4f60-95fb-708d1f50e628	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	additional_document	Bird eye view of Pong Dam  lake.jpg	/api/local-object/download/a1d441b6-6a15-42d6-82fb-c6324c764e8d?type=additional-document	383438	image/jpeg	2026-01-02 17:51:01.716446	\N	\N	\N	f	pending	\N	\N	\N
9dd4f20a-a557-45b5-a1c4-26921f69c509	726868b7-598d-44d3-92df-b9506a0d7376	identity_proof	mock_id.pdf	smoke-test/mock.pdf	1024	application/pdf	2026-01-02 18:07:35.563641	\N	\N	\N	t	verified	\N	\N	\N
3e968c89-66f7-4f03-91d4-e207d8f8d6c1	726868b7-598d-44d3-92df-b9506a0d7376	address_proof	mock_addr.pdf	smoke-test/mock.pdf	1024	application/pdf	2026-01-02 18:07:35.563641	\N	\N	\N	t	verified	\N	\N	\N
05a4d890-f387-4745-bb3b-9a8d3ef921e3	1346b4e4-9e80-40b6-9d1a-b2029c31342c	identity_proof	mock_id.pdf	smoke-test/mock.pdf	1024	application/pdf	2026-01-02 18:07:38.103696	\N	\N	\N	t	verified	\N	\N	\N
b884b330-9657-4669-a113-0e58a07a504e	1346b4e4-9e80-40b6-9d1a-b2029c31342c	address_proof	mock_addr.pdf	smoke-test/mock.pdf	1024	application/pdf	2026-01-02 18:07:38.103696	\N	\N	\N	t	verified	\N	\N	\N
124ca624-3bf0-4417-9c20-134cbbbe9c9e	de6c21e2-a836-4052-ae76-8c720e624e28	legacy_certificate	Test_Doc01-Hindi.pdf	/api/local-object/download/444b6364-e9a3-4109-9d9d-8069ba98c125?type=document	61398	application/pdf	2026-01-02 18:30:19.740651	\N	\N	\N	f	pending	\N	\N	\N
926749b5-929b-4d08-aca4-c6a9edb784ec	de6c21e2-a836-4052-ae76-8c720e624e28	owner_identity_proof	Test_Doc01-Hindi.pdf	/api/local-object/download/89cc27fe-91db-476a-b35a-2a2330264cbf?type=document	61398	application/pdf	2026-01-02 18:30:19.746114	\N	\N	\N	f	pending	\N	\N	\N
6778663a-b2d9-4266-9eaf-05b91c337599	de6c21e2-a836-4052-ae76-8c720e624e28	legacy_certificate	Test_Doc01-Hindi.pdf	/api/local-object/download/444b6364-e9a3-4109-9d9d-8069ba98c125?type=document	61398	application/pdf	2026-01-02 18:31:51.327648	\N	\N	\N	f	pending	\N	\N	\N
66f1ee6e-3345-4c22-9b1d-efe3cee1354d	de6c21e2-a836-4052-ae76-8c720e624e28	owner_identity_proof	Test_Doc01-Hindi.pdf	/api/local-object/download/89cc27fe-91db-476a-b35a-2a2330264cbf?type=document	61398	application/pdf	2026-01-02 18:31:51.33294	\N	\N	\N	f	pending	\N	\N	\N
\.


--
-- Data for Name: grievance_audit_log; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.grievance_audit_log (id, grievance_id, action, old_value, new_value, performed_by, performed_at, ip_address, user_agent) FROM stdin;
e06a8a67-dd36-45f4-84b6-73196225238c	10f1a815-aecf-4619-bc7a-524917c43162	created	\N	Ticket GRV-2026-JUUIRC created (owner_grievance)	158757ba-e95d-408d-b44b-09203e114fa2	2026-01-02 18:42:15.493011	223.178.213.122	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36
\.


--
-- Data for Name: grievance_comments; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.grievance_comments (id, grievance_id, user_id, comment, is_internal, created_at) FROM stdin;
\.


--
-- Data for Name: grievances; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.grievances (id, ticket_number, ticket_type, user_id, application_id, category, priority, status, subject, description, assigned_to, resolution_notes, attachments, last_comment_at, last_read_by_owner, last_read_by_officer, created_at, updated_at, resolved_at) FROM stdin;
10f1a815-aecf-4619-bc7a-524917c43162	GRV-2026-JUUIRC	owner_grievance	158757ba-e95d-408d-b44b-09203e114fa2	\N	application	medium	open	Relationship is not preserved.	On page 2 the relationship is not preserved.	\N	\N	\N	\N	2026-01-02 18:42:15.487	\N	2026-01-02 18:42:15.488762	2026-01-02 18:42:15.488762	\N
\.


--
-- Data for Name: himkosh_transactions; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.himkosh_transactions (id, application_id, dept_ref_no, app_ref_no, total_amount, tender_by, merchant_code, dept_id, service_code, ddo, head1, amount1, head2, amount2, head3, amount3, head4, amount4, head10, amount10, period_from, period_to, encrypted_request, request_checksum, ech_txn_id, bank_cin, bank_name, payment_date, status, status_cd, response_checksum, is_double_verified, double_verification_date, double_verification_data, challan_print_url, transaction_status, initiated_at, responded_at, verified_at, created_at, updated_at, portal_base_url, is_archived) FROM stdin;
c16bbd65-bbad-4e9a-9739-c961859553fc	04705665-7b99-4f2e-b4a1-114561dcd07a	HP-HS-2026-SML-000005	HPT1767376905258dno3	1	Test BBB	HIMKOSH230	230	TSM	SML00-532	0230-00-104-01	1	\N	\N	\N	\N	\N	\N	\N	\N	02-01-2026	02-01-2026	FdkGGiidekvpm0UUibJM5NLCoeGdXqcQsBV/MqcevsliKjN4IoLnt5N3D78Q28r8U8EWsf0g2NOhgKhQ5y3kqG1e8IG2Tb0EKQp8fae/X0TJTkkEZSL0IXBAfubO3HIpL8Xte6acBbTYF+6FXzwSAOJa7hvYzCgqIX+8gvqBPLCedRcS0dvbIO0eQ1yoj/uUo6cgMpG/wN1d1gBElEKGW5xe33zivxLxvVDmDqrRe6ZDWsaUDQnzdabk+JlNILBYqJ1AS8oJYDvmugl867zFbMt/L43m5fBbC/+5YufeZD2rl0t/BUE0eRW8vuj8ebF784FW3ZCF19aP9mJ2p4v84McUSh8N9ZCaa4DxVghCWhJfJsW6GOsnGCLwCHaerUJKhE84pxZn3g05KO3UBlbO3DT15UZ5nfrEdkcKbu8EWUA=	c5405ba5010784cf886c8be312e55d7b	\N	\N	\N	\N	Cancelled by applicant	0	\N	f	\N	\N	\N	failed	2026-01-02 18:01:45.26405	2026-01-02 18:01:54.792	\N	2026-01-02 18:01:45.26405	2026-01-02 18:01:54.792	https://dev.osipl.dev	f
a0328d4b-2b90-495b-a58d-1e62a785f6c4	04705665-7b99-4f2e-b4a1-114561dcd07a	HP-HS-2026-SML-000005	HPT1767376997159vnd6	1	Test BBB	HIMKOSH230	230	TSM	SML00-532	0230-00-104-01	1	\N	\N	\N	\N	\N	\N	\N	\N	02-01-2026	02-01-2026	FdkGGiidekvpm0UUibJM5NLCoeGdXqcQsBV/MqcevsliKjN4IoLnt5N3D78Q28r8U8EWsf0g2NOhgKhQ5y3kqG1e8IG2Tb0EKQp8fae/X0SDQiIVfGWDp5p/uJMWfylQPlwBOvytd8CcZ70rtkP0DldZUELBkKQqgQm0R4rL7T3Tb4cBxg890jWe/M+U5cmCxFnEhwpGQlt3T6xK9UaemnMeE4WVV9aAGr5CfZjT5IoVcRv0AyGqMdjrAAcydvELPQbwfkKSqX9nGKdLHIc6h7DgTqUu/o6WXXb2q8IR6KjtaFhm5dMY6+c3Am4K7P/eiPG/QudKqq6yeOLjMa+F19sebwKo6aD7ilAe89g9NvfJPiQjtn73UTF/9tqpK052zeoMMUVzuWmNS4bVTgq6GXQnRwt7X2pJ9uO4ksaziWY=	7caefbb29c4f99761e5e122c6bb42f57	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	initiated	2026-01-02 18:03:17.161569	\N	\N	2026-01-02 18:03:17.161569	2026-01-02 18:03:17.161569	https://dev.osipl.dev	f
9d33200f-ac58-4f1e-a963-b40e58321707	726868b7-598d-44d3-92df-b9506a0d7376	HP-HS-2026-SML-000006	HPT1767377256687UFAy	1	Smoke Owner	HIMKOSH230	230	TSM	SML00-532	0230-00-104-01	1	\N	\N	\N	\N	\N	\N	\N	\N	02-01-2026	02-01-2026	FdkGGiidekvpm0UUibJM5NLCoeGdXqcQsBV/MqcevsmYppq+Hfj+QN/qfJMR4DmA4cMwdmsavlFL4ji0iw3Taa5TAftdLtQt2QK/NcB+6HPvq+2fpU0fitx4EFVevhy+SjltVOnQ4Uo1iriVcUizZ1W4EpP+gFgRIbb1qZ8JtsKeY0rjn83VWFs/2Xk8oT8KvC1+a4RcYEX3dnzjS2Ug178bNDz1NO4yedD/9PPHRU0EMGA9KORoTuGlkHo1KawENMpidTsZzfZ+Blc+oFftaoTpcEs233BxBReqa+iLv7G4YmmbTfWD42Td2++eLkDV+nh1Te96NwUNaLD5rtZnVc93HXLaEUJ28FxwrMlxnZPT0hry2uRO21MhByaDfN7Z2Er4jp2aT9A3G7CvhEohi2jEym4Qd972AyYN5SUrp8s=	81f7919a79e875d73f81186584f4f049	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	initiated	2026-01-02 18:07:36.69325	\N	\N	2026-01-02 18:07:36.69325	2026-01-02 18:07:36.69325	https://hptourism.osipl.dev	f
\.


--
-- Data for Name: homestay_applications; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.homestay_applications (id, user_id, application_number, property_name, category, location_type, total_rooms, district, district_other, tehsil, tehsil_other, block, block_other, gram_panchayat, gram_panchayat_other, urban_body, urban_body_other, ward, address, pincode, telephone, fax, latitude, longitude, owner_name, owner_gender, owner_mobile, owner_email, owner_aadhaar, property_ownership, proposed_room_rate, project_type, property_area, single_bed_rooms, single_bed_room_size, single_bed_room_rate, double_bed_rooms, double_bed_room_size, double_bed_room_rate, family_suites, family_suite_size, family_suite_rate, attached_washrooms, gstin, selected_category, average_room_rate, highest_room_rate, lowest_room_rate, certificate_validity_years, is_pangi_sub_division, distance_airport, distance_railway, distance_city_center, distance_shopping, distance_bus_stand, lobby_area, dining_area, parking_area, eco_friendly_facilities, differently_abled_facilities, fire_equipment_details, nearest_hospital, amenities, rooms, base_fee, total_before_discounts, validity_discount, female_owner_discount, pangi_discount, total_discount, total_fee, per_room_fee, gst_amount, status, current_stage, current_page, district_officer_id, district_review_date, district_notes, da_id, da_review_date, da_forwarded_date, state_officer_id, state_review_date, state_notes, dtdo_id, dtdo_review_date, dtdo_remarks, rejection_reason, clarification_requested, site_inspection_scheduled_date, site_inspection_completed_date, site_inspection_officer_id, site_inspection_notes, site_inspection_outcome, site_inspection_findings, ownership_proof_url, aadhaar_card_url, pan_card_url, gst_certificate_url, fire_safety_noc_url, pollution_clearance_url, building_plan_url, property_photos_urls, documents, certificate_number, certificate_issued_date, certificate_expiry_date, submitted_at, approved_at, created_at, updated_at, single_bed_beds, double_bed_beds, family_suite_beds, application_kind, parent_application_id, parent_application_number, parent_certificate_number, inherited_certificate_valid_upto, service_context, service_notes, service_requested_at, guardian_name, da_remarks, correction_submission_count, application_type, water_sports_data, adventure_sports_data, guardian_relation, property_area_unit, key_location_highlight1, key_location_highlight2, nearby_attractions, mandatory_checklist, desirable_checklist, revert_count, payment_status, payment_id, payment_amount, payment_date, refund_date, refund_reason, form_completion_time_seconds) FROM stdin;
7792760d-3cb6-4a0d-a3a4-dda97f518c82	81df93f9-9adb-49e5-b635-a49190c26f8c	HP-HS-2026-SML-000010	Homestay 5	silver	mc	1	Shimla	\N	Chaupal	\N	\N	\N		\N	Shimla	\N		Sondh Niwas, Lower Lakkar Bazar ,\nApple Tree	171002		\N	\N	\N	Test GGG	female	6666666625	test@example.com	666666666625	owned	0.00	new_project	0.00	1	\N	\N	0	\N	0.00	0	\N	0.00	1		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N						{"cctv": false, "fireSafety": false}	\N	8000.00	8000.00	0.00	400.00	0.00	400.00	7600.00	0.00	0.00	draft	\N	3	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	\N	\N	2026-01-02 19:46:51.688288	2026-01-02 20:08:56.955	1	2	4	new_registration	\N	\N	\N	\N	\N	\N	\N	Subhash Thakur	\N	0	homestay	\N	\N	father	sqm	\N	\N	{}	{"1": true, "2": true, "7": true}	\N	0	pending	\N	\N	\N	\N	\N	\N
4a04e2d9-add0-478d-b57b-e0c5ad1eca73	264d453c-cbf8-403b-b36a-ccc671f1c705	HP-HS-2026-SML-000001	Test Homestay 1	silver	mc	1	Shimla	\N	Chaupal	\N	\N	\N	\N	\N	Shimla,,	\N	\N	Shiva Apartment, F L 2 Chakrail, Near I VY School, Shimla, Shimla\nShimla Himachal Pradesh, 171006	171006	\N	\N	\N	\N	Test AAA	female	6666666621	test@example.com	666666666621	owned	0.00	new_project	1000.00	1	1499.98	1499.00	0	\N	0.00	0	\N	0.00	1	\N	silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Fire Safety Equipment Details (Annexure-I #6g) *	\N	{"cctv": true, "fireSafety": true}	\N	8000.00	8000.00	0.00	400.00	0.00	400.00	7600.00	0.00	0.00	submitted	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "ae5c7682-d40e-46fc-9216-ac5f3a90ca9b", "url": "/api/local-object/download/f64d0313-b617-4aa3-b523-f41f10e23943?type=revenue-papers", "name": "Test_Doc01-Hindi.pdf", "type": "revenue_papers", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/f64d0313-b617-4aa3-b523-f41f10e23943?type=revenue-papers", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "85b7ee48-5c49-4848-b4ab-626bc30f9046", "url": "/api/local-object/download/720701ca-c954-4cd6-b94e-d027153a2e53?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/720701ca-c954-4cd6-b94e-d027153a2e53?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "dc5d7d47-0460-4d58-95cb-79dc3e5cd86d", "url": "/api/local-object/download/d669ab4b-3632-40d0-9037-aebee5230d65?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/d669ab4b-3632-40d0-9037-aebee5230d65?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "5751e829-8172-495f-8a4a-b25c0267e5c7", "url": "/api/local-object/download/4850da77-5f65-48a0-b993-a93ef23623b1?type=property-photo", "name": "Renuka ji lake at Renuka (Sirmaur).jpg", "type": "property_photo", "fileName": "Renuka ji lake at Renuka (Sirmaur).jpg", "filePath": "/api/local-object/download/4850da77-5f65-48a0-b993-a93ef23623b1?type=property-photo", "fileSize": 373585, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "6a4f38bf-2193-4821-a24f-b72ea5a937be", "url": "/api/local-object/download/6528ea51-3053-4c66-935c-1d5d350b9711?type=property-photo", "name": "View from Haripurdhar (Sirmaur).jpg", "type": "property_photo", "fileName": "View from Haripurdhar (Sirmaur).jpg", "filePath": "/api/local-object/download/6528ea51-3053-4c66-935c-1d5d350b9711?type=property-photo", "fileSize": 480003, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "5c9a0768-4453-47ce-aeca-da653eb77a10", "url": "/api/local-object/download/ae6faaa0-999b-4eff-bb03-72956ad05c02?type=property-photo", "name": "View from Kaumik village, Spiti.jpg", "type": "property_photo", "fileName": "View from Kaumik village, Spiti.jpg", "filePath": "/api/local-object/download/ae6faaa0-999b-4eff-bb03-72956ad05c02?type=property-photo", "fileSize": 514031, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "8ce5bc9e-67f6-4b82-900d-13d3baa81e1d", "url": "/api/local-object/download/a1d441b6-6a15-42d6-82fb-c6324c764e8d?type=additional-document", "name": "Bird eye view of Pong Dam  lake.jpg", "type": "additional_document", "fileName": "Bird eye view of Pong Dam  lake.jpg", "filePath": "/api/local-object/download/a1d441b6-6a15-42d6-82fb-c6324c764e8d?type=additional-document", "fileSize": 383438, "mimeType": "image/jpeg", "documentType": "additional_document"}]	\N	\N	\N	2026-01-02 17:51:01.682	\N	2026-01-02 17:42:21.985888	2026-01-02 17:51:01.682	1	2	4	new_registration	\N	\N	\N	\N	\N	\N	\N	Father Test	\N	0	homestay	\N	\N	father	sqft	\N	\N	{}	{"1": true, "2": true, "3": true, "4": true, "5": true, "6": true, "7": true, "8": true, "9": true, "10": true, "11": true, "12": true, "13": true, "14": true, "15": true, "16": true, "17": true, "18": true}	\N	0	pending	\N	\N	\N	\N	\N	949
04705665-7b99-4f2e-b4a1-114561dcd07a	4238b15b-ee75-4037-a4e2-7770e7d93748	HP-HS-2026-SML-000005	Test Homestay 2	diamond	mc	4	Shimla	\N	Chaupal	\N	\N	\N		\N	Shimla	\N		Sondh Niwas, Lower Lakkar Bazar ,\nApple Tree	171006		\N	\N	\N	Test BBB	female	6666666622	test@example.com	666666666622	owned	0.00	new_project	3.00	1	\N	1500.00	1	\N	3500.00	2	\N	12000.00	4	121212121212121	diamond	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N				Fire Safety Equipment Details (Annexure-I #6g) *		{"cctv": true, "fireSafety": true}	\N	18000.00	18000.00	0.00	900.00	0.00	900.00	17100.00	0.00	0.00	draft	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "4097dd81-844d-4467-882d-1eee027b9e50", "url": "/api/local-object/download/b206e23b-a914-4621-89e3-e265af54cd43?type=revenue-papers", "name": "Test_Doc01-Hindi.pdf", "type": "revenue_papers", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/b206e23b-a914-4621-89e3-e265af54cd43?type=revenue-papers", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "a7bcebdd-ebf4-458d-8cd9-aa5de6e4d48e", "url": "/api/local-object/download/3b07cfde-e0fc-40b3-a26c-3bdd75818469?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/3b07cfde-e0fc-40b3-a26c-3bdd75818469?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "674cb6be-48bc-4cfa-93e3-e76087d65421", "url": "/api/local-object/download/b66613bc-2944-440f-9c95-c12ab4395c3e?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/b66613bc-2944-440f-9c95-c12ab4395c3e?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "29c127b0-35f7-4f10-9a56-7e531e6b242b", "url": "/api/local-object/download/9a78bc46-ab0d-433a-ba0a-0be6db2c3eb8?type=commercial-electricity-bill", "name": "Test_Doc01-Hindi.pdf", "type": "commercial_electricity_bill", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/9a78bc46-ab0d-433a-ba0a-0be6db2c3eb8?type=commercial-electricity-bill", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "commercial_electricity_bill"}, {"id": "a67fd60c-bc26-46b1-a385-1b26c0931335", "url": "/api/local-object/download/ebfa8523-2354-4e88-97cc-f778b43198cd?type=commercial-water-bill", "name": "Test_Doc01-Hindi.pdf", "type": "commercial_water_bill", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/ebfa8523-2354-4e88-97cc-f778b43198cd?type=commercial-water-bill", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "commercial_water_bill"}, {"id": "bd9097b7-9b1d-4697-a6b8-f2742f387fa4", "url": "/api/local-object/download/72608d9b-4e5b-433c-aae6-25a1bfa33407?type=property-photo", "name": "View from Kaumik village, Spiti.jpg", "type": "property_photo", "fileName": "View from Kaumik village, Spiti.jpg", "filePath": "/api/local-object/download/72608d9b-4e5b-433c-aae6-25a1bfa33407?type=property-photo", "fileSize": 514031, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "6d979771-3d4c-4bc2-aeb9-2b6b651ba049", "url": "/api/local-object/download/a4e7e76b-32d9-4545-8e25-374ff5818000?type=property-photo", "name": "view from Naddi village.jpg", "type": "property_photo", "fileName": "view from Naddi village.jpg", "filePath": "/api/local-object/download/a4e7e76b-32d9-4545-8e25-374ff5818000?type=property-photo", "fileSize": 400821, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "3cf2aa59-88b1-47cb-8ac2-3da946001d6d", "url": "/api/local-object/download/5519b826-a9e2-4984-acfd-d7266090ac52?type=property-photo", "name": "View fromTriund top.jpg", "type": "property_photo", "fileName": "View fromTriund top.jpg", "filePath": "/api/local-object/download/5519b826-a9e2-4984-acfd-d7266090ac52?type=property-photo", "fileSize": 362197, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "a150dff9-a1cf-4337-a524-c804ac5a039d", "url": "/api/local-object/download/1d178878-0abe-4d8f-adae-1b2d3233d954?type=property-photo", "name": "view of Chitkul  valley.jpg", "type": "property_photo", "fileName": "view of Chitkul  valley.jpg", "filePath": "/api/local-object/download/1d178878-0abe-4d8f-adae-1b2d3233d954?type=property-photo", "fileSize": 411316, "mimeType": "image/jpeg", "documentType": "property_photo"}]	\N	\N	\N	\N	\N	2026-01-02 17:55:25.04055	2026-01-02 17:58:42.666	1	2	4	new_registration	\N	\N	\N	\N	\N	\N	\N	Subhash Thakur	\N	0	homestay	\N	\N	father	bigha	\N	\N	{}	{"1": true, "2": true, "3": true, "4": true, "5": true, "6": true, "7": true, "8": true, "9": true, "10": true, "11": true, "12": true, "13": true, "14": true, "15": true, "16": true, "17": true, "18": true}	\N	0	pending	\N	\N	\N	\N	\N	\N
6942ff5a-d98d-4d28-8163-d9d3a09379dc	f8b11841-95be-465d-814e-2dd2f5936b4a	HP-HS-2026-SML-000008	Test App 1 Property	gold	gp	2	Shimla	\N	Not Provided	\N	\N	\N	\N	\N	\N	\N	\N	Smoke Test Lane, Himachal Pradesh	171001	0177-0000000	\N	\N	\N	Smoke Owner	male	6666666610	owner@example.com	123456789012	owned	4000.00	new_project	1200.00	2	\N	3500.00	0	\N	5000.00	0	\N	5500.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	0.00	0.00	0.00	0.00	18000.00	\N	\N	draft	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	\N	\N	2026-01-02 18:07:40.812304	2026-01-02 18:07:40.812304	1	2	4	delete_rooms	726868b7-598d-44d3-92df-b9506a0d7376	HP-HS-2026-SML-000006	HP-HST-TEST-31245	2027-01-02 18:07:37.08	{"note": "delete_rooms via smoke test", "renewalWindow": {"end": "2027-01-02T18:07:37.080Z", "start": "2026-10-04T18:07:37.080Z"}, "requestedRooms": {"total": 2, "double": 0, "family": 0, "single": 2}, "requiresPayment": false, "requestedDeletions": [{"count": 1, "roomType": "single"}], "requestedRoomDelta": -1, "inheritsCertificateExpiry": "2027-01-02T18:07:37.080Z"}	delete_rooms via smoke test	2026-01-02 18:07:40.806	\N	Smoke-test automated forwarding.	0	homestay	\N	\N	father	sqm	\N	\N	\N	\N	\N	0	pending	\N	\N	\N	\N	\N	\N
726868b7-598d-44d3-92df-b9506a0d7376	f8b11841-95be-465d-814e-2dd2f5936b4a	HP-HS-2026-SML-000006	Test App 1 Property	gold	gp	3	Shimla	\N	Not Provided	\N	\N	\N	\N	\N	\N	\N	\N	Smoke Test Lane, Himachal Pradesh	171001	0177-0000000	\N	\N	\N	Smoke Owner	male	6666666610	owner@example.com	123456789012	owned	4000.00	new_project	1200.00	3	\N	3500.00	0	\N	5000.00	0	\N	5500.00	3	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	0.00	0.00	0.00	0.00	18000.00	\N	\N	approved	\N	1	\N	\N	\N	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-02 18:07:35.581	2026-01-02 18:07:35.581	\N	\N	\N	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-02 18:07:35.905	Smoke-test: accepting application.	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	HP-HST-TEST-31245	2026-01-02 18:07:37.080696	2027-01-02 18:07:37.080696	2026-01-02 18:07:34.817	2026-01-02 18:07:37.080696	2026-01-02 18:07:34.823357	2026-01-02 18:07:35.905	1	2	4	new_registration	\N	\N	\N	\N	\N	\N	\N	\N	Smoke-test automated forwarding.	0	homestay	\N	\N	father	sqm	\N	\N	\N	\N	\N	0	pending	\N	\N	\N	\N	\N	\N
1346b4e4-9e80-40b6-9d1a-b2029c31342c	5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0	HP-HS-2026-SML-000007	Test App 2 Revert Property	silver	gp	2	Shimla	\N	Not Provided	\N	\N	\N	\N	\N	\N	\N	\N	Smoke Test Lane, Himachal Pradesh	171001	0177-0000000	\N	\N	\N	Smoke Owner (Corrected)	male	6666666610	owner@example.com	123456789012	owned	1500.00	new_project	1200.00	2	\N	1000.00	0	\N	2000.00	0	\N	2500.00	2	\N	\N	\N	\N	\N	1	f	10.00	20.00	5.00	3.00	2.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	5000.00	5000.00	0.00	0.00	0.00	0.00	5000.00	\N	\N	approved	\N	1	\N	\N	\N	876f6ff4-8e8b-42cb-8927-e8d74399a947	2026-01-02 18:07:39.073	2026-01-02 18:07:39.073	\N	\N	\N	18122a8d-04cb-4616-87f6-ca91e130b5b1	2026-01-02 18:07:39.394	Smoke-test: accepting application.	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	HP-HST-TEST-47583	2026-01-02 18:07:39.785102	2027-01-02 18:07:39.785102	2026-01-02 18:07:38.754	2026-01-02 18:07:39.785102	2026-01-02 18:07:37.718244	2026-01-02 18:07:39.394	1	2	4	new_registration	\N	\N	\N	\N	\N	\N	\N	\N	Smoke-test automated forwarding.	1	homestay	\N	\N	father	sqm	\N	\N	\N	\N	\N	1	pending	\N	\N	\N	\N	\N	\N
de6c21e2-a836-4052-ae76-8c720e624e28	5650293a-5f4f-4e77-b381-f60d0c4dc62f	LG-HS-2026-SML-000001	Homestay 1	silver	gp	2	Shimla	\N	Chaupal	\N	\N	\N	\N	\N	\N	\N	\N	Sondh Niwas, Lower Lakkar Bazar ,\nApple Tree	171001	\N	\N	\N	\N	Test Test	other	6666666623	test@example.com	666666666623	owned	\N	existing_property	60.00	2	\N	\N	0	\N	\N	0	\N	\N	2	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"size": 0, "count": 2, "roomType": "Declared Rooms"}]	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	legacy_rc_review	legacy_rc_review	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	116-HP-20225-SML-001	2026-01-01 00:00:00	2027-01-01 00:00:00	2026-01-02 18:31:51.321	\N	2026-01-02 18:30:14.168	2026-01-02 18:31:51.321	1	2	4	renewal	\N	116-HP-20225-SML-001	116-HP-20225-SML-001	\N	{"note": "Additional Notes (optional)", "requestedRooms": {"total": 2}, "requiresPayment": false, "legacyOnboarding": true, "legacyGuardianName": "Subhash Thakur", "inheritsCertificateExpiry": "2027-01-01T00:00:00.000Z"}	Additional Notes (optional)	\N	Subhash Thakur	\N	0	homestay	\N	\N	father	sqm	\N	\N	\N	\N	\N	0	pending	\N	\N	\N	\N	\N	\N
fccf926e-c3cf-4828-8732-c278616ca494	158757ba-e95d-408d-b44b-09203e114fa2	HP-HS-2026-SML-000009	Homestay 3	silver	gp	1	Shimla	\N	Chaupal	\N	\N	\N	Village BBB	\N		\N		Shiva Apartment, F L 2 Chakrail, Near I VY School, Shimla, Shimla\nShimla Himachal Pradesh, 171006	171006		\N	\N	\N	Test CCC	female	6666666624	test@example.com	666666666624	owned	0.00	new_project	1000.00	1	\N	1499.00	0	\N	0.00	0	\N	0.00	1		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N				Mandatory Safety Checklist		{"cctv": true, "fireSafety": true}	\N	3000.00	3000.00	0.00	150.00	0.00	150.00	2850.00	0.00	0.00	draft	\N	3	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	\N	\N	2026-01-02 18:38:34.933094	2026-01-02 19:44:44.59	1	2	4	new_registration	\N	\N	\N	\N	\N	\N	\N	Test Father	\N	0	homestay	\N	\N	father	bigha	\N	\N	{}	{"1": true, "2": true, "7": true}	\N	0	pending	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: inspection_orders; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.inspection_orders (id, application_id, scheduled_by, scheduled_date, assigned_to, assigned_date, inspection_date, inspection_address, special_instructions, status, dtdo_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inspection_reports; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.inspection_reports (id, inspection_order_id, application_id, submitted_by, submitted_date, actual_inspection_date, room_count_verified, actual_room_count, category_meets_standards, recommended_category, mandatory_checklist, mandatory_remarks, desirable_checklist, desirable_remarks, amenities_verified, amenities_issues, fire_safety_compliant, fire_safety_issues, structural_safety, structural_issues, overall_satisfactory, recommendation, detailed_findings, inspection_photos, report_document_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_blocks; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_blocks (id, lgd_code, block_name, district_id, tehsil_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_districts; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_districts (id, lgd_code, district_name, division_name, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_gram_panchayats; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_gram_panchayats (id, lgd_code, gram_panchayat_name, district_id, block_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_tehsils; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_tehsils (id, lgd_code, tehsil_name, district_id, tehsil_type, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_urban_bodies; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.lgd_urban_bodies (id, lgd_code, urban_body_name, district_id, body_type, number_of_wards, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: login_otp_challenges; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.login_otp_challenges (id, user_id, otp_hash, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.notifications (id, user_id, application_id, type, title, message, channels, is_read, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: objections; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.objections (id, application_id, inspection_report_id, raised_by, raised_date, objection_type, objection_title, objection_description, severity, response_deadline, status, resolution_notes, resolved_by, resolved_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_reset_challenges; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.password_reset_challenges (id, user_id, channel, recipient, otp_hash, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.payments (id, application_id, payment_type, amount, payment_gateway, gateway_transaction_id, payment_method, payment_status, payment_link, qr_code_url, payment_link_expiry_date, initiated_at, completed_at, receipt_number, receipt_url) FROM stdin;
\.


--
-- Data for Name: production_stats; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.production_stats (id, total_applications, approved_applications, rejected_applications, pending_applications, scraped_at, source_url) FROM stdin;
3e67ed63-46a7-4f68-ae04-3390f95dfb5d	4	4	4	4	2026-01-02 09:43:40.160146	https://eservices.himachaltourism.gov.in/
c96b013d-890c-4e62-8f5e-743b2ea6b7a2	4	4	4	4	2026-01-02 10:29:21.383096	https://eservices.himachaltourism.gov.in/
7eaf3de7-8ccb-4db4-a8b9-65a856ef279e	4	4	4	4	2026-01-02 10:34:51.163198	https://eservices.himachaltourism.gov.in/
a75cc721-eb02-4892-906d-489eff06c7a0	4	4	4	4	2026-01-02 10:38:52.131863	https://eservices.himachaltourism.gov.in/
35adce3f-60ad-4083-9310-219d166c4b10	4	4	4	4	2026-01-02 10:39:43.483885	https://eservices.himachaltourism.gov.in/
2dcc2288-c18e-45ea-9ec0-904e9e354c96	4	4	4	4	2026-01-02 10:41:39.193065	https://eservices.himachaltourism.gov.in/
2ea42974-755c-440a-ada4-07aecb4a9c5f	4	4	4	4	2026-01-02 10:47:34.020694	https://eservices.himachaltourism.gov.in/
ee57f053-324f-4567-99da-3a2311c02acc	4	4	4	4	2026-01-02 11:31:52.433049	https://eservices.himachaltourism.gov.in/
a9ec50fc-1ac6-4525-9bc8-f9cc19ec294b	4	4	4	4	2026-01-02 11:51:13.137363	https://eservices.himachaltourism.gov.in/
11119f05-6f1c-4347-82e9-2abab7e30975	4	4	4	4	2026-01-02 12:13:06.092186	https://eservices.himachaltourism.gov.in/
79436bb6-f50c-4227-9fd9-6fc641b631cb	4	4	4	4	2026-01-02 12:33:05.884996	https://eservices.himachaltourism.gov.in/
239a94df-4822-4325-a946-79f7d1ebb83d	4	4	4	4	2026-01-02 13:05:23.615602	https://eservices.himachaltourism.gov.in/
da66dd37-fbc1-4c81-94c3-7b3e195a98c0	4	4	4	4	2026-01-02 14:05:23.288935	https://eservices.himachaltourism.gov.in/
397cceba-b6f7-4139-b8f6-45480e9f1720	4	4	4	4	2026-01-02 14:29:38.89863	https://eservices.himachaltourism.gov.in/
4c1d467c-3e88-4213-a381-9ea05c06260d	4	4	4	4	2026-01-02 14:40:02.055573	https://eservices.himachaltourism.gov.in/
2898eb29-7efd-41c7-9f36-834a66f59360	4	4	4	4	2026-01-02 15:40:01.746559	https://eservices.himachaltourism.gov.in/
7bc73fe2-6105-4e8a-aea3-6dda87847784	4	4	4	4	2026-01-02 15:49:13.57419	https://eservices.himachaltourism.gov.in/
3eb8b2b7-c236-4f4d-83b8-6f7133e9204c	4	4	4	4	2026-01-02 15:49:37.614106	https://eservices.himachaltourism.gov.in/
ae5d5011-104a-4dca-8be6-8eb7f020d52b	4	4	4	4	2026-01-02 15:50:38.698067	https://eservices.himachaltourism.gov.in/
7a970811-0f88-4073-8ade-b9f543a65c24	4	4	4	4	2026-01-02 15:51:32.8478	https://eservices.himachaltourism.gov.in/
ee1208ee-f904-4724-8409-2f82edfacb22	4	4	4	4	2026-01-02 15:51:58.843756	https://eservices.himachaltourism.gov.in/
b00615c5-4334-4ba3-8af2-b307cc8439c4	4	4	4	4	2026-01-02 15:52:23.882779	https://eservices.himachaltourism.gov.in/
3134f016-dd42-4e69-b2ef-364c3e7bf0ba	4	4	4	4	2026-01-02 15:54:09.313615	https://eservices.himachaltourism.gov.in/
a6480955-2e6b-46cf-9128-6f002c9e1540	4	4	4	4	2026-01-02 15:54:14.833838	https://eservices.himachaltourism.gov.in/
98dbb682-70e9-40d9-b8f3-3a4fe913bd3a	4	4	4	4	2026-01-02 16:07:38.477806	https://eservices.himachaltourism.gov.in/
ad1234c4-61d1-4f9b-93cf-4ab200ce10dd	4	4	4	4	2026-01-02 16:07:40.935602	https://eservices.himachaltourism.gov.in/
60c1014b-645d-4079-bc1b-177aa7831baa	4	4	4	4	2026-01-02 16:07:51.25527	https://eservices.himachaltourism.gov.in/
7e7c708f-f20e-46eb-8515-387aa8db5dc3	4	4	4	4	2026-01-02 16:07:54.164059	https://eservices.himachaltourism.gov.in/
8ce432d1-f93f-4721-ac10-dcc1fd53c702	4	4	4	4	2026-01-02 16:07:57.210586	https://eservices.himachaltourism.gov.in/
4d5430f8-2fcf-400b-b307-94ed3837cf42	4	4	4	4	2026-01-02 16:08:00.543218	https://eservices.himachaltourism.gov.in/
e8851a8b-cfbe-4757-b553-534bed54cac1	4	4	4	4	2026-01-02 16:08:03.703224	https://eservices.himachaltourism.gov.in/
0267d905-bd82-4d3d-a4b9-27963e5bc513	4	4	4	4	2026-01-02 16:08:08.241318	https://eservices.himachaltourism.gov.in/
7bb4bc3d-3652-4e76-8906-cd79b3bab9c4	4	4	4	4	2026-01-02 16:08:11.02991	https://eservices.himachaltourism.gov.in/
a9ba52b2-1ae5-4689-ab41-a1eea74f2f32	4	4	4	4	2026-01-02 16:08:13.796702	https://eservices.himachaltourism.gov.in/
880b46c8-87b8-44af-9652-199d7a2386a8	4	4	4	4	2026-01-02 16:08:18.706008	https://eservices.himachaltourism.gov.in/
70ff135b-a012-4b9b-bf44-35ad81e5e676	4	4	4	4	2026-01-02 16:08:25.540416	https://eservices.himachaltourism.gov.in/
5547eb02-07f8-49e2-bb10-6733619656ea	4	4	4	4	2026-01-02 16:08:28.398643	https://eservices.himachaltourism.gov.in/
8f4ed13b-c871-4aee-83b6-417aa49649bd	4	4	4	4	2026-01-02 16:08:30.709703	https://eservices.himachaltourism.gov.in/
064b12df-f551-44a6-852d-fd28a5f66be0	4	4	4	4	2026-01-02 16:08:33.582674	https://eservices.himachaltourism.gov.in/
5b73701c-0e4f-4380-9b04-b8a3791227c6	4	4	4	4	2026-01-02 16:08:36.945069	https://eservices.himachaltourism.gov.in/
1258d891-9e1b-42e9-9f85-78839392c5d7	4	4	4	4	2026-01-02 16:08:45.283933	https://eservices.himachaltourism.gov.in/
6a0f8211-bd1a-4aa3-a301-8bbd5d12b6fd	4	4	4	4	2026-01-02 16:08:51.755049	https://eservices.himachaltourism.gov.in/
1d7e12be-a388-4986-a3e4-c8caffe00281	4	4	4	4	2026-01-02 16:08:57.174372	https://eservices.himachaltourism.gov.in/
193a8008-2732-4fbe-8b97-5b6538230cb8	4	4	4	4	2026-01-02 16:09:05.61468	https://eservices.himachaltourism.gov.in/
11747263-7e91-408e-9500-b65ffbae1eca	4	4	4	4	2026-01-02 16:09:14.96569	https://eservices.himachaltourism.gov.in/
8fcf8226-5ae0-49ee-94f9-0980d2784d29	4	4	4	4	2026-01-02 16:09:38.427541	https://eservices.himachaltourism.gov.in/
3b59fadf-1946-4036-9d2b-48392eccef00	4	4	4	4	2026-01-02 16:10:23.864198	https://eservices.himachaltourism.gov.in/
901d7d6e-dfb4-4f07-81fa-bdd06041475d	4	4	4	4	2026-01-02 16:10:26.205227	https://eservices.himachaltourism.gov.in/
95547f30-28b5-45fc-9b7b-ced896b57586	4	4	4	4	2026-01-02 16:10:28.625907	https://eservices.himachaltourism.gov.in/
a8b9bb73-a56a-4c59-9324-2091cce22937	4	4	4	4	2026-01-02 16:10:54.17977	https://eservices.himachaltourism.gov.in/
f9e811ca-f39b-4803-a34a-bb773aebd7ea	4	4	4	4	2026-01-02 16:11:03.554837	https://eservices.himachaltourism.gov.in/
8b095070-9260-43c4-9253-403c236f00ee	4	4	4	4	2026-01-02 16:11:46.916445	https://eservices.himachaltourism.gov.in/
bd2253a4-a9fe-44cf-a0bc-e700cc972ff0	4	4	4	4	2026-01-02 16:11:57.590296	https://eservices.himachaltourism.gov.in/
6b797566-b8db-401e-9d8f-25979c910e59	4	4	4	4	2026-01-02 16:13:29.996725	https://eservices.himachaltourism.gov.in/
2a86a30e-2a97-40df-923a-891062b6c254	4	4	4	4	2026-01-02 16:13:58.620754	https://eservices.himachaltourism.gov.in/
4b062342-d27f-472c-8342-540715fe7d57	4	4	4	4	2026-01-02 17:13:58.574363	https://eservices.himachaltourism.gov.in/
76ae21d4-2671-466d-a3d2-5f0e05cecd72	4	4	4	4	2026-01-02 18:01:02.437438	https://eservices.himachaltourism.gov.in/
e6e2b03f-bfe5-4a08-bbad-5c51b24412b3	4	4	4	4	2026-01-02 18:05:02.212064	https://eservices.himachaltourism.gov.in/
360c9801-213f-414a-880d-11f68ea417a2	4	4	4	4	2026-01-02 18:13:00.904385	https://eservices.himachaltourism.gov.in/
e6c99585-5e50-4c78-b8ab-ec849b9468f7	4	4	4	4	2026-01-02 19:13:00.909765	https://eservices.himachaltourism.gov.in/
a5311189-3646-438b-ab10-28928d4406cb	4	4	4	4	2026-01-02 20:13:00.907111	https://eservices.himachaltourism.gov.in/
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.reviews (id, application_id, user_id, rating, review_text, is_verified_stay, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.session (sid, sess, expire) FROM stdin;
lHBfCm0SraBNkT8EDFLdZlwoX-W0p8vm	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:33:49.577Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:33:50
aPU42o9DiGAl5au-FUJ1EKt9IpejBUdM	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:33:49.602Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "876f6ff4-8e8b-42cb-8927-e8d74399a947", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:33:50
NXGu-469xqdGvNB3RMapU-Mv6tNnjxm2	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:33:49.618Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "18122a8d-04cb-4616-87f6-ca91e130b5b1", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:33:50
eeitImVQmjqkOpU2OTrNJEvG18UayYwF	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:34:07.657Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:34:08
NaLLNOf8tGLvMtNINfd5C2P3geefLszs	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:34:07.677Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "876f6ff4-8e8b-42cb-8927-e8d74399a947", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:34:08
qEkVsazuLvD7AEdyE8631D6svd1e6UVh	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:34:07.689Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "18122a8d-04cb-4616-87f6-ca91e130b5b1", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:34:08
erblTuG49toS26A2VVzBxyse6IoabtVe	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:34:27.528Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:34:28
Yl0D_al8_6GiqB2m0mF7jnt3hgLXZuKQ	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:34:43.808Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:34:44
z6xtW9HdjB2pCErcB4YWeSwCFYh3AEp6	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:35:00.877Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:35:01
9Gtqc4l-l4l-t1rwNTldHTL6M30MCIN5	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:35:00.898Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "876f6ff4-8e8b-42cb-8927-e8d74399a947", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:35:01
JQn5bIVriQWpDnHtCjkB6AZpmu16Gtoq	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:35:00.911Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "18122a8d-04cb-4616-87f6-ca91e130b5b1", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:35:01
kVDWR1DnFTbdzAhLgEt3q7KvQph_4MFA	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:35:13.514Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:35:14
bhCbvdSHnQSoOav0CgnRcdEasBmmg2El	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:35:13.533Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "876f6ff4-8e8b-42cb-8927-e8d74399a947", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:35:14
LC7VbIp7pHu3REB8SXlbRzt2YzlhNq2r	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:35:13.545Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "18122a8d-04cb-4616-87f6-ca91e130b5b1", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:35:14
Uh-DXKDzpN1UmUK-Q9LUJApp2yd0J-Rq	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:35:30.544Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "876f6ff4-8e8b-42cb-8927-e8d74399a947", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:35:31
vWj-4kNk0prX10oipcProeiKOTCf0MKF	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:35:30.559Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "18122a8d-04cb-4616-87f6-ca91e130b5b1", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:35:31
PZfTQeUv4fJB6TvMfyQGMpmtnxiCUM7W	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:35:30.517Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:35:31
YTRs8oyPPgwDHHiD0PunHuf0xQm2U3b_	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T18:06:35.076Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 18:06:40
EIegZ6-YthzGxMBu0lbPV5rtZBR9ojpH	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:42:40.686Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "876f6ff4-8e8b-42cb-8927-e8d74399a947", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:42:42
C2zkwzM-vtA_s6ioL6zNE-kvZd9BMPgx	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:42:40.700Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "18122a8d-04cb-4616-87f6-ca91e130b5b1", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:42:43
lJ2RwL1GGYaxewn8mLBDwQ3dn_tVGhSC	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:42:40.666Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:42:44
uol-sz6gA30x7yqgrsRq59M3YBy7rcx6	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T18:06:35.103Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "18122a8d-04cb-4616-87f6-ca91e130b5b1", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 18:06:41
DBo6ljP-_kzYuKe6ix8KK_re1qauJbLp	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:45:23.625Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "18122a8d-04cb-4616-87f6-ca91e130b5b1", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:45:26
dttdgaIY0HaYM3lx3nrxzAODft1QM2A5	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:45:56.259Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "876f6ff4-8e8b-42cb-8927-e8d74399a947", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:45:58
or7X0EBVR1-inYwoqGFoRcmIqdai9CY4	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:45:23.601Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:45:28
eXxgx8PykFgmPiIXWSyw_BvaFA7nDJDf	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:45:23.614Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "876f6ff4-8e8b-42cb-8927-e8d74399a947", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:45:28
QIN5-gHSwcjc2gkKdTyEWuEIheLAMOh0	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:45:23.513Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:45:29
EEuSQYgEe1wcb5_98zPpvNKP3tI2I00i	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:46:30.847Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "876f6ff4-8e8b-42cb-8927-e8d74399a947", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:46:35
UjpQucOyLIhqathRRQRrCuuF9pRO3Vj3	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:45:56.270Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "18122a8d-04cb-4616-87f6-ca91e130b5b1", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:45:58
2jDItXq-ymNfD3r5BhhBHtQwxnpzE0rY	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:45:56.247Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:45:59
Vx_T1eHSLC_1MnJCBQqffygbQOtXV6sU	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:45:56.160Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:46:00
iNYG_u4U4zp6wW3vAC6coHUVP5Uhaubr	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:46:30.859Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "18122a8d-04cb-4616-87f6-ca91e130b5b1", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:46:33
ZJ2vnHFbM7zoSSgIGOEbY_AjIaQaHTot	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:46:30.835Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:46:35
_d43zNLbJvtWTO4re2FnmgzEkWYWX-7K	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:46:30.744Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:46:36
nDY9zDAhAelz3SMOm-rSw17COwbfhOAq	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:49:09.510Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:49:14
EQSohVQoVni9MheqiWlQifNbaX6wBV1c	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:49:09.539Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "18122a8d-04cb-4616-87f6-ca91e130b5b1", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:49:12
7gRg6c7napGiexWZIcYSND-1nRtCSYX5	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:49:09.525Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "876f6ff4-8e8b-42cb-8927-e8d74399a947", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:49:14
rZ5L3aBE8PDMX4bVd0b0wWrG8Il9sTeV	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:49:09.406Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:49:15
fXz77GvBcjMOvZUsWMikeXNoMnrASFox	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:49:48.643Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:49:53
m9-29XJ3q3kB3JTj2zjCsi2DESSW_UH7	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:49:48.655Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "876f6ff4-8e8b-42cb-8927-e8d74399a947", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:49:53
CqvOKC070tMASRduN7tZled5v_ERJyhN	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:49:48.666Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "18122a8d-04cb-4616-87f6-ca91e130b5b1", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:49:53
9iopj4qJJZ0EXXeGYdkUKR4ijNGpXRMV	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T17:49:48.549Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 17:49:55
tuHRlk98NdDsZ8wry9thtYH3FSERd6HB	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T18:06:34.977Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 18:06:42
7vy3nztSnSIPel5pDvfrmN-VwkxULZb1	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T18:07:34.487Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "f8b11841-95be-465d-814e-2dd2f5936b4a", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 18:07:41
3u8GS854B8KdFaPVQIUN7MK-GMH8q8zc	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T18:06:35.090Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "876f6ff4-8e8b-42cb-8927-e8d74399a947", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 18:06:40
T0X0YnPpGRI-_DDI_n5H5dzY4pWyoflu	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T18:07:34.580Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 18:07:39
x7iYW_nYaYvUsGHRrHB9Spp5w3IMHSi_	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T18:07:34.592Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "876f6ff4-8e8b-42cb-8927-e8d74399a947", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 18:07:40
DE5SfnIlyGiFpc4JuFQZOX-gOT_FOtVd	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T18:07:34.607Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "18122a8d-04cb-4616-87f6-ca91e130b5b1", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 18:07:40
4BpVOH1XuFLFzLFCufgHRnhP3uxcVFm-	{"cookie": {"path": "/", "domain": "dev.osipl.dev", "secure": true, "expires": "2026-01-09T20:08:07.663Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 604800000}, "userId": "81df93f9-9adb-49e5-b635-a49190c26f8c", "captchaAnswer": null, "captchaIssuedAt": null}	2026-01-09 20:09:00
\.


--
-- Data for Name: storage_objects; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.storage_objects (id, object_key, storage_provider, file_type, category, mime_type, size_bytes, checksum_sha256, uploaded_by, application_id, document_id, created_at, last_accessed_at) FROM stdin;
72f82ed7-21df-40d2-834c-d3f8a8b8d0c8	revenue-paperss/f64d0313-b617-4aa3-b523-f41f10e23943	local	revenue-papers	revenue_papers	application/pdf	61398	\N	\N	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	5e436c5c-b123-4666-89aa-b6b3d3dbfef5	2026-01-02 17:46:15.752929	\N
e1047ad9-efc3-4ccb-bb3d-98ce217b0b86	affidavit-section29s/720701ca-c954-4cd6-b94e-d027153a2e53	local	affidavit-section29	affidavit_section_29	application/pdf	61398	\N	\N	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	d9541df0-5db2-4488-b47c-5302099c25e9	2026-01-02 17:46:21.189962	\N
24d8b6bd-2b26-47ff-a49b-51c9e3129a4c	undertaking-form-cs/d669ab4b-3632-40d0-9037-aebee5230d65	local	undertaking-form-c	undertaking_form_c	application/pdf	61398	\N	\N	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	46f565bc-7f43-4b3c-9ea1-d7e0b3ed58f8	2026-01-02 17:46:25.74762	\N
935e4901-9bd5-4c35-9552-31b6a70c2ccd	property-photos/4850da77-5f65-48a0-b993-a93ef23623b1	local	property-photo	property_photo	image/jpeg	373585	\N	\N	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	718eaa54-f6b1-4b62-952b-4e3ceed79919	2026-01-02 17:50:46.860875	\N
6b8c61b6-f5ee-4f84-bb93-53cda61b3092	property-photos/6528ea51-3053-4c66-935c-1d5d350b9711	local	property-photo	property_photo	image/jpeg	480003	\N	\N	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	4588e9b2-41c5-482b-b0a8-d7460657fdad	2026-01-02 17:50:46.994693	\N
1e12220a-e8ef-40db-a19c-a4a135d4ed4e	property-photos/ae6faaa0-999b-4eff-bb03-72956ad05c02	local	property-photo	property_photo	image/jpeg	514031	\N	\N	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	8ab8abe1-7921-4b59-b2c4-45852174fd1a	2026-01-02 17:50:47.11461	\N
e573bdb9-8d97-4fcb-b04c-01e402d15e44	additional-documents/a1d441b6-6a15-42d6-82fb-c6324c764e8d	local	additional-document	additional_document	image/jpeg	383438	\N	\N	4a04e2d9-add0-478d-b57b-e0c5ad1eca73	bb0dde1a-784e-4f60-95fb-708d1f50e628	2026-01-02 17:50:57.097989	\N
3f240d30-024a-4a24-9883-11cecfe39ff5	revenue-paperss/b206e23b-a914-4621-89e3-e265af54cd43	local	revenue-papers	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	4238b15b-ee75-4037-a4e2-7770e7d93748	\N	\N	2026-01-02 17:58:01.281834	\N
1a7d3a4a-9aeb-4b30-a3e5-5cfac286a7de	affidavit-section29s/3b07cfde-e0fc-40b3-a26c-3bdd75818469	local	affidavit-section29	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	4238b15b-ee75-4037-a4e2-7770e7d93748	\N	\N	2026-01-02 17:58:05.096599	\N
66abb49f-ebbf-4ee6-8c53-377c847e3a1a	undertaking-form-cs/b66613bc-2944-440f-9c95-c12ab4395c3e	local	undertaking-form-c	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	4238b15b-ee75-4037-a4e2-7770e7d93748	\N	\N	2026-01-02 17:58:09.093824	\N
a5498c23-698d-489f-951f-893816b33de2	commercial-electricity-bills/9a78bc46-ab0d-433a-ba0a-0be6db2c3eb8	local	commercial-electricity-bill	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	4238b15b-ee75-4037-a4e2-7770e7d93748	\N	\N	2026-01-02 17:58:12.417276	\N
300472b9-90c5-44ec-98df-022782cdf209	commercial-water-bills/ebfa8523-2354-4e88-97cc-f778b43198cd	local	commercial-water-bill	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	4238b15b-ee75-4037-a4e2-7770e7d93748	\N	\N	2026-01-02 17:58:16.247814	\N
43dee77a-424f-490e-ab87-1bb045ed852e	property-photos/72608d9b-4e5b-433c-aae6-25a1bfa33407	local	property-photo	photos	image/jpeg	514031	7d7c2fbc96020b22a8b247fe85d3ff797d8fd09a37ab2fdd583c11041cb8abbc	4238b15b-ee75-4037-a4e2-7770e7d93748	\N	\N	2026-01-02 17:58:33.201951	\N
0edba65f-601a-4577-bcf3-c91e1ade8aea	property-photos/a4e7e76b-32d9-4545-8e25-374ff5818000	local	property-photo	photos	image/jpeg	400821	fb3bc162564e911b098af3077c3ed51c2d883db20c44c6958001c32abc52d058	4238b15b-ee75-4037-a4e2-7770e7d93748	\N	\N	2026-01-02 17:58:33.30356	\N
8535bfb8-67b0-4938-b3ac-b7a3245c0014	property-photos/5519b826-a9e2-4984-acfd-d7266090ac52	local	property-photo	photos	image/jpeg	362197	bfe6d2753c1a73c49ce2161447281527b74ffe66050c75add289dcce9dde26db	4238b15b-ee75-4037-a4e2-7770e7d93748	\N	\N	2026-01-02 17:58:33.42109	\N
46fd46eb-c839-4c11-a652-3836ac715ee9	property-photos/1d178878-0abe-4d8f-adae-1b2d3233d954	local	property-photo	photos	image/jpeg	411316	faa69cf804339b201231a491f5bcafbb214e9f513e9ebdf3f9e618712e8c82a9	4238b15b-ee75-4037-a4e2-7770e7d93748	\N	\N	2026-01-02 17:58:33.547936	\N
c0d4dd9c-3c02-4a6f-a776-a45883979b00	documents/3d93b538-3a2e-48d5-a091-f3fc5e6a238f	local	document	photos	image/jpeg	383438	54c92d7810217a297df325acb3cc1b5cbb2c7b57d51a434325290bae07ed30fd	5650293a-5f4f-4e77-b381-f60d0c4dc62f	\N	\N	2026-01-02 18:29:13.960788	\N
681066a5-ecac-4511-b776-4a36eb8cff85	documents/47ccb771-f766-481c-961a-7de12e474617	local	document	photos	image/jpeg	480003	2aa4c9e403075d32f5bc8527bc72cf0e1ecf5005262181af4a6223a1e9d67c37	5650293a-5f4f-4e77-b381-f60d0c4dc62f	\N	\N	2026-01-02 18:29:20.341973	\N
4b63fc75-b0aa-4b2c-96e9-d20ce423ead3	documents/89cc27fe-91db-476a-b35a-2a2330264cbf	local	document	owner_identity_proof	application/pdf	61398	\N	\N	de6c21e2-a836-4052-ae76-8c720e624e28	66f1ee6e-3345-4c22-9b1d-efe3cee1354d	2026-01-02 18:28:27.192536	\N
5a8b5175-9f30-4174-b3cd-1f51216540db	documents/444b6364-e9a3-4109-9d9d-8069ba98c125	local	document	legacy_certificate	application/pdf	61398	\N	\N	de6c21e2-a836-4052-ae76-8c720e624e28	6778663a-b2d9-4266-9eaf-05b91c337599	2026-01-02 18:28:31.776686	\N
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.support_tickets (id, ticket_number, applicant_id, application_id, service_type, category, subject, description, status, priority, assigned_to, assigned_at, escalated_from, escalated_at, escalation_level, sla_deadline, sla_breach, resolved_at, resolved_by, resolution_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.system_settings (id, setting_key, setting_value, description, category, updated_by, created_at, updated_at) FROM stdin;
6baecb91-b1af-4dbf-940f-7eb5cfc49f23	admin_super_console_enabled	{"enabled": true}	Enable/disable super console	admin	super-admin-001	2026-01-02 16:27:55.175802	2026-01-02 16:28:02.879
78f644d2-9106-42ca-9818-f47574189ae4	upload_policy	{"photos": {"maxFileSizeMB": 25, "allowedMimeTypes": ["image/jpeg", "image/png", "image/jpg", "application/pdf"], "allowedExtensions": [".jpg", ".jpeg", ".png", ".pdf"]}, "documents": {"maxFileSizeMB": 5, "allowedMimeTypes": ["application/pdf", "image/jpeg", "image/png", "image/jpg"], "allowedExtensions": [".pdf", ".jpg", ".jpeg", ".png"]}, "totalPerApplicationMB": 25}	\N	general	super-admin-001	2026-01-02 17:50:13.290179	2026-01-02 17:50:13.290179
5ddbde43-60c5-4bfd-8476-44c766019381	payment_workflow	{"workflow": "upfront", "upfrontSubmitMode": "auto"}	Payment workflow: 'upfront' = pay before submission, 'on_approval' = pay after approval	payment	super-admin-001	2026-01-02 17:53:41.452534	2026-01-02 17:53:41.452534
\.


--
-- Data for Name: ticket_actions; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.ticket_actions (id, ticket_id, actor_id, actor_role, action, previous_status, new_status, previous_priority, new_priority, previous_assignee, new_assignee, notes, metadata, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: ticket_messages; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.ticket_messages (id, ticket_id, sender_id, sender_role, message, attachments, is_internal, is_read, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.user_profiles (id, user_id, full_name, gender, aadhaar_number, mobile, email, district, tehsil, block, gram_panchayat, urban_body, ward, address, pincode, telephone, fax, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hptourism_user
--

COPY public.users (id, mobile, full_name, first_name, last_name, username, email, alternate_phone, designation, department, employee_id, office_address, office_phone, role, aadhaar_number, district, password, is_active, created_at, updated_at, sso_id, enabled_services) FROM stdin;
super-admin-001	9999999998	Super Admin	Super	Admin	superadmin	superadmin@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	super_admin	\N	Shimla	$2a$06$S7mxp03EketNPtR1BBdvGuwRvD9nWipdQ/PbMwQ.cl.hcKp8HPn7O	t	2026-01-02 09:42:21.026827	2026-01-02 09:42:21.026827	\N	["homestay"]
admin-001	9999999999	System Admin	System	Admin	admin	admin@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	admin	\N	Shimla	$2a$06$.f4u2sghE4IXU/dzFEzLPunbLsL28l85O6opHGo3YU2Lmmb.XDn8a	t	2026-01-02 09:42:21.035195	2026-01-02 09:42:21.035195	\N	["homestay"]
f6cb4b30-6ee5-4e8a-a9bb-4d64fdb9429e	9999999997	Admin RC Console	Admin	RC	adminrc	admin.rc@hp.gov.in	\N	\N	\N	\N	\N	\N	admin_rc	\N	Shimla	$2a$06$0QYufUVwpp5N5OMNbSRAOOKpL/dqgiTbMeAW8cc/FrtC5lwv0IuE6	t	2026-01-02 09:42:21.041465	2026-01-02 09:42:21.041465	\N	["homestay"]
9eaffff0-3c8d-4ce2-83b7-b45121d38c45	7800001004	DA Hamirpur	DA	Hamirpur	da_hamirpur	da.hamirpur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Hamirpur (serving Una)	$2a$06$P9GH4j3NN4MeRnC8KKLrqOvynSyM.Ugm1oF/xfIUG9Tiob5nmYOqa	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
e24d0090-3e83-48c8-bd99-d863e7c1af20	7800001001	DA Chamba	DA	Chamba	da_chamba	da.chamba@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Chamba HQ	$2a$06$VTji/sOXykmoIaihztgOxeEJ.C9F5Rq3JMMDbl88k2ugS3x1iouYm	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
0a4a9b95-7d3d-4bd1-9c9d-ca479bb2daa9	7900001001	DTDO Chamba	DTDO	Chamba	dtdo_chamba	dtdo.chamba@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Chamba HQ	$2a$06$ZPTeZyZQXiXpasJ0DbFmZuvHcXq3EBpq1ijViyegSdUZGG.5RGxTm	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
1e65a65b-ca18-45ea-925e-7577bd7b0cd8	7800001002	DA Bharmour	DA	Bharmour	da_bharmour	da.bharmour@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Bharmour Sub-Division	$2a$06$RmVRJRTQcQi0gD5bPwSnZewZC9L4uqw5ZVCDZXX8O3JdBhEtgFgCS	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
232b7c09-4c62-458a-b8d2-6164c7afcd63	7900001002	DTDO Bharmour	DTDO	Bharmour	dtdo_bharmour	dtdo.bharmour@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Bharmour Sub-Division	$2a$06$bqN65raMjajQzftm5QbJ5OZGR.dMk5HrsO8SkeuM4YcXvuIi5oqLG	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
aa6fd747-8e36-48d4-bc27-74a4ee53fe6c	7900001003	DTDO Shimla Hq	DTDO	Shimla Hq	dtdo_shimla_hq	dtdo.shimla-hq@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Shimla HQ (AC Tourism)	$2a$06$8umQQi9wcQKf7gquMbSRZOnkQKnW1QCXTsz8Vbd.sQt1SDYH.xfg6	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
3952942f-f717-4b22-9bc4-d5e27c6db818	7900001004	DTDO Hamirpur	DTDO	Hamirpur	dtdo_hamirpur	dtdo.hamirpur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Hamirpur (serving Una)	$2a$06$2eirr6ezhKJ3fUz5c7RV9.l6G6I.2sMCMWbtfGZGi38A9UVA9BqiW	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
cea141d1-5e8d-4d71-9043-3683940e7b05	7800001005	DA Kullu Manali	DA	Kullu Manali	da_kullu_manali	da.kullu-manali@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Kullu (Bhuntar/Manali)	$2a$06$6fbm/earBOOIULfkxOY6SOZ2YvdEzBjuiQpEe/Z54CrVc/fHE9/P6	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
e5c91f84-4bd0-427d-82e2-37e3a22df4bd	7800001006	DA Kullu Dhalpur	DA	Kullu Dhalpur	da_kullu_dhalpur	da.kullu-dhalpur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Kullu Dhalpur	$2a$06$TN7MPT2uxkQMr23yaZsMOet0acKY88s7Ja/KMIdPBOhDt90lGUGWG	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
3a1487c1-fa79-456d-a038-4943579ee6f9	7900001006	DTDO Kullu Dhalpur	DTDO	Kullu Dhalpur	dtdo_kullu_dhalpur	dtdo.kullu-dhalpur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Kullu Dhalpur	$2a$06$sto0cPSmLo4AcINcage.O.MZn4sGMAQbdoY9RrG35EfeLab4T681u	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
83b8f7c5-67ef-4dad-835f-6baf939d46f7	7800001007	DA Dharamsala	DA	Dharamsala	da_dharamsala	da.dharamsala@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Dharamsala (Kangra)	$2a$06$ZyuCshGSVUXdDrsQlLWE9.Do9qWj4/o/JFXhoV0/nbfkMq6ZwX/Hy	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
3238f961-8f9a-4965-a429-9a4faedfa7fc	7900001007	DTDO Dharamsala	DTDO	Dharamsala	dtdo_dharamsala	dtdo.dharamsala@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Dharamsala (Kangra)	$2a$06$OL1LQkyZpho8cipFS2Zc0ed2rJKfOyn.fDAOValGd53w4ncrWKUKq	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
82a9811b-1801-4f1e-b0e9-38ceec06cefb	7800001008	DA Kinnaur	DA	Kinnaur	da_kinnaur	da.kinnaur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Kinnaur (Reckong Peo)	$2a$06$.gzgb6k/69EJz6rXhua8kuytrOe8ohqhYMF8dylHjMqcLmgJIRQFC	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
2b9f5017-9c17-4a4c-8277-21824cef2807	7900001008	DTDO Kinnaur	DTDO	Kinnaur	dtdo_kinnaur	dtdo.kinnaur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Kinnaur (Reckong Peo)	$2a$06$E0qZ14KG4DqoZ9rPCeQaEOowCDGvcuo1gU4SVPxkYpKCINyZJ1Z6e	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
a11d16af-df2c-4d9e-b2df-b8b22fbf97fc	7800001009	DA Kaza	DA	Kaza	da_kaza	da.kaza@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Kaza (Spiti ITDP)	$2a$06$LoiNzL5uoGo2eJyVTnUcVu.lPZ0dtUYCzOv/hm8InF9t.UNY0G4gy	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
36570f96-a7ba-4000-90c3-1015283ade5d	7900001009	DTDO Kaza	DTDO	Kaza	dtdo_kaza	dtdo.kaza@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Kaza (Spiti ITDP)	$2a$06$Xt..lBZyVaOdVeaH4DynauEhNonb8qu9/TMqGAatfaorMPo3Z9vsm	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
84de0c4a-9349-4f33-8b14-ad6bb4e8e4f2	7800001010	DA Lahaul	DA	Lahaul	da_lahaul	da.lahaul@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Lahaul (Keylong)	$2a$06$1YengHAWHIBpEfej2zAVgufaHIgGwEQnRYmYzVYJMEWvcWnZyyXey	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
3155aff1-2f1d-476c-8095-b8e9ce541549	7900001010	DTDO Lahaul	DTDO	Lahaul	dtdo_lahaul	dtdo.lahaul@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Lahaul (Keylong)	$2a$06$3OPusg.brcYP8Y2OPuWzf.kz4uO.p3Lny4.qDSZ16.ylap7EPHwqa	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
bc1485b6-e522-4488-87f9-3cb18cc84e7c	7800001011	DA Mandi	DA	Mandi	da_mandi	da.mandi@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Mandi Division	$2a$06$GZer5E6So3zcphlHvbzUP.xaBWp5jnI9ZrghvjGg3KP.WZHdScvae	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
87010e8d-b6c2-44d7-ac9a-591040976b61	7800001012	DA Pangi	DA	Pangi	da_pangi	da.pangi@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Pangi (ITDP)	$2a$06$0qyZ.zKq6zzgJs6eHxQ7bOvgsaSqf6pq.wJP1WRMBMfwspPUZGw..	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
de6c5054-5b19-40ad-8cf6-b830b6128f31	7900001012	DTDO Pangi	DTDO	Pangi	dtdo_pangi	dtdo.pangi@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Pangi (ITDP)	$2a$06$luJS26EhGkSn/mrZRbn0K.NRMBbzZguG1rtkLX6kRhb09IFDNMxT2	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
876f6ff4-8e8b-42cb-8927-e8d74399a947	7800001013	DA Shimla	DA	Shimla	da_shimla	da.shimla@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Shimla Division	$2a$06$YAzDlWOn4gIpC.3b7oyjDuu5CGa3ePDtQMSoc64vFSOxfR/za18Lm	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
18122a8d-04cb-4616-87f6-ca91e130b5b1	7900001013	DTDO Shimla	DTDO	Shimla	dtdo_shimla	dtdo.shimla@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Shimla Division	$2a$06$qrFb3A6/3Tl0tUBftYd4EuWbu7JQbf8cKy2woAywJ9r06KNUmJ9Nm	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
219cd5e8-7198-41e0-855a-1300ceb67afc	7800001003	DA Shimla Hq	DA	Shimla Hq	da_shimla_hq	da.shimla-hq@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Shimla HQ (AC Tourism)	$2a$06$Kdcciy9jw8FcPJsV1osdC.f9haYFrYBS3wQriWt2ZKVpUGRN9qM4e	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
e589f645-db21-4bb7-92a3-a115f014353e	7900001005	DTDO Kullu Manali	DTDO	Kullu Manali	dtdo_kullu_manali	dtdo.kullu-manali@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Kullu (Bhuntar/Manali)	$2a$06$.sAtXNWaAKU2dZJ0a7uKFOhG69GCgd5AM7RCdNJr3mEfkaWkQQKGq	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
c11c4ddc-ca3e-4675-a234-1eb74c566be4	7900001011	DTDO Mandi	DTDO	Mandi	dtdo_mandi	dtdo.mandi@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Mandi Division	$2a$06$83q68Va2K/cnPCw.374jiuuXUOFY.3WAnTZ.RAZ/wUigxe8tjVbJO	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
cac03a4a-004b-41fc-b4d0-58ddb3116147	7800001014	DA Sirmaur	DA	Sirmaur	da_sirmaur	da.sirmaur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Sirmaur (Nahan)	$2a$06$coMO.MbkPT6Ujj611Gr8PeL69f9RjyytXMctg4w7VHn3ptyeF4peS	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
3e9ea3f8-a125-42ec-a04c-c561569f6490	7900001014	DTDO Sirmaur	DTDO	Sirmaur	dtdo_sirmaur	dtdo.sirmaur@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Sirmaur (Nahan)	$2a$06$573cF2SpHXQL.SWJa45PeOLtsGyk9UTlkbT/oRXVsFLIX4lskeHnC	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
8a8343ea-91df-4be5-8c09-c1b56bb00d77	7800001015	DA Solan	DA	Solan	da_solan	da.solan@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	dealing_assistant	\N	Solan Division	$2a$06$NZ.GEGTdYWqIST6ps6PjL.UsEMAlDTrRyYQVCFGXNpnZa2RSPx/3S	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
2e330128-1d31-4e63-b67d-9db26b7f7844	7900001015	DTDO Solan	DTDO	Solan	dtdo_solan	dtdo.solan@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	district_tourism_officer	\N	Solan Division	$2a$06$XUprb.iyJ5m9fd6thUbYyuK5nhCZFSMOWTlF0NNJwbsDJ5IN/5/7u	t	2026-01-02 09:42:21.117699	2026-01-02 09:42:21.117699	\N	["homestay"]
264d453c-cbf8-403b-b36a-ccc671f1c705	6666666621	Test  AAA	Test 	AAA	\N	test@example.com	\N	\N	\N	\N	\N	\N	property_owner	666666666621	\N	$2b$10$qPnJuWgxdq3CPbkVCbzx5OZ8Dyh8zJ2oHrNKSpgiBzx8n2BAjDKqa	t	2026-01-02 17:30:55.971205	2026-01-02 17:30:55.971205	\N	["homestay"]
f8b11841-95be-465d-814e-2dd2f5936b4a	6666666610	Smoke Test Owner	Smoke	Owner	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	$2b$10$6wXu67fNe794qYvaNPf7wOD5LW7KwgzylfnCVCzGVhr1RBWf/1ycS	t	2026-01-02 17:33:48.139	2026-01-02 17:33:48.139	\N	["homestay"]
5ce3d0bc-0914-45a9-9b34-cd7e5d65ecf0	6666666611	Smoke Test Owner 2	Smoke	Owner 11	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	\N	\N	$2b$10$rT9dc.9EC4S5AVF6uBM8t.PplmdGh5Xe2fceq.44u/1YeR4go0z6G	t	2026-01-02 17:43:44.702101	2026-01-02 17:43:44.702101	\N	["homestay"]
4238b15b-ee75-4037-a4e2-7770e7d93748	6666666622	Test  BBB	Test 	BBB	\N	test@example.com	\N	\N	\N	\N	\N	\N	property_owner	666666666622	\N	$2b$10$ElAwfjP7RaKQ2lhsgb2CP.0A.EoW//JROQatWiPjoXwZIL7Ik1iuy	t	2026-01-02 17:54:35.368766	2026-01-02 17:54:35.368766	\N	["homestay"]
5650293a-5f4f-4e77-b381-f60d0c4dc62f	6666666623	Test Test	Test	Test	\N	test@example.com	\N	\N	\N	\N	\N	\N	property_owner	666666666623	\N	$2b$10$WTAPy8f0ByPUp37E.YeapupVOOb6Y4.6jF8PjmWcyNqESnccAvFzS	t	2026-01-02 18:09:09.997157	2026-01-02 18:09:09.997157	\N	["homestay"]
158757ba-e95d-408d-b44b-09203e114fa2	6666666624	Test  CCC	Test 	CCC	\N	test@example.com	\N	\N	\N	\N	\N	\N	property_owner	666666666624	\N	$2b$10$tRoscTEsiuwtstzIf35IXemrVk7ZhyJapTrxPVWenM0tC7itaNK42	t	2026-01-02 18:37:53.086606	2026-01-02 18:37:53.086606	\N	["homestay"]
81df93f9-9adb-49e5-b635-a49190c26f8c	6666666625	Test  GGG	Test 	GGG	\N	test@example.com	\N	\N	\N	\N	\N	\N	property_owner	666666666625	\N	$2b$10$xXThFgTFrOLCkh7JUvEl7eTFDQZbpZ9MBJd9/OYX9/Ez.MMhrO5Zq	t	2026-01-02 19:46:07.721096	2026-01-02 19:46:07.721096	\N	["homestay"]
\.


--
-- Name: application_actions application_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: certificates certificates_application_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_application_id_unique UNIQUE (application_id);


--
-- Name: certificates certificates_certificate_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_certificate_number_unique UNIQUE (certificate_number);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: clarifications clarifications_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_pkey PRIMARY KEY (id);


--
-- Name: ddo_codes ddo_codes_district_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ddo_codes
    ADD CONSTRAINT ddo_codes_district_unique UNIQUE (district);


--
-- Name: ddo_codes ddo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ddo_codes
    ADD CONSTRAINT ddo_codes_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: grievance_audit_log grievance_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_audit_log
    ADD CONSTRAINT grievance_audit_log_pkey PRIMARY KEY (id);


--
-- Name: grievance_comments grievance_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_comments
    ADD CONSTRAINT grievance_comments_pkey PRIMARY KEY (id);


--
-- Name: grievances grievances_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_pkey PRIMARY KEY (id);


--
-- Name: grievances grievances_ticket_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_ticket_number_unique UNIQUE (ticket_number);


--
-- Name: himkosh_transactions himkosh_transactions_app_ref_no_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_app_ref_no_unique UNIQUE (app_ref_no);


--
-- Name: himkosh_transactions himkosh_transactions_ech_txn_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_ech_txn_id_unique UNIQUE (ech_txn_id);


--
-- Name: himkosh_transactions himkosh_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_pkey PRIMARY KEY (id);


--
-- Name: homestay_applications homestay_applications_application_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_application_number_unique UNIQUE (application_number);


--
-- Name: homestay_applications homestay_applications_certificate_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_certificate_number_unique UNIQUE (certificate_number);


--
-- Name: homestay_applications homestay_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_pkey PRIMARY KEY (id);


--
-- Name: inspection_orders inspection_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_pkey PRIMARY KEY (id);


--
-- Name: inspection_reports inspection_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_pkey PRIMARY KEY (id);


--
-- Name: lgd_blocks lgd_blocks_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_blocks lgd_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_pkey PRIMARY KEY (id);


--
-- Name: lgd_districts lgd_districts_district_name_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_district_name_unique UNIQUE (district_name);


--
-- Name: lgd_districts lgd_districts_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_districts lgd_districts_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_pkey PRIMARY KEY (id);


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_pkey PRIMARY KEY (id);


--
-- Name: lgd_tehsils lgd_tehsils_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_tehsils lgd_tehsils_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_pkey PRIMARY KEY (id);


--
-- Name: lgd_urban_bodies lgd_urban_bodies_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_urban_bodies lgd_urban_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_pkey PRIMARY KEY (id);


--
-- Name: login_otp_challenges login_otp_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.login_otp_challenges
    ADD CONSTRAINT login_otp_challenges_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: objections objections_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_pkey PRIMARY KEY (id);


--
-- Name: password_reset_challenges password_reset_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.password_reset_challenges
    ADD CONSTRAINT password_reset_challenges_pkey PRIMARY KEY (id);


--
-- Name: payments payments_gateway_transaction_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_gateway_transaction_id_unique UNIQUE (gateway_transaction_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: payments payments_receipt_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_receipt_number_unique UNIQUE (receipt_number);


--
-- Name: production_stats production_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.production_stats
    ADD CONSTRAINT production_stats_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: storage_objects storage_objects_object_key_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_object_key_unique UNIQUE (object_key);


--
-- Name: storage_objects storage_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_ticket_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_ticket_number_unique UNIQUE (ticket_number);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_setting_key_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_setting_key_unique UNIQUE (setting_key);


--
-- Name: ticket_actions ticket_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_pkey PRIMARY KEY (id);


--
-- Name: ticket_messages ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_unique UNIQUE (user_id);


--
-- Name: users users_aadhaar_number_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_aadhaar_number_unique UNIQUE (aadhaar_number);


--
-- Name: users users_mobile_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_mobile_unique UNIQUE (mobile);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_sso_id_unique; Type: CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_sso_id_unique UNIQUE (sso_id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: users_district_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX users_district_idx ON public.users USING btree (district);


--
-- Name: users_mobile_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX users_mobile_idx ON public.users USING btree (mobile);


--
-- Name: users_role_idx; Type: INDEX; Schema: public; Owner: hptourism_user
--

CREATE INDEX users_role_idx ON public.users USING btree (role);


--
-- Name: application_actions application_actions_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: application_actions application_actions_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_officer_id_users_id_fk FOREIGN KEY (officer_id) REFERENCES public.users(id);


--
-- Name: audit_logs audit_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: certificates certificates_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_issued_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_issued_by_users_id_fk FOREIGN KEY (issued_by) REFERENCES public.users(id);


--
-- Name: certificates certificates_renewal_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_renewal_application_id_homestay_applications_id_fk FOREIGN KEY (renewal_application_id) REFERENCES public.homestay_applications(id);


--
-- Name: certificates certificates_revoked_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_revoked_by_users_id_fk FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: clarifications clarifications_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: clarifications clarifications_objection_id_objections_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_objection_id_objections_id_fk FOREIGN KEY (objection_id) REFERENCES public.objections(id) ON DELETE CASCADE;


--
-- Name: clarifications clarifications_reviewed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_reviewed_by_users_id_fk FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: clarifications clarifications_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: documents documents_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: documents documents_verified_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_verified_by_users_id_fk FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: grievance_audit_log grievance_audit_log_grievance_id_grievances_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_audit_log
    ADD CONSTRAINT grievance_audit_log_grievance_id_grievances_id_fk FOREIGN KEY (grievance_id) REFERENCES public.grievances(id) ON DELETE CASCADE;


--
-- Name: grievance_audit_log grievance_audit_log_performed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_audit_log
    ADD CONSTRAINT grievance_audit_log_performed_by_users_id_fk FOREIGN KEY (performed_by) REFERENCES public.users(id);


--
-- Name: grievance_comments grievance_comments_grievance_id_grievances_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_comments
    ADD CONSTRAINT grievance_comments_grievance_id_grievances_id_fk FOREIGN KEY (grievance_id) REFERENCES public.grievances(id) ON DELETE CASCADE;


--
-- Name: grievance_comments grievance_comments_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievance_comments
    ADD CONSTRAINT grievance_comments_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: grievances grievances_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: grievances grievances_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: grievances grievances_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: himkosh_transactions himkosh_transactions_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: homestay_applications homestay_applications_da_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_da_id_users_id_fk FOREIGN KEY (da_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_district_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_district_officer_id_users_id_fk FOREIGN KEY (district_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_dtdo_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_dtdo_id_users_id_fk FOREIGN KEY (dtdo_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_site_inspection_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_site_inspection_officer_id_users_id_fk FOREIGN KEY (site_inspection_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_state_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_state_officer_id_users_id_fk FOREIGN KEY (state_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: inspection_orders inspection_orders_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: inspection_orders inspection_orders_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: inspection_orders inspection_orders_scheduled_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_scheduled_by_users_id_fk FOREIGN KEY (scheduled_by) REFERENCES public.users(id);


--
-- Name: inspection_reports inspection_reports_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: inspection_reports inspection_reports_inspection_order_id_inspection_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_inspection_order_id_inspection_orders_id_fk FOREIGN KEY (inspection_order_id) REFERENCES public.inspection_orders(id) ON DELETE CASCADE;


--
-- Name: inspection_reports inspection_reports_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: lgd_blocks lgd_blocks_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_blocks lgd_blocks_tehsil_id_lgd_tehsils_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_tehsil_id_lgd_tehsils_id_fk FOREIGN KEY (tehsil_id) REFERENCES public.lgd_tehsils(id) ON DELETE SET NULL;


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_block_id_lgd_blocks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_block_id_lgd_blocks_id_fk FOREIGN KEY (block_id) REFERENCES public.lgd_blocks(id) ON DELETE CASCADE;


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_tehsils lgd_tehsils_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_urban_bodies lgd_urban_bodies_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: login_otp_challenges login_otp_challenges_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.login_otp_challenges
    ADD CONSTRAINT login_otp_challenges_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: notifications notifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: objections objections_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: objections objections_inspection_report_id_inspection_reports_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_inspection_report_id_inspection_reports_id_fk FOREIGN KEY (inspection_report_id) REFERENCES public.inspection_reports(id);


--
-- Name: objections objections_raised_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_raised_by_users_id_fk FOREIGN KEY (raised_by) REFERENCES public.users(id);


--
-- Name: objections objections_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: password_reset_challenges password_reset_challenges_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.password_reset_challenges
    ADD CONSTRAINT password_reset_challenges_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payments payments_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: reviews reviews_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: reviews reviews_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: storage_objects storage_objects_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE SET NULL;


--
-- Name: storage_objects storage_objects_document_id_documents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_document_id_documents_id_fk FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: storage_objects storage_objects_uploaded_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_uploaded_by_users_id_fk FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_applicant_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_applicant_id_users_id_fk FOREIGN KEY (applicant_id) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: support_tickets support_tickets_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_escalated_from_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_escalated_from_users_id_fk FOREIGN KEY (escalated_from) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: system_settings system_settings_updated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_actor_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_actor_id_users_id_fk FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_new_assignee_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_new_assignee_users_id_fk FOREIGN KEY (new_assignee) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_previous_assignee_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_previous_assignee_users_id_fk FOREIGN KEY (previous_assignee) REFERENCES public.users(id);


--
-- Name: ticket_actions ticket_actions_ticket_id_support_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_actions
    ADD CONSTRAINT ticket_actions_ticket_id_support_tickets_id_fk FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_messages ticket_messages_sender_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_sender_id_users_id_fk FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: ticket_messages ticket_messages_ticket_id_support_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_ticket_id_support_tickets_id_fk FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: user_profiles user_profiles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hptourism_user
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: hptourism_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict B1pmODCOpFIyzgKWdhxUc2dgTwRU3SlWF73wIgwrZ4e4LdxjXm8erl2LOuTVXMO

